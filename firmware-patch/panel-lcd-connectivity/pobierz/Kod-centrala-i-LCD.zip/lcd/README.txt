LCD: KOD ZRODLOWY, NIE PLIK BIN

Pliki src/ sa przygotowane z projektu LCD Centrali.zip. Skopiuj je do
src/ swojego ISTNIEJACEGO projektu panelu LCD z tego archiwum, po wykonaniu
kopii zapasowej. Nie usuwaj pozostalych plikow projektu. Dotyczy wersji
v1.1.0 z LCD Centrali.zip; nie nadpisuj nowszego/zmodyfikowanego projektu
bez porownania zmian.

UWAGA: hasla w src/main.cpp zastapiono znacznikami UZUPELNIJ_LOKALNIE.
Przed kompilacja porownaj SSID i ustawienia sprzetu z dzialajacym panelem,
wpisz lokalnie dotychczasowe WIFI_PASS i OTA_HASLO_PANEL, a nastepnie usun
linie #error umieszczona nad WIFI_SSID. Nazwa i haslo AP musza odpowiadac
konfiguracji centrali. Nie przesylaj hasel w czacie ani do repozytorium.
Uzyj swojego platformio.ini i pozostalych bibliotek/plikow.

Otworz projekt w PlatformIO i zbuduj srodowisko esp32dev (pio run -e
esp32dev). Dopiero po poprawnej kompilacji podejmij decyzje o wgraniu.
W paczce nie ma firmware.bin. Kod byl testowany hostowo, nie byl
skompilowany ani przetestowany na prawdziwym LCD.

Obie strony (LCD i centrala) musza miec poprawke, aby globus mial nowy
pomiar internetu; dla starszej centrali globus wskaze znak zapytania.
