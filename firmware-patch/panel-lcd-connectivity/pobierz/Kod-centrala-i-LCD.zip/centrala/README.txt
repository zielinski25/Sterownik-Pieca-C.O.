CENTRALA: KOD ZRODLOWY, NIE PLIK BIN

Te pliki src/ bazuja na v3.54.0-offline-buffer-toggle z repozytorium,
plus poprawka internetu LCD. Sa nakladka na TWOJ istniejacy projekt
PlatformIO centrali. Zrob pelna kopie zapasowa i skopiuj pliki z src/
archiwum do src/ projektu. Nie usuwaj pozostalych plikow; nie nadpisuj
nowszego ani zmodyfikowanego firmware bez porownania roznic.

Zachowaj wlasne platformio.ini, konfiguracje plytki, partycje,
biblioteki (w tym lib/dhtESP32-rmt/) oraz src/secrets.h. Wzor
src/secrets.h.example jest dolaczony, ale NIE zawiera Twoich hasel.
Jesli nie masz juz dzialajacego secrets.h, skonfiguruj go lokalnie przed
kompilacja. Nie wysylaj hasel w czacie ani nie publikuj ich w repozytorium.

Zbuduj w PlatformIO na odpowiednim srodowisku sprzetowym, np.
pio run -e esp32-s3-n16r8 dla zgodnej plytki. Przed wgraniem zapewnij
bezpieczne warunki i mozliwosc powrotu do dzialajacego firmware.
W paczce nie ma firmware.bin. Kod przeszedl testy hostowe, ale nie zostal
skompilowany i nie zostal przetestowany na prawdziwej centrali.

Globus pokazuje wynik proby DNS, nie gwarancje dostepnosci kazdej uslugi;
blokada resolverow lub UDP 53 moze dac falszywy brak internetu.
