SterownikCO — CAŁY PROJEKT ANDROID, wersja 0.31.62
====================================================

KOMPLETNY projekt, gotowy do zbudowania. Nie składasz nic z kawałków.
WERSJA: versionCode 31062, versionName "0.31.62"
W Ustawieniach po zbudowaniu musi być "v0.31.62".


CO JEST NOWEGO WOBEC 0.31.61 — „po powrocie znowu pulpit i znowu ładuje”
--------------------------------------------------------------------------
Zgłoszenie: „gdy odpakuję aplikację i wejdę za parę sekund, ona ładuje się
od nowa na dashboard, a w Wykresach znowu kilka sekund czyta historię”.

Przyczyna: przy KAŻDYM odtworzeniu okna (powrót z tła po zabiciu procesu,
opcja „Nie zachowuj aktywności”, klik w powiadomienie alarmu) Android tworzy
panel od zera: nowy model, zakładka nr 0 (pulpit), pusta pamięć próbek
i ponowne czytanie historii z Firebase.

Co zmieniono:
1) ZAKŁADKA JEST ZAPAMIĘTANA. Wracasz tam, gdzie byłeś — czyli na Wykresy,
   a nie na pulpit.
2) WYKRES ZOSTAJE W PAMIĘCI. Ostatnio policzone próbki siedzą w pamięci
   aplikacji, więc po powrocie rysują się NATYCHMIAST — bez czytania pliku
   i bez sieci. Do 0.31.61 każde odtworzenie czytało plik od nowa.
3) „PARĘ MINUT” — okno bez pytania chmury wydłużone z 60 s do 5 MINUT.
   Wracasz na Wykresy w tym czasie → zero ruchu sieciowego, wykres od razu.
   Przycisk „Odśwież” i zmiana zakresu nadal pobierają na żądanie.
4) ALARM NIE ODTWARZA PANELU. Powiadomienie alarmowe otwierało okno flagą,
   która niszczyła i tworzyła je od nowa. Teraz tylko podnosi istniejące
   (singleTop) — stan zostaje.
5) DZIENNIK MÓWI PRAWDĘ. Przy starcie jest wpis:
     „Start panelu: pid=1234 wiek=37s · zakładka 1 · wykres z pamięci (1450 pkt)”
   - PID INNY niż poprzednio  → Android naprawdę zabił proces (oszczędzanie
     baterii / brak pamięci). Wtedy RAM jest pusty, ale zakładka wraca
     z zapisu, a wykres i tak rysuje się z pliku na dysku.
   - PID TEN SAM, wiek procesu duży → proces żyje, tylko okno było odtwarzane.
     Wtedy wykres jest z pamięci i jest natychmiast.


ODPOWIEDŹ NA PYTANIE „dlaczego starsze wersje się tak nie ubijały”
------------------------------------------------------------------
W kodzie starszych wersji NIE było żadnej ochrony stanu — dokładnie ta sama
`page = 0` w modelu. Różnica jest w tym, kiedy Android decyduje się zabić
aplikację: decyduje o tym ilość wolnej pamięci i polityka baterii producenta,
a nie numer wersji. Aplikacja trzyma w RAM całą historię telemetrii
(od 0.31.43 — do 35 dni, przy 30 dniach to dziesiątki tysięcy rekordów),
więc jest „cięższym” kandydatem do zabicia niż wcześniej.
Dlatego zamiast zgadywać, 0.31.62 zapisuje PID i wiek procesu: pierwszy wpis
w dzienniku po powrocie rozstrzygnie, czy to zabicie procesu, czy odtworzenie
okna. Warto też sprawdzić w telefonie:
  - Ustawienia -> Opcje programisty -> „Nie zachowuj aktywności” = WYŁĄCZONE,
  - Ustawienia -> Aplikacje -> SterownikCO -> Bateria -> „Bez ograniczeń”.


CO JEST JESZCZE (z 0.31.61 — szybkie wykresy)
---------------------------------------------
Wykres z pamięci telefonu rysuje się od razu; dociąganie z Firebase, zapis
pamięci i archiwum centrali lecą w tle. Zapis pamięci ~2× szybszy.
W dzienniku widać czasy etapów:
  „WYKRESY 24h: pamięć 340 ms · sieć 1.8 s · zapis 600 ms · punktów 1450”.


CO JEST JESZCZE (z 0.31.60 i 0.31.59 — serwo)
---------------------------------------------
0.31.59 nie kompilowała się (brakująca zmienna `statusStampBefore`).
Od 0.31.60 buduje się, a komunikat po zmianie trybu serwa znika sam
w maks. 10 s i pokazuje, co raportuje centrala.


CO JEST JESZCZE (z 0.31.58 i 0.31.57 — oszczędność i szybkie komendy)
---------------------------------------------------------------------
Ekran co 8 s, meldunek „podgląd otwarty” co 50 s, gaśnie po 10 min ciszy
(~1 MB/h). Klik -> potwierdzenie ~1,3–2,3 s (wymaga firmware 3.57.1).


WAŻNE — reguły Firebase (bez tego dociąganie ściąga całe doby)
--------------------------------------------------------------
Na /piec/telemetry/1m/v1 nie ma indeksu po czasie. Pełna, gotowa treść reguł
z poprawnym wpisem jest w pliku REGULY-FIREBASE-2026-10-30.json w repo oraz
w dokumencie 244/245 na Dysku. W skrócie, w bloku "telemetry" -> "1m" -> "v1":

    "$y": { "$m": { "$d": { ".indexOn": ["ts"] } } }

Prawa odczytu/zapisu dziedziczą się z "v1", więc nic się nie zamyka.


CO JEST W TEJ WERSJI (bez zmian)
--------------------------------
- Wiersz Pogody: Promieniowanie i Długość dnia w jednym wierszu, Elewacja
  słońca pod nimi — żadna liczba nie kończy się "..."
- Stare nazwy: kafelek „Panel słon.”, „Panel słoneczny (solary)”,
  „Kolektor słoneczny próżniowy”, „Panel teraz / powietrze”,
  „Różnica panel - powietrze”, „BILANS & ZYSK KOLEKTORA SŁONECZNEGO”
- Wykres: praca pompy na całą wysokość; model z niebem (skyRadWk 8,20,
  tankUa 1,4); filtry anomalii i zakresy symulacji bez zmian
- Ustawienia -> „Bufor offline”, SERWO w %


POBIERANIE
----------
Ta paczka leży na Dysku Google jako:
    SterownikCO-Android-v0.31.62-PELNY-PROJEKT.zip
Link do pobrania jest w wiadomości na czacie — tam zawsze jest aktualny.


JAK ZBUDOWAĆ — JEDNO POLECENIE
------------------------------
Skoro czytasz ten plik, masz już ZIP. Rozpakuj go do
    C:\Users\<Ty>\Documents\SterownikCO-0.31.62
(a jeśli rozpakowałeś gdzie indziej — zmień $d na swój folder) i wklej CAŁĄ
tę linię do PowerShella. Znajduje SDK (także w starym projekcie), ustawia JDK
z Android Studio, buduje i kopiuje APK na pulpit:

$d="$env:USERPROFILE\Documents\SterownikCO-0.31.62"; $desk=[Environment]::GetFolderPath('Desktop'); $lp="$env:USERPROFILE\Documents\SterownikCO-0.31.49\android\local.properties"; $sdk=$null; if(Test-Path -LiteralPath $lp){ $m=Select-String -LiteralPath $lp -Pattern '^sdk\.dir=(.+)$' | Select-Object -First 1; if($m){ $sdk=$m.Matches[0].Groups[1].Value.Replace('\:',':').Replace('\\','\') } }; if(-not $sdk){ $sdk=@("$env:LOCALAPPDATA\Android\Sdk","$env:ANDROID_HOME","$env:ANDROID_SDK_ROOT","C:\Android\Sdk","D:\Android\Sdk") | Where-Object { $_ -and (Test-Path -LiteralPath $_) } | Select-Object -First 1 }; if($sdk){ $env:ANDROID_HOME=$sdk; $env:ANDROID_SDK_ROOT=$sdk; Write-Host "SDK: $sdk" } else { Write-Host "BRAK SDK — ustaw ANDROID_HOME recznie" }; $jbr="C:\Program Files\Android\Android Studio\jbr"; if((-not $env:JAVA_HOME) -and (Test-Path -LiteralPath $jbr)){ $env:JAVA_HOME=$jbr; Write-Host "JDK: $jbr" }; if(-not (Test-Path -LiteralPath "$d\gradlew.bat")){ Write-Host "BRAK PROJEKTU w $d — rozpakuj ZIP do tego folderu" } else { cd $d; .\gradlew.bat assembleDebug; $apk="$d\app\build\outputs\apk\debug\app-debug.apk"; if(Test-Path -LiteralPath $apk){ Copy-Item -LiteralPath $apk -Destination "$desk\SterownikCO-0.31.62.apk" -Force; Write-Host ""; Write-Host "=== GOTOWE — APK NA PULPICIE ==="; Get-Item -LiteralPath "$desk\SterownikCO-0.31.62.apk" | Format-List FullName,Length,LastWriteTime } else { Write-Host ""; Write-Host "=== NIE ZBUDOWALO SIE — patrz komunikat wyzej ===" } }


JAK SPRAWDZIĆ, ŻE MASZ DOBRĄ WERSJĘ
-----------------------------------
1. Ustawienia -> na dole "v0.31.62"
2. Wejdź w Wykresy (24 H), wyjdź do innego okna na kilka sekund, wróć
   -> jesteś na Wykresach, wykres już narysowany, bez „Czytam pamięć…”
3. Wejdź w Więcej -> TERMINAL (dziennik): wpis „Start panelu: pid=… wiek=…s”
   - jeśli PID się zmienił między powrotami, telefon zabija proces
     (patrz sekcja o baterii wyżej)
4. Serwo: zmiana trybu — komunikat znika sam w maks. 10 s
5. Firmware: Ustawienia -> wersja firmware. Pełny efekt komend = v3.57.1


CZEGO NIE RUSZA
---------------
Firmware centrali: bez zmian wobec 3.57.1.
Stary folder SterownikCO-0.31.49 możesz zostawić — ten ZIP go nie dotyka.
