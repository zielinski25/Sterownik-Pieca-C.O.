SterownikCO — CAŁY PROJEKT ANDROID, wersja 0.31.61
====================================================

KOMPLETNY projekt, gotowy do zbudowania. Nie składasz nic z kawałków.
WERSJA: versionCode 31061, versionName "0.31.61"
W Ustawieniach po zbudowaniu musi być "v0.31.61".


CO JEST NOWEGO WOBEC 0.31.60
----------------------------
Wykresy z pamięci telefonu wczytują się teraz od razu, a nie po ~6 s.

BYŁO (do 0.31.60): aplikacja czytała pamięć telefonu, potem CZEKAŁA po kolei na:
      dociągnięcie nowych próbek z Firebase, przepisanie całego pliku pamięci,
      a na końcu na archiwum centrali pod lokalny adres IP (do 2 s). Wykres
      pojawiał się dopiero po SUMIE tych etapów — przy 24 H ok. 6 s.

JEST (0.31.61): wykres z pamięci rysuje się NATYCHMIAST (zwykle 0,2–0,5 s).
      Dopiero potem, w tle: dociąganie nowych próbek, zapis pamięci i archiwum
      centrali. Gdy dojdą, wykres po cichu się uzupełnia — bez migotania,
      bo to te same punkty plus ogon.

Dodatkowo:
 - zapis pamięci jest ok. 2× szybszy (gzip poziom 3 zamiast 6 — plik rośnie
   o kilka procent i tak jest kilkakrotnie mniejszy od tekstu),
 - pamięć czyta się strumieniem, a nie „wszystkie linie naraz",
 - pamięć wczytuje się w tle już przy wejściu do aplikacji, więc pierwsze
   otwarcie Wykresów nie płaci za rozpakowanie pliku,
 - w dzienniku (arkusz TERMINAL) jest teraz wpis „WYKRESY 24h: pamięć 340 ms ·
   sieć 1.8 s · zapis 600 ms · punktów 1450" — jeśli znowu będzie wolno,
   od razu widać, który etap zjada czas.


WAŻNE — reguły Firebase (bez tego dociąganie dalej ściąga całe doby)
--------------------------------------------------------------------
Na ścieżce /piec/telemetry/1m/v1 NIE MA indeksu po czasie. Bez niego Firebase
nie potrafi oddać „tylko nowych próbek" i aplikacja musi pobierać CAŁE doby
(ok. 280 kB na dobę) zamiast kilku ostatnich rekordów. W Twoich regułach indeks
jest tylko na ścieżce testowej _rtdb_test.

Poprawka w konsoli Firebase -> Realtime Database -> Rules. W bloku
"telemetry" -> "1m" -> "v1" dopisz po ".write":

    "$y": { "$m": { "$d": { ".indexOn": ["ts"] } } }

Całość tego fragmentu ma wyglądać tak:

    "telemetry": {
      "1m": {
        "v1": {
          ".read": "auth != null",
          ".write": "auth != null",
          "$y": { "$m": { "$d": { ".indexOn": ["ts"] } } }
        }
      }
    },

Prawa odczytu/zapisu dziedziczą się z "v1", więc nic się nie zamyka.
Po tej zmianie „ogon" to jedno małe zapytanie zamiast dwóch pełnych dób.


CO JEST JESZCZE (z 0.31.60)
---------------------------
0.31.59 nie dała się zbudować („Unresolved reference 'statusStampBefore'").
W 0.31.60 brakująca zmienna jest zadeklarowana, a poprawka serwa działa:
komunikat po zmianie trybu znika sam w maks. 10 s i pokazuje, co raportuje
centrala.


CO JEST JESZCZE (z 0.31.58 — oszczędny heartbeat)
-------------------------------------------------
Ekran odświeża się co 8 s, meldunek „podgląd otwarty" idzie co 50 s i GASNIE
po 10 minutach bez dotknięcia ekranu (~1 MB/h zamiast ~3,7 MB/h).


CO JEST JESZCZE (z 0.31.57 — komendy i potwierdzenia)
-----------------------------------------------------
Klik -> „potwierdzone" w ~1,3–2,3 s (było do ~8 s), bo firmware 3.57.1 czyta
komendy co 2 s przy otwartej aplikacji, a aplikacja sprawdza potwierdzenie
co 300 ms.


CO JEST W TEJ WERSJI (bez zmian)
--------------------------------
- Wiersz Pogody: Promieniowanie i Długość dnia w jednym wierszu, Elewacja
  słońca pod nimi — żadna liczba nie kończy się "..."
- Stare nazwy: kafelek „Panel słon.", „Panel słoneczny (solary)",
  „Kolektor słoneczny próżniowy", „Panel teraz / powietrze",
  „Różnica panel - powietrze", „BILANS & ZYSK KOLEKTORA SŁONECZNEGO"
- Wykres: praca pompy na całą wysokość; model z niebem (skyRadWk 8,20,
  tankUa 1,4); filtry anomalii i zakresy symulacji bez zmian


POBIERANIE
----------
Ta paczka leży na Dysku Google jako:
    SterownikCO-Android-v0.31.61-PELNY-PROJEKT.zip
Link do pobrania jest w wiadomości na czacie — tam zawsze jest aktualny.


JAK ZBUDOWAĆ — JEDNO POLECENIE
------------------------------
Skoro czytasz ten plik, masz już ZIP. Rozpakuj go do
    C:\Users\<Ty>\Documents\SterownikCO-0.31.61
(a jeśli rozpakowałeś gdzie indziej — zmień $d na swój folder) i wklej CAŁĄ
tę linię do PowerShella. Znajduje SDK (także w starym projekcie), ustawia JDK
z Android Studio, buduje i kopiuje APK na pulpit:

$d="$env:USERPROFILE\Documents\SterownikCO-0.31.61"; $desk=[Environment]::GetFolderPath('Desktop'); $lp="$env:USERPROFILE\Documents\SterownikCO-0.31.49\android\local.properties"; $sdk=$null; if(Test-Path -LiteralPath $lp){ $m=Select-String -LiteralPath $lp -Pattern '^sdk\.dir=(.+)$' | Select-Object -First 1; if($m){ $sdk=$m.Matches[0].Groups[1].Value.Replace('\:',':').Replace('\\','\') } }; if(-not $sdk){ $sdk=@("$env:LOCALAPPDATA\Android\Sdk","$env:ANDROID_HOME","$env:ANDROID_SDK_ROOT","C:\Android\Sdk","D:\Android\Sdk") | Where-Object { $_ -and (Test-Path -LiteralPath $_) } | Select-Object -First 1 }; if($sdk){ $env:ANDROID_HOME=$sdk; $env:ANDROID_SDK_ROOT=$sdk; Write-Host "SDK: $sdk" } else { Write-Host "BRAK SDK — ustaw ANDROID_HOME recznie" }; $jbr="C:\Program Files\Android\Android Studio\jbr"; if((-not $env:JAVA_HOME) -and (Test-Path -LiteralPath $jbr)){ $env:JAVA_HOME=$jbr; Write-Host "JDK: $jbr" }; if(-not (Test-Path -LiteralPath "$d\gradlew.bat")){ Write-Host "BRAK PROJEKTU w $d — rozpakuj ZIP do tego folderu" } else { cd $d; .\gradlew.bat assembleDebug; $apk="$d\app\build\outputs\apk\debug\app-debug.apk"; if(Test-Path -LiteralPath $apk){ Copy-Item -LiteralPath $apk -Destination "$desk\SterownikCO-0.31.61.apk" -Force; Write-Host ""; Write-Host "=== GOTOWE — APK NA PULPICIE ==="; Get-Item -LiteralPath "$desk\SterownikCO-0.31.61.apk" | Format-List FullName,Length,LastWriteTime } else { Write-Host ""; Write-Host "=== NIE ZBUDOWALO SIE — patrz komunikat wyzej ===" } }


JAK SPRAWDZIĆ, ŻE MASZ DOBRĄ WERSJĘ
-----------------------------------
1. Ustawienia -> na dole "v0.31.61"
2. Wykresy -> 24 H: wykres pojawia się niemal natychmiast (z pamięci),
   a pod nim przez chwilę widać „Z pamięci telefonu — dociągam nowe dane…"
3. Dziennik (TERMINAL) ma wpis „WYKRESY 24h: pamięć ... · sieć ... · zapis ..."
4. Serwo: zmiana trybu — komunikat znika sam w maks. 10 s
5. Firmware: Ustawienia -> wersja firmware. Pełny efekt komend = v3.57.1


CZEGO NIE RUSZA
---------------
Firmware centrali: bez zmian wobec 3.57.1.
Stary folder SterownikCO-0.31.49 możesz zostawić — ten ZIP go nie dotyka.
