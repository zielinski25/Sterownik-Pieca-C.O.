package com.sterownikco.pro.ui.screens.sheets

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sterownikco.pro.core.AppModel
import com.sterownikco.pro.core.PiecState
import com.sterownikco.pro.core.SensorDef
import com.sterownikco.pro.ui.screens.SolarMultiDayForecast
import com.sterownikco.pro.ui.screens.solarSunLeft
import com.sterownikco.pro.ui.components.ManualRow
import com.sterownikco.pro.ui.components.Note
import com.sterownikco.pro.ui.components.NumRow
import com.sterownikco.pro.ui.components.SectionHeader
import com.sterownikco.pro.ui.components.Seg
import com.sterownikco.pro.ui.components.UstBtn
import com.sterownikco.pro.ui.theme.Pal
import com.sterownikco.pro.ui.theme.Txt

/* ══════════════════════════════════════════════════════════════════════════
   Arkusze czujników — port `sensorModalContent()` / `symulacjaSekcjaHtml()` /
   `MENUS.czujniki` / `MENUS.dym` / `overheat()` (Piec.html 5104-5345, 5574).
   ══════════════════════════════════════════════════════════════════════════ */

/** `.status-pill` (+ `.sim`); `.ok`/`.err` korzystają z barw `.pill`. */
@Composable
fun StatusPill(text: String, cls: String) {
    val (fg, bg) = when (cls) {
        "sim" -> Pal.Cyan to Pal.rgba(0, 212, 245, .15f)
        "err" -> Pal.Err to Pal.rgba(255, 95, 120, .18f)
        "stale" -> Pal.TextDim to Pal.rgba(148, 163, 184, .10f)
        else -> Pal.Live to Pal.rgba(74, 222, 128, .12f)
    }
    val bd = when (cls) {
        "sim" -> Pal.rgba(0, 212, 245, .4f)
        "err" -> Pal.rgba(255, 95, 120, .45f)
        "stale" -> Pal.rgba(148, 163, 184, .25f)
        else -> Pal.rgba(74, 222, 128, .35f)
    }
    Box(
        Modifier.padding(start = 6.dp)
            .background(bg, RoundedCornerShape(999.dp))
            .border(BorderStroke(1.dp, bd), RoundedCornerShape(999.dp))
            .padding(horizontal = 7.dp, vertical = 3.dp)
    ) { Text(text, style = Txt.pill, color = fg) }
}

/**
 * `symulacjaSekcjaHtml(pole, etykieta, jednostka, min, max, krok, statusKey)` —
 * przycisk „Symulacja” rozwijający panel z suwakami wartości / czasu.
 */
@Composable
fun SymUnit(m: AppModel, pole: String, etykieta: String, jednostka: String, min: Double, max: Double, krok: Double, statusKey: String = pole) {
    val S = m.S
    val simBounds = PiecState.SYM_BOUNDS[pole]
    val controlMin = simBounds?.first ?: min
    val controlMax = simBounds?.second ?: max
    val f: (Double) -> String = { v -> if (krok >= 1.0) Math.round(v).toString() else S.fmt1(v) }
    var open by remember(pole) { mutableStateOf(S.symAktywna(pole)) }
    val initialValue = S.valOf(pole, statusKey).takeIf { it.isFinite() } ?: (controlMin + controlMax) / 2.0
    var value by remember(pole) { mutableFloatStateOf(initialValue.toFloat()) }
    var czas by remember(pole) { mutableIntStateOf((S.sym[pole]?.min ?: 60).coerceIn(5, 180)) }

    Column(Modifier.fillMaxWidth().padding(top = 4.dp)) {
        SectionHeader("Symulacja — $etykieta")
        Seg(listOf(0 to "Symulacja"), current = if (open) 0 else -1, columns = 1, onPick = { open = !open })
        if (open) {
            Column(
                Modifier.fillMaxWidth().padding(top = 10.dp)
                    .background(Pal.rgba(17, 31, 53, .65f), RoundedCornerShape(12.dp))
                    .border(BorderStroke(1.dp, Pal.Border), RoundedCornerShape(12.dp))
                    .padding(12.dp, 14.dp),
                verticalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                Text(
                    if (pole == "dym")
                        "⚠ TEST NA ŻYWYM STEROWNIKU: przekroczenie progu może uruchomić prawdziwy alarm i buzzer oraz poruszyć klapą i syberkiem. Wyłączenie symulacji nie kasuje alarmu natychmiast — decyduje histereza centrali."
                    else
                        "Test wysyłany do sterownika. Wartość trafia do jego normalnej logiki i może wpłynąć na rzeczywiste urządzenia.",
                    style = Txt.tiny, color = if (pole == "dym") Pal.Err else Pal.Warn,
                    modifier = Modifier.padding(bottom = 6.dp)
                )
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("Wartość", style = Txt.rowDesc, modifier = Modifier.weight(1f))
                    Text("${f(value.toDouble())} $jednostka", style = Txt.monoVal, color = Pal.White)
                }
                Slider(
                    value = value.coerceIn(controlMin.toFloat(), controlMax.toFloat()),
                    onValueChange = { v ->
                        val step = krok.toFloat().coerceAtLeast(0.1f)
                        value = min.toFloat() + Math.round((v - min.toFloat()) / step) * step
                    },
                    valueRange = controlMin.toFloat()..controlMax.toFloat(),
                    colors = SliderDefaults.colors(thumbColor = Pal.Cyan, activeTrackColor = Pal.Cyan, inactiveTrackColor = Pal.Surface3)
                )
                Row(Modifier.fillMaxWidth().padding(top = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("Czas trwania", style = Txt.rowDesc, modifier = Modifier.weight(1f))
                    Text("$czas min", style = Txt.monoVal, color = Pal.White)
                }
                Slider(
                    value = czas.toFloat(), onValueChange = { v -> czas = Math.round(v / 5f) * 5 },
                    valueRange = 5f..180f,
                    colors = SliderDefaults.colors(thumbColor = Pal.Cyan, activeTrackColor = Pal.Cyan, inactiveTrackColor = Pal.Surface3)
                )
                Row(Modifier.fillMaxWidth().padding(top = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    UstBtn("Zastosuj", variant = "primary", modifier = Modifier.weight(1f), onClick = {
                        m.send("symuluj $pole ${f(value.toDouble())} $czas")
                        open = true
                        m.refreshSheet()
                    })
                    UstBtn("Wyłącz teraz", variant = "danger", modifier = Modifier.weight(1f), onClick = {
                        m.send("symuluj_stop $pole")
                        m.refreshSheet()
                    })
                }
            }
        }
        val info = when {
            S.symAktywna(pole) && m.isFbFresh && S.online ->
                "Aktywna na sterowniku — jeszcze ok. ${S.sym[pole]?.min ?: 0} min"
            S.symAktywna(pole) -> "Ostatnio zgłoszona symulacja — status sterownika nieaktualny"
            open -> "Brak aktywnej symulacji zgłoszonej przez sterownik"
            else -> ""
        }
        if (info.isNotEmpty()) {
            Text(info, style = Txt.rowDesc.copy(fontSize = 9.5.sp, fontWeight = FontWeight.Bold, lineHeight = 13.sp),
                color = Pal.Warn, modifier = Modifier.fillMaxWidth().padding(top = 6.dp).padding(vertical = 4.dp))
        }
    }
}

/** Nagłówek karty czujnika (`.sensor-full-card` → `.sensor-full-header` + stopka zakresów). */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SensorFullCard(m: AppModel, sen: SensorDef, listStyle: Boolean, onClickHeader: (() -> Unit)? = null) {
    val S = m.S
    val cur = S.valOf(sen.id, sen.key)
    val sim = S.symAktywna(sen.id)
    val available = S.hasData(sen.key)
    val stale = !m.isFbFresh || !S.online
    val pill = when {
        sen.id == "dym" && S.hasData("dym_alarm") && S.dym_alarm -> "ALARM" to "err"
        sen.id == "dym" && !S.hasData("dym_alarm") -> "STAN ALARMU — BRAK DANYCH" to "stale"
        sim -> Pair(
            if (stale) "SYMULACJA · DANE NIEAKTUALNE" else "SYMULACJA STEROWNIKA",
            if (stale) "stale" else "sim"
        )
        sen.id == "dym" && S.hasData("dym_wlaczony") && !S.dym_wlaczony -> "WYŁ." to "stale"
        !available -> "BRAK DANYCH" to "stale"
        stale -> "NIEAKTUALNE" to "stale"
        sen.id == "dym" -> "BRAK ALARMU" to "ok"
        else -> "LIVE" to "ok"
    }
    Column(
        Modifier.fillMaxWidth().background(Pal.Surface2, RoundedCornerShape(14.dp))
            .border(BorderStroke(1.dp, Pal.Border), RoundedCornerShape(14.dp))
            .then(if (onClickHeader != null) Modifier.clickable { onClickHeader() } else Modifier)
            .padding(12.dp, 14.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(if (sen.ico.isNotEmpty()) sen.ico else "🌡️", fontSize = 20.sp)
                    Column {
                        Text(sen.name, style = Txt.cardTitle)
                        Text(
                            if (sen.id == "dym" && !listStyle) "Przetwornik optyczny MQ-2 · ADC1 GPIO36" else sen.bus,
                            style = Txt.cardDesc, modifier = Modifier.padding(top = 2.dp)
                        )
                    }
                }
            }
            Column(horizontalAlignment = Alignment.End) {
                Text(
                    (if (sim) "~" else "") + SensorDef.fmt(sen, cur) + " " + sen.unit,
                    style = Txt.monoVal.copy(fontSize = 15.sp, color = Pal.Cyan)
                )
                StatusPill(pill.first, pill.second)
            }
        }
        if (!listStyle) {
            // Trzy dlugie napisy nie mieszcza sie w jednym wierszu — Row + SpaceBetween
            // sklejal je w "…ADCMagistrala:…MQ-2Odczyt:…". FlowRow ladnie je zawija.
            FlowRow(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                Text("Zakres roboczy: ${sen.min} do ${sen.max} ${sen.unit}", style = Txt.tiny)
                Text("Magistrala: ${sen.bus.split("·")[0].trim()}", style = Txt.tiny)
                Text(
                    when {
                        sim -> "Odczyt: symulacja sterownika — używana przez jego logikę, nie pomiar fizyczny"
                        available -> if (stale) "Odczyt: ostatnia odebrana wartość (nieaktualna)" else "Odczyt: odebrany ze sterownika"
                        else -> "Odczyt: oczekiwanie na dane sterownika"
                    },
                    style = Txt.tiny.copy(color = if (sim) Pal.Warn else if (available && !stale) Pal.Live else Pal.TextDim)
                )
            }
        }
    }
}

/** `sensorModalContent(sen)` — karta telemetryczna + sekcja symulacji. */
@Composable
fun SensorModal(m: AppModel, sen: SensorDef) {
    SensorFullCard(m, sen, listStyle = false)
    if (sen.id == "panel") SolarMetricsCard(m)
    SymUnit(m, sen.id, sen.name, sen.unit, sen.min, sen.max, sen.step, sen.key)
}

/** `MENUS.czujniki` — lista 10 czujników + podsumowanie magistral. */
@Composable
fun SensorListSheet(m: AppModel) {
    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Column(
            Modifier.fillMaxWidth().background(Pal.Surface2, RoundedCornerShape(12.dp))
                .border(BorderStroke(1.dp, Pal.Border), RoundedCornerShape(12.dp)).padding(12.dp, 14.dp)
        ) {
            Text("MAGISTRALA CZUJNIKÓW TELEMETRYCZNYCH", style = Txt.diagLbl)
            val received = SensorDef.ALL.count { m.S.hasData(it.key) }
            Text("$received / ${SensorDef.ALL.size} odczytów odebranych", style = Txt.diagVal, modifier = Modifier.padding(top = 4.dp))
            Text(
                if (received == 0) "Oczekiwanie na rzeczywiste dane sterownika."
                else "Licznik dotyczy pól z ostatniej odpowiedzi Firebase; brak pola nie jest zastępowany wartością przykładową.",
                style = Txt.diagSub, modifier = Modifier.padding(top = 4.dp)
            )
        }
        Note("Symulacje są wysyłane do sterownika i używane przez jego normalną logikę; wartości symulowane są oznaczone i pomijane w historii. Test dymu może uruchomić prawdziwy alarm, buzzer oraz ruch serw.")
        SensorDef.ALL.forEach { sen ->
            Column(Modifier.fillMaxWidth()) {
                SensorFullCard(m, sen, listStyle = true)
                SymUnit(m, sen.id, sen.name, sen.unit, sen.min, sen.max, sen.step, sen.key)
            }
        }
    }
}

/** `MENUS.dym` — karta MQ-2 + progi alarmu + cykl pracy czujnika. */
@Composable
fun DymSheet(m: AppModel) {
    val S = m.S
    val sen = SensorDef.byId("dym")!!
    SensorFullCard(m, sen, listStyle = false)
    SectionHeader("Ustawienia alarmu dymu")
    NumRow("Próg alarmu", "Surowy odczyt ADC czujnika (0-4095)", S.progAlarmDym, 0, 4095, known = S.hasData("progAlarmDym")) { v ->
        m.commitNum("Próg alarmu", "progAlarmDym", 0, 4095, v)
    }
    SectionHeader("Aktywacja od temperatury pieca")
    NumRow("Próg temperatury", "°C — poniżej tej temp. pieca czujnik jest wyłączony (histereza 3°C)", S.dymProgTemp, 0, 200, known = S.hasData("dymProgTemp")) { v ->
        m.commitNum("Próg temperatury", "dymProgTemp", 0, 200, v)
    }
    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp)) {
        Text("Tryb pracy po aktywacji", style = Txt.rowLabel, modifier = Modifier.weight(1f))
    }
    val smokeModePresentation = m.smokeModePresentation()
    Seg(listOf(0 to "Impulsowo", 1 to "Ciągle"), current = smokeModePresentation.mode ?: -1, onPick = { v ->
        m.setSmokeMode(v)
    })
    if (smokeModePresentation.awaitingStatus) {
        Note("Sterownik potwierdził zmianę trybu; oczekuję na świeży odczyt centrali.")
    }
    SectionHeader("Cykl pracy czujnika (tryb Impulsowo)")
    NumRow("Czas WŁ.", "s — rozgrzewanie + pomiar", S.dymCzasOn, 20, 600, known = S.hasData("dymCzasOn")) { v -> m.commitNum("Czas WŁ.", "dymCzasOn", 20, 600, v) }
    NumRow("Czas WYŁ.", "s — między pomiarami", S.dymCzasOff, 10, 600, known = S.hasData("dymCzasOff")) { v -> m.commitNum("Czas WYŁ.", "dymCzasOff", 10, 600, v) }
    NumRow("Czas stabilizacji", "s — część Czasu WŁ. zanim odczyt zaufany (dotyczy obu trybów)", S.dymCzasStabilizacji, 5, 590, known = S.hasData("dymCzasStabilizacji")) { v ->
        m.commitNum("Czas stabilizacji", "dymCzasStabilizacji", 5, 590, v)
    }
    SymUnit(m, "dym", "Dym", "ADC", 0.0, 4095.0, 1.0)
}

/** `overheat(panel)` — próg przegrzania pieca / kolektora. */
@Composable
fun OverheatSheet(m: AppModel, panel: Boolean) {
    val S = m.S
    if (panel) SolarMetricsCard(m)
    SectionHeader("Zabezpieczenie przed przegrzaniem")
    Note("Wspólny próg dla pieca C.O. i panelu słonecznego — histereza: piec -10°C, panel -4°C.")
    NumRow("Próg alarmu przegrzania", "°C", S.progAlarmTemp, 0, 100, known = S.hasData("progAlarmTemp")) { v ->
        m.commitNum("Próg alarmu przegrzania", "progAlarmTemp", 0, 100, v)
    }
    if (panel) SymUnit(m, "panel", "Panel słoneczny", "°C", -30.0, 160.0, 0.5)
    else SymUnit(m, "ogrz", "Piec C.O.", "°C", 0.0, 160.0, 0.5)
}

@Composable
private fun SolarMetricsCard(m: AppModel) {
    // [0.31.30] Czy do końca doby zostało jeszcze słońce — ten sam warunek co karta
    // „DO KOŃCA DNIA” na ekranie Pogoda. Bez tego po zachodzie wychodziło „+0,0 °C”,
    // co czyta się jak awaria modelu, a jest poprawnym wynikiem.
    val sunnyHours = m.weather?.hourly.orEmpty()
    val sunLeft = solarSunLeft(sunnyHours, com.sterownikco.pro.core.Weather.startOfHour())
    val s = m.S
    val solar = m.solar
    val panelTemp = s.valOf("panel", "t_panel")
    val outsideTemp = s.valOf("zewn", "t_zewn")
    val panelSim = s.symAktywna("panel")
    val outsideSim = s.symAktywna("zewn")
    val deltaKnown = s.hasData("t_panel") && s.hasData("t_zewn") && !panelSim && !outsideSim
    val delta = if (deltaKnown) s.t_panel - s.t_zewn else Double.NaN
    val panelText = if (panelTemp.isFinite()) (if (panelSim) "~" else "") + s.fmt1(panelTemp) + "°C" else "—"
    val outsideText = if (outsideTemp.isFinite()) (if (outsideSim) "~" else "") + s.fmt1(outsideTemp) + "°C" else "—"

    Column(
        Modifier.fillMaxWidth()
            .background(Pal.Surface2, RoundedCornerShape(12.dp))
            .border(BorderStroke(1.dp, Pal.Border), RoundedCornerShape(12.dp))
            .padding(horizontal = 12.dp, vertical = 8.dp)
    ) {
        Text("BILANS SOLARNY", style = Txt.diagLbl)
        Spacer(Modifier.height(2.dp))
        // [0.31.28] Każda liczba mówi wprost, skąd pochodzi: „zmierzone" to czujnik,
        // „szacunek" to wyliczenie z prognozy. Zniknęły sumy narastające — nie dały
        // się obronić (sumowały każdy drobny wzrost, także szum czujnika).
        SolarMetricRow("Panel teraz / powietrze", "$panelText / $outsideText")
        SolarMetricRow(
            "Różnica panel − powietrze",
            if (delta.isFinite()) (if (delta >= 0) "+" else "") + s.fmt1(delta) + "°C" else "brak danych"
        )
        SolarMetricRow(
            "Zysk dziś · zmierzone",
            if (solar.todayGain > 0) "+${s.fmt1(solar.todayGain)}°C" else "brak próbek z dziś"
        )
        SolarMetricRow(
            "Do końca dnia · szacunek",
            when {
                !sunLeft -> "bez słońca do końca dnia"
                !solar.forecastGain.isFinite() -> "brak prognozy"
                // [0.31.31] Ten sam warunek co karta „DO KOŃCA DNIA” — patrz Weather.kt.
                !solar.forecastPeakReal -> "słońce nie przebije strat ciepła"
                solar.forecastPeakLabel.isNotEmpty() && solar.forecastEnergyKwh.isFinite() ->
                    "+${s.fmt1(solar.forecastGain)}°C · szczyt ${solar.forecastPeakLabel} · ${s.fmt1(solar.forecastEnergyKwh)} kWh"
                else -> "+${s.fmt1(solar.forecastGain)}°C"
            }
        )
        SolarMetricRow(
            "Pobrania ciepłej wody",
            if (solar.todayDrawCount > 0) "${solar.todayDrawCount} razy · −${s.fmt1(solar.todayDrawDrop)}°C" else "brak"
        )
        Text(
            "Zysk = o ile °C ogrzała się woda w zbiorniku 100 l. " +
                "„Zmierzone” to odczyt czujnika w zbiorniku, „szacunek” to wyliczenie " +
                "z prognozy słońca — nie pomiar.",
            fontSize = 7.5.sp, color = Pal.TextDim2, lineHeight = 10.sp,
            modifier = Modifier.padding(top = 6.dp)
        )
        SolarMultiDayForecast(m)
    }
}

@Composable
private fun SolarMetricRow(title: String, value: String) {
    Column {
        Box(Modifier.fillMaxWidth().height(1.dp).background(Pal.Border))
        Row(
            Modifier.fillMaxWidth().padding(vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                title,
                style = Txt.rowLabel.copy(fontSize = 9.5.sp, lineHeight = 12.sp),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f)
            )
            Text(
                value,
                style = Txt.monoVal.copy(fontSize = 9.5.sp, lineHeight = 12.sp, color = Color(0xFFFFD32A)),
                textAlign = TextAlign.End,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(start = 8.dp)
            )
        }
    }
}
