Sterownik CO - aplikacja Android 0.31.66 (pelny projekt)
=========================================================

Co nowego w 0.31.66
-------------------
* Poprawiony test jednostkowy ChartTimeAxisTest: dla 4 z 12 minut oczekiwal 60 px,
  a poprawna wartosc to 100 px (20 + 240/3). Blad byl w tescie, nie w wykresie.
  Dzieki temu ":app:testDebugUnitTest" przechodzi w calosci (156/156).
* Numer wersji: versionCode 31066 / versionName 0.31.66.
* Reszta bez zmian wzgledem 0.31.65 (ekran "Zapis historii na flash" + import HistFsSheet).

Jak zbudowac (Windows, PowerShell)
----------------------------------
1. Rozpakuj ZIP, np. do %USERPROFILE%\SterownikCO-0.31.66
2. W tym folderze:
     .\gradlew.bat :app:testDebugUnitTest :app:assembleDebug --console=plain
   Gdy Gradle zglosi "SDK location not found", utworz plik local.properties:
     sdk.dir=C:/Users/<user>/AppData/Local/Android/Sdk
3. APK: app\build\outputs\apk\debug\app-debug.apk
4. Wersja w Ustawieniach aplikacji: v0.31.66-debug (pakiet com.sterownikco.pro.debug)
