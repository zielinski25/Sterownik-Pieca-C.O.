Sterownik CO - aplikacja Android 0.31.67 (pelny projekt)
=========================================================

Co nowego w 0.31.67
-------------------
Kafelek SERWO na Pulpicie wygladal inaczej niz dwa sasiednie (POMPA, MIESZADLO):
mial pigulke "AUTO" w naglowku i mala wartosc "klapa 100%", podczas gdy obok
staly duze wersaliki "WYLACZONA" / "WYLACZONE".

Teraz jest tak samo jak w panelu HTML:
  AUTO 100%      <- stan duza czcionka + procent klapy
  syberek 100%
  RECZNY 100%    <- zolta ramka
  BEZPIECZNY     <- czerwona ramka, podpis "tryb bezpieczenstwa"
  CEL 40%        <- gdy komenda jeszcze czeka na potwierdzenie

Numer wersji: versionCode 31067 / versionName 0.31.67.
Reszta bez zmian wzgledem 0.31.66.

Jak zbudowac (Windows, PowerShell)
----------------------------------
1. Rozpakuj ZIP, np. do %USERPROFILE%\SterownikCO-0.31.67
2. W tym folderze:
     .\gradlew.bat :app:testDebugUnitTest :app:assembleDebug --console=plain
   Gdy Gradle zglosi "SDK location not found", utworz plik local.properties:
     sdk.dir=C:/Users/<user>/AppData/Local/Android/Sdk
3. APK: app\build\outputs\apk\debug\app-debug.apk
4. Wersja w Ustawieniach aplikacji: v0.31.67-debug (pakiet com.sterownikco.pro.debug)
