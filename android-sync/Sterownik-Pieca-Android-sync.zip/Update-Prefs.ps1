$ErrorActionPreference = 'Stop'
$repo = Split-Path -Parent $MyInvocation.MyCommand.Path
$prefsPath = Join-Path $repo 'android\app\src\main\java\com\sterownikco\pro\core\Prefs.kt'
if (-not (Test-Path -LiteralPath $prefsPath)) { throw "Nie znaleziono Prefs.kt: $prefsPath" }
$text = [System.IO.File]::ReadAllText($prefsPath)
$old = 'credentialPrefs.edit().remove(K_ID_TOKEN).remove(K_REF_TOKEN).apply()'
$new = 'credentialPrefs.edit().remove(K_ID_TOKEN).remove(K_REF_TOKEN).commit()'
if ($text.Contains($new)) {
    Write-Host 'Prefs.kt ma już synchroniczne usuwanie tokenów.'
} elseif ($text.Contains($old)) {
    $text = $text.Replace($old, $new)
    [System.IO.File]::WriteAllText($prefsPath, $text)
    Write-Host 'Zaktualizowano zapis usunięcia tokenów w Prefs.kt.'
} else {
    throw 'Nie znaleziono oczekiwanego kodu w Prefs.kt; niczego w tym pliku nie zmieniono.'
}
