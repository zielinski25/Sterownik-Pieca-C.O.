Paczka synchronizacyjna Android — pliki do wypakowania do głównego folderu projektu.

Zawiera 4 aktualne pliki Kotlin oraz Update-Prefs.ps1. Skrypt zmienia w istniejącym Prefs.kt tylko usunięcie tokenów z apply() na commit(); nie zawiera całego Prefs.kt ani wbudowanych w nim danych dostępowych.

Instrukcja:
1. Wypakuj całą paczkę do katalogu projektu, który zawiera folder android i Piec.html, nadpisując wskazane 4 pliki.
2. Otwórz PowerShell w głównym folderze projektu i uruchom: .\Update-Prefs.ps1
3. Przejdź do android i uruchom: .\gradlew.bat :app:testDebugUnitTest :app:assembleDebug --rerun-tasks

Paczka odzwierciedla zmiany lokalne po ostatnim statycznym sprawdzeniu; ostatni Windows build użytkownika poprzedzał te zmiany.
