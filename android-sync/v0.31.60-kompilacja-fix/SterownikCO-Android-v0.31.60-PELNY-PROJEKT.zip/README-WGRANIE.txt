SterownikCO — CAŁY PROJEKT ANDROID, wersja 0.31.60
====================================================

KOMPLETNY projekt, gotowy do zbudowania. Nie składasz nic z kawałków.
WERSJA: versionCode 31060, versionName "0.31.60"
W Ustawieniach po zbudowaniu musi być "v0.31.60".


CO JEST NOWEGO WOBEC 0.31.59
----------------------------
0.31.59 NIE DAŁO SIĘ ZBUDOWAĆ. Twoje ostatnie budowanie padło na:

    e: AppModel.kt:1023:40 Unresolved reference 'statusStampBefore'

To mój błąd: w poprawce serwa użyłem zmiennej "statusStampBefore", ale jej
nie zadeklarowałem. Kompilator wywalał cały build — żadnej APK z 0.31.59
nie było.

POPRAWKA (0.31.60): zmienna jest teraz zadeklarowana na początku funkcji
setServoMode i zapamiętuje czas ostatniego udanego odczytu statusu SPRZED
wysłania komendy. To ta wartość, do której porównujemy "czy odczyt jest
świeży". Reszta poprawki serwa z 0.31.59 zostaje bez zmian.


CO ROBI POPRAWKA SERWA (z 0.31.59)
----------------------------------
Naprawiony komunikat "Sterownik przyjął tryb — oczekuję na świeży odczyt",
który wisiał na ekranie po zmianie trybu serwa.

BYŁO: po potwierdzeniu ACK aplikacja czekała, aż status poda DOKŁADNIE
      żądany tryb — do 30 s. Jeśli centrala sama wybrała inny tryb
      (np. bezpieczny) albo status nie miał tego pola, warunek nigdy nie
      był spełniony, a przy kolejnym kliknięciu toast zostawał na zawsze.
JEST: czekamy na ŚWIEŻY ODCZYT (maks. 10 s), a potem uczciwy komunikat:
      - "Status centrali potwierdził tryb: AUTO." (zielony),
      - "Centrala raportuje tryb AUTO, nie RĘCZNY — pokazuję stan
        z centrali." (żółty) — gdy centrala ma własne zdanie,
      - "Brak świeżego statusu po 10 s..." (żółty).
      Każde wyjście zdejmuje wiszący komunikat.


CO JEST JESZCZE (z 0.31.58 — oszczędny heartbeat)
-------------------------------------------------
Aplikacja odświeża ekran co 8 s (było 2 s), a meldunek "podgląd otwarty"
idzie co 50 s i GASNIE po 10 minutach bez dotknięcia ekranu. Dzięki temu
leżenie aplikacji na wierzchu to ~1 MB/h zamiast ~3,7 MB/h.


CO JEST JESZCZE (z 0.31.57 — komendy i potwierdzenia)
-----------------------------------------------------
Klik -> "potwierdzone" w ~1,3-2,3 s (było do ~8 s). Działa tak:
 - aplikacja co 50 s melduje centrali "podglad_wl" (nic nie przełącza),
 - firmware 3.57.1 czyta wtedy komendy co 2 s zamiast 7 s (status dalej 15 s),
 - aplikacja sprawdza potwierdzenie co 300 ms zamiast 1000 ms.
Schowanie aplikacji = "podglad_wyl" = natychmiastowy powrót do 7 s.
Zabita aplikacja = okno samo wygasa po 90 s.


CO JEST W TEJ WERSJI (bez zmian wobec 0.31.55)
----------------------------------------------
- Wiersz Pogody: Promieniowanie i Długość dnia w jednym wierszu,
  Elewacja słońca pod nimi — żadna liczba nie kończy się "..."
- Stare nazwy: kafelek "Panel słon.", "Panel słoneczny (solary)",
  "Kolektor słoneczny próżniowy", "Panel teraz / powietrze",
  "Różnica panel - powietrze", "BILANS & ZYSK KOLEKTORA SŁONECZNEGO"
- Wykres: praca pompy na całą wysokość
- Model z niebem (0.31.52): skyRadWk 8,20, tankUa 1,4


POBIERANIE
----------
Ta paczka leży na Dysku Google jako:
    SterownikCO-Android-v0.31.60-PELNY-PROJEKT.zip
Link do pobrania (z ID pliku) jest w wiadomości na czacie — tam zawsze jest
aktualny.


JAK ZBUDOWAĆ — JEDNO POLECENIE
------------------------------
Skoro czytasz ten plik, masz już ZIP. Rozpakuj go do
    C:\Users\<Ty>\Documents\SterownikCO-0.31.60
(a jeśli rozpakowałeś gdzie indziej — zmień $d na swój folder) i wklej CAŁĄ
tę linię do PowerShella. Znajduje SDK (także w starym projekcie), ustawia JDK
z Android Studio, buduje i kopiuje APK na pulpit:

$d="$env:USERPROFILE\Documents\SterownikCO-0.31.60"; $desk=[Environment]::GetFolderPath('Desktop'); $lp="$env:USERPROFILE\Documents\SterownikCO-0.31.49\android\local.properties"; $sdk=$null; if(Test-Path -LiteralPath $lp){ $m=Select-String -LiteralPath $lp -Pattern '^sdk\.dir=(.+)$' | Select-Object -First 1; if($m){ $sdk=$m.Matches[0].Groups[1].Value.Replace('\:',':').Replace('\\','\') } }; if(-not $sdk){ $sdk=@("$env:LOCALAPPDATA\Android\Sdk","$env:ANDROID_HOME","$env:ANDROID_SDK_ROOT","C:\Android\Sdk","D:\Android\Sdk") | Where-Object { $_ -and (Test-Path -LiteralPath $_) } | Select-Object -First 1 }; if($sdk){ $env:ANDROID_HOME=$sdk; $env:ANDROID_SDK_ROOT=$sdk; Write-Host "SDK: $sdk" } else { Write-Host "BRAK SDK — ustaw ANDROID_HOME recznie" }; $jbr="C:\Program Files\Android\Android Studio\jbr"; if((-not $env:JAVA_HOME) -and (Test-Path -LiteralPath $jbr)){ $env:JAVA_HOME=$jbr; Write-Host "JDK: $jbr" }; if(-not (Test-Path -LiteralPath "$d\gradlew.bat")){ Write-Host "BRAK PROJEKTU w $d — rozpakuj ZIP do tego folderu" } else { cd $d; .\gradlew.bat assembleDebug; $apk="$d\app\build\outputs\apk\debug\app-debug.apk"; if(Test-Path -LiteralPath $apk){ Copy-Item -LiteralPath $apk -Destination "$desk\SterownikCO-0.31.60.apk" -Force; Write-Host ""; Write-Host "=== GOTOWE — APK NA PULPICIE ==="; Get-Item -LiteralPath "$desk\SterownikCO-0.31.60.apk" | Format-List FullName,Length,LastWriteTime } else { Write-Host ""; Write-Host "=== NIE ZBUDOWALO SIE — patrz komunikat wyzej ===" } }


JEŚLI "SDK location not found"
------------------------------
To normalne przy świeżo rozpakowanym projekcie: plik local.properties nie jest
w paczce (bo zawiera ścieżki z cudzego komputera). Polecenie wyżej i tak
znajduje SDK i ustawia ANDROID_HOME + ANDROID_SDK_ROOT — Gradle czyta te
zmienne, więc błąd nie wystąpi. Samemu local.properties NIE wpisuj ręcznie
(trzeba by podwajać backslashe).


JAK SPRAWDZIĆ, ŻE MASZ DOBRĄ WERSJĘ
-----------------------------------
1. Ustawienia -> na dole "v0.31.60"
2. Serwo: zmień tryb — komunikat znika sam w maks. 10 s (nie wisi)
3. Pogoda -> nad łukiem słońca: Promieniowanie i Długość dnia w jednym
   wierszu, Elewacja słońca pod nimi — żadna liczba nie kończy się "..."
4. Kafelek: "Panel słon." — NIE "Zbiornik"
5. Wykresy: legenda "Panel", praca pompy jako kolumna na całą wysokość
6. Szybkość: kliknij np. pompę — potwierdzenie w ~1–3 s (wymaga firmware 3.57.1)
7. Firmware: Ustawienia -> wersja firmware. Pełny efekt = v3.57.1


CZEGO NIE RUSZA
---------------
Firmware centrali: bez zmian wobec 3.57.1 (masz go już w src).
Stary folder SterownikCO-0.31.49 możesz zostawić — ten ZIP go nie dotyka.
