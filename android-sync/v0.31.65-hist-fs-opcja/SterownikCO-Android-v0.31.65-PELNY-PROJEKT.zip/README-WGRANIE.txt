SterownikCO — CAŁY PROJEKT ANDROID, wersja 0.31.65
==================================================

KOMPLETNY projekt, gotowy do zbudowania. Nie składasz nic z kawałków.
WERSJA: versionCode 31065, versionName "0.31.65"
Po zbudowaniu w Ustawieniach ma być "v0.31.65-debug" (build debug).


CO BYŁO NIE TAK W 0.31.64 (i dlaczego ta wersja istnieje)
---------------------------------------------------------
0.31.64 NIE SKOMPILOWAŁA SIĘ. Twoje budowanie padło na:

    e: Overlays.kt:128:31 Unresolved reference 'HistFsSheet'.

Brakowało JEDNEJ linii importu w pliku, który wybiera, jaki arkusz pokazać.
Sam ekran `HistFs.kt` był na miejscu — tylko plik nadrzędny go nie widział.
Poprawka w 0.31.65:

    import com.sterownikco.pro.ui.screens.sheets.HistFsSheet

Sprawdziłem przy okazji każdy symbol, którego używa nowy ekran
(`CheckRowEcho`, `Note`, `SectionHeader`, `Pal.Warn`, `S.rev`, `S.hasData`,
`MenuCard`, `setHistFs`, `clearHistFiles`) — wszystkie istnieją i mają
zgodne sygnatury. Numer podbity, bo zmienił się kod.


CO JEST NOWE (ekran z 0.31.64, bez zmian)
------------------------------------------
Ustawienia -> "Zapis historii na flash":
- przełącznik: zapisywać hist_short.csv i hist_long.csv na flashu centrali czy nie
  (wymaga firmware 3.57.4+; bez niego ekran pokaże "Ta wersja firmware nie zgłasza tego ustawienia"),
- przycisk "Wyczyść oba pliki historii" — pliki znikają przy NASTĘPNYM restarcie centrali
  (tak jest bezpiecznie: kasowanie przy starcie, zanim cokolwiek otworzy pliki),
- wyłączenie zapisu NIE zmienia wysyłki do Firebase ani wykresów z pamięci RAM.

Stan pochodzi z pola `hist_fs` w /piec/status (1 = zapis włączony, 0 = wyłączony).


ZBUDOWANIE — JEDNO POLECENIE
-----------------------------
1. Rozpakuj ten ZIP (np. na Pulpit).
2. W PowerShell, w katalogu rozpakowanego projektu:

   .\gradlew.bat :app:testDebugUnitTest :app:assembleDebug --console=plain

3. APK: app\build\outputs\apk\debug\app-debug.apk
   Instalacja na telefonie (kabel + debugowanie USB):

   & "$env:LOCALAPPDATA\Android\Sdk\platform-tools\adb.exe" install -r ".\app\build\outputs\apk\debug\app-debug.apk"


GDY GRADLE MÓWI "SDK location not found"
------------------------------------------
Trzeba wskazać Android SDK. Najkrócej — utwórz plik `local.properties`
w katalogu projektu z linią (ukośniki, nie backslashe):

    sdk.dir=C:/Users/<twoja-nazwa>/AppData/Local/Android/Sdk

Ścieżkę sprawdzisz: Test-Path "$env:LOCALAPPDATA\Android\Sdk\platform-tools\adb.exe"
Wymagany Android SDK 35 (Android 15) + Build-Tools + Platform-Tools.
JDK: 17–21 (Android Studio ma własny: ...\Android Studio\jbr).


CO ZWRÓCIĆ, JEŚLI BUILD PADNIE
------------------------------
Skopiuj z konsoli wszystko od "FAILURE" w górę, razem z liniami zaczynającymi
się od "e:" — to wystarcza, żeby znaleźć i naprawić błąd.

Numer wersji podbijam po KAŻDEJ zmianie kodu, więc 0.31.64 zostaje wycofana.
