Sterownik CO - aplikacja Android 0.31.68 (pelny projekt)
=========================================================

Co nowego w 0.31.68
-------------------
Kafelek SERWO na Pulpicie pokazywal "AUTO 100%" - a takiej wielkosci nie ma.
Serwo ma TRYB (AUTO / RECZNY / BEZPIECZNY) i DWIE osobne pozycje:
klape (0..180 stopni) i syberek (0..90 stopni).

Teraz:
  AUTO           <- duza wartosc = tylko tryb
  klapa 100% - syberek 100%   <- pod spodem obie pozycje (mniejsza czcionka)

  RECZNY         <- zolta ramka
  klapa 50% - syberek 0%

  BEZPIECZNY     <- czerwona ramka
  klapa 0% - syberek 0%

  CEL 40%        <- tylko gdy komenda czeka na potwierdzenie
  klapa 96 stopni - czekam

Numer wersji: versionCode 31068 / versionName 0.31.68.
Reszta bez zmian wzgledem 0.31.66.

Jak zbudowac (Windows, PowerShell)
----------------------------------
1. Rozpakuj ZIP, np. do %USERPROFILE%\SterownikCO-0.31.68
2. W tym folderze:
     .\gradlew.bat :app:testDebugUnitTest :app:assembleDebug --console=plain
   Gdy Gradle zglosi "SDK location not found", utworz plik local.properties:
     sdk.dir=C:/Users/<user>/AppData/Local/Android/Sdk
3. APK: app\build\outputs\apk\debug\app-debug.apk
4. Wersja w Ustawieniach aplikacji: v0.31.68-debug (pakiet com.sterownikco.pro.debug)
