/* Host-only fault injection into the exact upstream littlefs source selected for review.
 * RAM block device, not ESP flash and not a power-loss qualification. */
#include "lfs.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>
static unsigned char disk[128][512];
static int fail_prog,fail_sync;
static int rd(const struct lfs_config*c,lfs_block_t b,lfs_off_t o,void*p,lfs_size_t n){(void)c;assert(b<128&&o+n<=512);memcpy(p,disk[b]+o,n);return 0;}
static int wr(const struct lfs_config*c,lfs_block_t b,lfs_off_t o,const void*p,lfs_size_t n){(void)c;assert(b<128&&o+n<=512);if(fail_prog)return LFS_ERR_IO;memcpy(disk[b]+o,p,n);return 0;}
static int er(const struct lfs_config*c,lfs_block_t b){(void)c;assert(b<128);memset(disk[b],255,512);return 0;}
static int sy(const struct lfs_config*c){(void)c;return fail_sync?LFS_ERR_IO:0;}
static struct lfs_config cfg={.read=rd,.prog=wr,.erase=er,.sync=sy,.read_size=16,.prog_size=16,.block_size=512,.block_count=128,.block_cycles=100,.cache_size=64,.lookahead_size=16};
int main(void){
 for(int scenario=0;scenario<3;scenario++){
  lfs_t fs;lfs_file_t file;fail_prog=fail_sync=0;memset(disk,255,sizeof(disk));
  assert(lfs_format(&fs,&cfg)==0);assert(lfs_mount(&fs,&cfg)==0);
  assert(lfs_file_open(&fs,&file,"record",LFS_O_WRONLY|LFS_O_CREAT|LFS_O_EXCL)==0);
  char data[1024];memset(data,42,sizeof(data));
  if(scenario==1)fail_prog=1;
  int write_result=lfs_file_write(&fs,&file,data,sizeof(data));
  if(scenario==2)fail_sync=1;
  int first_sync=lfs_file_sync(&fs,&file);
  fail_prog=fail_sync=0;
  int second_sync=lfs_file_sync(&fs,&file);
  int close_result=lfs_file_close(&fs,&file);
  if(scenario==0){assert(write_result==1024&&first_sync==0&&second_sync==0&&close_result==0);}
  if(scenario==1){assert(write_result<0&&first_sync==0&&second_sync==0&&close_result==0);}
  if(scenario==2){assert(write_result==1024&&first_sync<0&&second_sync==0&&close_result==0);}
  printf("scenario=%d write=%d first_sync=%d second_sync=%d close=%d PASS\n",scenario,write_result,first_sync,second_sync,close_result);
  assert(lfs_unmount(&fs)==0);
 }
 puts("3 host scenarios PASS; RAM model only; no ESP/power-loss test");
}
