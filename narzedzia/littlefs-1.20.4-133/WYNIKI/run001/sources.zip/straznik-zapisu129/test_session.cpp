#include "WriteSession.h"
#include <cassert>
#include <cstring>
#include <string>
#include <iostream>
#include <limits>
using namespace guarded_write;
struct Fake:Io {
 std::string calls;unsigned char stored[256]={};unsigned char* caller=nullptr;
 bool closeBad=false;int mode=0;int closes=0;std::uint64_t position=0;
 Transfer write(std::uint64_t p,const unsigned char*b,std::size_t n)noexcept override{
  calls+='W';position=p;std::memcpy(stored,b,n);
  if(caller)caller[0]^=1;
  if(mode==1)return {true,n-1};
  if(mode==2)return {false,n};
  if(mode==3)return {true,n+1};
  return {true,n};
 }
 bool sync()noexcept override{calls+='S';return mode!=4;}
 Transfer read(std::uint64_t p,unsigned char*b,std::size_t n)noexcept override{
  calls+='R';assert(p==position);std::memcpy(b,stored,n);
  if(mode==8)b[0]^=1;
  if(mode==5)return {false,n};
  if(mode==6)return {true,n-1};
  if(mode==7)return {true,n+1};
  return {true,n};
 }
 bool close()noexcept override{calls+='C';closes++;return !closeBad&&mode!=9&&mode!=10;}
};
int main(){
 int groups=0;unsigned char bytes[256];std::memset(bytes,42,sizeof(bytes));
 const Error errors[]={Error::None,Error::Write,Error::Write,Error::Write,Error::Sync,Error::Read,Error::Read,Error::Read,Error::Mismatch,Error::Close};
 const char* traces[]={"WSRC","WC","WC","WC","WSC","WSRC","WSRC","WSRC","WSRC","WSRC"};
 for(int mode=0;mode<10;mode++){
  Fake io;io.mode=mode;
  {Session s(io,Admission::CallerVerifiedPrerequisites);
   assert(s.commit(17,bytes,96)==(mode==0));assert(s.committed()==(mode==0));assert(s.error()==errors[mode]);assert(io.calls==traces[mode]);
   assert(s.shutdown()==(mode==0));assert(io.closes==1);
   if(mode){io.mode=0;assert(!s.commit(17,bytes,96));assert(s.error()==errors[mode]);assert(!s.committed());assert(io.calls==traces[mode]);}
  }assert(io.closes==1);groups++;
 }
 for(int invalid=0;invalid<4;invalid++){
  Fake io;Session s(io,Admission::CallerVerifiedPrerequisites);
  auto offset=invalid==3?std::numeric_limits<std::uint64_t>::max():0;
  assert(!s.commit(offset,invalid==0?nullptr:bytes,invalid==1?0:invalid==2?257:96));assert(s.error()==Error::InvalidInput);assert(io.calls=="C");groups++;
 }
 {Fake io;Session s(io);assert(!s.commit(0,bytes,96));assert(s.error()==Error::NotAdmitted&&io.calls=="C");groups++;}
 {Fake io;{Session s(io,Admission::CallerVerifiedPrerequisites);}assert(io.calls=="C");groups++;}
 {Fake io;io.mode=10;Session s(io,Admission::CallerVerifiedPrerequisites);assert(!s.shutdown());assert(s.error()==Error::Aborted);assert(!s.commit(0,bytes,96));assert(io.calls=="C");groups++;}
 {Fake io;io.mode=10;Session s(io);assert(!s.commit(0,bytes,96));assert(s.error()==Error::NotAdmitted);assert(io.calls=="C");groups++;}
 {Fake io;io.caller=bytes;Session s(io,Admission::CallerVerifiedPrerequisites);assert(s.commit(0,bytes,256));assert(s.committed());assert(io.stored[0]!=bytes[0]);groups++;}
 {Fake io;Session s(io,Admission::CallerVerifiedPrerequisites);assert(s.commit(0,bytes,1));assert(!s.commit(0,bytes,1));assert(!s.committed());assert(s.error()==Error::AlreadyUsed&&io.calls=="WSRC");groups++;}
 for(int mode: {1,4,8}){
  Fake io;io.mode=mode;io.closeBad=true;
  {Session s(io,Admission::CallerVerifiedPrerequisites);assert(!s.commit(0,bytes,96));assert(s.error()==errors[mode]);assert(io.closes==1);assert(!s.shutdown());assert(s.error()==errors[mode]);}
  assert(io.closes==1);groups++;
 }
 std::cout<<groups<<" groups PASS: state, first error, call order, one close, no retry, bounds, snapshot\n";
}
