#pragma once
#include <cstddef>
#include <cstdint>
namespace guarded_write {
// One already-open, exclusively owned handle. Implementations must not throw,
// retry uncertain operations, replace handles, or hide sync/close errors.
// The caller keeps Io alive longer than Session and relinquishes handle use.
struct Transfer { bool certain; std::size_t bytes; };
struct Io {
 virtual ~Io()=default;
 virtual Transfer write(std::uint64_t,const unsigned char*,std::size_t) noexcept=0;
 virtual bool sync() noexcept=0;
 virtual Transfer read(std::uint64_t,unsigned char*,std::size_t) noexcept=0;
 virtual bool close() noexcept=0;
};
// External prerequisite only, NOT a capability or storage qualification proof.
enum class Admission {Denied,CallerVerifiedPrerequisites};
enum class Error {None,NotAdmitted,InvalidInput,AlreadyUsed,Write,Sync,Read,Mismatch,Close,Aborted};
enum class State {Idle,Writing,Syncing,Reading,Closing,Committed,Blocked};
class Session final {
 Io& io_;
 Error first_=Error::None;
 State state_=State::Idle;
 bool attempted_=false,closeAttempted_=false;
 unsigned char expected_[256]={},actual_[256]={};
 void fail(Error) noexcept;
 bool closeOnce() noexcept;
 public:
 static constexpr std::size_t Capacity=256;
 // Owns exactly one close obligation even when admission is denied.
 explicit Session(Io&,Admission=Admission::Denied) noexcept;
 ~Session();
 Session(const Session&)=delete;Session& operator=(const Session&)=delete;
 Session(Session&&)=delete;Session& operator=(Session&&)=delete;
 bool commit(std::uint64_t offset,const unsigned char*,std::size_t) noexcept;
 // Cleanup cannot turn a failed session into a successful transaction.
 bool shutdown() noexcept;
 bool committed()const noexcept{return state_==State::Committed&&first_==Error::None;}
 Error error()const noexcept{return first_;}
 State state()const noexcept{return state_;}
};
} // namespace guarded_write
