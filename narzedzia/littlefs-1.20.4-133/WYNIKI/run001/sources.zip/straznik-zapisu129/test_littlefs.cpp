// Tests the guard with real upstream littlefs; RAM callbacks, NOT an ESP adapter.
#include "WriteSession.h"
#include "lfs.h"
#include <cassert>
#include <cstdio>
#include <cstring>
using namespace guarded_write;
struct Ram {
 unsigned char disk[128][512];bool badProg=false,badSync=false;
 static Ram& self(const lfs_config*c){return *static_cast<Ram*>(c->context);}
 static int rd(const lfs_config*c,lfs_block_t b,lfs_off_t o,void*p,lfs_size_t n){assert(b<128&&o+n<=512);std::memcpy(p,self(c).disk[b]+o,n);return 0;}
 static int wr(const lfs_config*c,lfs_block_t b,lfs_off_t o,const void*p,lfs_size_t n){assert(b<128&&o+n<=512);if(self(c).badProg)return LFS_ERR_IO;std::memcpy(self(c).disk[b]+o,p,n);return 0;}
 static int er(const lfs_config*c,lfs_block_t b){assert(b<128);std::memset(self(c).disk[b],255,512);return 0;}
 static int sy(const lfs_config*c){return self(c).badSync?LFS_ERR_IO:0;}
};
struct Backend:Io {
 Ram ram;lfs_config cfg={};lfs_t fs={};lfs_file_t file={};int scenario,closes=0,syncs=0,reads=0,closeResult=99;
 explicit Backend(int mode):scenario(mode){
  std::memset(ram.disk,255,sizeof(ram.disk));cfg.context=&ram;cfg.read=Ram::rd;cfg.prog=Ram::wr;cfg.erase=Ram::er;cfg.sync=Ram::sy;
  cfg.read_size=16;cfg.prog_size=16;cfg.block_size=512;cfg.block_count=128;cfg.block_cycles=100;cfg.cache_size=64;cfg.lookahead_size=16;
  assert(lfs_format(&fs,&cfg)==0);assert(lfs_mount(&fs,&cfg)==0);assert(lfs_file_open(&fs,&file,"record",LFS_O_RDWR|LFS_O_CREAT|LFS_O_EXCL)==0);
 }
 ~Backend(){assert(closes==1);assert(lfs_unmount(&fs)==0);}
 Transfer write(std::uint64_t off,const unsigned char*p,std::size_t n)noexcept override{
  assert(off==0);ram.badProg=scenario==1;auto r=lfs_file_write(&fs,&file,p,n);return {r>=0,r>=0?static_cast<std::size_t>(r):0};
 }
 bool sync()noexcept override{syncs++;ram.badSync=scenario==2;return lfs_file_sync(&fs,&file)==0;}
 Transfer read(std::uint64_t off,unsigned char*p,std::size_t n)noexcept override{
  reads++;assert(off==0);assert(lfs_file_seek(&fs,&file,0,LFS_SEEK_SET)==0);auto r=lfs_file_read(&fs,&file,p,n);return {r>=0,r>=0?static_cast<std::size_t>(r):0};
 }
 bool close()noexcept override{
  closes++;ram.badProg=ram.badSync=false;closeResult=lfs_file_close(&fs,&file);return closeResult==0;
 }
};
int main(){
 unsigned char data[256];std::memset(data,42,sizeof(data));
 for(int mode=0;mode<3;mode++){
  Backend io(mode);
  {Session s(io,Admission::CallerVerifiedPrerequisites);
   assert(s.commit(0,data,sizeof(data))==(mode==0));assert(s.committed()==(mode==0));
   assert(s.error()==(mode==0?Error::None:mode==1?Error::Write:Error::Sync));
   assert(io.closeResult==0);assert(io.closes==1);assert(io.reads==(mode==0?1:0));assert(io.syncs==(mode==1?0:1));
   assert(s.shutdown()==(mode==0));assert(io.closes==1);
   std::printf("littlefs mode=%d committed=%d close=%d PASS\n",mode,s.committed(),io.closeResult);
  }
 }
 puts("3 real littlefs host integration scenarios PASS; no ESP/power-loss qualification");
}
