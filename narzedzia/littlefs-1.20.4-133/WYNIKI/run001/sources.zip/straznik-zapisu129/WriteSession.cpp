#include "WriteSession.h"
#include <cstring>
#include <limits>
namespace guarded_write {
Session::Session(Io&i,Admission a) noexcept:io_(i){
 if(a!=Admission::CallerVerifiedPrerequisites)fail(Error::NotAdmitted);
}
Session::~Session(){shutdown();}
void Session::fail(Error e) noexcept {
 if(first_==Error::None)first_=e;
 state_=State::Blocked;
}
bool Session::closeOnce() noexcept {
 if(closeAttempted_)return first_==Error::None;
 closeAttempted_=true; // Before external call: never retry an uncertain close.
 bool ok=io_.close();
 if(!ok)fail(Error::Close);
 return ok;
}
bool Session::shutdown() noexcept {
 if(!committed()&&first_==Error::None)fail(Error::Aborted);
 closeOnce();
 return committed();
}
bool Session::commit(std::uint64_t offset,const unsigned char* data,std::size_t size) noexcept {
 if(attempted_||closeAttempted_){fail(Error::AlreadyUsed);return false;}
 attempted_=true;
 if(first_!=Error::None){closeOnce();return false;}
 if(!data||!size||size>Capacity||offset>std::numeric_limits<std::uint64_t>::max()-size){
  fail(Error::InvalidInput);closeOnce();return false;
 }
 std::memcpy(expected_,data,size); // Snapshot; do not trust later caller mutation.
 state_=State::Writing;
 Transfer w=io_.write(offset,expected_,size);
 if(!w.certain||w.bytes!=size){fail(Error::Write);closeOnce();return false;}
 state_=State::Syncing;
 if(!io_.sync()){fail(Error::Sync);closeOnce();return false;}
 state_=State::Reading;
 Transfer r=io_.read(offset,actual_,size);
 if(!r.certain||r.bytes!=size){fail(Error::Read);closeOnce();return false;}
 if(std::memcmp(expected_,actual_,size)!=0){fail(Error::Mismatch);closeOnce();return false;}
 state_=State::Closing;
 if(!closeOnce())return false;
 state_=State::Committed;
 return true;
}
} // namespace guarded_write
