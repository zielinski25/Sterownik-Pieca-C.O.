# SPRAWDZ.ps1 (etap 223, wersja 3 - v3.56.5)
# Sprawdza pliki projektu i plik secrets.h. Niczego nie zmienia.
# Uruchom:  powershell -ExecutionPolicy Bypass -File .\SPRAWDZ.ps1

$ErrorActionPreference = "Continue"

$Projekt = "C:\Users\Rafcio\Documents\PlatformIO\sterownik-co-esp32"
if (-not (Test-Path $Projekt)) {
  $Projekt = Split-Path -Parent $PSScriptRoot
  Write-Host "Nie ma folderu projektu w domyslnej lokalizacji, uzywam: $Projekt" -ForegroundColor Yellow
}
$Src = Join-Path $Projekt "src"

$oczekiwane = @{
  "main_centrala.cpp"       = "F8C8E4F53A4BDCF1C6D3B42C313984D59D9F2B0A150D01DDE0DB37F7F2739042"
  "HistoriaPobranie.h"      = "B58D1A4C299E339798D3F229AD81177B0EE34F44DD37DAE1776BA48279A4EDE8"
  "HistoriaBilety.h"        = "339F83FDDA1219F7C925BE468787C2D102C756B2DA0366FAB1833D8F88DBDE30"
  "HistoriaPin.h"           = "547512387489BFFCFE4E7FC0ED11FA7E64A1B6F32E7764F5F67E61F51E13F307"
  "CheckedHistoryIO.h"      = "8EB1869329308CBEC2D09D087E12EB896C3BCE59E3B4099D4B295360F1BC78B9"
  "EspVfsCalls.h"           = "5FEB306F52FAA0C6099FA1DD133F09C0A37DD8538A0419FCCAB35576BA5F93CF"
  "HistoryStartup.h"        = "961E3385D4B90591C7BB9C8170CB6DF4409E7D856F8152CCF9E038BA437EEAC4"
  "HistoryBoot.h"           = "A26634C6D65900D11F82DAE0043A75D7DF81F76B3DD6266BFED727B9E24A8661"
  "BootFilesystem.h"        = "3EA3DDF118BAE45149D02BD88B3284BB54C8F18FAD7F736E382702FF982D971D"
  "Storage.h"               = "9AA0AB963E90787CF56842C36D252F361E27F780B806EE03BDB14EB59B3E0B3F"
  "Transition.h"            = "E7B8B7631FC302EA501506723520142858B86D5F399B24AD97A44D94BABE51B2"
  "AlarmBuzzerProfiles.h"   = "D7DDD929DCA6E66F62655482653DAF68D710D5573C68D89640A544922CBA100B"
  "AutoIgnitionColdTimer.h" = "7055A28C7D7BC8B817F75875A2CD2499F4B22370AA483E88F26543EC67C35F47"
  "MieszadloTrocinyAuto.h"  = "108CF30D609D5D02EC0A6645538D687FD4801CB3C9349CC0BC6088995D1DB0D9"
  "SolarDailyArchive.h"     = "DF2B0B8FEABB99B8F07095122330E3173AEC180BCEC3511188C52AAC3069122D"
}

Write-Host ""
Write-Host "Sprawdzam folder: $Src" -ForegroundColor Cyan
Write-Host ""

$dobre = 0
$zle = 0
foreach ($nazwa in ($oczekiwane.Keys | Sort-Object)) {
  $p = Join-Path $Src $nazwa
  if (-not (Test-Path $p)) {
    $p2 = Join-Path (Join-Path $Projekt "include") $nazwa
    if (Test-Path $p2) { $p = $p2 }
  }
  if (-not (Test-Path $p)) {
    Write-Host ("  BRAK       {0}" -f $nazwa) -ForegroundColor Red
    ++$zle
    continue
  }
  $h = (Get-FileHash -Path $p -Algorithm SHA256).Hash
  if ($h -eq $oczekiwane[$nazwa]) {
    Write-Host ("  OK         {0}" -f $nazwa) -ForegroundColor Green
    ++$dobre
  } else {
    Write-Host ("  INNY       {0}" -f $nazwa) -ForegroundColor Red
    Write-Host ("             jest:   {0}" -f $h)
    Write-Host ("             ma byc: {0}" -f $oczekiwane[$nazwa])
    ++$zle
  }
}

# --- sekcja secrets.h -------------------------------------------------------
Write-Host ""
Write-Host "--- secrets.h ---" -ForegroundColor Cyan
$sekr = Join-Path $Src "secrets.h"
$wymagane = @("SECRET_WIFI_AP_SSID","SECRET_WIFI_AP_PASSWORD","SECRET_OTA_HASLO","SECRET_FIREBASE_PASS","SECRET_CMD_TOKEN","SECRET_HISTORIA_TOKEN")

if (-not (Test-Path $sekr)) {
  Write-Host "  BRAK pliku secrets.h - bez niego sie NIE SKOMPILUJE." -ForegroundColor Red
  ++$zle
} else {
  foreach ($klucz in $wymagane) {
    $m = Select-String -Path $sekr -Pattern ('^\s*#define\s+' + $klucz + '\s+"([^"]*)"')
    if (-not $m) {
      Write-Host ("  BRAK  {0}" -f $klucz) -ForegroundColor Red
      ++$zle
      continue
    }
    $wartosc = $m.Matches[0].Groups[1].Value
    if ($wartosc -eq "") {
      Write-Host ("  PUSTE {0}" -f $klucz) -ForegroundColor Red
      ++$zle
    } elseif ($wartosc -like "ZMIEN-MNIE*" -or $wartosc -like "WKLEJ*") {
      Write-Host ("  WZOR  {0}  (nadal tekst z przykladu - wpisz swoja wartosc)" -f $klucz) -ForegroundColor Yellow
      ++$zle
    } elseif ($klucz -eq "SECRET_WIFI_AP_PASSWORD" -and $wartosc.Length -lt 8) {
      Write-Host ("  KROTKI {0}  ({1} znakow, WiFi wymaga min. 8)" -f $klucz, $wartosc.Length) -ForegroundColor Red
      ++$zle
    } elseif ($klucz -eq "SECRET_HISTORIA_TOKEN" -and $wartosc.Length -lt 16) {
      Write-Host ("  KROTKI {0}  ({1} znakow, zalecane 32)" -f $klucz, $wartosc.Length) -ForegroundColor Yellow
    } else {
      Write-Host ("  OK    {0}  ({1} znakow)" -f $klucz, $wartosc.Length) -ForegroundColor Green
    }
  }
}

Write-Host ""
if ($zle -eq 0) {
  Write-Host "WYNIK: wszystko gotowe ($dobre plikow + secrets.h). Mozesz budowac." -ForegroundColor Green
} else {
  Write-Host "WYNIK: $zle rzeczy do poprawienia, $dobre plikow OK." -ForegroundColor Red
}
