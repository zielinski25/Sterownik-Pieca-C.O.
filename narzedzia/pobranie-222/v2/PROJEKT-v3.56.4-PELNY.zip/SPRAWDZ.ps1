# SPRAWDZ.ps1  (etap 222, wersja 2 - komplet naglowkow)
# Sprawdza, czy w projekcie sa WSZYSTKIE pliki wlasciwej wersji.
# Uruchom:  powershell -ExecutionPolicy Bypass -File .\SPRAWDZ.ps1
# Skrypt niczego nie zmienia - tylko czyta i wypisuje wynik.

$ErrorActionPreference = "Continue"

$Projekt = "C:\Users\Rafcio\Documents\PlatformIO\sterownik-co-esp32"
if (-not (Test-Path $Projekt)) {
  $Projekt = Split-Path -Parent $PSScriptRoot
  Write-Host "Nie ma folderu projektu w domyslnej lokalizacji, uzywam: $Projekt" -ForegroundColor Yellow
}
$Src = Join-Path $Projekt "src"

$oczekiwane = @{
  "main_centrala.cpp"       = "F89874F3390009ACD79632DB1031D04CD90E67435EDA68E2007EA7C4B3168E38"
  "HistoriaPobranie.h"      = "B58D1A4C299E339798D3F229AD81177B0EE34F44DD37DAE1776BA48279A4EDE8"
  "HistoriaBilety.h"        = "339F83FDDA1219F7C925BE468787C2D102C756B2DA0366FAB1833D8F88DBDE30"
  "HistoriaPin.h"           = "547512387489BFFCFE4E7FC0ED11FA7E64A1B6F32E7764F5F67E61F51E13F307"
  "CheckedHistoryIO.h"      = "8EB1869329308CBEC2D09D087E12EB896C3BCE59E3B4099D4B295360F1BC78B9"
  "EspVfsCalls.h"           = "5FEB306F52FAA0C6099FA1DD133F09C0A37DD8538A0419FCCAB35576BA5F93CF"
  "HistoryStartup.h"        = "961E3385D4B90591C7BB9C8170CB6DF4409E7D856F8152CCF9E038BA437EEAC4"
  "HistoryBoot.h"           = "A26634C6D65900D11F82DAE0043A75D7DF81F76B3DD6266BFED727B9E24A8661"
  "BootFilesystem.h"        = "3EA3DDF118BAE45149D02BD88B3284BB54C8F18FAD7F736E382702FF982D971D"
  "Storage.h"               = "9AA0AB963E90787CF56842C36D252F361E27F780B806EE03BDB14EB59B3E0B3F"
  "Transition.h"            = "E7B8B7631FC302EA501506723520142858B86D5F399B24AD97A44D94BABE51B2"
  "AlarmBuzzerProfiles.h"   = "D7DDD929DCA6E66F62655482653DAF68D710D5573C68D89640A544922CBA100B"
  "AutoIgnitionColdTimer.h" = "7055A28C7D7BC8B817F75875A2CD2499F4B22370AA483E88F26543EC67C35F47"
  "MieszadloTrocinyAuto.h"  = "108CF30D609D5D02EC0A6645538D687FD4801CB3C9349CC0BC6088995D1DB0D9"
  "SolarDailyArchive.h"     = "DF2B0B8FEABB99B8F07095122330E3173AEC180BCEC3511188C52AAC3069122D"
}

Write-Host ""
Write-Host "Sprawdzam folder: $Src" -ForegroundColor Cyan
Write-Host ""

$dobre = 0
$zle = 0
foreach ($nazwa in ($oczekiwane.Keys | Sort-Object)) {
  $p = Join-Path $Src $nazwa
  if (-not (Test-Path $p)) {
    # moze lezy w include\
    $p2 = Join-Path (Join-Path $Projekt "include") $nazwa
    if (Test-Path $p2) { $p = $p2 }
  }
  if (-not (Test-Path $p)) {
    Write-Host ("  BRAK       {0}" -f $nazwa) -ForegroundColor Red
    ++$zle
    continue
  }
  $h = (Get-FileHash -Path $p -Algorithm SHA256).Hash
  if ($h -eq $oczekiwane[$nazwa]) {
    Write-Host ("  OK         {0}" -f $nazwa) -ForegroundColor Green
    ++$dobre
  } else {
    Write-Host ("  INNY       {0}" -f $nazwa) -ForegroundColor Red
    Write-Host ("             jest: {0}" -f $h)
    Write-Host ("             ma byc: {0}" -f $oczekiwane[$nazwa])
    ++$zle
  }
}

Write-Host ""
$sekr = Join-Path $Src "secrets.h"
if (Test-Path $sekr) {
  $m = Select-String -Path $sekr -Pattern 'SECRET_HISTORIA_TOKEN\s+"([^"]*)"'
  if (-not $m) {
    Write-Host "  secrets.h  BRAK linii SECRET_HISTORIA_TOKEN (dopisz)" -ForegroundColor Yellow
  } elseif ($m.Matches.Groups[1].Value.Length -lt 16) {
    Write-Host "  secrets.h  token jest za krotki albo pusty (dopisz wlasny, min. 32 znaki)" -ForegroundColor Yellow
  } else {
    Write-Host "  secrets.h  token jest (dlugosc OK)" -ForegroundColor Green
  }
} else {
  Write-Host "  secrets.h  BRAK pliku (skopiuj z projektu albo z secrets.h.example)" -ForegroundColor Yellow
}

Write-Host ""
if ($zle -eq 0) {
  Write-Host "WYNIK: wszystkie $dobre plikow sa wlasciwe. Mozesz budowac." -ForegroundColor Green
} else {
  Write-Host "WYNIK: $zle plikow brakuje albo ma zla wersje, $dobre jest OK. Skopiuj je z rozpakietego ZIP-a." -ForegroundColor Red
}
