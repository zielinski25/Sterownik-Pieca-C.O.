$ErrorActionPreference = 'Stop'

# B15 — bezpieczny build gate dla v3.31.20.
# NIE wykonuje uploadu. Tymczasowo podmienia src\main_centrala.cpp kandydatem,
# buduje oba środowiska i zawsze przywraca poprzedni plik.

$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$Pio = Join-Path $env:USERPROFILE '.platformio\penv\Scripts\pio.exe'
$Project = $Root
$Candidate = Join-Path $Project 'main_centrala_v3.31.20_DIAG_POLICY_READY_FOR_BUILD.cpp'
$Target = Join-Path $Project 'src\main_centrala.cpp'
$Backup = Join-Path $Project 'src\main_centrala.cpp.bak_before_v3.31.20'
$Log = Join-Path $Project ('b15_build_' + (Get-Date -Format 'yyyyMMdd_HHmmss') + '.log')

function Fail([string]$Message) {
    Write-Host "B15: FAIL — $Message" -ForegroundColor Red
    throw $Message
}

Write-Host '=== B15 v3.31.20 BUILD GATE ==='
Write-Host "Projekt: $Project"
Write-Host "PIO:     $Pio"

if (-not (Test-Path -LiteralPath $Pio)) { Fail 'Nie znaleziono PlatformIO pod %USERPROFILE%\\.platformio\\penv\\Scripts\\pio.exe.' }
if (-not (Test-Path -LiteralPath (Join-Path $Project 'platformio.ini'))) { Fail 'Brak platformio.ini w katalogu projektu.' }
if (-not (Test-Path -LiteralPath $Candidate)) { Fail 'Brak kandydata v3.31.20 obok skryptu.' }
if (-not (Test-Path -LiteralPath $Target)) { Fail 'Brak src\\main_centrala.cpp.' }

$Required = @(
    'boards\esp32-s3-n16r8.json',
    'partitions.csv',
    'scripts\patch_ds18b20.py',
    'lib\dhtESP32-rmt\dhtESP32-rmt.h',
    'lib\dhtESP32-rmt\dhtESP32-rmt.cpp'
)
foreach ($rel in $Required) {
    if (-not (Test-Path -LiteralPath (Join-Path $Project $rel))) { Fail "Brak wymaganego pliku: $rel" }
}

$targetText = Get-Content -LiteralPath $Target -Raw
$candidateText = Get-Content -LiteralPath $Candidate -Raw
if ($targetText -notmatch 'FIRMWARE_VERSION\s*=\s*"v3\.31\.19"') { Fail 'src\\main_centrala.cpp nie jest potwierdzonym baseline v3.31.19 — przerwano bez zmian.' }
if ($candidateText -notmatch 'FIRMWARE_VERSION\s*=\s*"v3\.31\.20"') { Fail 'Kandydat nie ma znacznika v3.31.20.' }

& $Pio --version 2>&1 | Tee-Object -FilePath $Log
"`n=== pio project config ===" | Tee-Object -FilePath $Log -Append
& $Pio project config 2>&1 | Tee-Object -FilePath $Log -Append

Copy-Item -LiteralPath $Target -Destination $Backup -Force
try {
    Copy-Item -LiteralPath $Candidate -Destination $Target -Force
    "`n=== BUILD esp32-s3-n16r8 ===" | Tee-Object -FilePath $Log -Append
    & $Pio run -e esp32-s3-n16r8 2>&1 | Tee-Object -FilePath $Log -Append
    if ($LASTEXITCODE -ne 0) { Fail "Build esp32-s3-n16r8 zakończony kodem $LASTEXITCODE." }

    "`n=== BUILD esp32-s3-ota ===" | Tee-Object -FilePath $Log -Append
    & $Pio run -e esp32-s3-ota 2>&1 | Tee-Object -FilePath $Log -Append
    if ($LASTEXITCODE -ne 0) { Fail "Build esp32-s3-ota zakończony kodem $LASTEXITCODE." }

    Write-Host 'B15: oba buildy zakończone kodem 0.' -ForegroundColor Green
}
finally {
    Copy-Item -LiteralPath $Backup -Destination $Target -Force
    Remove-Item -LiteralPath $Backup -Force -ErrorAction SilentlyContinue
    Write-Host 'Przywrócono src\main_centrala.cpp do stanu sprzed B15.'
}

Write-Host "Log B15: $Log"
Write-Host 'UWAGA: B15 nie wykonuje uploadu ani OTA.'
