Import("env")
import os

# [FIX 2] nettigo/DS18B20 (biblioteka z API begin/available/request/
# readTemperature, zgodnym z main.cpp) ma w nagłówku:
#     #include <avr/pgmspace.h>
# co jest specyficzne dla AVR (Uno/Mega) i nie istnieje na ESP32.
# Biblioteka potrzebuje stąd tylko makr PROGMEM/__FlashStringHelper, a te
# ESP32 i tak dostarcza przez Arduino.h (zaimportowany wyżej w tym samym
# pliku) — więc ta linijka jest na ESP32 zbędna, wystarczy ją usunąć.
#
# Ten skrypt patchuje plik w .pio/libdeps automatycznie przy KAŻDYM buildzie,
# więc przeżywa `pio run -t clean` i aktualizacje biblioteki — nie trzeba
# ręcznie edytować niczego w .pio za każdym razem.

def patch_ds18b20():
    libdeps_dir = env.get("PROJECT_LIBDEPS_DIR")
    pioenv = env.get("PIOENV")
    header_path = os.path.join(libdeps_dir, pioenv, "DS18B20", "DS18B20.h")

    if not os.path.isfile(header_path):
        # Biblioteka jeszcze nie ściągnięta (np. pierwszy przebieg Library
        # Managera) — nic do zrobienia, kolejny build i tak ją złapie.
        return

    with open(header_path, "r") as f:
        content = f.read()

    if "avr/pgmspace.h" not in content:
        # Już załatane (albo inna wersja pliku) — nic do zrobienia.
        return

    patched = content.replace("#include <avr/pgmspace.h>\n", "")
    with open(header_path, "w") as f:
        f.write(patched)

    print(f"[patch_ds18b20] Usunieto avr/pgmspace.h z {header_path}")

patch_ds18b20()
