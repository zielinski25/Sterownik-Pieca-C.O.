package pl.sterownikco.dev

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.view.animation.DecelerateInterpolator
import kotlin.math.*

/**
 * Native telemetry renderer. No WebView/HTML.
 * Visual goals: polished telemetry studio, restrained chrome, clear hierarchy,
 * readable axes, subtle single-series area, GAP zones and compact inspection tooltip.
 */
class ProfessionalTelemetryChartView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
) : View(context, attrs) {

    enum class Mode { SPLIT, COMMON, NORMALIZED, FROM_START, XY }
    enum class LineStyle { SMOOTH, STEPPED }

    data class Series(
        val id: String,
        val label: String,
        val channel: Int?,
        val servo: Boolean = false,
        val scale: Double = 0.1,
        val unit: String = "°C",
        val accent: Int,
    )

    var onSelectionChanged: ((String) -> Unit)? = null

    private var rows: List<TelemetryRecord> = emptyList()
    private var allSeries: List<Series> = emptyList()
    private val selected = LinkedHashSet<String>()
    private var mode = Mode.COMMON
    private var lineStyle = LineStyle.SMOOTH
    private var realOnly = true
    private var anomalyFilter = true
    private var showBand = false
    private var fixedMin: Double? = null
    private var fixedMax: Double? = null
    private var zoom = 1f
    private var offset = 1f
    private var crosshairX: Float? = null
    private var downX = 0f
    private var downAt = 0L
    private var moved = false
    private var lastTapAt = 0L
    private var animationProgress = 1f
    private var animator: ValueAnimator? = null

    private var zoomFocusX = 0.5f
    private var previousZoom = 1f

    private val scaleDetector = ScaleGestureDetector(context, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScaleBegin(detector: ScaleGestureDetector): Boolean {
            zoomFocusX = ((detector.focusX - plotLeft()) / max(1f, plotRight() - plotLeft())).coerceIn(0f, 1f)
            previousZoom = zoom
            return true
        }
        override fun onScale(detector: ScaleGestureDetector): Boolean {
            val next = (zoom * detector.scaleFactor).coerceIn(1f, 24f)
            if (abs(next - zoom) > 0.001f) {
                val oldCount = max(2, (rows.size / zoom).roundToInt().coerceAtMost(rows.size))
                val oldMaxStart = max(0, rows.size - oldCount)
                val oldStart = oldMaxStart * (1f - offset)
                val anchorIndex = oldStart + (oldCount - 1) * zoomFocusX
                zoom = next
                val newCount = max(2, (rows.size / zoom).roundToInt().coerceAtMost(rows.size))
                val newMaxStart = max(0, rows.size - newCount)
                val newStart = (anchorIndex - (newCount - 1) * zoomFocusX).coerceIn(0f, newMaxStart.toFloat())
                offset = if (newMaxStart <= 0) 1f else 1f - (newStart / newMaxStart).coerceIn(0f, 1f)
                invalidate()
            }
            return true
        }
    })

    private val outerPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val plotPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val gridPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val axisPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val axisText = Paint(Paint.ANTI_ALIAS_FLAG)
    private val titleText = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tooltipPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tooltipStroke = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tooltipText = Paint(Paint.ANTI_ALIAS_FLAG)
    private val crosshairPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val badgePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val badgeText = Paint(Paint.ANTI_ALIAS_FLAG)
    private val bandPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var alarmLoLo: Double? = null
    private var alarmLo: Double? = null
    private var alarmHi: Double? = null
    private var alarmHiHi: Double? = null
    private var showAlarmLines = false

    init {
        isClickable = true
        isFocusable = true
        gridPaint.color = 0x2A5A7C92
        axisPaint.color = 0x56738CA5
        axisPaint.strokeWidth = dp(1f)
        axisText.color = 0xFF8EA6BA.toInt()
        axisText.textSize = dp(10f)
        titleText.color = 0xFF7E9AB0.toInt()
        titleText.textSize = dp(8.8f)
        tooltipPaint.color = 0xF0121F31.toInt()
        tooltipStroke.color = 0x765F7890
        tooltipStroke.style = Paint.Style.STROKE
        tooltipStroke.strokeWidth = dp(1f)
        tooltipText.color = Color.WHITE
        crosshairPaint.color = 0xA06F94AF.toInt()
        crosshairPaint.strokeWidth = dp(1f)
        crosshairPaint.pathEffect = DashPathEffect(floatArrayOf(dp(5f), dp(5f)), 0f)
        bandPaint.color = 0x143CC8F0
    }

    fun setCatalog(series: List<Series>) {
        allSeries = series
        if (selected.isEmpty()) {
            series.take(if (series.any { it.servo }) 2 else 4).forEach { selected += it.id }
        }
        invalidate()
    }

    fun setData(value: List<TelemetryRecord>, animate: Boolean = true) {
        rows = value.asSequence()
            .filter { it.ts > 0L }
            .sortedWith(compareBy<TelemetryRecord> { it.ts }.thenBy { it.seq })
            .fold(LinkedHashMap<Long, TelemetryRecord>()) { acc, row ->
                // Last row for a timestamp wins, preventing vertical spikes when shards overlap.
                acc[row.ts] = row
                acc
            }.values.toList()
        zoom = 1f
        offset = 1f
        crosshairX = null
        if (animate) startReveal() else {
            animationProgress = 1f
            post { invalidate() }
        }
        post { invalidate() }
    }

    private fun startReveal() {
        animator?.cancel()
        animationProgress = 0f
        animator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 620L
            // Whatever ends the animation (finish, cancel, system "remove animations"), the chart must end fully drawn.
            addListener(object : android.animation.AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: android.animation.Animator) { animationProgress = 1f; invalidate() }
            })
            interpolator = DecelerateInterpolator(1.55f)
            addUpdateListener {
                animationProgress = it.animatedValue as Float
                invalidate()
            }
            start()
        }
    }

    fun setSeriesEnabled(id: String, enabled: Boolean) {
        if (enabled) selected += id else selected -= id
        if (selected.isEmpty()) allSeries.firstOrNull()?.let { selected += it.id }
        invalidate()
    }

    fun isSeriesEnabled(id: String): Boolean = selected.contains(id)
    fun selectedSeries(): List<Series> = allSeries.filter { selected.contains(it.id) }
    fun snapshot(): List<TelemetryRecord> = rows
    fun currentMode(): Mode = mode
    fun currentZoom(): Float = zoom
    fun isRealOnly(): Boolean = realOnly
    fun isAnomalyFilter(): Boolean = anomalyFilter
    fun isSmooth(): Boolean = lineStyle == LineStyle.SMOOTH
    fun isBandVisible(): Boolean = showBand

    data class SummaryStats(val rangeText: String, val pointsText: String)

    fun readouts(): List<String> {
        if (rows.isEmpty()) return emptyList()
        return selectedSeries().mapNotNull { s ->
            val values = buildValues(s, rows).mapNotNull { it.second }
            values.lastOrNull()?.let { "${s.label}: ${fmt(it)}${if (s.servo) "%" else s.unit}" }
        }
    }

    fun summaryStats(): SummaryStats {
        if (rows.isEmpty() || selected.isEmpty()) return SummaryStats("—", "0")
        val active = selectedSeries()
        if (active.isEmpty()) return SummaryStats("—", rows.size.toString())
        val units = active.map { if (it.servo) "%" else it.unit }.distinct()
        if (units.size > 1) return SummaryStats("wiele jednostek", rows.size.toString())
        val all = active.flatMap { s -> buildValues(s, rows).mapNotNull { it.second } }
        if (all.isEmpty()) return SummaryStats("—", rows.size.toString())
        val lo = all.minOrNull() ?: 0.0
        val hi = all.maxOrNull() ?: 0.0
        return SummaryStats("${fmt(lo)}–${fmt(hi)} ${units.firstOrNull().orEmpty()}", rows.size.toString())
    }

    fun setMode(value: Mode) { mode = value; invalidate() }
    fun setLineStyle(value: LineStyle) { lineStyle = value; invalidate() }
    fun setRealOnly(value: Boolean) { realOnly = value; invalidate() }
    fun setAnomalyFilter(value: Boolean) { anomalyFilter = value; invalidate() }
    fun setFixedRange(min: Double?, max: Double?) { fixedMin = min; fixedMax = max; invalidate() }
    fun toggleBand() { showBand = !showBand; invalidate() }

    fun setAlarmLines(loLo: Double?, lo: Double?, hi: Double?, hiHi: Double?, visible: Boolean = true) {
        alarmLoLo = loLo
        alarmLo = lo
        alarmHi = hi
        alarmHiHi = hiHi
        showAlarmLines = visible
        invalidate()
    }

    fun clearAlarmLines() {
        alarmLoLo = null; alarmLo = null; alarmHi = null; alarmHiHi = null
        showAlarmLines = false
        invalidate()
    }

    fun hasAlarmLines(): Boolean = showAlarmLines && listOf(alarmLoLo, alarmLo, alarmHi, alarmHiHi).any { it != null }

    fun zoomBy(factor: Float) {
        val target = (zoom * factor).coerceIn(1f, 24f)
        ValueAnimator.ofFloat(zoom, target).apply {
            duration = 220L
            interpolator = DecelerateInterpolator(1.5f)
            addUpdateListener { zoom = it.animatedValue as Float; invalidate() }
        }.start()
    }

    fun resetViewport(animated: Boolean = false) {
        if (!animated) {
            zoom = 1f; offset = 1f; crosshairX = null; invalidate(); return
        }
        ValueAnimator.ofFloat(zoom, 1f).apply {
            duration = 240L
            interpolator = DecelerateInterpolator(1.6f)
            addUpdateListener {
                zoom = it.animatedValue as Float
                offset += (1f - offset) * .16f
                invalidate()
            }
            addListener(object : android.animation.AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: android.animation.Animator) {
                    zoom = 1f; offset = 1f; crosshairX = null; invalidate()
                }
            })
            start()
        }
    }

    override fun onDetachedFromWindow() {
        animator?.cancel()
        // cancel() leaves the reveal progress where it stopped (often 0) - the lines would stay invisible.
        animationProgress = 1f
        super.onDetachedFromWindow()
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        scaleDetector.onTouchEvent(event)
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = event.x
                downAt = System.currentTimeMillis()
                moved = false
                crosshairX = plotLeft().let { max(it, min(event.x, plotRight())) }
                dispatchSelection()
                invalidate()
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                if (abs(event.x - downX) > dp(7f)) moved = true
                if (!scaleDetector.isInProgress && moved && zoom > 1.02f) {
                    val span = max(dp(1f), plotRight() - plotLeft())
                    offset = (offset - (event.x - downX) / span * .92f).coerceIn(0f, 1f)
                    downX = event.x
                }
                crosshairX = event.x.coerceIn(plotLeft(), plotRight())
                dispatchSelection()
                invalidate()
                return true
            }
            MotionEvent.ACTION_UP -> {
                val now = System.currentTimeMillis()
                if (!moved && now - downAt < 280L && now - lastTapAt < 380L) resetViewport(true)
                lastTapAt = now
                dispatchSelection()
                invalidate()
                return true
            }
            MotionEvent.ACTION_CANCEL -> return true
        }
        return true
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat(); val h = height.toFloat()
        if (w < dp(120f) || h < dp(160f)) return

        drawOuter(canvas, w, h)
        if (rows.size < 2 || selected.isEmpty()) {
            drawEmpty(canvas, if (rows.isEmpty()) "Brak danych dla wybranego zakresu" else "Wybierz serię do analizy")
            return
        }

        val (start, end) = visibleSlice()
        if (end - start < 2) {
            drawEmpty(canvas, "Powiększony zakres ma za mało punktów")
            return
        }
        val viewRows = rows.subList(start, end)
        val minTs = viewRows.first().ts
        val maxTs = viewRows.last().ts
        if (maxTs <= minTs) return

        if (mode == Mode.XY) drawXy(canvas, viewRows) else drawTimeSeries(canvas, viewRows, minTs, maxTs)
        drawAxes(canvas, minTs, maxTs)
        crosshairX?.let { drawCrosshair(canvas, viewRows, it, minTs, maxTs) }
        drawContextBar(canvas, start, end)
    }

    private fun drawOuter(canvas: Canvas, w: Float, h: Float) {
        outerPaint.shader = LinearGradient(0f, 0f, w, h, 0xFF0C1B2C.toInt(), 0xFF07131F.toInt(), Shader.TileMode.CLAMP)
        canvas.drawRoundRect(dp(2f), dp(2f), w-dp(2f), h-dp(2f), dp(18f), dp(18f), outerPaint)
        outerPaint.shader = null
        val cap = Paint(Paint.ANTI_ALIAS_FLAG)
        cap.color = 0xFF6F8BA0.toInt(); cap.textSize = dp(7.8f); cap.typeface = Typeface.create("sans-serif", Typeface.BOLD)
        canvas.drawText(if (mode == Mode.XY) "KORELACJA" else if (selected.size <= 1) "1 SERIA" else "${selected.size} SERIE", dp(12f), dp(17f), cap)
        cap.textAlign = Paint.Align.RIGHT
        canvas.drawText(if (realOnly) "REAL" else "RAW", w-dp(12f), dp(17f), cap)
        cap.textAlign = Paint.Align.LEFT
        outerPaint.style = Paint.Style.STROKE
        outerPaint.strokeWidth = dp(1f)
        outerPaint.color = 0x4A334A5D
        canvas.drawRoundRect(dp(2f), dp(2f), w-dp(2f), h-dp(2f), dp(18f), dp(18f), outerPaint)
        outerPaint.style = Paint.Style.FILL
    }

    private fun drawEmpty(canvas: Canvas, message: String) {
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = 0xFF8EA6BA.toInt(); textSize = dp(12f); typeface = Typeface.create("sans-serif", Typeface.BOLD)
        }
        p.textAlign = Paint.Align.CENTER
        canvas.drawText(message, width/2f, height/2f, p)
        p.textAlign = Paint.Align.LEFT
    }

    private fun drawTimeSeries(canvas: Canvas, viewRows: List<TelemetryRecord>, minTs: Long, maxTs: Long) {
        val series = selectedSeries()
        val left = plotLeft(); val right = plotRight(); val top = plotTop(); val bottom = plotBottom()
        val prepared = series.map { it to buildValues(it, viewRows) }
        val finiteAll = prepared.flatMap { it.second.mapNotNull { p -> p.second } }
        if (finiteAll.isEmpty()) {
            drawEmpty(canvas, if (realOnly) "Brak świeżych danych" else "Brak danych")
            return
        }

        val common = fixedMin?.let { fm -> fixedMax?.let { fx -> fm to fx } } ?: rangeFor(finiteAll)
        val groups = prepared.groupBy { it.first.unit to it.first.servo }
        val useSplit = mode == Mode.SPLIT && groups.size > 1
        val leftSeries = if (useSplit) prepared.filter { it.first.unit == prepared.first().first.unit } else prepared
        val rightSeries = if (useSplit) prepared.filter { it.first.unit != prepared.first().first.unit } else emptyList()
        val leftVals = leftSeries.flatMap { it.second.mapNotNull { p -> p.second } }
        val rightVals = rightSeries.flatMap { it.second.mapNotNull { p -> p.second } }
        val leftRange = if (mode == Mode.NORMALIZED) 0.0 to 100.0 else if (mode == Mode.FROM_START) -100.0 to 100.0 else (fixedMin to fixedMax).takeUnless { it.first == null || it.second == null }?.let { it.first!! to it.second!! } ?: rangeFor(leftVals.ifEmpty { finiteAll })
        val rightRange = if (rightVals.isNotEmpty()) rangeFor(rightVals) else leftRange

        val plotGradient = LinearGradient(left, top, right, bottom, 0xFF0C2033.toInt(), 0xFF091724.toInt(), Shader.TileMode.CLAMP)
        plotPaint.shader = plotGradient
        canvas.drawRoundRect(left-dp(8f), top-dp(12f), right+dp(4f), bottom+dp(7f), dp(18f), dp(18f), plotPaint)
        plotPaint.shader = null

        if (maxTs - minTs >= 36L * 3600L) {
            val dayPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = 0x0B65AFC6 }
            val zone = java.time.ZoneId.of("Europe/Warsaw")
            var day = java.time.Instant.ofEpochSecond(minTs).atZone(zone).toLocalDate().atStartOfDay(zone).toEpochSecond()
            var flip = false
            while (day < maxTs) {
                val next = java.time.Instant.ofEpochSecond(day).atZone(zone).plusDays(1).toEpochSecond()
                val x1 = left + (right-left) * ((max(day,minTs)-minTs).toFloat()/max(1f,(maxTs-minTs).toFloat()))
                val x2 = left + (right-left) * ((min(next,maxTs)-minTs).toFloat()/max(1f,(maxTs-minTs).toFloat()))
                if (flip) canvas.drawRect(x1,top,x2,bottom,dayPaint)
                flip=!flip; day=next
            }
        }

        // Instrument-style grid: strong major lines, almost invisible minor structure.
        val framePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = dp(1f)
            color = 0x4C46677D
        }
        canvas.drawRoundRect(left-dp(6f), top-dp(8f), right+dp(3f), bottom+dp(5f), dp(14f), dp(14f), framePaint)
        gridPaint.strokeWidth = dp(.65f)
        gridPaint.color = 0x2B5D7B8D
        for (i in 0..5) {
            val x = left + (right-left) * i/5f
            canvas.drawLine(x, top, x, bottom, gridPaint)
        }
        for (i in 0..8) {
            val y = top + (bottom-top) * i/8f
            gridPaint.color = if (i % 2 == 0) 0x355B788A else 0x1E4C687A
            canvas.drawLine(left, y, right, y, gridPaint)
        }

        if (showAlarmLines && mode != Mode.XY) {
            drawAlarmLine(canvas, alarmLoLo, "LoLo", 0xB0E06B82.toInt(), common.first, common.second, left, right, top, bottom)
            drawAlarmLine(canvas, alarmLo, "Lo", 0xB0C99B4A.toInt(), common.first, common.second, left, right, top, bottom)
            drawAlarmLine(canvas, alarmHi, "Hi", 0xB0C99B4A.toInt(), common.first, common.second, left, right, top, bottom)
            drawAlarmLine(canvas, alarmHiHi, "HiHi", 0xB0E06B82.toInt(), common.first, common.second, left, right, top, bottom)
        }

        drawGaps(canvas, viewRows, minTs, maxTs, left, right, top, bottom)

        if (showBand && prepared.size >= 2 && !useSplit && mode == Mode.COMMON) {
            drawEnvelopeBand(canvas, prepared, minTs, maxTs, left, right, top, bottom, common.first, common.second)
        }

        prepared.forEach { (s, pts) ->
            if (pts.none { it.second != null }) return@forEach
            val range = if (useSplit && s in rightSeries.map { it.first }) rightRange else if (mode == Mode.NORMALIZED) 0.0 to 100.0 else if (mode == Mode.FROM_START) -100.0 to 100.0 else if (mode == Mode.COMMON || mode == Mode.SPLIT) common else rangeFor(pts.mapNotNull { it.second })
            drawOneSeries(canvas, s, pts, minTs, maxTs, left, right, top, bottom, range.first, range.second)
        }
        drawLatestMarker(canvas, prepared, minTs, maxTs, left, right, top, bottom, common)
    }

    private fun drawAlarmLine(canvas: Canvas, value: Double?, label: String, color: Int, lo: Double, hi: Double, left: Float, right: Float, top: Float, bottom: Float) {
        if (value == null || !value.isFinite() || hi <= lo) return
        val n = ((value - lo) / (hi - lo)).toFloat().coerceIn(0f, 1f)
        val y = bottom - (bottom - top) * n
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = dp(1f)
            this.color = color
            pathEffect = DashPathEffect(floatArrayOf(dp(4f), dp(5f)), 0f)
        }
        canvas.drawLine(left, y, right, y, p)
        val t = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            this.color = color or 0xFF000000.toInt()
            textSize = dp(7.2f)
            typeface = Typeface.DEFAULT_BOLD
        }
        canvas.drawText("$label ${fmt(value)}", left + dp(4f), y - dp(3f), t)
    }

    private fun drawLatestMarker(canvas: Canvas, prepared: List<Pair<Series, List<Pair<Long, Double?>>>>, minTs: Long, maxTs: Long, left: Float, right: Float, top: Float, bottom: Float, common: Pair<Double,Double>) {
        if (maxTs <= minTs) return
        val latestTs = prepared.flatMap { it.second.filter { p -> p.second != null } }.maxOfOrNull { it.first } ?: return
        val lx = left + (right-left) * ((latestTs-minTs).toFloat()/max(1f,(maxTs-minTs).toFloat()))
        val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color=0x4F7A93A8; strokeWidth=dp(1f); pathEffect=DashPathEffect(floatArrayOf(dp(3f),dp(4f)),0f)
        }
        canvas.drawLine(lx,top,lx,bottom,linePaint)
        val labelPaint=Paint(Paint.ANTI_ALIAS_FLAG).apply{
            color=0xFFACC0CE.toInt();textSize=dp(7.4f);typeface=Typeface.DEFAULT_BOLD;textAlign=Paint.Align.CENTER
        }
        canvas.drawText("OSTATNI",lx.coerceIn(left+dp(28f),right-dp(28f)),top+dp(10f),labelPaint)
        prepared.take(5).forEachIndexed { idx, (series, pts) ->
            val last = pts.lastOrNull { it.second != null } ?: return@forEachIndexed
            val xx = left + (right-left) * ((last.first-minTs).toFloat()/max(1f,(maxTs-minTs).toFloat()))
            val yy = pointYForRange(series,last.second!!,top,bottom,common) ?: return@forEachIndexed
            val halo=Paint(Paint.ANTI_ALIAS_FLAG).apply{color=Color.argb(52,Color.red(series.accent),Color.green(series.accent),Color.blue(series.accent))}
            val dot=Paint(Paint.ANTI_ALIAS_FLAG).apply{color=series.accent}
            canvas.drawCircle(xx,yy,dp(6f),halo);canvas.drawCircle(xx,yy,dp(2.9f),dot)
            if (prepared.size <= 4) drawEndpointLabel(canvas, series, last.second!!, yy, right, top, bottom, idx)
        }
    }

    private fun drawEndpointLabel(canvas: Canvas, series: Series, value: Double, y: Float, right: Float, top: Float, bottom: Float, slot: Int) {
        val w = dp(54f)
        val h = dp(18f)
        val x2 = right - dp(3f)
        val yy = (y - h/2f + (slot % 3) * dp(6f)).coerceIn(top, bottom-h)
        val x1 = x2 - w
        val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(220, 10, 25, 39) }
        val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style=Paint.Style.STROKE; strokeWidth=dp(.8f); color=Color.argb(120,Color.red(series.accent),Color.green(series.accent),Color.blue(series.accent)) }
        canvas.drawRoundRect(x1,yy,x2,yy+h,dp(8f),dp(8f),fill)
        canvas.drawRoundRect(x1,yy,x2,yy+h,dp(8f),dp(8f),stroke)
        val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply{color=series.accent}
        canvas.drawCircle(x1+dp(7f),yy+h/2f,dp(2.0f),dot)
        val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply{color=Color.WHITE;textSize=dp(7.1f);typeface=Typeface.create("sans-serif",Typeface.BOLD)}
        canvas.drawText(fmt(value) + if(series.servo) "%" else series.unit, x1+dp(12f), yy+dp(12.2f), tp)
    }

    private fun pointYForRange(series: Series, value: Double, top: Float, bottom: Float, common: Pair<Double,Double>): Float? {
        val v=transformValue(series,value,0,listOf(0L to value))
        val range=when(mode){
            Mode.NORMALIZED->0.0 to 100.0
            Mode.FROM_START->-100.0 to 100.0
            Mode.SPLIT->fixedMin?.let{fm->fixedMax?.let{fx->fm to fx}}?:rangeFor(buildValues(series,rows).mapNotNull{it.second})
            else->common
        }
        val n=((v-range.first)/max(1e-9,range.second-range.first)).toFloat().coerceIn(0f,1f)
        return bottom-(bottom-top)*n
    }

    private fun drawOneSeries(canvas: Canvas, s: Series, pts: List<Pair<Long, Double?>>, minTs: Long, maxTs: Long, left: Float, right: Float, top: Float, bottom: Float, lo: Double, hi: Double) {
        val glow = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE; strokeWidth = dp(4.2f); strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
            color = Color.argb(26, Color.red(s.accent), Color.green(s.accent), Color.blue(s.accent)); setShadowLayer(dp(3.5f),0f,0f,Color.argb(28,Color.red(s.accent),Color.green(s.accent),Color.blue(s.accent)))
        }
        val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE; strokeWidth = dp(1.85f); strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND; color = s.accent
        }
        var prevX: Float? = null; var prevY: Float? = null; var prevTs: Long? = null
        var lastPoint: Pair<Float,Float>? = null
        val revealTs = minTs + ((maxTs-minTs) * animationProgress).toLong()

        pts.forEachIndexed { idx, (ts, raw) ->
            if (ts > revealTs) return@forEachIndexed
            if (raw == null || (prevTs != null && ts - prevTs!! > GAP_BREAK_SECONDS)) {
                prevX = null; prevY = null; prevTs = null
                return@forEachIndexed
            }
            val v = transformValue(s, raw, idx, pts)
            val x = left + (right-left) * ((ts-minTs).toFloat() / max(1f,(maxTs-minTs).toFloat()))
            val norm = ((v-lo) / max(1e-9,hi-lo)).toFloat().coerceIn(0f,1f)
            val y = bottom - (bottom-top) * norm
            if (prevX != null && prevY != null) {
                if (lineStyle == LineStyle.STEPPED) {
                    canvas.drawLine(prevX!!, prevY!!, x, prevY!!, glow); canvas.drawLine(x, prevY!!, x, y, glow)
                    canvas.drawLine(prevX!!, prevY!!, x, prevY!!, line); canvas.drawLine(x, prevY!!, x, y, line)
                } else {
                    val path = Path().apply {
                        moveTo(prevX!!, prevY!!)
                        val dx = (x-prevX!!)
                        cubicTo(prevX!!+dx*.32f, prevY!!, prevX!!+dx*.68f, y, x, y)
                    }
                    canvas.drawPath(path, glow); canvas.drawPath(path, line)
                }
            }
            prevX=x;prevY=y;prevTs=ts;lastPoint=x to y
        }
        // Single-series mode gets a restrained area fill so the latest trajectory is easier to read.
        if (selectedSeries().size == 1 && lineStyle == LineStyle.SMOOTH) {
            // Rebuild the visible segment as a filled path; this is intentionally subtle.
            val area = Path()
            var startedArea = false
            var lastAx = left
            pts.forEachIndexed { idx, (ts, raw) ->
                if (ts > revealTs || raw == null || (idx > 0 && pts[idx-1].second != null && ts - pts[idx-1].first > GAP_BREAK_SECONDS)) return@forEachIndexed
                val v = transformValue(s, raw, idx, pts)
                val x = left + (right-left) * ((ts-minTs).toFloat() / max(1f,(maxTs-minTs).toFloat()))
                val norm = ((v-lo) / max(1e-9,hi-lo)).toFloat().coerceIn(0f,1f)
                val y = bottom - (bottom-top) * norm
                if (!startedArea) { area.moveTo(x,bottom); area.lineTo(x,y); startedArea=true } else { area.lineTo(x,y) }
                lastAx=x
            }
            if (startedArea) {
                area.lineTo(lastAx,bottom); area.close()
                val aPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    style=Paint.Style.FILL
                    shader=LinearGradient(0f,top,0f,bottom,Color.argb(48,Color.red(s.accent),Color.green(s.accent),Color.blue(s.accent)),Color.argb(4,Color.red(s.accent),Color.green(s.accent),Color.blue(s.accent)),Shader.TileMode.CLAMP)
                }
                canvas.drawPath(area,aPaint)
            }
        }

        lastPoint?.let { (x,y) ->
            val halo = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(48,Color.red(s.accent),Color.green(s.accent),Color.blue(s.accent)) }
            val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply { color=s.accent }
            canvas.drawCircle(x,y,dp(7f),halo); canvas.drawCircle(x,y,dp(3.2f),dot)
        }
    }

    private fun drawGaps(canvas: Canvas, rows: List<TelemetryRecord>, minTs: Long, maxTs: Long, left: Float, right: Float, top: Float, bottom: Float) {
        val gap = Paint(Paint.ANTI_ALIAS_FLAG).apply { color=0x1B7891A8; style=Paint.Style.FILL }
        val mark = Paint(Paint.ANTI_ALIAS_FLAG).apply { color=0x706F879B.toInt(); strokeWidth=dp(1f); pathEffect=DashPathEffect(floatArrayOf(dp(3f),dp(4f)),0f) }
        var count=0
        for(i in 1 until rows.size) {
            if(rows[i].ts - rows[i-1].ts > GAP_BREAK_SECONDS && count < 18) {
                val x1=left+(right-left)*((rows[i-1].ts-minTs).toFloat()/(maxTs-minTs).toFloat())
                val x2=left+(right-left)*((rows[i].ts-minTs).toFloat()/(maxTs-minTs).toFloat())
                val mid=(x1+x2)/2f
                canvas.drawRect(x1,top,x2,bottom,gap)
                canvas.drawLine(mid,top,mid,bottom,mark)
                badgeText.color=0xFF8299AD.toInt();badgeText.textSize=dp(7.1f);badgeText.typeface=Typeface.DEFAULT_BOLD
                canvas.drawText("GAP",min(mid+dp(3f),right-dp(22f)),top+dp(10f),badgeText)
                count++
            }
        }
    }

    private fun drawAxes(canvas: Canvas, minTs: Long, maxTs: Long) {
        val l=plotLeft();val r=plotRight();val t=plotTop();val b=plotBottom()
        canvas.drawLine(l,t,l,b,axisPaint);canvas.drawLine(l,b,r,b,axisPaint)
        titleText.textSize=dp(8.8f);titleText.typeface=Typeface.create("sans-serif",Typeface.BOLD)
        titleText.color=0xFF7E98AD.toInt()
        val label = when(mode){Mode.NORMALIZED->"0–100%";Mode.FROM_START->"ZMIANA OD STARTU";Mode.XY->"KORELACJA XY";else->selectedSeries().firstOrNull()?.let { if (selectedSeries().size > 1) "WSPÓLNA SKALA · ${it.unit}" else "SKALA · ${it.unit}" } ?: "TELEMETRIA"}
        canvas.drawText(label,l,t-dp(15f),titleText)
        val chosen=selectedSeries()
        val vals=chosen.flatMap { buildValues(it, rows).mapNotNull { p->p.second } }
        val range=if(mode==Mode.NORMALIZED)0.0 to 100.0 else if(mode==Mode.FROM_START)-100.0 to 100.0 else fixedMin?.let{fm->fixedMax?.let{fx->fm to fx}}?:rangeFor(vals.ifEmpty{listOf(0.0,1.0)})
        axisText.textSize=dp(9.2f)
        for(i in 0..4){
            val f=i/4f;val y=b-(b-t)*f;val v=range.first+(range.second-range.first)*f
            canvas.drawText(fmt(v),dp(7f),y+dp(3f),axisText)
        }
        // In SPLIT mode show a second scale only when units really differ.
        if(mode==Mode.SPLIT && chosen.size>1){
            val firstUnit=chosen.first().unit
            val rightVals=chosen.filter{it.unit!=firstUnit}.flatMap{buildValues(it,rows).mapNotNull{p->p.second}}
            if(rightVals.isNotEmpty()){
                val rr=rangeFor(rightVals)
                for(i in 0..4){
                    val f=i/4f;val y=b-(b-t)*f;val v=rr.first+(rr.second-rr.first)*f
                    val text=fmt(v);canvas.drawText(text,r-axisText.measureText(text),y+dp(3f),axisText)
                }
                val unit=chosen.firstOrNull{it.unit!=firstUnit}?.unit ?: ""
                canvas.drawText(unit,r-axisText.measureText(unit),t-dp(15f),titleText)
            }
        }
        drawXAxis(canvas,minTs,maxTs)
    }

    private fun drawXAxis(canvas: Canvas, minTs: Long, maxTs: Long) {
        val hours=(maxTs-minTs)/3600.0
        val longSpan=hours>=36.0
        val veryLong=hours>=24*14
        val l=plotLeft();val r=plotRight();val b=plotBottom()
        val dateFmt=java.text.SimpleDateFormat(if(veryLong)"dd.MM" else "dd.MM",java.util.Locale.US).apply{timeZone=java.util.TimeZone.getTimeZone("Europe/Warsaw")}
        val timeFmt=java.text.SimpleDateFormat("HH:mm",java.util.Locale.US).apply{timeZone=java.util.TimeZone.getTimeZone("Europe/Warsaw")}
        axisText.textSize=dp(if(longSpan)8.2f else 9.1f)
        for(i in 0..5){
            val fr=i/5f; val x=l+(r-l)*fr; val ts=(minTs+((maxTs-minTs)*fr)).toLong(); val date=java.util.Date(ts*1000L)
            if(longSpan){
                val ds=dateFmt.format(date); val hm=timeFmt.format(date)
                canvas.drawText(ds,x-axisText.measureText(ds)/2f,b+dp(17f),axisText)
                axisText.color=0xFF6F879B.toInt(); canvas.drawText(hm,x-axisText.measureText(hm)/2f,b+dp(29f),axisText); axisText.color=0xFF8EA6BA.toInt()
            }else{
                val hm=timeFmt.format(date); canvas.drawText(hm,x-axisText.measureText(hm)/2f,b+dp(22f),axisText)
            }
        }
    }

    private fun drawCrosshair(canvas: Canvas, viewRows: List<TelemetryRecord>, x: Float, minTs: Long, maxTs: Long) {
        val l=plotLeft();val r=plotRight();val t=plotTop();val b=plotBottom()
        if (r <= l || maxTs <= minTs) return
        val ratio=((x-l)/(r-l)).coerceIn(0f,1f)
        val targetTs=minTs+((maxTs-minTs)*ratio).toLong()
        val nearest=viewRows.minByOrNull{abs(it.ts-targetTs)}?:return
        val px=l+(r-l)*((nearest.ts-minTs).toFloat()/max(1f,(maxTs-minTs).toFloat()))
        canvas.drawLine(px,t,px,b,crosshairPaint)
        selectedSeries().forEach { sr ->
            val v=if(sr.servo){val deg=if(sr.id=="servo_flap")nearest.k else nearest.s;if(!deg.isFinite())null else if(sr.id=="servo_flap")deg/180.0*100.0 else deg/90.0*100.0}else sr.channel?.let{ch->nearest.a.getOrNull(ch)?.takeIf{it.isFinite()}?.times(sr.scale)}
            if(v!=null){
                val yy=pointY(sr,v,minTs,maxTs)?:return@forEach
                val halo=Paint(Paint.ANTI_ALIAS_FLAG).apply{color=Color.argb(40,Color.red(sr.accent),Color.green(sr.accent),Color.blue(sr.accent))}
                val dot=Paint(Paint.ANTI_ALIAS_FLAG).apply{color=sr.accent}
                canvas.drawCircle(px,yy,dp(6.2f),halo);canvas.drawCircle(px,yy,dp(3.0f),dot)
            }
        }
        val date=java.text.SimpleDateFormat("dd.MM  HH:mm:ss",java.util.Locale.US).apply{timeZone=java.util.TimeZone.getTimeZone("Europe/Warsaw")}
        val txt=date.format(java.util.Date(nearest.ts*1000L))
        val pw=dp(150f);val ph=dp(24f)
        var bx=px-pw/2f;bx=bx.coerceIn(l,r-pw)
        val fill=Paint(Paint.ANTI_ALIAS_FLAG).apply{color=0xF2142537.toInt()}
        val border=Paint(Paint.ANTI_ALIAS_FLAG).apply{style=Paint.Style.STROKE;strokeWidth=dp(1f);color=0x805C7890.toInt()}
        canvas.drawRoundRect(bx,dp(9f),bx+pw,dp(9f)+ph,dp(9f),dp(9f),fill)
        canvas.drawRoundRect(bx,dp(9f),bx+pw,dp(9f)+ph,dp(9f),dp(9f),border)
        val tp=Paint(Paint.ANTI_ALIAS_FLAG).apply{color=Color.WHITE;textSize=dp(8.0f);typeface=Typeface.DEFAULT_BOLD;textAlign=Paint.Align.CENTER}
        canvas.drawText(txt,bx+pw/2f,dp(24.6f),tp)
    }

    private fun pointY(series: Series, value: Double, minTs: Long, maxTs: Long): Float? {
        val vals=buildValues(series,rows).mapNotNull{it.second};if(vals.isEmpty())return null
        val range=when(mode){
            Mode.NORMALIZED->0.0 to 100.0
            Mode.FROM_START->-100.0 to 100.0
            Mode.COMMON->fixedMin?.let{fm->fixedMax?.let{fx->fm to fx}}?:rangeFor(selectedSeries().flatMap{buildValues(it,rows).mapNotNull{p->p.second}})
            Mode.SPLIT->fixedMin?.let{fm->fixedMax?.let{fx->fm to fx}}?:rangeFor(vals)
            else->rangeFor(vals)
        }
        val vv=transformValue(series,value,0,buildValues(series,rows));val norm=((vv-range.first)/max(1e-9,range.second-range.first)).toFloat().coerceIn(0f,1f)
        return plotBottom()-(plotBottom()-plotTop())*norm
    }

    private fun drawContextBar(canvas: Canvas, start: Int, end: Int) {
        if (rows.size < 4) return
        val left=plotLeft(); val right=plotRight(); val trackY=height-dp(35f); val h=dp(24f)
        val track=Paint(Paint.ANTI_ALIAS_FLAG).apply{color=0x24435B73}
        canvas.drawRoundRect(left,trackY,right,trackY+h,dp(7f),dp(7f),track)
        val navSeries=selectedSeries().firstOrNull()
        if(navSeries!=null){
            val pts=buildValues(navSeries,rows).mapNotNull{(ts,v)->v?.let{ts to it}}
            if(pts.size>1){
                val lo=pts.minOf{it.second};val hi=pts.maxOf{it.second};val rg=max(1e-9,hi-lo)
                val path=Path();pts.forEachIndexed{i,(ts,v)->
                    val xx=left+(right-left)*((ts-rows.first().ts).toFloat()/max(1f,(rows.last().ts-rows.first().ts).toFloat()))
                    val yy=trackY+h-dp(4f)-(h-dp(8f))*((v-lo)/rg).toFloat().coerceIn(0f,1f)
                    if(i==0)path.moveTo(xx,yy) else path.lineTo(xx,yy)
                }
                val pp=Paint(Paint.ANTI_ALIAS_FLAG).apply{style=Paint.Style.STROKE;strokeWidth=dp(1.3f);strokeCap=Paint.Cap.ROUND;color=navSeries.accent;alpha=170}
                canvas.drawPath(path,pp)
            }
        }
        val a=left+(right-left)*(start.toFloat()/max(1,(rows.size-1)))
        val b=left+(right-left)*(end.toFloat()/max(1,(rows.size-1)))
        val active=Paint(Paint.ANTI_ALIAS_FLAG).apply{color=0xA52FD0EE.toInt()}
        canvas.drawRoundRect(a,trackY+dp(1f),b,trackY+h-dp(1f),dp(6f),dp(6f),active)
        val edgePaint=Paint(Paint.ANTI_ALIAS_FLAG).apply{style=Paint.Style.STROKE;strokeWidth=dp(.8f);color=0xB034CDE8.toInt()}
        canvas.drawRoundRect(a,trackY+dp(1f),b,trackY+h-dp(1f),dp(6f),dp(6f),edgePaint)
        titleText.textSize=dp(7.4f);titleText.color=0xFF7B93A5.toInt();titleText.typeface=Typeface.DEFAULT_BOLD
        canvas.drawText(if(zoom<=1.02f)"PEŁNY ZAKRES" else "POWIĘKSZENIE  ${zoom.toInt()}×",left,trackY-dp(4f),titleText)
        titleText.textAlign=Paint.Align.RIGHT
        canvas.drawText(navSeries?.label ?: "TELEMETRIA",right,trackY-dp(4f),titleText)
        titleText.textAlign=Paint.Align.LEFT
    }

    private fun visibleSlice(): Pair<Int,Int> {
        val n=rows.size
        val count=max(2,(n/zoom).roundToInt().coerceAtMost(n))
        val maxStart=max(0,n-count)
        val start=(maxStart*(1f-offset)).roundToInt().coerceIn(0,maxStart)
        return start to min(n,start+count)
    }

    private fun buildValues(s: Series, source: List<TelemetryRecord>): List<Pair<Long,Double?>> = source.mapIndexed { idx,row ->
        var v: Double? = if(s.servo){
            val deg=if(s.id=="servo_flap")row.k else row.s
            if(!deg.isFinite())null else if(s.id=="servo_flap")deg/180.0*100.0 else deg/90.0*100.0
        } else {
            val q=s.channel?.let{quality(row.q,it)}?:0
            val simulated=s.channel?.let{(((row.sim) ushr it) and 1L) == 1L}==true
            if(realOnly&&(q!=0||simulated))null else s.channel?.let{row.a.getOrNull(it)?.takeIf{v->v.isFinite()}?.times(s.scale)}
        }
        if(anomalyFilter&&v!=null&&s.channel!=null&&idx>3){
            val ch=s.channel!!
            val neigh=source.subList(max(0,idx-3),min(source.size,idx+4)).mapNotNull{it.a.getOrNull(ch)?.takeIf{v->v.isFinite()}?.times(s.scale)}
            if(neigh.size>=4){
                val med=neigh.sorted()[neigh.size/2];val dev=abs(v!!-med);val span=max(1.0,(neigh.maxOrNull()?:med)-(neigh.minOrNull()?:med))
                if(dev>span*4.0)v=null
            }
        }
        row.ts to v
    }

    private fun transformValue(s:Series,v:Double,index:Int,pts:List<Pair<Long,Double?>>):Double = when(mode){
        Mode.NORMALIZED->{val f=pts.mapNotNull{it.second};val lo=f.minOrNull()?:v;val hi=f.maxOrNull()?:v;(v-lo)/max(1e-9,hi-lo)*100.0}
        Mode.FROM_START->{val start=pts.firstOrNull{it.second!=null}?.second?:v;(v-start)/max(1.0,abs(start))*100.0}
        else->v
    }

    private fun drawEnvelopeBand(canvas: Canvas, prepared: List<Pair<Series,List<Pair<Long,Double?>>>>, minTs: Long, maxTs: Long, left: Float, right: Float, top: Float, bottom: Float, lo: Double, hi: Double) {
        if (prepared.size < 2 || prepared.any { it.second.isEmpty() }) return
        val upper=Path(); val lower=Path(); var started=false
        val n=prepared.first().second.size
        for(i in 0 until n){
            val vals=prepared.mapNotNull{it.second.getOrNull(i)?.second}; if(vals.isEmpty()) continue
            val ts=prepared.first().second[i].first; val x=left+(right-left)*((ts-minTs).toFloat()/max(1f,(maxTs-minTs).toFloat()))
            val mx=vals.maxOrNull()!!; val mn=vals.minOrNull()!!
            val yu=bottom-(bottom-top)*(((mx-lo)/max(1e-9,hi-lo)).toFloat().coerceIn(0f,1f))
            val yl=bottom-(bottom-top)*(((mn-lo)/max(1e-9,hi-lo)).toFloat().coerceIn(0f,1f))
            if(!started){upper.moveTo(x,yu);lower.moveTo(x,yl);started=true}else{upper.lineTo(x,yu);lower.lineTo(x,yl)}
        }
        if(!started)return
        val polygon=Path(upper); val rev=prepared.first().second.indices.reversed(); var rs=false
        for(i in rev){val vals=prepared.mapNotNull{it.second.getOrNull(i)?.second};if(vals.isEmpty())continue;val ts=prepared.first().second[i].first;val x=left+(right-left)*((ts-minTs).toFloat()/max(1f,(maxTs-minTs).toFloat()));val mn=vals.minOrNull()!!;val y=bottom-(bottom-top)*(((mn-lo)/max(1e-9,hi-lo)).toFloat().coerceIn(0f,1f));if(!rs){polygon.lineTo(x,y);rs=true}else polygon.lineTo(x,y)}
        polygon.close(); val p=Paint(Paint.ANTI_ALIAS_FLAG).apply{style=Paint.Style.FILL;shader=LinearGradient(0f,top,0f,bottom,0x223CC8F0,0x043CC8F0,Shader.TileMode.CLAMP)};canvas.drawPath(polygon,p)
    }

    private fun drawBand(canvas:Canvas,aPair:Pair<Series,List<Pair<Long,Double?>>>,bPair:Pair<Series,List<Pair<Long,Double?>>>,minTs:Long,maxTs:Long,left:Float,right:Float,top:Float,bottom:Float,lo:Double,hi:Double){
        val a=aPair.second;val b=bPair.second;val path=Path();var started=false
        for(i in a.indices){val va=a[i].second;val vb=b.getOrNull(i)?.second;if(va==null||vb==null)continue;val x=left+(right-left)*((a[i].first-minTs).toFloat()/max(1f,(maxTs-minTs).toFloat()));val ya=bottom-(bottom-top)*(((va-lo)/max(1e-9,hi-lo)).toFloat().coerceIn(0f,1f));if(!started){path.moveTo(x,ya);started=true}else path.lineTo(x,ya)}
        for(i in b.lastIndex downTo 0){val va=a.getOrNull(i)?.second;val vb=b[i].second;if(va==null||vb==null)continue;val x=left+(right-left)*((b[i].first-minTs).toFloat()/max(1f,(maxTs-minTs).toFloat()));val yb=bottom-(bottom-top)*(((vb-lo)/max(1e-9,hi-lo)).toFloat().coerceIn(0f,1f));path.lineTo(x,yb)}
        if(started){path.close();canvas.drawPath(path,bandPaint)}
    }

    private fun drawXy(canvas:Canvas,rows:List<TelemetryRecord>){
        val series=selectedSeries().take(2);if(series.size<2){drawEmpty(canvas,"XY wymaga dwóch serii");return}
        val a=buildValues(series[0],rows).filter{it.second!=null}.associate{it.first to it.second!!}
        val b=buildValues(series[1],rows).filter{it.second!=null}.associate{it.first to it.second!!}
        val pairs=a.keys.intersect(b.keys).sorted().map{it to (a[it]!! to b[it]!!)}
        if(pairs.size<2){drawEmpty(canvas,"Brak wspólnych punktów dla XY");return}
        val xs=pairs.map{it.second.first};val ys=pairs.map{it.second.second};val xr=rangeFor(xs);val yr=rangeFor(ys)
        val l=plotLeft();val r=plotRight();val t=plotTop();val bot=plotBottom()
        val grid=Paint(Paint.ANTI_ALIAS_FLAG).apply{color=0x22546D80;strokeWidth=dp(.7f)}
        for(i in 0..4){val yy=t+(bot-t)*i/4f;val xx=l+(r-l)*i/4f;canvas.drawLine(l,yy,r,yy,grid);canvas.drawLine(xx,t,xx,bot,grid)}
        val glow=Paint(Paint.ANTI_ALIAS_FLAG).apply{color=Color.argb(35,Color.red(series[0].accent),Color.green(series[0].accent),Color.blue(series[0].accent))}
        val point=Paint(Paint.ANTI_ALIAS_FLAG).apply{color=series[0].accent}
        pairs.forEach{(_,xy)->val xx=l+(r-l)*((xy.first-xr.first)/(xr.second-xr.first)).toFloat().coerceIn(0f,1f);val yy=bot-(bot-t)*((xy.second-yr.first)/(yr.second-yr.first)).toFloat().coerceIn(0f,1f);canvas.drawCircle(xx,yy,dp(6f),glow);canvas.drawCircle(xx,yy,dp(2.7f),point)}
        titleText.color=0xFF8EA6BA.toInt();titleText.textSize=dp(8.8f);canvas.drawText("X  ${series[0].label}   ·   Y  ${series[1].label}",l,t-dp(15f),titleText)
        axisText.textSize=dp(8.7f);axisText.color=0xFF8EA6BA.toInt()
        canvas.drawText(fmt(xr.first),l,t-dp(2f),axisText);val xrText=fmt(xr.second);canvas.drawText(xrText,r-axisText.measureText(xrText),t-dp(2f),axisText)
        val yrText=fmt(yr.second);canvas.drawText(yrText,dp(7f),t+dp(9f),axisText);canvas.drawText(fmt(yr.first),dp(7f),bot,axisText)
    }

    private fun dispatchSelection(){
        val x=crosshairX?:return
        if(rows.size<2||selected.isEmpty())return
        val (start,end)=visibleSlice();if(end-start<2)return
        val vr=rows.subList(start,end);val minTs=vr.first().ts;val maxTs=vr.last().ts;val ratio=((x-plotLeft())/(plotRight()-plotLeft())).coerceIn(0f,1f);val ts=minTs+((maxTs-minTs)*ratio).toLong();val row=vr.minByOrNull{abs(it.ts-ts)}?:return
        val dt=java.text.SimpleDateFormat("dd.MM HH:mm:ss",java.util.Locale.US).apply{timeZone=java.util.TimeZone.getTimeZone("Europe/Warsaw")}
        val text=buildString{
            append(dt.format(java.util.Date(row.ts*1000L)));selectedSeries().take(6).forEach{sr->val v=if(sr.servo){val deg=if(sr.id=="servo_flap")row.k else row.s;if(!deg.isFinite())null else if(sr.id=="servo_flap")deg/180.0*100.0 else deg/90.0*100.0}else sr.channel?.let{ch->row.a.getOrNull(ch)?.takeIf{it.isFinite()}?.times(sr.scale)};if(v!=null)append("   •   ").append(sr.label).append(" ").append(fmt(v)).append(if(sr.servo)"%" else sr.unit)}
        }
        onSelectionChanged?.invoke(text)
    }

    private fun plotLeft()=dp(46f)
    private fun plotRight()=width-dp(16f)
    private fun plotTop()=dp(42f)
    private fun plotBottom()=height-dp(78f)
    private fun quality(q:Long,channel:Int)=((q ushr(channel*2)) and 3L).toInt()
    private fun rangeFor(values:List<Double>):Pair<Double,Double>{var lo=values.minOrNull()?:0.0;var hi=values.maxOrNull()?:1.0;if(lo==hi){lo-=1.0;hi+=1.0};val pad=max(.5,(hi-lo)*.08);return lo-pad to hi+pad}
    private fun fmt(v:Double)=String.format(java.util.Locale.US,"%.1f",v)
    private fun dp(v:Float)=v*resources.displayMetrics.density
    private companion object{const val GAP_BREAK_SECONDS=150L}
}
