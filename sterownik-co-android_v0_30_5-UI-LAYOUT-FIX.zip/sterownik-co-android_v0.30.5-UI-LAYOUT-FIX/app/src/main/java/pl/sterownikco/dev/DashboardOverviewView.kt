package pl.sterownikco.dev

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.View
import android.view.animation.DecelerateInterpolator
import kotlin.math.max
import kotlin.math.min

/** Compact native telemetry trend used on the Dashboard. */
class DashboardOverviewView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
) : View(context, attrs) {
    private data class Sample(val outside: Float, val heating: Float, val boiler: Float, val pump: Boolean)

    private val samples = ArrayDeque<Sample>()
    private var reveal = 1f
    private var animator: ValueAnimator? = null

    private val gridPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; color = 0x25445D74
    }
    private val outsidePaint = linePaint(0xFFFFB347.toInt())
    private val heatingPaint = linePaint(0xFFFF5A64.toInt())
    private val boilerPaint = linePaint(0xFF00D4F5.toInt())
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF91A4B8.toInt() }
    private val valuePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFE8F1F8.toInt(); typeface = Typeface.create("sans-serif", Typeface.BOLD) }

    private fun linePaint(color: Int) = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 2.1f; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND; this.color = color
    }

    fun submit(outside: Double?, heating: Double?, boiler: Double?, pump: Boolean) {
        if (outside == null || heating == null || boiler == null) return
        val s = Sample(outside.toFloat(), heating.toFloat(), boiler.toFloat(), pump)
        if (samples.lastOrNull() == s) return
        samples.addLast(s)
        while (samples.size > 36) samples.removeFirst()
        startReveal()
        invalidate()
    }

    private fun startReveal() {
        animator?.cancel()
        reveal = 0f
        animator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 360L
            interpolator = DecelerateInterpolator(1.6f)
            addUpdateListener { reveal = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    override fun onDetachedFromWindow() { animator?.cancel(); super.onDetachedFromWindow() }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val d = resources.displayMetrics.density
        canvas.drawColor(0xFF0A1624.toInt())
        if (samples.size < 2) {
            textPaint.textSize = dp(10f)
            canvas.drawText("Oczekiwanie na dane LIVE…", dp(16f), dp(28f), textPaint)
            return
        }

        val l = dp(16f); val r = width - dp(16f); val t = dp(18f); val b = height - dp(28f)
        repeat(3) { i -> val y = t + (b-t) * i / 2f; canvas.drawLine(l,y,r,y,gridPaint) }
        val all = samples.toList()
        val minV = all.minOf { min(it.outside, min(it.heating, it.boiler)) } - 1.5f
        val maxV = all.maxOf { max(it.outside, max(it.heating, it.boiler)) } + 1.5f
        val range = max(.001f, maxV-minV)
        val visible = max(2, (all.size * reveal).toInt())

        fun draw(values: (Sample)->Float, color: Int) {
            val points = ArrayList<Pair<Float,Float>>(visible)
            for (i in 0 until min(visible, all.size)) {
                val x = l + (r-l) * (i.toFloat() / max(1, all.size-1).toFloat())
                val y = b - (b-t) * ((values(all[i])-minV)/range).coerceIn(0f,1f)
                points += x to y
            }
            if (points.size < 2) return
            val path=Path().apply{moveTo(points.first().first,points.first().second)}
            for(i in 1 until points.size){
                val prev=points[i-1];val cur=points[i];val dx=(cur.first-prev.first)*.42f
                path.cubicTo(prev.first+dx,prev.second,cur.first-dx,cur.second,cur.first,cur.second)
            }
            val glow=Paint(Paint.ANTI_ALIAS_FLAG).apply{style=Paint.Style.STROKE;strokeWidth=dp(6f);strokeCap=Paint.Cap.ROUND;strokeJoin=Paint.Join.ROUND;this.color=Color.argb(32,Color.red(color),Color.green(color),Color.blue(color))}
            val line=Paint(Paint.ANTI_ALIAS_FLAG).apply{style=Paint.Style.STROKE;strokeWidth=dp(2.0f);strokeCap=Paint.Cap.ROUND;strokeJoin=Paint.Join.ROUND;this.color=color}
            canvas.drawPath(path,glow);canvas.drawPath(path,line)
            val end=points.last();val halo=Paint(Paint.ANTI_ALIAS_FLAG).apply{this.color=Color.argb(36,Color.red(color),Color.green(color),Color.blue(color))};canvas.drawCircle(end.first,end.second,dp(6f),halo);canvas.drawCircle(end.first,end.second,dp(2.5f),line)
        }
        draw({it.outside},outsidePaint.color);draw({it.heating},heatingPaint.color);draw({it.boiler},boilerPaint.color)

        val last=all.last()
        valuePaint.textSize=dp(9.4f)
        canvas.drawText("Zew. ${one(last.outside)}°",l,height-dp(10f),valuePaint)
        valuePaint.color=heatingPaint.color;canvas.drawText("Piec ${one(last.heating)}°",l+dp(84f),height-dp(10f),valuePaint)
        valuePaint.color=boilerPaint.color;canvas.drawText("Bojler ${one(last.boiler)}°",l+dp(170f),height-dp(10f),valuePaint)
        valuePaint.color=0xFFE8F1F8.toInt()
        if(last.pump){
            val p=Paint(Paint.ANTI_ALIAS_FLAG).apply{color=0xFF4ADE80.toInt();strokeWidth=dp(1.6f);style=Paint.Style.STROKE}
            canvas.drawCircle(r-dp(18f),t+dp(1f),dp(4f),p)
            textPaint.color=0xFF4ADE80.toInt();textPaint.textSize=dp(8.2f);textPaint.typeface=Typeface.DEFAULT_BOLD
            canvas.drawText("POMPA",r-dp(72f),t+dp(4f),textPaint)
            textPaint.color=0xFF91A4B8.toInt();textPaint.typeface=Typeface.DEFAULT
        }
    }

    private fun one(v: Float) = String.format(java.util.Locale.US, "%.1f", v)
    private fun dp(v:Float)=v*resources.displayMetrics.density
}
