package pl.sterownikco.dev

import android.content.Context
import android.graphics.*
import android.view.MotionEvent
import android.view.View
import kotlin.math.*

/**
 * STEROWNIK CO — premium telemetry tile.
 * Visual language follows the strongest parts of the WWW reference:
 * compact cards, rich multi-part illustrations, restrained glow,
 * explicit state, and a live micro-indicator.
 */
class DashboardTileView @JvmOverloads constructor(
    context: Context,
    attrs: android.util.AttributeSet? = null
) : View(context, attrs) {

    enum class Kind { OUTSIDE, HEATING, BOILER, PANEL, ROOM, PRESSURE, HUMIDITY, PUMP, SERVO, MIXER, SMOKE, CHARTS, CLOCK }

    private var kind = Kind.OUTSIDE
    private var title = ""
    private var value = "—"
    private var state = "LIVE"
    private var accent = 0xFFFF9F43.toInt()
    private var active = false
    private var alarm = false
    private var fraction = 0f
    private var pressed = false
    private var flash = 0f
    private var lastValue = ""
    private var stale = false

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG)
    private val valuePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val small = Paint(Paint.ANTI_ALIAS_FLAG)
    private val icon = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }

    init {
        isClickable = true
        isFocusable = true
        setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { pressed = true; invalidate(); true }
                MotionEvent.ACTION_UP -> { pressed = false; invalidate(); performClick(); false }
                MotionEvent.ACTION_CANCEL -> { pressed = false; invalidate(); false }
                else -> true
            }
        }
    }

    override fun performClick(): Boolean { super.performClick(); return true }

    fun bind(
        kind: Kind,
        title: String,
        value: String,
        state: String = "LIVE",
        accent: Int,
        active: Boolean = false,
        alarm: Boolean = false,
        fraction: Float = 0f
    ) {
        this.kind = kind
        this.title = title
        this.value = value
        this.state = state
        this.accent = accent
        this.active = active
        this.alarm = alarm
        this.fraction = fraction.coerceIn(0f, 1f)
        this.stale = false
        if (value != lastValue) flash = 1f
        lastValue = value
        invalidate()
    }

    fun pulse() { flash = 1f; invalidate() }

    fun setStale(value: Boolean) {
        stale = value
        if (value) pressed = false
        invalidate()
    }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val d = resources.displayMetrics.density
        val w = width.toFloat()
        val h = height.toFloat()
        if (w < dp(120f) || h < dp(90f)) return

        val radius = dp(18f)
        val left = dp(3f); val top = dp(3f); val right = w-dp(3f); val bottom = h-dp(3f)

        // Base card with controlled depth.
        fill.shader = LinearGradient(0f, top, w, bottom, 0xFF102437.toInt(), 0xFF07131F.toInt(), Shader.TileMode.CLAMP)
        c.drawRoundRect(left, top, right, bottom, radius, radius, fill)
        fill.shader = RadialGradient(w*.95f, h*.08f, w*.85f,
            Color.argb(if (alarm) 64 else if(active) 50 else 22, Color.red(accent), Color.green(accent), Color.blue(accent)),
            Color.TRANSPARENT, Shader.TileMode.CLAMP)
        c.drawRoundRect(left, top, right, bottom, radius, radius, fill)
        fill.shader = null

        stroke.strokeWidth = dp(if (alarm) 1.8f else if (pressed) 1.6f else if (active) 1.25f else 0.85f)
        stroke.color = when {
            alarm -> 0xFFFF627B.toInt()
            stale -> 0x6A7F93A3
            pressed -> Color.argb(185, Color.red(accent), Color.green(accent), Color.blue(accent))
            active -> Color.argb(150, Color.red(accent), Color.green(accent), Color.blue(accent))
            else -> 0x3C4B6477
        }
        c.drawRoundRect(left, top, right, bottom, radius, radius, stroke)

        // Illustration well — a true visual component, not just a circular icon.
        val ix = dp(43f); val iy = dp(42f)
        val wellL=ix-dp(27f); val wellT=iy-dp(27f); val wellR=ix+dp(27f); val wellB=iy+dp(27f)
        fill.shader = LinearGradient(wellL, wellT, wellR, wellB,
            Color.argb(if(alarm) 44 else if(active) 38 else 28, Color.red(accent), Color.green(accent), Color.blue(accent)),
            0x15101D2B, Shader.TileMode.CLAMP)
        c.drawRoundRect(wellL,wellT,wellR,wellB,dp(16f),dp(16f),fill)
        fill.shader=null
        stroke.strokeWidth = dp(if(active) 1.35f else 1f)
        stroke.color = Color.argb(if(active) 120 else 72, Color.red(accent), Color.green(accent), Color.blue(accent))
        c.drawRoundRect(wellL,wellT,wellR,wellB,dp(16f),dp(16f),stroke)
        stroke.strokeWidth = dp(2.1f)
        stroke.color = Color.argb(50, Color.red(accent), Color.green(accent), Color.blue(accent))
        c.drawArc(ix-dp(30f), iy-dp(30f), ix+dp(30f), iy+dp(30f), -105f, 210f, false, stroke)
        if (fraction > 0f) {
            stroke.strokeWidth = dp(2.1f)
            stroke.color = Color.argb(220, Color.red(accent), Color.green(accent), Color.blue(accent))
            c.drawArc(ix-dp(30f), iy-dp(30f), ix+dp(30f), iy+dp(30f), -105f, 210f*fraction, false, stroke)
        }
        // Compact live-meter bars — visual feedback even when the value itself is textual.
        val meterX = right-dp(84f)
        val meterY = dp(49f)
        for(i in 0 until 7){
            val level=((fraction*6f)+(i*.22f)).coerceIn(.18f,1f)
            val bh=dp(4f)+dp(14f)*level*(if(active)1f else .74f)
            fill.color=Color.argb(if(active)145 else 80,Color.red(accent),Color.green(accent),Color.blue(accent))
            c.drawRoundRect(meterX+i*dp(9f),meterY+dp(15f)-bh,meterX+i*dp(9f)+dp(5f),meterY+dp(15f),dp(2f),dp(2f),fill)
        }
        drawIllustration(c, ix, iy, d)
        when(kind){Kind.OUTSIDE,Kind.HEATING,Kind.PANEL,Kind.HUMIDITY,Kind.PUMP,Kind.SERVO,Kind.MIXER,Kind.SMOKE,Kind.CHARTS,Kind.CLOCK->postInvalidateDelayed(90);else->Unit}

        // Tiny state badge.
        val badgeText = if(stale) "STALE" else state.uppercase().take(12)
        small.typeface = Typeface.create("sans-serif", Typeface.BOLD)
        small.textSize = dp(8.0f)
        val bw = max(dp(62f), min(dp(108f), small.measureText(badgeText) + dp(28f)))
        fill.color = when { stale -> 0x1C7F93A3; alarm -> 0x2E4B1420; active -> Color.argb(32,Color.red(accent),Color.green(accent),Color.blue(accent)); else -> 0x17213546 }
        c.drawRoundRect(right-bw-dp(10f), dp(11f), right-dp(10f), dp(31f), dp(10f), dp(10f), fill)
        fill.color = when { stale -> 0xFF8298A9.toInt(); alarm -> 0xFFFF7087.toInt(); active -> accent; else -> 0xFF71879A.toInt() }
        c.drawCircle(right-bw+dp(1f), dp(21f), dp(2.1f), fill)
        small.color = when { stale -> 0xFF9DB0BE.toInt(); alarm -> 0xFFFF9EAC.toInt(); active -> accent; else -> 0xFF96ABBB.toInt() }
        small.typeface = Typeface.create("sans-serif", Typeface.BOLD)
        small.textSize = dp(8.0f)
        small.textAlign = Paint.Align.CENTER
        c.drawText(badgeText, right-bw/2f-dp(4f), dp(25f), small)
        small.textAlign = Paint.Align.LEFT

        // Copy.
        text.color = 0xFF92A9BC.toInt()
        text.typeface = Typeface.create("sans-serif", Typeface.BOLD)
        text.textSize = dp(9.0f)
        text.letterSpacing = .055f
        c.drawText(title.uppercase(), dp(13f), h-dp(41f), text)

        valuePaint.color = if(alarm) 0xFFFF7B91.toInt() else 0xFFF4F8FB.toInt()
        valuePaint.typeface = Typeface.create("sans-serif", Typeface.BOLD)
        valuePaint.textSize = when {
            value.length > 15 -> dp(15.2f)
            value.length > 11 -> dp(18f)
            else -> dp(21.5f)
        }
        while (valuePaint.measureText(value) > w-dp(28f) && valuePaint.textSize > dp(12.8f)) valuePaint.textSize -= dp(.6f)
        c.drawText(value, dp(13f), h-dp(14f), valuePaint)

        // Bottom status rail, inspired by the reference card's state accent.
        fill.color = 0x2330475D
        c.drawRoundRect(dp(13f), h-dp(5f), w-dp(13f), h-dp(2.8f), dp(2f), dp(2f), fill)
        if (fraction > 0f) {
            fill.color = Color.argb(if(alarm)240 else 205, Color.red(accent), Color.green(accent), Color.blue(accent))
            c.drawRoundRect(dp(13f), h-dp(5f), dp(13f)+(w-dp(26f))*fraction, h-dp(2.8f), dp(2f), dp(2f), fill)
        }

        if (active && !stale) {
            val t = (System.currentTimeMillis() % 1600L) / 1600f
            fill.color = Color.argb((55f * (.25f + .75f * sin(t*PI*2))).toInt(), Color.red(accent), Color.green(accent), Color.blue(accent))
            c.drawCircle(w-dp(17f), h-dp(4f), dp(2.8f), fill)
            postInvalidateDelayed(50)
        }
        if (flash > 0.01f) {
            fill.color = Color.argb((flash*18f).toInt(), Color.red(accent), Color.green(accent), Color.blue(accent))
            c.drawRoundRect(dp(2f),dp(2f),w-dp(2f),h-dp(2f),radius,radius,fill)
            flash *= .82f
            postInvalidateDelayed(32)
        }
    }

    private fun drawIllustration(c: Canvas, x: Float, y: Float, d: Float) {
        val warm = 0xFFFFB23E.toInt()
        val warm2 = 0xFFFFD166.toInt()
        val cool = 0xFF38D5F4.toInt()
        val cool2 = 0xFF0EA5E9.toInt()
        val steel = 0xFFD4DEE6.toInt()
        val muted = 0xFF9AAFC0.toInt()
        icon.style = Paint.Style.FILL
        icon.strokeWidth = dp(1.8f)
        icon.color = accent
        when (kind) {
            Kind.OUTSIDE -> {
                val tm=(System.currentTimeMillis()%16000L)/16000f
                c.save();c.rotate(tm*360f,x-dp(5f),y-dp(4f))
                c.drawCircle(x-dp(5f),y-dp(4f),dp(6f),icon.apply{color=0xFFFFD94D.toInt()})
                icon.style=Paint.Style.STROKE;icon.strokeWidth=dp(1.5f)
                repeat(8){i->val a=i*PI/4;c.drawLine(x-dp(5f)+cos(a).toFloat()*dp(9f),y-dp(4f)+sin(a).toFloat()*dp(9f),x-dp(5f)+cos(a).toFloat()*dp(14f),y-dp(4f)+sin(a).toFloat()*dp(14f),icon)}
                c.restore();icon.style=Paint.Style.FILL;icon.color=0xFFE1E9EF.toInt();val drift=sin(tm*PI*2).toFloat()*dp(1.2f);c.drawOval(x+drift,y+dp(2f),x+dp(21f)+drift,y+dp(12f),icon);c.drawCircle(x+dp(8f)+drift,y+dp(1f),dp(5f),icon);c.drawCircle(x+dp(15f)+drift,y,dp(6f),icon)
            }
            Kind.HEATING -> {
                val pulse=1f+sin((System.currentTimeMillis()%1100L)/1100f*PI.toDouble()*2).toFloat()*.07f
                c.save();c.scale(pulse,pulse,x,y);flame(c,x,y,dp(19f),0xFFC2410C.toInt()); flame(c,x,y+dp(2f),dp(12.5f),0xFFFF923A.toInt()); flame(c,x,y+dp(4f),dp(7f),warm2);c.restore()
            }
            Kind.BOILER -> {
                icon.style=Paint.Style.STROKE; icon.strokeWidth=dp(1.7f); icon.color=steel
                c.drawRoundRect(x-dp(10f),y-dp(14f),x+dp(10f),y+dp(15f),dp(5f),dp(5f),icon)
                icon.style=Paint.Style.FILL;icon.color=0xFF0EA5E9.toInt();val fh=dp(23f)*fraction.coerceAtLeast(.08f);c.drawRoundRect(x-dp(7f),y+dp(11f)-fh,x+dp(7f),y+dp(11f),dp(2f),dp(2f),icon)
                val tm=(System.currentTimeMillis()%1700L)/1700f;icon.color=0xFFE0F7FF.toInt();c.drawCircle(x-dp(3f),y+dp(8f)-fh*tm,dp(1.2f),icon);c.drawCircle(x+dp(4f),y-dp(2f)-fh*((tm+.35f)%1f),dp(1.2f),icon)
            }
            Kind.PANEL -> {
                icon.style=Paint.Style.STROKE;icon.strokeWidth=dp(1.2f);icon.color=0xFF7A8FA0.toInt();c.drawRoundRect(x-dp(14f),y-dp(8f),x+dp(9f),y+dp(9f),dp(2f),dp(2f),icon)
                icon.color=0xFFFFC53D.toInt();icon.strokeWidth=dp(.8f);repeat(2){i->c.drawLine(x-dp(14f),y+dp(-.5f+i*dp(8f)),x+dp(9f),y+dp(-.5f+i*dp(8f)),icon)};repeat(2){i->c.drawLine(x-dp(6f)+i*dp(9f),y-dp(8f),x-dp(6f)+i*dp(9f),y+dp(9f),icon)}
                icon.style=Paint.Style.FILL;icon.color=0xFFFFD94D.toInt();c.drawCircle(x+dp(15f),y-dp(12f),dp(4f),icon)
                val tm=(System.currentTimeMillis()%1200L)/1200f;icon.color=0xFFFFE46B.toInt();c.drawCircle(x-dp(6f)+dp(18f)*tm,y+dp(1f),dp(1.2f),icon);c.drawCircle(x-dp(3f)+dp(20f)*((tm+.45f)%1f),y+dp(7f),dp(1f),icon)
            }
            Kind.ROOM -> {
                icon.style=Paint.Style.STROKE;icon.strokeWidth=dp(1.8f);icon.color=muted;val p=Path();p.moveTo(x-dp(13f),y-dp(3f));p.lineTo(x,y-dp(14f));p.lineTo(x+dp(13f),y-dp(3f));p.lineTo(x+dp(13f),y+dp(12f));p.lineTo(x-dp(13f),y+dp(12f));p.close();c.drawPath(p,icon);icon.style=Paint.Style.FILL;icon.color=warm;c.drawRoundRect(x-dp(3f),y+dp(3f),x+dp(3f),y+dp(12f),dp(1f),dp(1f),icon);c.drawRoundRect(x-dp(5f),y-dp(1f),x+dp(5f),y+dp(5f),dp(1f),dp(1f),icon)
            }
            Kind.PRESSURE -> {
                icon.style=Paint.Style.STROKE;icon.strokeWidth=dp(2f);icon.color=0xFF334A5E.toInt();c.drawArc(x-dp(13f),y-dp(13f),x+dp(13f),y+dp(13f),-135f,270f,false,icon);icon.color=if(fraction>.7f)0xFFFF7B91.toInt() else if(fraction>.35f)0xFFFFD166.toInt() else 0xFF4ADE80.toInt();c.drawArc(x-dp(13f),y-dp(13f),x+dp(13f),y+dp(13f),-135f,270f*fraction,false,icon);val a=Math.toRadians((-135+270*fraction).toDouble());c.drawLine(x,y,x+dp(10f)*cos(a).toFloat(),y+dp(10f)*sin(a).toFloat(),icon);icon.style=Paint.Style.FILL;icon.color=steel;c.drawCircle(x,y,dp(2f),icon)
            }
            Kind.HUMIDITY -> { icon.style=Paint.Style.FILL;icon.color=cool2;val p=Path();p.moveTo(x,y-dp(15f));p.cubicTo(x-dp(10f),y-dp(3f),x-dp(10f),y+dp(7f),x,y+dp(12f));p.cubicTo(x+dp(10f),y+dp(7f),x+dp(10f),y-dp(3f),x,y-dp(15f));p.close();c.drawPath(p,icon);val tm=(System.currentTimeMillis()%1300L)/1300f;icon.style=Paint.Style.STROKE;icon.strokeWidth=dp(1f);icon.color=0x6638BDF8;c.drawOval(x-dp(6f)-dp(3f)*tm,y+dp(10f)+dp(1f)*tm,x+dp(6f)+dp(3f)*tm,y+dp(14f)+dp(2f)*tm,icon);c.drawOval(x-dp(10f)-dp(4f)*((tm+.45f)%1f),y+dp(11f),x+dp(10f)+dp(4f)*((tm+.45f)%1f),y+dp(16f)+dp(3f)*tm,icon) }
            Kind.PUMP -> {
                icon.style=Paint.Style.FILL
                val rot=if(active) ((System.currentTimeMillis()%1600L)/1600f*360f) else 0f
                c.save();c.rotate(rot,x,y);repeat(4){i->c.save();c.rotate(i*90f,x,y);icon.color=if(i%2==0)cool else cool2;c.drawOval(x-dp(3f),y-dp(12f),x+dp(4f),y-dp(1f),icon);c.restore()};c.restore();icon.color=0xFFE0F7FF.toInt();c.drawCircle(x,y,dp(2.3f),icon);icon.style=Paint.Style.STROKE;icon.strokeWidth=dp(.9f);icon.color=cool;c.drawCircle(x,y,dp(17f),icon)
            }
            Kind.SERVO -> {
                icon.style=Paint.Style.STROKE;icon.strokeWidth=dp(1.6f);icon.color=steel;c.drawOval(x-dp(12f),y-dp(4f),x+dp(12f),y+dp(4f),icon);c.drawLine(x,y-dp(11f),x,y+dp(11f),icon);val a=Math.toRadians((-90+fraction*180f).toDouble());icon.color=accent;icon.strokeWidth=dp(2.2f);c.drawLine(x,y,x+dp(13f)*cos(a).toFloat(),y+dp(13f)*sin(a).toFloat(),icon);icon.style=Paint.Style.FILL;icon.color=0xFFEAF3F8.toInt();c.drawCircle(x,y,dp(2.3f),icon)
            }
            Kind.MIXER -> {
                val rot=if(active) ((System.currentTimeMillis()%1700L)/1700f*360f) else 0f
                c.save();c.rotate(rot,x,y);repeat(3){i->c.save();c.rotate(i*120f,x,y);icon.style=Paint.Style.FILL;icon.color=if(i==1)cool2 else cool;c.drawOval(x-dp(2f),y-dp(13f),x+dp(3.5f),y-dp(1f),icon);c.restore()};c.restore();icon.color=0xFFE0F7FF.toInt();c.drawCircle(x,y,dp(2.3f),icon)
            }
            Kind.SMOKE -> {
                icon.style=Paint.Style.STROKE;icon.strokeWidth=dp(1.7f);val tm=(System.currentTimeMillis()%1800L)/1800f;repeat(3){i->icon.color=if(i==1)0xFFD9E2E9.toInt() else 0xFF93A9B8.toInt();val off=dp((i-1)*7f)+sin((tm+i*.2f)*PI.toDouble()*2).toFloat()*dp(1.8f);val p=Path();p.moveTo(x-dp(8f)+off,y+dp(10f));p.cubicTo(x-dp(12f)+off,y+dp(3f),x-dp(3f)+off,y-dp(1f),x-dp(7f)+off,y-dp(9f));p.cubicTo(x-dp(11f)+off,y-dp(17f),x-dp(2f)+off,y-dp(18f),x-dp(5f)+off,y-dp(22f));c.drawPath(p,icon)}
            }
            Kind.CHARTS -> {
                icon.style=Paint.Style.FILL;val k=(System.currentTimeMillis()%1300L)/1300f;val heights=floatArrayOf(.45f,.78f,1f,.62f);for(i in 0..3){icon.color=when(i){0->0xFF22D3EE.toInt();1->0xFF0891B2.toInt();2->0xFF67E8F9.toInt();else->0xFF38BDF8.toInt()};val boost=1f+sin((k+i*.18f)*PI.toDouble()*2).toFloat()*.08f;val hh=dp(17f)*heights[i]*boost;c.drawRoundRect(x-dp(16f)+i*dp(8f),y+dp(10f)-hh,x-dp(10f)+i*dp(8f),y+dp(10f),dp(2f),dp(2f),icon)}
            }
            Kind.CLOCK -> {
                icon.style=Paint.Style.STROKE;icon.strokeWidth=dp(1.8f);icon.color=0xFFD0DCE5.toInt();c.drawCircle(x,y,dp(13f),icon);val sec=java.util.Calendar.getInstance().get(java.util.Calendar.SECOND)+java.util.Calendar.getInstance().get(java.util.Calendar.MILLISECOND)/1000f;val a=sec/60f*PI.toFloat()*2f;icon.color=accent;c.drawLine(x,y,x+dp(10f)*cos(a),y+dp(10f)*sin(a),icon);c.drawLine(x,y,x,y-dp(8f),icon);c.drawLine(x,y,x+dp(6f),y+dp(4f),icon);icon.style=Paint.Style.FILL;c.drawCircle(x,y,dp(2f),icon)
            }
        }
    }

    private fun flame(c: Canvas, x: Float, y: Float, size: Float, color: Int) {
        val p=Path();p.moveTo(x,y+size);p.cubicTo(x-size*.9f,y+size*.25f,x-size*.15f,y-size*.2f,x,y-size);p.cubicTo(x+size*.8f,y-size*.15f,x+size*.95f,y+size*.2f,x+size*.35f,y+size);p.close();fill.color=color;c.drawPath(p,fill)
    }

    private fun dp(v: Float): Float = v * resources.displayMetrics.density
}
