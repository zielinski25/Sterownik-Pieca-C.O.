package pl.sterownikco.dev

import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.View
import kotlin.math.*

/** Rich native boiler illustration inspired by the original WWW controller artwork. */
class BoilerHeroView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {
    private var temperature = Double.NaN
    private var running = false
    private var alarm = false
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val s = Paint(Paint.ANTI_ALIAS_FLAG).apply { style=Paint.Style.STROKE; strokeCap=Paint.Cap.ROUND; strokeJoin=Paint.Join.ROUND }

    fun bind(temp: Double, running: Boolean, alarm: Boolean) { temperature=temp;this.running=running;this.alarm=alarm;invalidate() }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val d=resources.displayMetrics.density
        val w=width.toFloat();val h=height.toFloat();if(w<20||h<20)return
        val cx=w*.53f; val cy=h*.48f; val bodyW=min(w*.55f,dp(102f)); val bodyH=min(h*.66f,dp(112f))
        val l=cx-bodyW/2f;val r=cx+bodyW/2f;val t=cy-bodyH/2f;val b=cy+bodyH/2f
        val accent=if(alarm)0xFFFF5F78.toInt() else if(running)0xFFFFA23F.toInt() else 0xFF6D8DA4.toInt()
        // glow
        p.shader=RadialGradient(cx,cy,bodyW*.75f,Color.argb(if(alarm)80 else if(running)55 else 24,Color.red(accent),Color.green(accent),Color.blue(accent)),Color.TRANSPARENT,Shader.TileMode.CLAMP);c.drawCircle(cx,cy,bodyW*.75f,p);p.shader=null
        // pipework behind
        s.strokeWidth=dp(3f);s.color=0xFF4A667A.toInt();c.drawLine(r-dp(9f),t+dp(24f),r+dp(23f),t+dp(24f),s);c.drawLine(r+dp(23f),t+dp(24f),r+dp(23f),t+dp(55f),s);c.drawLine(l+dp(7f),b-dp(18f),l-dp(18f),b-dp(18f),s);c.drawLine(l-dp(18f),b-dp(18f),l-dp(18f),b-dp(3f),s)
        // tank
        p.shader=LinearGradient(l,t,r,b,0xFF193C54.toInt(),0xFF0B2033.toInt(),Shader.TileMode.CLAMP);c.drawRoundRect(l,t,r,b,dp(18f),dp(18f),p);p.shader=null
        s.strokeWidth=dp(1.6f);s.color=if(alarm)0xFFFF6179.toInt() else 0xFF416C86.toInt();c.drawRoundRect(l,t,r,b,dp(18f),dp(18f),s)
        // boiler ribs
        s.strokeWidth=dp(1f);s.color=0xFF24485E.toInt();for(i in 1..3){val yy=t+bodyH*i/4f;c.drawLine(l+dp(8f),yy,r-dp(8f),yy,s)}
        // temperature gauge arc
        val frac=if(temperature.isFinite())((temperature-20)/80).coerceIn(0.0,1.0).toFloat() else .12f
        s.strokeWidth=dp(4f);s.color=0xFF29485C.toInt();c.drawArc(l+dp(10f),t+dp(10f),r-dp(10f),b-dp(10f),210f,120f,false,s);s.color=accent;c.drawArc(l+dp(10f),t+dp(10f),r-dp(10f),b-dp(10f),210f,120f*frac,false,s)
        // burner + flame
        p.color=0xFF243747.toInt();c.drawRoundRect(cx-dp(24f),b-dp(23f),cx+dp(24f),b-dp(9f),dp(6f),dp(6f),p)
        if(running){
            drawFlame(c,cx,b-dp(10f),dp(30f),0xFFC2410C.toInt());drawFlame(c,cx,b-dp(8f),dp(21f),0xFFFF8A34.toInt());drawFlame(c,cx+dp(1f),b-dp(6f),dp(12f),0xFFFFD166.toInt())
        } else { p.color=0xFF567186.toInt();c.drawCircle(cx,b-dp(16f),dp(5f),p) }
        // side gauge / indicator
        p.color=0xFF0A1723.toInt();c.drawRoundRect(r+dp(7f),cy-dp(17f),r+dp(22f),cy+dp(17f),dp(5f),dp(5f),p)
        s.strokeWidth=dp(2f);s.color=accent; c.drawLine(r+dp(14f),cy+dp(7f),r+dp(14f),cy-dp(6f)-dp(16f)*frac,s)
        p.color=if(alarm)0xFFFF6179.toInt() else if(running)0xFF4ADE80.toInt() else 0xFF6B8498.toInt();c.drawCircle(r+dp(14f),cy-dp(7f),dp(2.7f),p)
        // steam/smoke accents
        if(running){s.strokeWidth=dp(1.6f);s.color=0x709FB6C4;var k=0;while(k<2){val off=dp(k*9f);val path=Path();path.moveTo(l+dp(23f)+off,t-dp(4f));path.cubicTo(l+dp(16f)+off,t-dp(13f),l+dp(31f)+off,t-dp(18f),l+dp(24f)+off,t-dp(29f));c.drawPath(path,s);k++}}
        // label
        p.color=0xFFEFF6FB.toInt();p.textAlign=Paint.Align.CENTER;p.typeface=Typeface.create("sans-serif",Typeface.BOLD);p.textSize=dp(9f);c.drawText(if(alarm)"ALARM" else if(running)"PRACA" else "CZUWANIE",cx,b+dp(25f),p);p.textAlign=Paint.Align.LEFT
        postInvalidateDelayed(60)
    }

    private fun drawFlame(c:Canvas,x:Float,y:Float,size:Float,color:Int){val path=Path();path.moveTo(x,y);path.cubicTo(x-size*.9f,y-size*.28f,x-size*.2f,y-size*.65f,x,y-size);path.cubicTo(x+size*.85f,y-size*.55f,x+size*.9f,y-size*.15f,x+size*.22f,y);path.close();p.color=color;c.drawPath(path,p)}
    private fun dp(v:Float)=v*resources.displayMetrics.density
}
