# STEROWNIK CO Android — v0.18.0 NATIVE PREMIUM UX

Ta wersja rozwija natywny interfejs v0.17.0 bez WebView/HTML jako UI.

## Główne zmiany
- własne natywne ikony zamiast ikon znakowych/emoji w nawigacji i szybkich akcjach,
- natywne stany pressed/selected z ripple,
- bardziej czytelna nawigacja dolna,
- Dashboard zachowuje hierarchię: stan instalacji → szybkie sterowanie → pomiary → bezpieczeństwo → analiza,
- Wykresy otrzymują trzy małe KPI: TERAZ / ZAKRES / PUNKTY,
- statystyki są wyliczane z danych pobranych do aplikacji, RAW Firebase pozostaje bez zmian,
- zachowane są GAP, real-only, filtr anomalii, zoom, marker, osie, linia gładka/schodkowa i analiza.

## Build
W Android Studio: Build → Make Project, potem Run na telefon po Wi‑Fi.
