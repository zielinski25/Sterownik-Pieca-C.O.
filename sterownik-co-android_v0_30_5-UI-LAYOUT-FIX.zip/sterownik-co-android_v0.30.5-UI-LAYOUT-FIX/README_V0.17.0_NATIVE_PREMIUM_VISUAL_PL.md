# STEROWNIK CO Android — v0.17.0 NATIVE PREMIUM VISUAL

Pełny visual rebuild Dashboardu i Wykresów na bazie dotychczasowej natywnej warstwy danych.

Najważniejsze: brak WebView, brak HTML jako UI. Firebase/Auth/telemetria/komendy pozostają bez zmian.

Dashboard: HERO instalacji, szybkie sterowanie, pomiary, sterowanie+bezpieczeństwo, analiza.
Wykresy: jeden workspace, zakres, typ danych, serie, marker, zoom, filtry i analiza.

Przed użyciem: Android Studio → Build → Make Project → Run na telefonie po Wi‑Fi.
