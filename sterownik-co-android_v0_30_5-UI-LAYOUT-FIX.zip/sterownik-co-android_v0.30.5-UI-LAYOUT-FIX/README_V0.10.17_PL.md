# STEROWNIK CO Android v0.10.18-DEV

## Cel tej wersji

**Poprawka builda po v0.10.16:** usunięto błędne wywołanie `bind()`, konflikt nazw `max` w `SeekBar` oraz niejawne literały kolorów `0xFF...`, które Kotlin interpretował jako `Long`.

Przebudowa Dashboardu Android na wzór istniejącego Dashboardu WWW/ESP: pełna lista kafelków, animowany stan LIVE i osobne menu po kliknięciu każdego kafelka.

## Zmiany
- 13 kafelków Dashboardu zgodnych funkcjonalnie z panelem WWW:
  Zewnętrzna, Piec C.O., Bojler, Panel słon., Pomieszczenie, Ciśnienie,
  Wilgotność, Pompa, Serwo, Mieszadło, Czujnik dymu, Wykresy, Data i czas.
- Każdy kafelek operacyjny ma własne menu.
- Menu używa istniejących komend firmware (`/piec/cmd`) i oczekuje ACK z `/piec/ack`.
- Dodane animacje ikon i stanu: pompa/łopatki, mieszadło, serwo, płomień,
  bojler, ciśnienie, wilgotność, dym, słońce, wykresy, zegar.
- Dodany mocniejszy feedback `pressed` kafelków: zmiana tła/obramowania + krótki scale.
- Dashboard zachowuje LIVE status trybu, pompy, dymu i alarmu oraz ma mały trend LIVE.
- Zachowane są istniejące wykresy i telemetryka.
- Logowanie pozostaje oparte o szyfrowany refresh token; chwilowy błąd sieci nie czyści sesji.
- Przy obsłudze ID tokena `TOKEN_EXPIRED` jest traktowany jako sygnał do refreshu, a nie jako powód do wylogowania.

## Ważne
To nadal wersja DEV. Komendy z Dashboardu wykonują rzeczywiste operacje sterownika. Przed wydaniem produkcyjnym trzeba zamknąć Security Rules, autoryzację komend i test ACK/retry/timeout.

## Test użytkownika
1. Uruchom aplikację i potwierdź brak ponownego logowania.
2. Wejdź na Dashboard.
3. Sprawdź wszystkie kafelki: czy mają menu i czy otwierają się bez crasha.
4. Nie wykonuj jeszcze poleceń zmieniających pracę pieca bez świadomego testu na urządzeniu.
5. Sprawdź animacje i reakcję na nacisk.
6. Przejdź do Wykresów i wykonaj krótką regresję 24 H.


## FIX v0.10.18

Naprawiono konflikt nazw `SeekBar.max` z parametrem `max: Float` w `MainActivity.kt`.
Linie budujące suwaki używają teraz jawnie `it.max`, więc Kotlin nie traktuje wartości jako ponownego przypisania parametru funkcji.
