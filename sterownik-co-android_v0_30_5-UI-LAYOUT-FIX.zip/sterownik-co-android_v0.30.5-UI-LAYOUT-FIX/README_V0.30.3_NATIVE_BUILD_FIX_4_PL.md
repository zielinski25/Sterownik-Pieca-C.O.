# STEROWNIK CO Android v0.30.3 — NATIVE BUILD FIX 4

## Naprawy builda

- `logout` ma typ `FrameLayout`, zgodny z `iconButton()`.
- `chartHeight` jawnie zwraca `Int`.
- Terminal nie używa już łańcucha `Sequence.takeLast()/optString()` powodującego błędy inferencji; dane chunks są zbierane do `MutableList<JSONObject>` i ostatnie 80 są wybierane jawnie.
- `NativeIconView.Icon.INFO` ma własny renderer, więc `when(icon)` jest wyczerpujący.
- numer wersji: `0.30.3-NATIVE-BUILD-FIX-4`, code 3003.

## UI

Warstwa UI pozostaje natywna Android; brak WebView jako interfejsu.

## Build

Uruchom w Android Studio: **Build → Make Project**.
