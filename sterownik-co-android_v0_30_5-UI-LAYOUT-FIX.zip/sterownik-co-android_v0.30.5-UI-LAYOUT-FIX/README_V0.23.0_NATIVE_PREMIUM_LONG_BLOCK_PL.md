# STEROWNIK CO — v0.24.0 NATIVE PREMIUM LONG BLOCK

## Cel tej wersji

To jest większy blok prac zamiast kolejnej kosmetycznej łatki. Warstwa UI pozostaje w pełni natywna Android; WWW jest wyłącznie referencją funkcjonalną i wizualną.

## Dashboard

- dynamiczny HERO instalacji: stan kotła, tryb, pompa i alarm,
- natywny banner alarmowy z konkretną przyczyną,
- szybkie sterowanie Pompa / Serwo / Mieszadło,
- wizualne kafelki z animacjami, stanem LIVE/STALE/ALARM i mikro-indykatorem,
- sekcje POMIARY / STEROWANIE I BEZPIECZEŃSTWO / ANALIZA,
- natywne KPI trendu temperatur,
- lepsza obsługa danych nieświeżych i chwilowego offline.

## Wykresy

- workspace natywnego Chart Studio,
- TEMPERATURY / SERWA,
- 6 H / 24 H / 7 DNI / 30 DNI,
- przewijany wybór serii,
- wspólna / podzielona / znormalizowana / od startu / XY,
- gładka / schodkowa,
- tylko rzeczywiste, filtr anomalii, pasmo min-max,
- marker, zoom kotwiczony w miejscu gestu, pan po powiększeniu,
- mini-nawigator zakresu,
- właściwe oznaczenia GAP,
- analiza PRO: min / max / średnia / zmiana / GAP / A-B,
- alarmy 4-poziomowe jako linie pomocnicze LoLo / Lo / Hi / HiHi,
- prawidłowa konwersja pozycji serw: Klapa 0..180°, Syberek 0..90° → 0..100%.

## Moduły natywne

- Pogoda: bezpośredni HTTPS do Open-Meteo na współrzędnych używanych przez panel WWW,
- Logi: natywna diagnostyka aplikacji i przejście do lokalnego panelu pieca,
- Terminal: odczyt ostatnich chunków Remote Terminal z Firebase, gdy sesja diagnostyczna jest dostępna,
- OTA: natywna karta informacyjna + przejście do lokalnego panelu pieca,
- Sesja: stan logowania, ostatni odczyt i informacje o przechowywaniu sesji.

## Bezpieczeństwo i komunikacja

- Firebase Auth/REST pozostaje bez zmian,
- refresh token nadal przechowywany szyfrowanie przez Android Keystore,
- komendy przechodzą przez `/piec/cmd` i są potwierdzane ACK,
- timeout nie jest pokazywany jako wykonanie,
- brak WebView jako warstwy UI.

## Weryfikacja w tym środowisku

- wykonano statyczny audyt źródeł,
- usunięto wykryty błąd składniowy `setStale(...)`,
- ZIP będzie zawierał ten README i zaktualizowany Master Plan,
- pełny Android Studio `Build → Make Project` nadal wymaga środowiska użytkownika z Android SDK.

## Uruchomienie

Android Studio → File → Open → wybierz folder projektu → Build → Make Project → Run → telefon po Wi‑Fi.
