# STEROWNIK CO Android — v0.21.0 NATIVE PRODUCT UI

Pełna warstwa UI pozostaje natywnym Android View/Canvas — bez WebView i bez HTML jako interfejsu.

## Cel tej wersji

- ujednolicenie języka wizualnego z najlepszymi cechami istniejącego WWW,
- ograniczenie ciężkich, przypadkowych bloków sterowania,
- pierwszeństwo danych i wykresu nad dekoracją,
- cyan jako kolor podstawowej nawigacji i analizy, orange jako akcent urządzeń/akcji,
- dopracowane natywne bottom sheet z uchwytem,
- poprawa wydajności Canvas przez hardware layer.

## Test

Android Studio → Build → Make Project → Run na telefonie po Wi‑Fi.
