# STEROWNIK CO — v0.22.0 NATIVE PREMIUM FINISH

Kolejny etap natywnego UI. Bez WebView i bez HTML jako warstwy interfejsu.

## Zmiany
- natywne ikony również w menu Ustawienia/Więcej i akcjach przejścia,
- usunięto symbole znakowe używane wcześniej jako strzałki w kluczowych miejscach,
- szybkimi akcjami sterowania nadal obsługują Pompa/Serwo/Mieszadło, ale otrzymały spójny komponent ikony + opis + przejście,
- wykres otrzymał subtelne wypełnienie dla pojedynczej serii, linię OSTATNI i punkty końcowe,
- zachowano GAP, marker, zoom, pan, wspólną/podzieloną oś, filtry i analizę,
- wersja aplikacji: 0.22.0-NATIVE-PREMIUM-FINISH / versionCode 2200.

## Build
Android Studio → Build → Make Project → Run na telefonie po Wi‑Fi.
