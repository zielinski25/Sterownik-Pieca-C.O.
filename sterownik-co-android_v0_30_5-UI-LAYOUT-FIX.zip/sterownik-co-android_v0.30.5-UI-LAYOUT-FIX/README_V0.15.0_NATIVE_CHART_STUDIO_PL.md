# STEROWNIK CO Android — v0.15.0 NATIVE CHART STUDIO

## Cel tej wersji

v0.15.0 przebudowuje ekran **Wykresy** jako jeden spójny natywny „Chart Studio”, zamiast kilku kart z dużymi rzędami przycisków.

### Najważniejsze zmiany

- jeden aktywny obszar analizy: **TEMPERATURY / SERWA**,
- zakres: **6 H / 24 H / 7 DNI / 30 DNI**,
- osobna strefa serii z małymi chipami,
- osobne akcje: **SERIE / WIDOK / NARZĘDZIA**,
- reset widoku zawsze przy wykresie,
- odczyt bieżących wartości pod wykresem,
- zachowane zoom, marker, GAP, q/sim i filtr anomalii,
- serwa mają stały zakres 0–100%,
- historia 24 h ładuje się automatycznie po przywróceniu sesji,
- UI nadal w 100% natywne Android Views — bez WebView/HTML jako interfejsu.

## Test na telefonie

1. Otwórz projekt w Android Studio.
2. `Build → Make Project`.
3. `Run ▶` na telefonie po Wi‑Fi.
4. Wejdź w `Wykresy`.
5. Sprawdź kolejno `24 H`, `7 DNI`, `SERWA`.
6. Sprawdź marker dotykiem, pinch zoom i `SERIE/WIDOK/NARZĘDZIA`.
7. Sprawdź, czy po restarcie aplikacji sesja i historia zostają dostępne.

## Znane ograniczenie środowiska

Pełny build Androida musi zostać potwierdzony w Android Studio, ponieważ paczka nie zawiera kompletnego lokalnego Android SDK tego środowiska.
