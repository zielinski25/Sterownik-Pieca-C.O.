# STEROWNIK CO Android — v0.29.0 NATIVE ADAPTIVE PRO

## Cel
Pełna przebudowa warstwy wizualnej aplikacji bez WebView. Referencją funkcjonalną i stylistyczną jest istniejący panel WWW/ESP, ale interfejs pozostaje natywnym Androidem.

## Zmiany
- kompaktowy system strip i HERO na Dashboardzie,
- szybsze dojście do sterowania pompą, serwem i mieszadłem,
- mniejszy ciężar wizualny nagłówków i dolnej nawigacji,
- siatka pomiarów zachowuje 13 funkcji i osobne handlery,
- Wykresy zostały przełożone na jeden workspace z czytelnym rail'em danych, zakresu i narzędzi,
- marker, zoom, GAP, q/sim, analiza i pełny ekran pozostają natywne,
- wersja aplikacji 0.29.0.

## Ważne
Pełny Build Android Studio musi zostać potwierdzony na PC; środowisko generujące paczkę nie ma kompletnego Android SDK.

- siatka kafelków jest adaptacyjna: 2/3/4 kolumny zależnie od szerokości okna,
- workspace wykresu zwiększa wysokość na większych ekranach,
- usunięto nieużywany legacy renderer TelemetryChartView.
