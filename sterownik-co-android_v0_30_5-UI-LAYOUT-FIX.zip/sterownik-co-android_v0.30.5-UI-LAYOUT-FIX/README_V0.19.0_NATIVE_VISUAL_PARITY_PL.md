# STEROWNIK CO Android — v0.19.0 NATIVE VISUAL PARITY

Ta wersja kontynuuje natywną przebudowę UI. Nie używa WebView ani HTML jako warstwy interfejsu.

## Zmiany
- wielowarstwowe ilustracje kafelków: słońce/chmura, płomień, bojler z wodą, panel, dom, manometr, kropla, pompa, serwo, mieszadło, dym, wykres i zegar,
- richer native HERO kotła z rurami, łukiem temperatury i palnikiem,
- bardziej zwarte nagłówki i nawigacja,
- większa przestrzeń robocza wykresu,
- poprawiony renderer przebiegów,
- poprawka błędu `row.sim ushr it`,
- zachowane Firebase/Auth, telemetryka, GAP, q/sim, zoom, marker i analiza.

## Build
Otwórz projekt w Android Studio, wykonaj `Build > Make Project`, następnie `Run` na telefonie przez Wi‑Fi.
