# STEROWNIK CO Android — v0.21.1 NATIVE PRODUCT UI

Dopracowanie natywnego języka ikon i stanów wybranych kontrolek.

- natywne ikony odświeżenia, resetu i zamknięcia;
- spójny cyan selected-state w analizatorze;
- bottom sheet z uchwytem i natywną kontrolką zamknięcia;
- bez WebView/HTML jako UI.

Test: Android Studio → Build → Make Project → Run po Wi‑Fi.
