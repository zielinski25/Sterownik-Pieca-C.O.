# STEROWNIK CO Android v0.30.4 — UI STABILITY FIX

## Naprawione (na podstawie zrzutów ekranu i przeglądu kodu)

**UI**
- Poucinane kafelki/chipy: w `MainActivity` 21 wierszy z wagą miały wysokość podaną w *pikselach* (`LayoutParams(0,46,1f)`),
  a nie w dp. Dotyczyło: mini-statusów hero (TRYB/POMPA/BEZPIECZEŃSTWO), kart szybkiego sterowania, kart „Wykresy / Data i czas",
  chipów DANE/ZAKRES, kafelków ZAKRES/PUNKTY/ZOOM, paska akcji wykresu, stopek arkuszy i formularza alarmów. Teraz `dp(...)`.
- Wykres bywał pusty: animacja „reveal" mogła zostać na 0 po `cancel()` / odłączeniu widoku. Teraz zawsze kończy na 100%.
  Usunięto też zbędny `LAYER_TYPE_HARDWARE` z widoku wykresu.
- Kafelki potrafiły pokazać „STALE" przy aktywnym LIVE: wiek danych był liczony na wątku roboczym i trafiał na UI po odświeżeniu.
  Teraz liczony na UI, a świeże dane zdejmują STALE.

**Stabilność / sesja**
- Odświeżanie tokenu w trakcie wylogowania mogło przywrócić zapisaną sesję. Dodano blokadę w `ensureToken`.
- Wylogowanie czyści teraz dane na ekranie (wykresy, ostatni status).
- Odpytywanie co 5 s: `scheduleWithFixedDelay` zamiast `scheduleAtFixedRate` (brak serii zaległych żądań po uśpieniu procesu),
  wstrzymane gdy aplikacja w tle, natychmiastowe odświeżenie po powrocie (`onStart`).
- Historia i komendy mają własne wątki (30 s oczekiwania na ACK nie blokuje już wykresów). Przy szybkim przełączaniu
  zakresu 6H/24H/7D/30D stare odpowiedzi są odrzucane.

**Sterowanie**
- Polecenia `ustaw …` i `symuluj…` wymagają potwierdzenia przed wysłaniem.
- Odrzucony ACK (`ok=false`) pokazuje komunikat błędu sterownika zamiast „brak potwierdzenia".

## Nie zmieniono (do decyzji)
- `FirebaseCommandRest.commandToken` jest wpisany na stałe w kodzie.
- Brakuje `gradle/wrapper/gradle-wrapper.jar` (działa z Android Studio, nie z CLI `./gradlew`).
- Brak własnej ikony aplikacji.

Wersja: 0.30.4-UI-STABILITY-FIX, code 3004. Zbuduj: **Build → Make Project**.
