# STEROWNIK CO Android v0.10.12-DEV

Wersja ukierunkowana na WARSTWĘ WIZUALNĄ I UX.

## Założenie

Android ma wizualnie i funkcjonalnie zmierzać w stronę referencyjnego panelu WWW STEROWNIK CO:
- ciemne granatowe tło,
- karty i kafelki z zaokrąglonymi rogami,
- pomarańczowy/cyjanowy język akcentów,
- górna nawigacja w stylu panelu,
- Dashboard jako zestaw kafelków,
- Wykresy jako osobne karty.

Na ten moment faktyczne moduły Firebase pozostają bez zmian. Przyciski Ustawienia/Pogoda/Logi/Terminal/OTA są obecne jako nawigacja UX i sygnalizują, że moduł jest zaplanowany, ale jeszcze nie wdrożony w Androidzie.
