# STEROWNIK CO — v0.20.0-NATIVE-PREMIUM-CHART-STUDIO-2

## Cel tej wersji
Pełne uporządkowanie ekranu Wykresy bez powrotu do WebView. Warstwa danych, Firebase Auth/REST, telemetria, GAP i komendy pozostają natywne.

## Najważniejsze zmiany
- jeden spójny workspace wykresu,
- spokojniejsze, małe przełączniki zakresu i widoku,
- brak wielkich bloków pomarańczowych jako podstawowej nawigacji,
- aktywne serie są widoczne jako kompaktowy pasek legendy,
- `SERIE / OŚ / FILTRY / ANALIZA` są czterema czytelnymi akcjami,
- wykres zajmuje większą część ekranu,
- usunięto powtarzające się badge'e serii rysowane wewnątrz pola wykresu,
- usunięto dekoracyjne wypełnienie pod każdą serią, które zwiększało wizualny chaos,
- wzmocniono czytelność osi i jednostki,
- pozostaje marker, tooltip, pinch-zoom, przesuwanie po zoomie i GAP,
- serwa pozostają w skali 0–100%,
- UI pozostaje natywne Android Views — bez WebView/HTML jako warstwy UI.

## Test
Android Studio → Open projekt → Build → Make Project → Run na telefonie po Wi‑Fi.

Pełny build Android SDK nie jest wykonywany w tym środowisku; wykonanie kompilacji końcowej należy potwierdzić w Android Studio.
