# STEROWNIK CO Android — v0.10.11-DEV

## Co jest w tej wersji

Wykresy 1.0 — pierwszy krok warstwy jakości danych:

- `q` dla kanałów temperatury jest interpretowane zgodnie z kontraktem 2-bitowym; FRESH tworzy główną linię, STALE nie jest z nią łączone, a q=2/3 nie jest rysowane.
- `sim` jest oznaczane na wykresie punktami.
- `age` jest pokazywany jako maksymalny znany wiek danych dla temperatur.
- rekordy z identycznym `ts` nie tworzą sztucznych pionowych odcinków; konflikt wartości w tym samym `ts` jest pomijany w warstwie prezentacji.
- położenie punktów na osi X wynika z czasu, dzięki czemu GAP jest rzeczywistą przerwą.
- wielodniowe zapytania RTDB mają osobne `start/end` dla każdego sharda dnia.
- klapa i syberek pozostają prezentowane jako procenty z kątów telemetrycznych.

## Test po instalacji

1. Uruchom aplikację na telefonie po Wi-Fi z Android Studio.
2. Sesja powinna wznowić się bez ponownego logowania.
3. Otwórz **WYKRESY**.
4. Sprawdź kolejno **24 H**, **7 DNI**, **30 DNI**.
5. Sprawdź, czy nie ma crasha, a GAP-y pozostają przerwami.
6. Na wykresie temperatury sprawdź opis `Jakość temp`.

Nie wykonujemy jeszcze komend sterujących, zapisów nastaw, OTA ani zmian firmware tylko z powodu tej wersji Androida.


## v0.10.11 — korekta czytelności Wykresów

Test v0.10.10 pokazał, że przy zakresie wielodniowym wysoki pik Bojlera nadmiernie ściskał Zewn./Ogrzewanie. W v0.10.11:

- przy dużej różnicy poziomów stosowane są dwie jawnie opisane skale: lewa dla Zewn./Ogrzewanie, prawa dla Bojlera,
- STALE są nadal liczone i raportowane, ale nie są domyślnie rysowane jako setki markerów,
- komunikat używa nazwy `max age FRESH`, aby nie sugerować, że jest to maksymalny wiek STALE,
- zachowano GAP > 150 s, deduplikację `ts`, filtr anomalii i przeliczenie serw na %.
