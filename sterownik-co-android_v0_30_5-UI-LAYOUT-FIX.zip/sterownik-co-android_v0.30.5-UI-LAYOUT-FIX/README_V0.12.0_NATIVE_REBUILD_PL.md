# STEROWNIK CO Android — v0.12.0 NATIVE REBUILD

To jest pełna przebudowa warstwy UI bez WebView i bez HTML jako interfejsu.

## Kierunek

WWW pozostaje referencją funkcjonalną i wizualną. Android używa natywnych widoków oraz własnego Canvas tylko tam, gdzie jest potrzebny (wykresy, grafika kotła, ikony).

## Dashboard

Nowa hierarchia:

`STAN INSTALACJI → NAJWAŻNIEJSZE → STEROWANIE → INFORMACJE`

13 funkcji referencyjnych nadal jest dostępnych:

- Zewnętrzna
- Piec C.O.
- Bojler
- Panel słon.
- Pomieszczenie
- Ciśnienie
- Wilgotność
- Pompa
- Serwo
- Mieszadło
- Czujnik dymu
- Wykresy
- Data i czas

## Wykresy

- osobny wybór serii,
- osobny wybór trybu osi,
- narzędzia w natywnym panelu zamiast szerokich rzędów przycisków,
- temperatura i pozycje serw mają różne domyślne prezentacje,
- serwo ma stałą skalę 0–100%,
- schodkowa linia jest domyślna dla pozycji serw,
- GAP nadal jest zachowywany,
- zachowane są 6 h / 24 h / 7 dni / 30 dni.

## Firebase

Bez zmian w kontrakcie Auth/RTDB/ACK i telemetrii. Hasło nie jest zapisywane.

## Ważne

Pełny Build Android Studio i test na realnym telefonie pozostają obowiązkowym krokiem przed kolejną wersją.

## Co zostało przebudowane wizualnie

- jedna hierarchia informacji na Dashboardzie zamiast „ściany” równych kafelków,
- compact top bar,
- sekcje Najważniejsze / Sterowanie / Informacje,
- Wykresy z trzema poziomami sterowania: zakres, seria, widok, narzędzia,
- kontrolki narzędzi otwierane w natywnym panelu od dołu,
- brak szerokich rzędów przycisków wychodzących poza ekran,
- wykres nie maluje już drugiej karty w środku karty,
- tooltip wykresu jest mały i nie zakrywa całej powierzchni danych,
- serwo ma skalę 0–100% i linię schodkową.
