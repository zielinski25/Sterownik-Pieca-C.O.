# STEROWNIK CO Android v0.30.2 — NATIVE BUILD FIX 3

Poprawki względem v0.30.1:
- `DashboardOverviewView`: wywołanie `path.cubicTo(...)` na właściwym obiekcie `Path`.
- `NativeIconView`: dodane brakujące ikony `EXPAND` i `INFO`.
- `ProfessionalTelemetryChartView`: jawny receiver `this.color` w `Paint.apply`.
- `MainActivity`: dodane `dp(Float)` dla wysokości wykresu i poprawiony receiver `v` w `primaryChartAction`.

UI pozostaje natywny Android.
