# STEROWNIK CO Android — v0.16.0 NATIVE CHART STUDIO PRO

## Cel wersji
Kolejna przebudowa modułu WYKRESY. UI pozostaje natywne Android Views — bez WebView i bez HTML jako warstwy interfejsu.

## Najważniejsze zmiany
- jeden główny obszar wykresu zamiast wielu zagnieżdżonych kart,
- spokojniejszy selected-state zakresów i trybów,
- poziomy, przewijany wybór aktywnych serii,
- osobne akcje `SERIE`, `OŚ`, `FILTRY`, `ANALIZA`,
- kompaktowy marker i tooltip z wartościami kilku serii,
- kolorowe punkty na przecięciu kursora z przebiegami,
- 6 znaczników osi czasu z datą dla długich zakresów,
- subtelne oznaczenia rzeczywistych GAP,
- dolny pasek kontekstu pokazujący pełny zakres i poziom zoomu,
- zoom do 24× oraz przesuwanie zakresu po powiększeniu,
- wspólna skala jako domyślny widok temperatur,
- prawdziwe dwie osie w trybie `PODZIELONE`, gdy serie mają różne jednostki,
- panel `Analiza PRO`: min/max/średnia/zmiana, liczba GAP i porównanie A−B,
- interakcja wykresu aktualizuje tekst markera w UI.

## Zachowane kontrakty
- Firebase Authentication i trwała sesja,
- `/piec/status`, `/piec/cmd`, `/piec/ack`,
- kontrakt telemetrii `seq, ts, mono, a[11], k, s, state, q, sim, age[11]`,
- konwersja serw: Klapa 0..180° → 0..100%, Syberek 0..90° → 0..100%,
- GAP > 150 s,
- RAW danych Firebase nie jest modyfikowany przez filtry prezentacyjne.

## Ważne
Pełny build Android Studio i test na fizycznym telefonie pozostają wymagane przed uznaniem wersji za stabilną.
