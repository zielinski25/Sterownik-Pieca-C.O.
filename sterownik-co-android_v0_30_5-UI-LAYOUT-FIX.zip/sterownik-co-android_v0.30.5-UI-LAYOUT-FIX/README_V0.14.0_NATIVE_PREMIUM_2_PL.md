# STEROWNIK CO Android — v0.14.0 NATIVE PREMIUM 2

Ta wersja jest kolejnym krokiem przebudowy UI po testach ekranów telefonu.

## Najważniejsze

- natywny Android Views, bez WebView/HTML jako warstwy UI,
- stabilizacja danych wykresu: sortowanie po `ts` + deduplikacja timestampów,
- 1x: przeciągnięcie przesuwa marker, nie panoramuje całego wykresu,
- pan aktywuje się dopiero po zoomie,
- wyraźniejsze tło pola wykresu i delikatna siatka,
- nagłówek trybu wykresu nad osią,
- zachowane GAP > 150 s,
- zachowane serwa 0–100%, q/sim, Firebase/Auth i komendy/ACK.

## Cel następnego testu

Na telefonie sprawdzić:

1. Dashboard — czy hierarchia jest czytelna przy przewijaniu.
2. Wykres temperatur — czy nie ma pionowych igieł ani sztucznych połączeń.
3. Marker — czy przesuwa się płynnie przy 1x.
4. Zoom — pinch lub `+`, następnie pan jednym palcem.
5. Serwa — stała oś 0–100% i schodkowy przebieg.
