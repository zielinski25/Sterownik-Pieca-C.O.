# STEROWNIK CO Android v0.10.14-DEV

Cel tej wersji: **LIVE Dashboard + wyraźny feedback interakcji + lepsza obsługa wykresów**.

## Zmiany
- Dashboard pobiera `/piec/status` cyklicznie co kilka sekund podczas aktywnej sesji.
- Dodano live status: tryb, pompa, dym, alarm oraz czas ostatniej aktualizacji.
- Dodano trend LIVE dla temperatur Zewn./Piec/Bojler.
- Dodano dodatkowe dane: Ogrz. śr., Powrót, Panel, Pokój, Wilgotność, Ciśnienie.
- Zakres 24 H / 7 DNI / 30 DNI ma stan zaznaczenia i animowany feedback naciśnięcia.
- Nawigacja ma stan aktywny i stan pressed.
- Wykresy mają dwuklik resetu, rozróżniają tap od pan oraz mają przyciski zoom +/-/reset.
- Crosshair pokazuje konkretny punkt i wartości.

## Ważne
To jest **DEV do testu użytkownika**. Nie uznajemy jeszcze Wykresów 1.0 za zamknięte.
