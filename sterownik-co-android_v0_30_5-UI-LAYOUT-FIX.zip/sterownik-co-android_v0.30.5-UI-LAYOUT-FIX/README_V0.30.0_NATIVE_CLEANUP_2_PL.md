# STEROWNIK CO Android — v0.30.1 NATIVE BUILD FIX 2

Naprawa błędów potwierdzonych w Android Studio po v0.30.0.

- `BoilerHeroView.kt`: poprawiono `Path.cubicTo(...)` — usunięto błędny dodatkowy argument `Path`.
- `MainActivity.kt`: rozdzielono deklaracje helperów `action()` i `label()` oraz doprecyzowano typ zwracany `action()`.
- wersja aplikacji: `0.30.1`.

Interfejs pozostaje natywnym Android Views; Firebase/Auth/telemetria bez zmian.
