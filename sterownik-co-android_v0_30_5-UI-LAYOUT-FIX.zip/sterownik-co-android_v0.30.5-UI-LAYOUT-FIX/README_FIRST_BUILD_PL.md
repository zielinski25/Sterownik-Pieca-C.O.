# STEROWNIK CO ANDROID — v0.11.3-NATIVE-PRO-UI

To jest **natywna aplikacja Android**. Interfejs nie korzysta z WebView, HTML ani JavaScript.

## Co jest w tej wersji

- natywny Dashboard z 13 kafelkami,
- natywne animacje i ekran główny z panelem stanu instalacji,
- natywne Wykresy z wyborem serii, trybami osi, zoomem, przesuwaniem, crosshair i obsługą GAP,
- Firebase Authentication + szyfrowana sesja,
- komunikacja z istniejącym `/piec/status`, `/piec/cmd` i ACK.

## Uruchomienie w Android Studio — Windows

1. Rozpakuj ZIP do **nowego folderu**. Nie wgrywaj plików do starego projektu 0.10.x.
2. W Android Studio wybierz `File → Open` i wskaż folder główny zawierający `settings.gradle.kts`.
3. Poczekaj na `Gradle Sync`.
4. Jeżeli Android Studio poprosi o JDK, wybierz **Embedded JDK 17**.
5. Wybierz `Build → Make Project`.
6. Dopiero po poprawnym buildzie uruchom `Run ▶` na telefonie po Wi‑Fi.

## Ważne

Nie otwieraj do testu wersji `0.10.20-PRO` ani `0.10.21-DEV` — wcześniejsze paczki z tego ciągu zawierały niepożądane podejście WebView. Ta wersja jest kontynuacją natywnego projektu.

## Logowanie i sesja

Przy pierwszym uruchomieniu wpisujesz e-mail i hasło Firebase. Hasło nie jest zapisywane.

Po poprawnym logowaniu aplikacja zapisuje szyfrowany refresh token i przy kolejnym uruchomieniu próbuje odtworzyć sesję bez pokazywania logowania. Chwilowy brak internetu nie powinien usuwać sesji. `WYLOGUJ` usuwa sesję lokalną.

## Firebase DEV

Projekt korzysta z istniejącej konfiguracji DEV. Nie wpisuj hasła operatora ani prywatnych tokenów do plików projektu.

## Test po instalacji

Najpierw sprawdź: logowanie → Dashboard → kafelek Wykresy → zmiana zakresu → powrót Dashboard → zamknięcie aplikacji → ponowne uruchomienie.

Jeżeli `Build → Make Project` pokaże błąd, wklej **cały pierwszy czerwony błąd z Build Output** — nie zmieniaj projektu na własną rękę.
