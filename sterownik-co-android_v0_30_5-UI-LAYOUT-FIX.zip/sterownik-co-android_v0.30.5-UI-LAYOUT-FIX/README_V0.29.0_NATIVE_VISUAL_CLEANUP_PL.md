# STEROWNIK CO Android — v0.29.0 NATIVE VISUAL CLEANUP

## Cel
Stabilizacja i wizualne uporządkowanie natywnego Dashboardu oraz Wykresów na podstawie rzeczywistych ekranów telefonu.

## Zmiany
- dolna nawigacja ma jeden spokojny stan aktywny zamiast czterech ciężkich ramek,
- wszystkie ekrany przewijane mają dodatkowy dół, dzięki czemu dolna nawigacja nie zasłania treści,
- wysokość wykresu jest dobierana do wysokości okna zamiast używania niekontrolowanie dużego obszaru,
- dodano brakujący mechanizm animacji reveal wykresu,
- wymuszono redraw po ustawieniu telemetrii,
- zmniejszono glow i grubość przebiegów,
- zmniejszono etykiety końcowe serii,
- poprawiono numerację wersji w module OTA.

## Architektura
UI pozostaje natywnym Android Views. Brak WebView/HTML jako warstwy interfejsu.

## Ważne
Pełny `Build -> Make Project` musi zostać potwierdzony w Android Studio na komputerze testowym.
