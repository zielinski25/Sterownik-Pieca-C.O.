# STEROWNIK CO Android v0.30.5 — UI LAYOUT FIX

Druga runda poprawek ucinanych ramek (po zrzutach z v0.30.3).

1. `lp(w,h,N)` ustawia **górny** margines. W poziomych wierszach miało to być odsunięcie od lewej, więc przyciski
   były spychane w dół i ucinane: przycisk „…" w nagłówku, REAL, reset i pełny ekran wykresu, pigułka stanu CENTRALA CO,
   kocioł w hero, tytuły sekcji. Dodano `lpS()` (margines START) i podmieniono te miejsca.
2. Dolna nawigacja: przyciski miały 51 dp w pasku o dostępnych 47 dp. Teraz pasek 72 dp, przyciski 54 dp.
3. Nagłówek 54 → 60 dp. Pasek CENTRALA CO bez sztywnej wysokości.
4. Chipy serii na wykresie: padding kontenera zjadał 13 z 30 dp wysokości. Usunięty.
5. (z v0.30.4) wysokości w pikselach zamiast dp — 21 miejsc.

Wersja w Ustawienia Androida → Aplikacje → STEROWNIK CO ma pokazać **0.30.5-UI-LAYOUT-FIX**.
Jeśli widzisz starszą, to uruchomiona jest stara kompilacja.
