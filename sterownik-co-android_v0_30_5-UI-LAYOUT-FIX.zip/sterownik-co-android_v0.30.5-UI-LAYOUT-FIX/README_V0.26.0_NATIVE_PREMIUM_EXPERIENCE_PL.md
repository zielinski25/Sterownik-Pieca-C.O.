# STEROWNIK CO Android — v0.26.0 NATIVE PREMIUM EXPERIENCE

Duży blok poprawy UX na bazie v0.25.0.

## Wykresy
- pełny ekran analizatora historii,
- kopiowanie aktywnych serii i trybu do widoku pełnoekranowego,
- własna natywna ikona Expand,
- większa powierzchnia robocza wykresu,
- wspólna/podzielona skala, GAP, marker, zoom, pan i analiza pozostają dostępne.

## Dashboard / UI
- zachowana architektura natywna Android Views,
- istniejące Firebase/Auth/REST bez zmian,
- zero WebView/HTML jako warstwy UI.

## Test
Po rozpakowaniu: Android Studio → Open → Build → Make Project → Run na telefonie po Wi-Fi.
