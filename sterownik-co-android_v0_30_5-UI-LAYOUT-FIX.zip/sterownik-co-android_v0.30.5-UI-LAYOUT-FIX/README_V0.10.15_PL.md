# STEROWNIK CO Android v0.10.15-DEV

## Cel
Naprawa trwałości sesji Firebase: aplikacja nie ma wylogowywać użytkownika z powodu chwilowego braku sieci lub pojedynczego błędu HTTP.

## Zmiany
- zapis szyfrowanego refresh tokena pozostaje podstawą sesji,
- dodatkowo szyfrowany jest ostatni ID token i jego czas wygaśnięcia,
- automatyczne odświeżanie ID tokena przed jego wygaśnięciem,
- odświeżanie działa także podczas długiego pozostawienia aplikacji otwartej,
- jednorazowy błąd sieci nie czyści zapisanej sesji,
- aplikacja ponawia połączenie automatycznie,
- ekran logowania pojawia się ponownie tylko wtedy, gdy Firebase jednoznacznie odrzuci sesję (np. unieważniony refresh token, konto usunięte/wyłączone),
- zapytania Dashboardu i historii mogą odświeżyć token i ponowić odczyt po jego wygaśnięciu.

## Test użytkownika
1. Zalogować się raz.
2. Zamknąć aplikację.
3. Po kilku godzinach uruchomić ponownie.
4. Sprawdzić, czy nie ma ekranu logowania.
5. Przy aktywnej aplikacji pozostawić ją na kilka godzin i sprawdzić, czy Dashboard nadal odświeża dane.

Hasło nie jest zapisywane.
