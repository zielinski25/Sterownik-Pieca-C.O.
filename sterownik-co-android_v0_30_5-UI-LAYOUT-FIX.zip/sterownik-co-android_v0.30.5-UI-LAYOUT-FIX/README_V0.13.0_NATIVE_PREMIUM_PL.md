# STEROWNIK CO Android — v0.13.0 NATIVE PREMIUM

## Cel
Pełna przebudowa warstwy UI na podstawie rzeczywistego panelu WWW jako referencji funkcjonalnej i wizualnej. Android pozostaje natywną aplikacją — bez WebView, HTML i JavaScript jako warstwy interfejsu.

## Najważniejsze zmiany
- Dashboard: nowa hierarchia informacji i kompaktowe kafelki.
- HERO: wizualizacja stanu kotła, trybu, pompy i alarmu.
- Wykresy: zakres, serie, osie i narzędzia rozdzielone na czytelne komponenty.
- Serie można przełączać bezpośrednio z poziomego paska.
- Narzędzia wykresu są w natywnym bottom sheet.
- GAP > 150 s nadal rozcina przebieg.
- Serwa są prezentowane jako 0–100%.
- Konto operatora nie jest eksponowane pełnym adresem e-mail w głównym nagłówku.

## Build
1. Otwórz projekt w Android Studio.
2. Ustaw Embedded JDK 17.
3. Wykonaj Build → Make Project.
4. Uruchom na telefonie po Wi-Fi.

## Ważne
Pełny build Android SDK powinien zostać potwierdzony na komputerze z Android Studio. Projekt nie używa WebView jako warstwy UI.
