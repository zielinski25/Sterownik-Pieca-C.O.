# STEROWNIK CO — v0.24.0 NATIVE PRODUCT INTERACTION

To jest większy blok prac UI/UX i wykresów. Interfejs pozostaje natywnym Android Views. HTML nie jest warstwą UI aplikacji.

## Dashboard
- kompaktowy top bar z graficznym menu sesji,
- wyraźniejsze sekcje i separator wizualny,
- większe kafelki telemetryczne z animowanymi ilustracjami,
- szybkie sterowanie pozostaje oddzielone od pomiarów,
- zachowane LIVE / STALE / ALARM i feedback dotykowy.

## Chart Studio
- jedno spójne pole robocze,
- zestaw danych TEMPERATURY / SERWA,
- zakres 6 H / 24 H / 7 DNI / 30 DNI,
- serie jako przewijane chipy,
- osobne OŚ / FILTRY / ANALIZA,
- wspólna / podzielona / znormalizowana / od startu / XY,
- marker i tooltip,
- zoom + pan po powiększeniu,
- mini-nawigator,
- GAP > 150 s jako prawdziwa przerwa,
- dzień jako delikatna strefa przy dłuższych zakresach,
- oś czasu z datą i godziną przy 7/30 dniach,
- pasmo min–max jako obwiednia całego zestawu aktywnych serii,
- linie pomocnicze LoLo / Lo / Hi / HiHi,
- analiza min / max / średnia / zmiana / GAP / A−B,
- serwa zawsze 0–100% zgodnie z kontraktem firmware.

## Sesja i bezpieczeństwo
- hasło nie jest przechowywane,
- refresh token pozostaje szyfrowany przez Android Keystore,
- wylogowanie przeniesiono do menu sesji, aby nie zaśmiecać Dashboardu,
- komendy nadal przechodzą przez `/piec/cmd` i są potwierdzane przez ACK.

## Weryfikacja
- statyczna kontrola balansu nawiasów Kotlin: OK,
- brak funkcjonalnych odwołań do WebView / android.webkit,
- brak zduplikowanych deklaracji metod poza prawidłowym przeciążeniem `lp`,
- pełny Android Studio Build nadal wymaga lokalnego Android SDK.

## Uruchomienie
Android Studio → File → Open → wybierz folder projektu → Build → Make Project → Run → telefon po Wi‑Fi.
