# STEROWNIK CO Android v0.10.13-DEV

Wykresy 1.0 — UX i interaktywność.

Zmiany:
- animowane odsłanianie przebiegu po zmianie zakresu,
- crosshair + tooltip po dotknięciu wykresu,
- czytelniejsze osie i skale,
- lżejsza decymacja długich przebiegów serw,
- zachowane GAP > 150 s, q/STale, filtr anomalii i przeliczenie kątów serw na %.

Test: 24 H / 7 DNI / 30 DNI oraz dotknięcie/przesunięcie wykresu.
