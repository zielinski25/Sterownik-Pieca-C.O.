# STEROWNIK CO Android — v0.10.18-DEV

## FIX BUILD

v0.10.17 zatrzymywał się na 4 błędach Kotlin w `MainActivity.kt`.
Przyczyną był konflikt parametru funkcji `max: Float` z właściwością `SeekBar.max` wewnątrz `apply {}`.

v0.10.18 używa jawnie:
- `it.max = ...`
- `it.progress = ...`

## Test

1. Otwórz projekt w Android Studio.
2. **Build → Make Project**.
3. Dopiero po sukcesie uruchom **Run ▶** na telefonie po Wi-Fi.
4. Sprawdź Dashboard: 13 kafelków i własne menu każdego klikalnego kafelka.

Nie zmieniono kontraktu Firebase `/piec/status`, `/piec/cmd`, `/piec/ack`.
