# Reference points for agent

## HTML
- `html/Piec_CO_App_v2_19_WYKRESY_SERWO_PROCENT.html` — newest advanced chart-focused HTML version included in the handoff.
- `html/Piec_CO_App_v2_9_TERMINAL_LIVE_WYKRESY_POGODA.html` — integrated terminal + live + charts + weather baseline.
- Earlier `v1_*` and `v2_*` files are historical iterations and contain useful fixes/behavior that may not all be present in one file.

## Documentation
- `docs/WYKRESY_RESEARCH_v2_16.md` — chart research notes.
- `docs/Research_Terminal_Firebase_ESP32_v2.md` — terminal/Firebase research.
- `docs/TELEMETRIA_RESEARCH_PLAN_R216.md`, `...R238.md`, `...R240.md` — telemetry architecture and test history.
- `docs/R*.md` — implementation plans, handoffs, test reports, master states.

## Safety
All embedded credentials found in the HTML/Markdown handoff were removed or replaced with `[REMOVED_*]` placeholders. The original Library files were not modified.
