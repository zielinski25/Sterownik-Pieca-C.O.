# Sterownik CO — SAFE HANDOFF

Ten pakiet jest przygotowany do przekazania agentowi zewnętrznemu. Zawiera historyczne wersje aplikacji HTML oraz dokumentację Markdown dotyczącą projektu.

## Zakres
- `html/` — wszystkie znalezione wersje panelu HTML `Piec*` / `wykresy*`.
- `docs/` — dokumenty Markdown związane z projektem, telemetryką, wykresami, planami, handoffami i stanami projektu.
- `meta/` — zakres pakietu i informacja o sanityzacji.

## Bezpieczeństwo
Z pakietu usunięto wpisane dane logowania i inne credentiale: hasła, adresy e-mail operatora, Firebase API keys, Database Secret/LegacyToken, token sterowania oraz znalezione tokeny sesyjne.
W miejscach wymagających konfiguracji pozostawiono puste wartości lub znaczniki `[REMOVED_*]`.

## Uwaga dla agenta
Nie zakładaj, że każda historyczna wersja HTML jest wersją produkcyjną. Wersje należy traktować chronologicznie; najnowszy pełny panel HTML jest referencją funkcjonalną, a wcześniejsze wersje pokazują ewolucję wykresów, sesji, anomalii, pogody i terminala.
