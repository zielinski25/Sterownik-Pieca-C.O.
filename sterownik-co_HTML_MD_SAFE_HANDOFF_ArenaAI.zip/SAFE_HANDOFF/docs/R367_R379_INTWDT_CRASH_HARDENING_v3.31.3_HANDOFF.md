# R367-R379 / INT_WDT crash hardening — v3.31.3

Status: LOCAL/TEST ONLY. Production remains v3.19.2.

## Incident
Observed immediately before reset:
- boot=2
- reset=INT_WDT
- streak=1
- twdt_isr_count=0
- TG checkpoint: TG_COMMAND / BEFORE / detail=33
- TG_POLL checkpoint: TG_POLL_WAIT / BEFORE
- no coredump

## Diagnosis
`TgDeferCmd` maps detail=33 to `TG_RTDB_INTEGRATION_BATCH`, i.e. the R367-R379 mega test.
The exact reset call stack is unavailable because no coredump was produced, so the precise CPU-level instruction is not proven.

The v3.31.2 batch had one architectural exception: `rtdbTestQueryRange()` called the synchronous FirebaseClient `get<String>(..., DatabaseOptions)` directly from `tgTaskFn` on Core 0. The other RTDB test operations used the existing bounded `fbLoopWorker` path.

The device also runs `tgTask` and `tgPollTask` on Core 0. The `TG_POLL_WAIT/BEFORE` checkpoint is therefore evidence of concurrent long-poll activity, not proof that long-poll itself caused the reset.

## v3.31.3 changes
1. Removed the synchronous FirebaseClient range GET from R367-R379.
2. Replaced range query with a dedicated Core-0 REST worker using:
   - Firebase UserAuth ID token from `fbApp.getToken()` (never logged)
   - explicit CA trust store
   - DNS through existing bounded `wifiHostByNameZLimitem()` helper
   - explicit IP + Firebase hostname TLS connect (SNI/certificate hostname retained)
   - bounded TLS handshake / socket timeouts
   - bounded response read loop with `vTaskDelay()` and WDT service
3. During R367-R379, `tgPollTask` stops starting new long-polls.
4. If a poll is already in flight when `/rtdbmega` starts, the batch waits for it to finish before touching RTDB.
5. Added TG command sub-checkpoints:
   - 3670 = waiting for existing TG poll
   - 3680/3681/3682 = R368 start/set/get
   - 3690/3691/3692 = R369 start/update/get
   - 3700/3701/3702 = R370 start/update/range query
   - 3710 = R371 range validation
   - 3720 = R372 retry
   - 3730 = R373 duplicate key
   - 3740 = R374 ts=0
   - 3750 = R375 rollback
   - 3760 = R376 deterministic IDs
   - 3770 = R377 cleanup
6. R371 no longer assumes JSON object transport order. Firebase REST documentation states filtered REST results are not guaranteed to be returned in order, so the gate validates range membership/exclusion instead.

## Safety
- No production firmware change.
- No Firebase Rules change.
- V1 telemetry path remains untouched.
- Test subtree remains under the device's own H2 shadow telemetry path.
- No credential values are emitted in diagnostics.

## Build artifact
`main_centrala_v3.31.3_LOCAL_RTDB_INTWDT_FIX.cpp`
SHA-256: 91e903cdf264c5866c92cc1dd53fe30479839aed1414664462eb1d337f9845a3

## Validation note
The container used for this handoff did not have PlatformIO installed and could not download it because outbound package DNS was unavailable. Source-level checks were performed, including removal of the old synchronous range call and presence of the new worker/gating/checkpoint paths. Hardware compile/run still needs to be done on the user's existing PlatformIO environment.

## Run acceptance
On the LOCAL/TEST board only:
1. `/version` -> v3.31.3
2. `/rtdbmega`
3. Return the complete R367-R379 result.

Do not USB-flash the production controller.
