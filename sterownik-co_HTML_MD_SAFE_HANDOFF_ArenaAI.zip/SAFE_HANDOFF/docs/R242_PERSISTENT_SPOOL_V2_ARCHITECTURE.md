# R242 — PERSISTENT SPOOL V2 — ARCHITECTURE FREEZE CANDIDATE

Data: 2026-09-26
Status: DESIGN / NO FIRMWARE CHANGE

## Input facts

Current TelemetrySample ABI:
```text
sizeof(TelemetrySample) = 80 B
ring = 1440 records
ring payload = 115,200 B
```

The project rules already require immutable pages, CRC validation, FIFO replay and delete only after full ACK.

## Page candidate

Test range remains:
```text
32 KiB
48 KiB
64 KiB
```

Preferred candidate for first benchmark:
```text
64 KiB page
768 records/page
84 B/record = 80 B sample + 4 B record CRC
768 × 84 = 64,512 B
~1,024 B left for header/footer/format metadata
```

This is a benchmark candidate, not yet a final freeze.

## Page format candidate

HEADER
```text
magic
format_version
page_sequence
first_sample_sequence
record_size
record_capacity
header_crc32
```

RECORD × N
```text
TelemetrySample payload (80 B)
record_crc32 (4 B)
```

FOOTER
```text
committed_magic
record_count
last_sample_sequence
page_crc32
footer_crc32
```

## Recovery

```text
scan /telemetry_spool/
→ sort by page_sequence
→ validate header
→ validate records sequentially
→ stop at first invalid/truncated record
→ ignore incomplete tail
→ validate committed footer
→ replay oldest valid page first
```

No repair should delete a page merely because its tail is incomplete.
A confirmed valid prefix remains usable.

## Naming

Candidate:
```text
/telemetry_spool/page_0000000001.bin
```

The sequence is part of both filename and header, but header CRC remains authoritative for integrity.

## Write policy

Online:
```text
PSRAM ring → Firebase
```

Offline/backpressure:
```text
PSRAM ring → closed spool pages only when watermark requires it
```

Do not mirror every minute to flash.

## Replay

```text
oldest page
→ batches of max 10 records
→ one Firebase request in flight
→ full ACK
→ advance replay cursor
→ delete page only after all records ACKed
```

## Hard quota interaction

Spool admission must always satisfy:
```text
free_after_write >= protected reserve
```

and also remain under the future telemetry hard cap.

Spool must never reclaim:
```text
coredump
log_krytyczny
settings
history
panel firmware
```

to create telemetry space.

## Required fault tests before Commit G PASS

```text
power loss during record write
power loss after record write
power loss before footer
power loss after footer
power loss during rename
corrupt header
corrupt first record
corrupt middle record
corrupt footer
full quota
replay interruption
replay ACK then restart before delete
```

Expected property:
at-least-once replay with deterministic record identity; no silent acceptance of corrupted records.
