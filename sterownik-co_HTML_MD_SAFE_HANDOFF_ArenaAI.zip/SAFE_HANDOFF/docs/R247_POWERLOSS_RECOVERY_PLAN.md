# R247 — kontrolowane przerwanie zasilania na otwartej stronie Spool V2

## Cel

Zweryfikowac na pustej plytce testowej, ze po rzeczywistym odcieciu zasilania strona Spool V2 bez footer commit jest po restarcie wykrywana jako otwarta i odzyskiwany jest tylko poprawny prefiks.

## Zakres

- TYLKO lokalna pusta plytka ESP32-S3.
- Produkcyjny sterownik pozostaje v3.19.2.
- Testowy plik: `/telemetry_spool/r247_powerloss_page.bin`.
- Header: 64 B.
- 2 kompletne rekordy: 2 × 84 B.
- Następnie zapisane pierwsze 40 B trzeciego rekordu i `flush()`.
- Stan ARM: 272 B.
- Footer nie jest zapisywany.
- Okno 15 s na rzeczywiste odlaczenie zasilania plytki.

## Przebieg

1. Zbuduj i wgraj v3.20.6 na pusta plytke.
2. W Telegramie wpisz `/spool247 TAK`.
3. Odbierz komunikat `R247 READY`.
4. W ciagu 15 s odlacz zasilanie plytki testowej.
5. Podlacz zasilanie ponownie i poczekaj na start Wi-Fi/Telegrama.
6. Wpisz `/spool247recover`.

## Oczekiwany wynik po power loss

PASS jest oczekiwany dla wariantu, w ktorym po restarcie plik zawiera:

- poprawny header CRC,
- co najmniej 2 kompletne rekordy z poprawnym CRC,
- brak footeru,
- tail krótszy niż 84 B (typowo 0 B albo 40 B, zaleznie od tego, co LittleFS zapisze przed odcieciem).

Przyklad poprawnego wyniku:

`R247 powerloss recover: PASS`
`recovery OK: size=272 validRecords=2 tail=40B headerCRC=OK recordCRC=OK footer=ABSENT open=RECOVERABLE`

Dopuszczalny jest także `size=232 validRecords=2 tail=0B`, jezeli pierwszy fragment nie zdazyl stac sie widoczny po restarcie.

## Kryterium PASS

R247 PASS dopiero po rzeczywistym odcieciu zasilania oraz poprawnym `/spool247recover`.

Nie zaliczac jako power-loss PASS samego wygasniecia 15 s bez odciecia zasilania.
