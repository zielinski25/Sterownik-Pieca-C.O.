# R241 — MASTER STATE / PIEС_CO

Data: 2026-09-26
Status: CURRENT

## PRODUCTION

Real controller:
```text
v3.19.2
OTA only
```

No R241/R242 firmware has been sent to production.

## CLOSED

```text
Telemetry V1     PASS
Commit F1        PASS
F2.1             PASS
F2.2             PASS
F2.3             PASS
F2.5             PASS
F2.7             PASS
```

## PENDING

F2.6 runtime v3.19.8 = pending user runtime result.
F2.8 hard quota = implementation prepared, not runtime verified.

## LITTLEFS CONTRACT

```text
TOTAL                10,354,688 B
COREDUMP RESERVE      1,310,720 B
HIST_SHORT RESERVE      131,072 B
HIST_LONG RESERVE     2,097,152 B
CRITICAL_FREE_MIN       310,641 B
PANEL_MAX              2,097,152 B
PANEL_PEAK             4,194,304 B
```

Physical `usedBytes()` remains the quota source.

## NEXT

1. Runtime verify v3.19.8/F2.6.
2. Runtime verify local v3.19.9/F2.8.
3. Freeze spool page benchmark candidate.
4. Commit G persistent spool V2 only after storage fault tests.
