# R239 — MASTER STATE / PIEС_CO

Data: 2026-09-26
Status: AKTUALNY STAN PROJEKTU

## PRODUKCJA

Prawdziwa centrala:
- firmware: **v3.19.2**
- wdrożenie: OTA only
- brak zmian produkcyjnych w R238/R239

Telemetry V1:
- **PASS / ZAMKNIĘTA**
- ring 1440
- batch 10
- payload limit 6144 B
- jeden request in-flight
- retry przez zachowanie tail do ACK
- Drop 0 w ostatnich testach
- at-least-once + deterministyczne record IDs / idempotent overwrite

## COMMIT F

F1: **PASS / ZAMKNIĘTY**

## F2 — LITTLEFS ACCOUNTING / QUOTA

### F2.1
PASS — `LittleFS.usedBytes()` / `totalBytes()` jako fizyczne źródło quota.

### F2.2
PASS — stałe rezerwy:

```text
COREDUMP_RESERVE     1 310 720 B
HIST_SHORT_RESERVE     131 072 B
HIST_LONG_RESERVE    2 097 152 B
CRITICAL_FREE_MIN      310 641 B
RAZEM                3 849 585 B
```

### F2.3
PASS — `FsUsageSnapshot`.

### F2.5
PASS — shadow quota.

Ostatni potwierdzony runtime:

```text
free=9 031 680 B
static reserve=3 849 585 B
after reserve=5 182 095 B
status=OK
```

### F2.6
RUNTIME PENDING — v3.19.8.

Model dynamiczny:

```text
critical reserve
+ niewykorzystana część rezerwy coredump
+ niewykorzystana część rezerwy histS
+ niewykorzystana część rezerwy histL
= chroniona pozostała rezerwa
```

Nie steruje jeszcze kasowaniem ani quota.

## F2.7 — PANEL FIRMWARE

**OPEN / READY FOR MEASUREMENT**

Kod obecnie:
- pobiera `firmware_panel.bin` z GitHub;
- zapisuje do `.tmp`;
- sprawdza pierwszy bajt `0xE9`;
- porównuje zapisany rozmiar z `Content-Length`, jeżeli dostępny;
- wykonuje `rename` dopiero po udanym zapisie;
- przechowuje rozmiar w `g_panelFirmwareSize`;
- raportuje panel w accounting FS.

Brak aktualnego, zweryfikowanego artefaktu panelu uniemożliwia ustalenie `PANEL_FIRMWARE_MAX_B`.

## ZASADA

Nie używamy arbitralnego 1–2 MiB jako formalnego limitu.

## INVARIANTS

```text
I1  producer nie blokuje sterowania siecią/FS
I2  jeden AsyncClient Firebase
I3  jeden fbApp.loop path
I4  maks. jeden telemetry request in-flight
I5  tail przesuwa się dopiero po ACK/commit
I6  retry zachowuje te same record_id
I7  timestamp nie jest jedyną tożsamością
I8  quality rozróżnia last-good od fresh
I9  physical FS usedBytes() jest źródłem quota
I10 coredump source nie jest kasowany przed verify
I11 mount error nie formatuje produkcyjnych danych
I12 persistent spool ma mieć twardą quota i nie może zjadać rezerwy crash/log
I13 status i telemetry mają niezależne kontrakty
I14 upgrade biblioteki/toolchainu jest osobnym etapem
```

## NEXT

1. Zamknąć/zweryfikować runtime F2.6.
2. Uzyskać rzeczywisty `firmware_panel.bin` + size + SHA-256.
3. Zamknąć F2.7.
4. Dopiero potem finalna hard quota.
5. Następnie przygotowanie architektury persistent spool V2.

## SPRZĘT

```text
PRAWDZIWY PIEC: OTA ONLY / bez USB / bez /testcrash / bez odcinania sieci
PUSTA PŁYTKA: USB/build/upload/fault injection dozwolone
```

## R240 — F2.7 PANEL FIRMWARE

**PASS / ZAMKNIĘTE**

Pomiar aktualnego artefaktu użytkownika:

```text
firmware_panel.bin = 1,445,952 B
```

Kontrakt:

```text
PANEL_FIRMWARE_MAX_B = 2,097,152 B (2 MiB)
```

Margines: 651,200 B (~45.0%).

Ponieważ nowy panel jest zapisywany do `.tmp` przy zachowaniu starego pliku, przyszły hard pre-check musi uwzględniać transient peak:

```text
PANEL_PEAK_STORAGE_B = 4,194,304 B (4 MiB)
```

SHA-256 aktualnego panelu: NIEZAARCHIWIZOWANY — otrzymano rozmiar, nie bajtowy artefakt.

## R241 — F2.8

READY / design only.

Celem jest hard quota oparty o physical `LittleFS.usedBytes()`, dynamiczne rezerwy i osobny staging panel OTA. Implementacja dopiero po PASS F2.6.
