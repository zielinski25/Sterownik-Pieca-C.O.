# ESP32 CENTRALA — HANDOFF R221
Data: 2026-09-26

## Stan
- v3.15.2 Network/WDT: runtime observation PASS 30 min 12 s.
- v3.16.0 TelemetryRing: runtime observation PASS ~29 min.
- Ring: 1440 x 80 B = 115200 B PSRAM.
- `telemetry_produced=28`, `telemetry_dropped=0`.
- 0 TASK_WDT/PANIC/reset/coredump w capture R220.
- Gate A-0 = YELLOW.

## Nowy artefakt
`main_centrala_v3.17.0_FIREBASE_BATCH.cpp`

Pierwszy transport telemetryczny:
ring -> compact JSON multi-path update -> istniejący Firebase worker -> SUCCESS -> commit tail.

## Zasada
Nie przesuwać tail przed pełnym ACK/SUCCESS. FAIL/TIMEOUT zachowuje batch w ring.

## Operator
Najpierw tylko:
`pio run -e esp32-s3-n16r8`

Bez uploadu do czasu przeglądu builda.
