# R188 / TELEMETRIA — MASTER STATE R223

Data: 2026-09-26

> Jeden bieżący stan projektu. Przy wznowieniu pracy czytać ten plik, następnie końcówkę żywego research planu.

## 1. CEL

Zaprojektować i wdrożyć telemetrykę/logowanie cloud dla istniejącego sterownika CO na ESP32-S3 bez pogorszenia bezpieczeństwa i sterowania. Praca jest etapowa i każda zmiana ma być osobno mierzona.

## 2. STAN BIEŻĄCY

- Aktualny przygotowany firmware do testu runtime: **v3.18.0**.
- v3.18.0: odłączenie `tgTask` i `tgPollTask` od per-task TASK_WDT + heartbeat/state w HEALTH-A.
- PlatformIO build: **PASS dla `esp32-s3-n16r8` oraz `esp32-s3-ota`** (potwierdzone przez operatora).
- Upload v3.18.0 przez USB: rozpoczęty/wykonany przed bieżącą sesją obserwacyjną.
- **R223 runtime: W TOKU** na pustej płytce.
- Oczekiwany czas obserwacji: około 30 min.
- Nie wykonywać w trakcie: OTA, kolejnego uploadu, restartu, erase, ręcznych zmian automatyki.
- `GATE_A0 = YELLOW`.

## 3. STABILNE ELEMENTY ZAMKNIĘTE PRZED R223

### R219 — Network/WDT hardening v3.15.2
- Runtime observation: 30 min 12 s.
- 0 TASK_WDT / PANIC / reset / coredump w capture.
- Patch ownership workerów DNS/Firebase przeszedł hostowy race harness.

### R220 — TelemetryRing v3.16.0
- PSRAM SPSC ring: **1440 x 80 B = 115200 B**.
- Producer w istniejącej ścieżce `historiaZapiszProbke()`.
- FIFO `peek()` + `commitPop()`.
- Pełny ring: `push()` zwraca false; `sampleSeq` nie jest cofany.
- Runtime na pustej płytce: około 29 min; `telemetry_produced=28`, `telemetry_dropped=0`; 0 TASK_WDT/PANIC/reset/coredump.

### R221 — Firebase batch v3.17.0
- Runtime początkowo działał około 45 min 52 s.
- W obserwowanej sesji: 92 HEALTH, 44 `batch_ok`, brak `batch_fail` i timeoutów w tym oknie.
- Dane potwierdzone ręcznie w RTDB pod `/piec/telemetry/1m/v1`.
- Przykładowe rekordy: `seq=29` i `seq=32`; `mono` oraz `ts` różnią się dokładnie o 180 s.
- Test wykonywano na **pustej płytce bez czujników**. Dlatego `a[]` zawiera wartości zastępcze, a `age[11]=65535` jest oczekiwane jako `UNKNOWN`, nie jako błąd freshness.
- Należy jednak rozdzielić ten krótki PASS od stabilności długoterminowej: później v3.17.0 wygenerował serię TASK_WDT.

## 4. KRYTYCZNE WDT Z v3.17.0 — DIAGNOZA ZAMKNIĘTA

Coredumpy 11–16 + matching `firmware.elf`:

- seq11 / boot2: `tgTask`, CPU0, `HTTPClient::handleHeaderResponse()` podczas DESZCZ `http.GET()`.
- seq12 / boot3: `tgPollTask`, CPU0, `ssl_starttls_handshake()` podczas Telegram `NetworkClientSecure::connect()`.
- seq13–15: kolejne TASK_WDT w `TG_CONNECT`, dotyczące workerów Telegrama.
- seq16: TASK_WDT w `tgTask` podczas `FB_SEND`.

Wniosek: obecne timeouty HTTP/TLS nie są twardym limitem całkowitego czasu wall-clock dla wszystkich niższych operacji. Per-task TWDT na workerach sieciowych był więc niewłaściwie sprzężony z blokującą naturą tych operacji.

Nie jest to błąd `TelemetrySample` ani `TelemetryRing`.

## 5. R222 / v3.18.0

Zakres wyłącznie network/WDT:

1. `tgTask` nie jest rejestrowany przez `esp_task_wdt_add(NULL)`.
2. `tgPollTask` nie jest rejestrowany przez `esp_task_wdt_add(NULL)`.
3. Globalna konfiguracja TWDT i ochrona zadań sterujących pozostają bez zmiany.
4. Dodano heartbeat/state dla `tgTask` i `tgPollTask`.
5. `HEALTH-A` ma raportować stan i wiek heartbeatów workerów.
6. Brak zmian w `TelemetrySample`, `TelemetryRing`, wire schema, retry/commit, wyjściach sterujących.

### Build evidence
- `v3.18.0` `esp32-s3-n16r8`: **SUCCESS**.
- `v3.18.0` `esp32-s3-ota`: **SUCCESS**.
- Źródło: `main_centrala_v3.18.0_NETWORK_WDT_DECOUPLED.cpp`.
- SHA-256: `8895f243a6c45b07b843f1bca5aa49011ff9adfaca31798bee7ad19eedc66401`.

## 6. R223 — RUNTIME W TOKU

Cel: sprawdzić, czy po odłączeniu workerów od per-task TWDT znikają powtarzalne resetowania podczas blokujących operacji sieciowych.

Sukces obserwacyjny:
- brak TASK_WDT w `tgTask` / `tgPollTask`;
- brak PANIC/reset/coredump;
- sterowanie działa normalnie;
- heartbeat workerów pozostaje sensowny;
- telemetryka nadal produkuje i wysyła rekordy;
- brak `telemetry_dropped` wynikających z nowej zmiany.

R223 nie jest 24 h baseline.

## 7. GATE A-0

Nadal **YELLOW**. Historyczny R188 24 h na jednej zamrożonej wersji nie został osiągnięty. Krótkie testy runtime służą do walidacji kolejnych commitów, nie są zamiennikiem 24 h baseline.

## 8. ZAMROŻONE ZASADY TELEMETRYKI

- producent: istniejąca ścieżka historii;
- `TelemetrySample = 80 B`;
- sidecar freshness x11;
- `sessionNonce` + `sampleSeq` jako identity;
- `ageS=65535` = brak last-good/UNKNOWN;
- `qualityBits` niezależne od freshness;
- 1440 rekordów ringa = 24 h przy 60 s;
- jeden Firebase client/app;
- brak osobnego `TelemetryTask`;
- tail ring przesuwać dopiero po potwierdzonym sukcesie batcha;
- retry używa tych samych `record_id`.

## 9. CZEGO TERAZ NIE ROBIĆ

- nie dodawać kolejnego patcha przed wynikiem R223;
- nie podnosić arbitralnie timeoutu TWDT;
- nie wykonywać kolejnego uploadu w trakcie bieżącej sesji;
- nie łączyć z tym etapem migracji auth/TLS, upgrade FirebaseClient, Rules ani persistent spool.

## 10. NASTĘPNY KROK

Po zakończeniu R223 dostarczyć ZIP R188. Dopiero na podstawie danych zdecydować:
- PASS -> dalsza walidacja telemetryki/retry;
- FAIL -> analiza nowego coredumpu i checkpointów.
