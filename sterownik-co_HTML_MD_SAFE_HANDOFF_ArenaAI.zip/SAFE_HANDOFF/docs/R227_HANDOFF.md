# R227 HANDOFF — Piec_CO

Data: 2026-09-26

## MASTER / STABLE

Firmware produkcyjny: **v3.18.1**

v3.18.1 jest traktowana jako stabilna baza projektu po testach lokalnych i obserwacji prawdziwej centrali.

## Potwierdzone lokalnie

### R224
- v3.18.1
- ~15 min 39 s runtime
- TASK_WDT=0
- reset=0
- PANIC=0
- COREDUMP=0
- "task not found"=0
- telemetry_produced=15
- telemetry_dropped=0
- Firebase batch_ok=15

### R225 — offline buffering
- Wi-Fi wyłączone bez wyłączenia ESP32
- brak resetów/WDT/PANIC/coredump
- telemetry_dropped=0
- rekordy zostały zbuforowane i po powrocie sieci zostały wysłane
- explicit FAIL -> RETRY -> ACK -> COMMIT TAIL nie został bezpośrednio zaobserwowany

## Potwierdzone na prawdziwej centrali

Najnowszy log `piec_log (14).txt`:
- boot=27 bez zmiany przez całą obserwację
- brak oznak TASK_WDT/PANIC/COREDUMP/restartu w badanym materiale
- telemetry_dropped=0
- telemetry_produced doszło do 289
- Wi-Fi=1 i Firebase=1 w końcowym materiale
- pamięć ustabilizowała się około 111 kB wolnego RAM wewnętrznego
- PSRAM pozostał stabilny
- zapisane statusy czujników zmieniały się normalnie

## Ważna decyzja

**v3.18.1 zostaje zamrożona jako MASTER/STABLE.**

Nie wykonujemy kolejnego OTA tylko dla dodatkowego testu stabilności.

## Architektura telemetryki — stan

Potwierdzone/obowiązujące:
- TelemetrySample = 80 B
- 11 kanałów
- sessionNonce + sampleSeq jako identity
- qualityBits + ageS jako metadata świeżości/jakości
- SPSC TelemetryRing w PSRAM
- wspólny Firebase client
- maksymalnie jeden telemetry request in-flight
- tail przesuwany dopiero po sukcesie
- backlog drain FIFO
- telemetryka nie ma własnego taska

## Persistent spool

LittleFS persistent spool pozostaje osobnym etapem projektu. Nie należy implementować go teraz jako przypadkowego rozszerzenia v3.18.1.

Wcześniejszy plan ustala kolejność:
C = RAM Ring
D = Firebase single batch
E = backlog/adaptive batch
F = LittleFS/coredump hardening
G = persistent spool V2

## Następny etap

Rozwój nowych funkcji prowadzić od osobnej gałęzi/wersji od v3.18.1.

Zasada:
CODE -> BUILD -> LOCAL TEST -> DEVICE TEST -> FAULT INJECTION -> SOAK -> REVIEW -> RELEASE

Na prawdziwym sterowniku tylko OTA; USB wyłącznie na lokalnej pustej płytce/testowym ESP32-S3.
