# Handoff R263-R272

1. Zbuduj v3.23.0 z `main_centrala_v3.23.0_LOCAL_SPOOL_BATCH2.cpp`.
2. Wgraj USB tylko na pusta plytke testowa.
3. Telegram: `/spoolbatch2 TAK`.
4. Oczekuj 10 linii R263-R272.
5. Jezeli cala bateria PASS, zamknij R263-R272 jako PASS.

Produkcja pozostaje na v3.19.2.
