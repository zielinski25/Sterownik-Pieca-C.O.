﻿# ESP32-S3 Centrala CO — Research / Plan telemetryki

**Dokument żywy — aktualizować po każdym zakończonym kroku audytu lub implementacji.**

Data rozpoczęcia: 2026-09-23  
Status: **RESEARCH / BASELINE FREEZE**  
Źródło prawdy projektu na tym etapie: pliki dostarczone przez użytkownika + zweryfikowana dokumentacja techniczna.

---

## 0. Zasady prowadzenia prac

1. Nie mieszać kilku dużych zmiennych w jednym kroku. Telemetryka, aktualizacja toolchainu, migracja auth i duże zmiany security mają być osobnymi zmianami.
2. Po każdym kroku aktualizować ten plik o:
   - wykonane czynności,
   - ustalenia potwierdzone źródłowo,
   - zmienione decyzje,
   - ryzyka otwarte i zamknięte,
   - pomiary/testy,
   - następny krok.
3. Nie wprowadzać `TelemetryTask`, drugiego `FirebaseApp` ani drugiego `AsyncClientClass`, dopóki pomiary nie wykażą konieczności.
4. Najpierw zabezpieczyć obecne mechanizmy diagnostyczne i zarządzanie LittleFS, dopiero potem dodawać persistent telemetry spool.
5. Nie traktować `sdkconfig.defaults` jako dowodu tego, co zostało skompilowane. Potwierdzić wygenerowany `sdkconfig.<env>` / konfigurację faktycznego buildu.

---

# 1. Baseline — pliki i fingerprinty

| Plik | SHA-256 |
|---|---|
| `main_centrala (3).cpp` | `ea5d47a76fb9fce42708e3670836228305e8b1e02bc1249331de3a9df7988a73` |
| `partitions.csv` | `36af8d29305c63bd0d90a6c5c9b89159122ef70351d6d2f58c1adeddc3c16da7` |
| `platformio.ini` | `52886861f0a845a28917f1378dd324caac01f31d46f559a7369498e0f9233511` |
| `sdkconfig.defaults` | `cbf0cf40133a87f8f7a2f4d9cb532d0c348368196cbfda4430b94c63742dcc5b` |
| `esp32-s3-n16r8.json` | dostarczony baseline |

Poprzednia wersja źródła `main_centrala_v3.10.6.cpp` różni się od obecnej wersji zasadniczo zmianami DHT; nie wykryto dodatkowej zmiany architektury telemetrycznej.

---

# 2. Aktualna architektura — stan wejściowy

```text
czujniki / stan automatyki
        │
        └── historiaZapiszProbke() co 60 s
               ├── hist_short.csv / HistoriaProbka
               ├── long history / zdarzenia
               └── [PLAN] TelemetryRing w PSRAM
                              │
                              └── istniejąca ścieżka Firebase
                                      │
                                      └── /piec/telemetry/1m/...
```

Aktualnie **nie ma kodu telemetrycznego** (`telemetry` / `Telemetry` nie występuje w `main_centrala (3).cpp`).

Istnieją już mechanizmy:
- `fbApp`, `fbAsyncClient`, `RealtimeDatabase`, `LegacyToken`, `AsyncResult`,
- pojedynczy worker `fbLoopWork`,
- współdzielony circuit breaker Firebase,
- status `/piec/status`,
- komendy `/piec/cmd`,
- `historiaZapiszProbke()` co 60 s,
- LittleFS i rozbudowane archiwum logów/historii/coredumpów.

---

# 3. Najważniejsze ustalenia z obecnych plików

## 3.1. Scheduler

- Scheduler ma `MAX_ZADAN=20`.
- `historiaZapiszProbke()` jest już zadaniem schedulera.
- Nie ma powodu dodawać osobnego slotu na telemetrykę, jeżeli próbka będzie tworzona w istniejącej ścieżce historii.

**Decyzja:** telemetrykę produkować w `historiaZapiszProbke()` i przekazywać do pierścienia, bez nowego `TelemetryTask`.

## 3.2. PSRAM

Obecny firmware ma duże bufory historii w PSRAM. Konfiguracja `sdkconfig.defaults` zawiera m.in.:

- `CONFIG_SPIRAM=y`
- `CONFIG_SPIRAM_MODE_OCT=y`
- `CONFIG_SPIRAM_SPEED=80`
- `CONFIG_SPIRAM_USE_MALLOC=y`
- `CONFIG_SPIRAM_TRY_ALLOCATE_WIFI_LWIP=y`
- `CONFIG_FREERTOS_TASK_CREATE_ALLOW_EXT_MEM=y`

Nie oznacza to jednak, że stosy tasków powinny trafić do PSRAM.

**Decyzja:** `TelemetryRing` może być w PSRAM; nowe stosy tasków pozostają w RAM wewnętrznym.

## 3.3. Coredump

`sdkconfig.defaults` ma:

- `CONFIG_ESP_COREDUMP_ENABLE_TO_FLASH=y`
- `CONFIG_ESP_COREDUMP_DATA_FORMAT_ELF=y`
- `CONFIG_ESP_COREDUMP_CHECKSUM_CRC32=y`
- `CONFIG_ESP_COREDUMP_CHECK_BOOT=y`
- `CONFIG_ESP_COREDUMP_ENABLE=y`
- `CONFIG_ESP_COREDUMP_MAX_TASKS_NUM=64`
- `CONFIG_ESP_COREDUMP_USE_STACK_SIZE=y`
- `CONFIG_ESP_COREDUMP_STACK_SIZE=1792`
- `CONFIG_FREERTOS_TASK_CREATE_ALLOW_EXT_MEM=y`

`partitions.csv` zawiera partycję `coredump` 64 KiB.

**Stan:** zapis coredumpu jest przewidziany przez konfigurację dostarczonego pliku, ale finalny build nadal trzeba zweryfikować na wygenerowanym `sdkconfig.<env>`.

## 3.4. Watchdog

`sdkconfig.defaults` ma domyślne `CONFIG_ESP_TASK_WDT_TIMEOUT_S=5` i monitoring idle CPU0. Kod runtime rekonfiguruje TWDT na 15 000 ms i obejmuje oba rdzenie.

**Decyzja:** przy analizie zachowania WDT priorytet ma faktyczna konfiguracja runtime + wygenerowane `sdkconfig`, a nie samo `sdkconfig.defaults`.

## 3.5. LittleFS / storage accounting — P0

`partitions.csv`:

- `nvs`: 20 KiB
- `otadata`: 8 KiB
- `app0`: 3 MiB
- `app1`: 3 MiB
- `coredump`: 64 KiB
- `spiffs` (używany przez LittleFS): 9.875 MiB (10,354,688 B)

Na LittleFS znajdują się m.in.:
- `/hist_short.csv`
- `/hist_long.csv`
- `log_a.txt`
- `log_b.txt`
- `log_krytyczny.txt`
- `log_ustawien.txt`
- `/panel_firmware.bin`
- `/coredumps/dump_bootN.bin`

Aktualny guard logów nie liczy wszystkich tych plików: pomija historię, `log_ustawien` i archiwum coredumpów. To jest istotne, istniejące ryzyko zajęcia partycji.

**Decyzja P0:** przed persistent telemetry spool ujednolicić księgowanie wszystkich danych na LittleFS.

---

# 4. Coredump — znalezione problemy do naprawy przed telemetryką

Aktualna funkcja `archiwizujCoredumpJesliCrash()`:

1. sprawdza `LittleFS`,
2. wywołuje `esp_core_dump_image_get()`,
3. kopiuje dane po 1 KiB do pliku LittleFS,
4. **nie sprawdza wyniku `File::write()`**,
5. po samym braku błędu odczytu wywołuje `esp_core_dump_image_erase()`.

Brakuje:
- `esp_core_dump_image_check()` przed archiwizacją,
- sprawdzenia liczby faktycznie zapisanych bajtów,
- pliku tymczasowego `.part`,
- bezpiecznego rename dopiero po pełnym zapisie.

**Ryzyko:** przy pełnym/niestabilnym filesystemie teoretycznie możliwa jest utrata jedynej kopii coredumpu przed bezpiecznym zapisaniem archiwum.

**Plan naprawy:**

```text
image_check()
  ↓
image_get()
  ↓
write do .part
  ↓
sprawdzenie write + size
  ↓
close
  ↓
rename
  ↓
image_erase()
```

Do wykonania także kontrolowany `/testcrash TAK` i późniejsze sprawdzenie dekodowania dumpa na PC.

---

# 5. Research zewnętrzny — potwierdzone informacje

## 5.1. PSRAM / flash-cache

Oficjalna dokumentacja ESP-IDF mówi, że podczas operacji, które wyłączają cache flash, zewnętrzna RAM staje się niedostępna; dlatego task stacków nie należy bezrefleksyjnie umieszczać w PSRAM. Jednocześnie PSRAM jest dobrym miejscem na duże bufory danych, pod warunkiem respektowania ograniczeń cache/flash/DMA.  
Źródło: ESP-IDF External RAM documentation.

## 5.2. Task Watchdog

ESP-IDF definiuje bazowy timeout TWDT w Kconfig, ale pozwala na rekonfigurację runtime. Konfiguracja obejmuje m.in. timeout, maskę rdzeni idle-task i zachowanie panic.  
Źródło: ESP-IDF Watchdogs documentation.

## 5.3. Minimalizacja pamięci / stosy

ESP-IDF zaleca pomiar `uxTaskGetStackHighWaterMark()` oraz `uxTaskGetSystemState()` przy doborze rozmiarów stosów i diagnozie zużycia RAM. Dokumentacja wskazuje też, że redukcja liczby tasków może ograniczyć stałe zużycie pamięci.  
Źródło: ESP-IDF ESP32-S3 RAM usage documentation.

## 5.4. Coredump

ESP-IDF udostępnia `esp_core_dump_image_check()`, który sprawdza checksum obrazu w partycji flash, oraz `esp_core_dump_image_get()` i `esp_core_dump_image_erase()`. `MAX_TASKS_NUM` ogranicza liczbę tasków umieszczanych w dumpie; crashed task jest zawsze uwzględniany.  
Źródła: ESP-IDF coredump Kconfig + `esp_core_dump.h` + implementation.

Włączenie `CAPTURE_DRAM` znacząco zwiększa wymagany rozmiar partycji; w aktualnym projekcie opcja jest wyłączona, co ogranicza rozmiar dumpa.  

## 5.5. FirebaseClient

Aktualny upstream `mobizt/FirebaseClient` to v2.2.13 (13 lipca 2026). Ta wersja naprawia m.in. problemy z reused HTTP connection, obsługą `Connection: close` i chunked responses. Projekt używa obecnie `^2.2.9`.

**Decyzja:** nie aktualizować FirebaseClient razem z implementacją telemetryki. Najpierw baseline, potem osobny eksperyment z aktualizacją biblioteki.

## 5.6. Firebase Realtime Database — odczyt historyczny

RTDB REST API obsługuje `orderBy`, `startAt`, `endAt`, `limitToFirst`, `limitToLast` i `equalTo`. Wyniki REST nie muszą być zwrócone przez JSON w uporządkowanej kolejności, więc aplikacja powinna sortować wynik po stronie klienta, gdy kolejność ma znaczenie.  
Źródło: Firebase Realtime Database REST retrieval docs.

## 5.7. Firebase Security Rules

Reguły RTDB kontrolują `.read`, `.write`, `.validate` i `.indexOn`. Dokumentacja podkreśla, że indeksy należy jawnie zdefiniować dla zapytań używanych produkcyjnie oraz że szerokie reguły mogą nadpisać bardziej szczegółowe ograniczenia przez mechanizm kaskady/OR.  
Źródło: Firebase Realtime Database Security Rules documentation.

---

# 6. Docelowa architektura telemetryki — hipoteza robocza

```text
                  SENSOR / STATE
                       │
                       ▼
              historiaZapiszProbke()
                  co 60 sekund
                       │
             ┌─────────┴─────────┐
             ▼                   ▼
       LOCAL HISTORY       TelemetrySample
                                  │
                                  ▼
                         TelemetryRing PSRAM
                                  │
                                  ▼
                      wspólny Firebase worker
                       (istniejący fbLoopWork)
                                  │
                                  ▼
                         Realtime Database
                       /piec/telemetry/1m/...
```

### Zasady

- jeden producer próbek,
- stały ring w PSRAM,
- brak `String` w hot path producenta,
- krótka sekcja krytyczna,
- brak nieograniczonej kolejki,
- jeden wykonawca `fbApp.loop()`,
- wykorzystanie istniejącego circuit breaker,
- klucz próbki oparty o stabilny timestamp,
- retry tej samej próbki powinien być idempotentny.

---

# 7. Wstępny model danych

Roboczy `TelemetrySample`:

- `uint32_t ts`
- temperatury krytyczne,
- ciśnienie,
- wilgotność,
- stan pompy,
- `klapa_proc`,
- `syberko_proc`,
- opcjonalnie wersja schematu / flags.

Nie kopiować 1:1 `HistoriaProbkaDluga`; telemetryka ma być kompaktowa i stabilna po stronie API.

Robocza ścieżka:

```text
/piec/status
/piec/cmd
/piec/telemetry/1m/t<timestamp>
/piec/events/...
```

`/1h` nie dodawać, dopóki nie będzie potwierdzone, że agregaty godzinne są potrzebne po stronie aplikacji/retencji.

---

# 8. Ilość danych — wstępny rząd wielkości

Przy 1 próbce/min:

- 1 dzień: 1 440 próbek,
- 30 dni: 43 200,
- rok: 525 600.

Dlatego aplikacja mobilna powinna pracować zakresami czasu i cachem lokalnym, zamiast każdorazowo pobierać pełną historię.

Obecny status co 15 s (~650 B JSON, wg kodu) generuje znacznie większy ruch surowy niż kompaktowy zapis jednej próbki/min. Na pierwszym etapie **nie zmieniać statusu**, tylko zmierzyć telemetrykę osobno.

---

# 9. Plan etapów

## P0 — Baseline / build truth
- [ ] wygenerować i zarchiwizować `sdkconfig.<env>` z konkretnego buildu
- [ ] zarejestrować wersję platformy / Arduino-ESP32 / IDF
- [ ] build firmware bez zmian funkcjonalnych
- [ ] zapisać ELF do późniejszego dekodowania coredumpu
- [ ] zapisać rozmiary app/FS

## P0 — LittleFS accounting
- [ ] jeden mechanizm sumowania wszystkich plików
- [ ] jawna rezerwa bezpieczeństwa
- [ ] uwzględnić coredumpy
- [ ] uwzględnić historię, settings i panel firmware
- [ ] test przy zapełnieniu partycji

## P0 — Coredump hardening
- [ ] `esp_core_dump_image_check()`
- [ ] atomowy `.part -> final`
- [ ] sprawdzenie `File::write()`
- [ ] weryfikacja pełnego rozmiaru
- [ ] dopiero potem erase source
- [ ] `/testcrash TAK`
- [ ] dekodowanie przez `esp-coredump`
- [ ] pomiar realnego rozmiaru dumpa
- [ ] decyzja, czy 64 KiB wystarcza

## P1 — Diagnostics
- [ ] internal free/largest/min-ever
- [ ] PSRAM free/largest/min-ever
- [ ] task stack high-water
- [ ] Firebase worker/queue metrics
- [ ] ring used/dropped
- [ ] telemetry success/fail
- [ ] oldest pending timestamp

## P1 — TelemetryRing
- [ ] zdefiniować `TelemetrySample`
- [ ] stały ring w PSRAM
- [ ] producer w `historiaZapiszProbke()`
- [ ] brak alokacji hot path
- [ ] test długiego okresu

## P1 — Firebase writer
- [ ] użyć istniejącego `fbLoopWork`
- [ ] wspólny circuit breaker
- [ ] bounded execution
- [ ] małe batch'e
- [ ] idempotentne klucze timestamp
- [ ] metryki uploadów

## P2 — RTDB / aplikacja
- [ ] schema
- [ ] Security Rules
- [ ] `.indexOn`
- [ ] zakresy czasu
- [ ] paging
- [ ] lokalny cache/SQLite

## P3 — Persistent offline spool
Dopiero po pomiarach i zamknięciu FS accounting.

Kandydat:
- append-only binary,
- sequence number,
- CRC,
- recovery po restarcie,
- limit/quota,
- kontrola wear,
- backpressure / drop policy.

## P4 — Security hardening
Osobna zmiana:
- migracja z Database Secret,
- rotacja sekretów,
- brak domyślnego sekretu w firmware,
- weryfikacja TLS zamiast `setInsecure()`,
- wzmocnienie autoryzacji komend.

## P4 — Dependency upgrade
Osobny eksperyment:
- FirebaseClient 2.2.13,
- ewentualnie nowszy pioarduino/Arduino-ESP32,
- test regresji WDT/TLS/AsyncTCP/OTA.

---

# 10. Otwarte pytania

1. Jaki jest faktyczny wygenerowany `sdkconfig.<env>` dla obecnego środowiska?
2. Jaki jest faktyczny rozmiar coredumpu po `/testcrash TAK`?
3. Czy 64 KiB partycji bez `CAPTURE_DRAM` daje wystarczający margines dla aktualnej liczby tasków?
4. Ile LittleFS rzeczywiście zajmuje przy normalnej eksploatacji po 24 h / 7 d / 30 d?
5. Jaki batch telemetryczny nie powoduje nadmiernego opóźnienia `fbLoopWork`?
6. Ile RAM wewnętrznego zostaje podczas jednoczesnego Firebase + Telegram + OTA + zapisu LittleFS?
7. Czy telemetryka ma działać jako best-effort RAM-only, czy wymagany jest gwarantowany spool offline 7/30 dni?
8. Jakie dokładnie zakresy czasu i agregacje będą potrzebne aplikacji mobilnej?

---

# 11. Historia aktualizacji dokumentu

### 2026-09-23 — wersja 0.1
**Wykonano:**
- przyjęto `sdkconfig.defaults` do baseline,
- potwierdzono konfigurację coredump ELF → flash,
- potwierdzono WDT 5 s w defaults i 15 s runtime w kodzie,
- policzono bezpośrednie miejsca tworzenia tasków w aplikacji,
- wykryto brak `esp_core_dump_image_check()` w archiwizacji,
- wykryto ignorowanie wyniku `File::write()` podczas kopiowania coredumpu,
- potwierdzono problem niepełnego księgowania zajętości LittleFS,
- zrobiono research ESP-IDF PSRAM/WDT/coredump oraz Firebase RTDB/FirebaseClient,
- przyjęto etapowanie P0/P1/P2/P3/P4.

**Kluczowa decyzja:** najpierw bezpieczeństwo baseline + storage accounting + coredump, dopiero potem telemetryka.

**Następny krok:** P0 — ustalenie faktycznie wygenerowanego `sdkconfig.<env>` i artefaktów buildu; równolegle przygotowanie modelu testów pamięci/coredumpu.

---

# 12. Źródła zewnętrzne wykorzystane w researchu

- ESP-IDF ESP32-S3 External RAM: https://docs.espressif.com/projects/esp-idf/en/latest/esp32s3/api-guides/external-ram.html
- ESP-IDF Watchdogs v5.5: https://docs.espressif.com/projects/esp-idf/en/release-v5.5/esp32/api-reference/system/wdts.html
- ESP-IDF ESP32-S3 RAM usage v5.5: https://docs.espressif.com/projects/esp-idf/en/release-v5.5/esp32s3/api-guides/performance/ram-usage.html
- ESP-IDF Core Dump Kconfig: https://github.com/espressif/esp-idf/blob/master/components/espcoredump/Kconfig
- ESP-IDF Core Dump API: https://github.com/espressif/esp-idf/blob/master/components/espcoredump/include/esp_core_dump.h
- Firebase RTDB REST retrieve data: https://firebase.google.com/docs/database/rest/retrieve-data
- Firebase RTDB Security Rules: https://firebase.google.com/docs/database/security
- FirebaseClient releases: https://github.com/mobizt/FirebaseClient/releases

---

# 7. RESEARCH R2 — Firebase queue, RTDB schema, storage economics i LittleFS

Data: 2026-09-23
Status kroku: **ZAKOŃCZONY / RESEARCH**

## 7.1. FirebaseClient — potwierdzenie modelu kolejki

Aktualna dokumentacja `FirebaseClient` potwierdza, że `AsyncClientClass` utrzymuje zadania asynchroniczne w **FIFO queue**. Dokumentacja podaje również `taskCount()`, zwracające liczbę zadań przechowywanych w kolejce.

Źródła:
- https://github.com/mobizt/FirebaseClient/blob/main/README.md
- https://github.com/mobizt/FirebaseClient/blob/main/resources/docs/async_client.md

Konsekwencja dla centrali:
- `fbAsyncClient` powinien pozostać pojedynczym współdzielonym klientem;
- uploader telemetryki nie może generować nieograniczonego backlogu;
- przed dodaniem kolejnego uploadu warto obserwować `fbAsyncClient.taskCount()`;
- metryka `firebase_queue_depth` powinna być częścią diagnostyki;
- jeżeli istnieje już oczekujące zadanie status/commands, telemetryka ma czekać lub zostać chwilowo pominięta, zamiast tworzyć konkurencyjnego workera.

**Decyzja D-R2-01:** utrzymujemy jeden `AsyncClientClass`, jeden `fbApp.loop()` i jeden mechanizm worker/gate. Nie tworzymy drugiej kolejki ani drugiego `FirebaseApp`.

## 7.2. RTDB — limit nie jest problemem dla pojedynczego urządzenia, ale struktura danych jest krytyczna

Aktualne limity Realtime Database obejmują m.in. 1000 zapisów/s na pojedynczą bazę, 64 MB/min zapisanych danych, 16 MB dla pojedynczego zapisu przez SDK i 256 MB przez REST, 256 MB dla pojedynczej odpowiedzi oraz maksymalnie 75 mln węzłów na ścieżce podlegającej listenerom/zapytaniom.

Źródło: https://firebase.google.com/docs/database/usage/limits (strona zaktualizowana 2026-09-17).

Dla jednej centrali zapis 1 próbki/minutę to tylko 1440 próbek/dobę, więc sam limit operacji zapisu jest odległy. Prawdziwym problemem będzie:
- koszt/ilość przechowywanych danych,
- wielkość odpowiedzi przy odczycie historii,
- sposób indeksowania,
- przypadkowe pobieranie całego poddrzewa przez aplikację,
- backlog urządzenia podczas niedostępności sieci.

## 7.3. Nie wybierać kluczy Firebase generowanych przez push dla próbek czasowych

Własny klucz rekordu może być oparty na czasie (`t<epoch>`), ponieważ klucze są automatycznie indeksowane i można używać `orderByKey()` + zakresu `startAt`/`endAt`.

Firebase REST pozwala filtrować po `orderBy`, `startAt`, `endAt`, `limitToFirst`, `limitToLast`, `equalTo`. Dokumentacja jednocześnie ostrzega, że wynik REST może zostać zwrócony w kolejności nieokreślonej przez JSON, więc aplikacja powinna sortować po stronie klienta, gdy kolejność ma znaczenie.

Źródła:
- https://firebase.google.com/docs/database/rest/retrieve-data
- https://firebase.google.com/docs/database/security/indexing-data

**Decyzja D-R2-02:** dla 1-min telemetryki preferowany jest klucz deterministyczny oparty na timestampie, np. `t176...`, ponieważ retry tej samej próbki może nadpisać ten sam rekord zamiast tworzyć duplikat.

## 7.4. Jeszcze lepsze: naturalny podział danych na zakresy czasu

Oficjalna dokumentacja struktury RTDB zaleca płaską/denormalizowaną strukturę tam, gdzie ułatwia ona selektywne pobieranie danych.

Źródło: https://firebase.google.com/docs/database/rest/structure-data

Rozważane są dwa warianty:

### Wariant A — jedna kolekcja 1m

```text
/piec/telemetry/1m/
    t1760000000: {...}
    t1760000060: {...}
    t1760000120: {...}
```

Zalety:
- najprostszy writer;
- `orderByKey + startAt/endAt`;
- brak dodatkowej logiki kalendarza.

Ryzyko:
- bardzo długa lista dzieci;
- łatwo przypadkowo wykonać zbyt szeroki odczyt.

### Wariant B — podział dzienny

```text
/piec/telemetry/1m/2026/09/23/
    t000000: {...}
    t000060: {...}
```

Zalety:
- naturalna paginacja;
- łatwiejsze usuwanie/retencja całych dni;
- mniejsze pojedyncze poddrzewa;
- łatwiejsza diagnostyka ręczna.

Wada:
- aplikacja musi wykonać kilka zapytań dla zakresu obejmującego wiele dni.

**Decyzja D-R2-03:** nie zamykamy jeszcze schematu A/B. Do prototypu writer może używać A, ale przed produkcją wykonamy test odczytów 1h / 24h / 7d oraz test retencji. Wybór schematu ma wynikać z pomiarów i sposobu działania aplikacji.

## 7.5. `.indexOn` — konieczne dla produkcyjnych zapytań po polach

Firebase automatycznie indeksuje klucz węzła. Dla zapytań `orderByChild()` trzeba jawnie zdefiniować `.indexOn`, jeżeli chcemy utrzymać dobrą wydajność wraz ze wzrostem danych. Firebase zaleca dodanie indeksów przed produkcyjnym wzrostem zbioru danych.

Źródło: https://firebase.google.com/docs/database/security/indexing-data

Dla schematu z kluczem timestampowym najkorzystniejsze jest używanie `orderByKey()` i zakresów klucza, co nie wymaga dodatkowego indeksu czasu.

**Decyzja D-R2-04:** nie będziemy przechowywać `ts` tylko po to, aby sortować po `ts`, jeżeli klucz rekordu już jest deterministycznym timestampem. Pole `ts` może jednak zostać zachowane w rekordzie jako walidowalna informacja diagnostyczna.

## 7.6. Reguły RTDB — `.write` nie może być szerokie

Reguły Firebase są kaskadowe: przyznanie `.write` na rodzicu daje dostęp również potomkom. `.validate` działa dopiero po uzyskaniu prawa zapisu i nie zezwala na zapis niezgodny ze schematem. Usuwanie danych (`null`) nie przechodzi przez `.validate`.

Źródła:
- https://firebase.google.com/docs/database/security
- https://firebase.google.com/docs/database/security/rules-conditions

Konsekwencja:
- telemetryka powinna mieć osobną gałąź reguł;
- writer urządzenia nie powinien mieć możliwości nadpisania `/piec/status` lub `/piec/cmd`, jeśli architektura bezpieczeństwa ma te role rozdzielać;
- `.validate` należy wykorzystać do ograniczenia zakresów/liczb/obowiązkowych pól;
- retencję/usuwanie danych trzeba projektować osobno, bo samo `.validate` jej nie zabezpiecza.

**Decyzja D-R2-05:** reguły bezpieczeństwa dla telemetryki powstaną jako osobny artefakt i nie będą mieszane z implementacją firmware w pierwszym kroku.

## 7.7. Koszt przechowywania — telemetryka jest znacznie lżejsza od obecnego statusu

Dla 1440 próbek/dobę:

| Średni rekord telemetryczny | 1 dzień | 30 dni | 365 dni |
|---:|---:|---:|---:|
| 120 B | 172.8 KB | 5.18 MB | 63.1 MB |
| 150 B | 216 KB | 6.48 MB | 78.8 MB |
| 200 B | 288 KB | 8.64 MB | 105.1 MB |
| 250 B | 360 KB | 10.8 MB | 131.4 MB |
| 300 B | 432 KB | 12.96 MB | 157.7 MB |

To są wartości payloadu danych, bez narzutów reprezentacji/bazy/protokołu.

Dla obecnego `/piec/status`, jeżeli przyjąć aktualny rozmiar około 650 B i interwał 15 s:

```text
5760 wysyłek/dobę
≈ 3.744 MB payloadu/dobę
≈ 112.32 MB payloadu / 30 dni
≈ 1.367 GB payloadu / rok
```

**Wniosek R2:** telemetryka 1/min nie stanowi dużego problemu sieciowego względem istniejącego statusu 15 s. Nie zmieniamy jednak teraz interwału statusu — byłaby to osobna optymalizacja i zmiana baseline.

## 7.8. Aktualny cennik Firebase — wpływ na retencję

Aktualna strona Firebase podaje dla Realtime Database bezpłatny poziom obejmujący 1 GB przechowywanych danych i 10 GB pobierania/miesiąc; na Blaze zachowane są te limity jako bezpłatne, a nadwyżki są rozliczane według bieżącego cennika.

Źródła:
- https://firebase.google.com/pricing
- https://firebase.google.com/docs/database/usage/billing

Nie wolno traktować 1 GB jako docelowej pojemności projektu. Trzeba uwzględnić wszystkie urządzenia, wszystkie gałęzie RTDB i narzut danych.

Przy orientacyjnym 200 B/rekord same surowe payloady telemetryczne dawałyby ~105 MB/urządzenie/rok. To sugeruje, że dla wielu urządzeń retencja będzie musiała być jawnie kontrolowana albo dane będą musiały być okresowo agregowane/archiwizowane poza RTDB.

## 7.9. LittleFS — nowy ważny wniosek: sumowanie rozmiarów plików nie równa się `usedBytes()`

Arduino-ESP32 udostępnia zarówno `LittleFS.totalBytes()`, jak i `LittleFS.usedBytes()`. Implementacja wrappera pobiera te wartości z `esp_littlefs_info()`.

Źródło: https://github.com/espressif/arduino-esp32/blob/master/libraries/LittleFS/src/LittleFS.cpp

Aktualny firmware celowo zrezygnował z `LittleFS.usedBytes()` w guardzie ze względu na problemy ze współbieżnością i zamiast tego sumuje cache rozmiarów plików.

To zabezpiecza nas przed częścią wyścigów, ale ma wadę koncepcyjną: suma rozmiarów plików nie musi odpowiadać realnemu `usedBytes()` filesystemu, bo LittleFS ma własne metadane, bloki i stan FS.

Oficjalna dokumentacja ESP-IDF opisuje LittleFS jako filesystem z własnym wear levelling, niskim zużyciem RAM i ochroną przed utratą danych przy zaniku zasilania.

Źródło: https://docs.espressif.com/projects/esp-idf/en/stable/esp32s3/api-guides/file-system-considerations.html

**Decyzja D-R2-06:** docelowy guard miejsca powinien bazować na rzeczywistym stanie filesystemu, ale pobieranym w kontrolowanym, współbieżnie bezpiecznym miejscu. Sama suma `File.size()` nie jest wystarczającym źródłem prawdy.

Rozważany model:

```text
fsMutex
   ├── open/read/write/remove/rename
   └── esp_littlefs_info()/LittleFS.usedBytes()

fsUsageSnapshot
   ├── total
   ├── used
   ├── free
   └── reserved
```

Nie przesądzam jeszcze, że wszystkie obecne operacje FS trzeba przepiąć pod jeden mutex. To będzie osobny audyt call-site'ów, ponieważ zmiana globalnego lockowania FS może sama w sobie stworzyć deadlocki.

## 7.10. LittleFS i persistent spool — nowa decyzja architektoniczna

Konfiguracja `sdkconfig.defaults` zawiera:

```text
CONFIG_LITTLEFS_BLOCK_CYCLES=512
CONFIG_LITTLEFS_CACHE_SIZE=512
CONFIG_LITTLEFS_LOOKAHEAD_SIZE=128
CONFIG_LITTLEFS_PAGE_SIZE=256
CONFIG_LITTLEFS_READ_SIZE=128
CONFIG_LITTLEFS_WRITE_SIZE=128
```

LittleFS stosuje dynamiczne wear levelling; parametr `block_cycles` wpływa na balans zużycia bloków.

Źródła:
- https://github.com/littlefs-project/littlefs/blob/master/lfs.h
- https://docs.espressif.com/projects/esp-idf/en/stable/esp32s3/api-guides/file-system-considerations.html

Nowy wniosek projektowy: persistent telemetry spool **nie powinien zapisywać każdej próbki 1/minutę przez cały czas**, jeśli połączenie z Firebase jest prawidłowe.

Lepszy model:

```text
ONLINE
  → ring PSRAM
  → Firebase
  → brak zapisu telemetryki do flash

OFFLINE / backlog
  → ring PSRAM
  → po przekroczeniu progu
  → zapis paczki do spoolu LittleFS

POWRÓT ONLINE
  → odczyt paczki
  → upload
  → dopiero po sukcesie usunięcie/zwolnienie paczki
```

Daje to dwa efekty:
1. praktycznie zerowe zużycie flash przez telemetrykę podczas normalnej pracy;
2. zapis do flash następuje głównie wtedy, kiedy rzeczywiście potrzebujemy bufora offline.

**Decyzja D-R2-07:** persistent spool projektować jako mechanizm awaryjny/backlog, nie jako drugi logger równoległy do `hist_short.csv`.

## 7.11. Timestamp i synchronizacja czasu

Obecna funkcja `historiaZapiszProbke()` zapisuje `czas_unix = 0`, gdy nie ma wiarygodnego RTC/NTP. To należy zachować także dla telemetryki — nie wolno udawać poprawnego czasu.

Firebase oferuje również serwerowy timestamp i mechanizm `ServerValue.TIMESTAMP`, a `/.info/serverTimeOffset` może służyć do oceny rozjazdu zegara klienta.

Źródło: https://firebase.google.com/docs/database/web/offline-capabilities

**Decyzja D-R2-08:** telemetryka będzie rozróżniała:
- `ts=0` / czas niezweryfikowany,
- prawidłowy timestamp urządzenia.

Nie będziemy po cichu zastępować czasu urządzenia czasem serwera, ponieważ pomiar ma reprezentować moment odczytu czujników, nie moment dotarcia do Firebase.

## 7.12. Metryki diagnostyczne — doprecyzowanie

Po researchu lista metryk zostaje rozszerzona o:

```text
firebase.queue_depth
firebase.queue_depth_max
firebase.upload_ok
firebase.upload_fail
firebase.upload_timeout
firebase.retry_count
firebase.oldest_pending_ts
firebase.newest_pending_ts
telemetry.ring_used
telemetry.ring_peak
telemetry.ring_drop
telemetry.samples_produced
telemetry.samples_uploaded
telemetry.samples_spooled
telemetry.samples_replayed
fs.used_bytes
fs.total_bytes
fs.free_bytes
fs.reserve_bytes
```

ESP-IDF zaleca `uxTaskGetStackHighWaterMark()` do pomiaru minimalnego wolnego stosu taska; `uxTaskGetSystemState()` daje zbiorczy snapshot tasków.

Źródło: https://docs.espressif.com/projects/esp-idf/en/latest/esp32s3/api-guides/performance/ram-usage.html

---

# 8. Zmieniony plan po R2

## P0 — przed telemetryką

1. Potwierdzić faktyczny `sdkconfig.<env>` z buildu.
2. Zrobić pełny audyt wszystkich call-site'ów LittleFS i zaprojektować bezpieczny `fsMutex` / snapshot użycia.
3. Naprawić archiwizację coredump: checksum, wynik `write()`, `.part`, rozmiar, dopiero potem erase.
4. Zrobić kontrolowany crash-test i sprawdzić dekodowanie ELF.

## P1 — telemetryka RAM + Firebase

5. Zdefiniować kompaktowy `TelemetrySample`.
6. Dodać `TelemetryRing` do PSRAM.
7. Produkować próbkę tylko w `historiaZapiszProbke()`.
8. Dodać bounded uploader przez istniejący Firebase worker.
9. Rejestrować `taskCount()` i metryki backlogu.
10. Przetestować batch 5 / 10 / 20 próbek względem WDT i opóźnienia.

## P2 — backend / aplikacja

11. Wybrać schemat RTDB A/B po testach odczytu.
12. Zdefiniować reguły `.read/.write/.validate/.indexOn`.
13. Zaimplementować zakresowe pobieranie historii i lokalny cache aplikacji.
14. Zdefiniować retencję i agregaty.

## P3 — offline durability

15. Zaprojektować persistent spool tylko jako awaryjny backlog.
16. Prowadzić zapis paczkami, z CRC/sekwencją/recovery.
17. Po sukcesie uploadu atomowo zwalniać paczki.

## P4 — osobno od telemetryki

18. Migracja Firebase LegacyToken / Database Secret.
19. Włączenie poprawnej weryfikacji TLS zamiast `setInsecure()`.
20. Osobny test aktualizacji FirebaseClient.
21. Osobny test aktualizacji toolchainu pioarduino/Arduino-ESP32.

---

# 9. Otwarte pytania po R2

1. Jaki jest faktycznie wygenerowany `sdkconfig.<env>` z ostatniego buildu?
2. Czy obecny coredump 64 KiB pomieści rzeczywisty zestaw tasków centrali w formacie ELF?
3. Jakie jest realne `LittleFS.usedBytes()` przy typowym i maksymalnym stanie wszystkich plików?
4. Czy wszystkie operacje LittleFS można objąć jednym mutexem bez ryzyka blokad krzyżowych?
5. Jaki jest docelowy okres offline, który telemetryka ma przetrwać bez Firebase: 1 h / 24 h / 7 dni / 30 dni?
6. Ile central ma docelowo korzystać z jednej bazy RTDB?
7. Czy aplikacja potrzebuje pełnej rozdzielczości 1/min przez rok, czy tylko ostatnich N dni + agregaty starszych danych?
8. Czy `ts=0` ma być przechowywane jako rekord diagnostyczny, czy takie próbki mają trafiać wyłącznie do lokalnego spoolu z użyciem `seq`?

---

# 10. Źródła zewnętrzne wykorzystane w R2

- Firebase Realtime Database Limits — https://firebase.google.com/docs/database/usage/limits
- Firebase Realtime Database: Retrieving Data — https://firebase.google.com/docs/database/rest/retrieve-data
- Firebase Realtime Database: Structure Your Database — https://firebase.google.com/docs/database/rest/structure-data
- Firebase Realtime Database: Index your data — https://firebase.google.com/docs/database/security/indexing-data
- Firebase Realtime Database: Security Rules — https://firebase.google.com/docs/database/security
- Firebase Realtime Database: Rule Conditions — https://firebase.google.com/docs/database/security/rules-conditions
- Firebase Realtime Database: Saving Data — https://firebase.google.com/docs/database/rest/save-data
- Firebase Realtime Database: Billing — https://firebase.google.com/docs/database/usage/billing
- Firebase Pricing — https://firebase.google.com/pricing
- Firebase Database Performance Monitoring — https://firebase.google.com/docs/database/usage/monitor-performance
- FirebaseClient AsyncClientClass — https://github.com/mobizt/FirebaseClient/blob/main/resources/docs/async_client.md
- FirebaseClient README — https://github.com/mobizt/FirebaseClient
- Arduino-ESP32 LittleFS wrapper — https://github.com/espressif/arduino-esp32/blob/master/libraries/LittleFS/src/LittleFS.cpp
- ESP-IDF File System Considerations — https://docs.espressif.com/projects/esp-idf/en/stable/esp32s3/api-guides/file-system-considerations.html
- littlefs `lfs.h` — https://github.com/littlefs-project/littlefs/blob/master/lfs.h
- ESP-IDF RAM Usage — https://docs.espressif.com/projects/esp-idf/en/latest/esp32s3/api-guides/performance/ram-usage.html
- Firebase Offline Capabilities / Server Timestamp — https://firebase.google.com/docs/database/web/offline-capabilities

---

# 11. RESEARCH R3 — batch upload, idempotencja, auth i doprecyzowanie schematu

Data: 2026-09-23
Status kroku: **ZAKOŃCZONY / RESEARCH**

## 11.1. Batch telemetryki: `update()` jest lepszym kandydatem niż wiele `set()`

FirebaseClient posiada `RealtimeDatabase::update()` dla `object_t`. Dokumentacja biblioteki określa tę operację jako aktualizację (PATCH) obiektu JSON.

Firebase REST API definiuje PATCH jako aktualizację tylko wskazanych dzieci, bez zastępowania całej zawartości lokalizacji. Firebase obsługuje również multi-path updates: w jednym PATCH można wskazać wiele ścieżek i aktualizacja jest wykonywana atomowo.

Źródła:
- https://github.com/mobizt/FirebaseClient/blob/main/resources/docs/realtime_database.md
- https://firebase.google.com/docs/database/rest/save-data

### Proponowany mechanizm

```text
TelemetryRing
   ↓ pop 10 próbek
JSON/object_t
   {
     "t<ts1>": {...},
     "t<ts2>": {...},
     ...
     "t<ts10>": {...}
   }
   ↓
Database.update<object_t>(...)
```

Przy 10 próbkach zamiast 10 osobnych requestów otrzymujemy jeden request.

**Decyzja D-R3-01:** początkowy eksperyment uploadu będzie porównywał batch 5 / 10 / 20 próbek. `update()` jest preferowanym mechanizmem dla batcha, ale nie zakładamy z góry maksymalnego rozmiaru JSON.

## 11.2. Atomowość batcha rozwiązuje ważny problem retry

Przy deterministycznych kluczach timestampowych ponowienie całego batcha po timeout może ponownie zapisać te same rekordy. Ponieważ te rekordy mają identyczne klucze, retry nie tworzy kolejnych dzieci.

Jeżeli PATCH obejmuje 10 rekordów i operacja się nie powiedzie, nie można traktować jej jako częściowo zaakceptowanej na poziomie aplikacji. Z punktu widzenia writer'a poprawny model jest prostszy:

```text
batch = pending
     ↓
UPDATE
     ├── sukces → usuń/oznacz wszystkie próbki z batcha
     └── błąd    → zostaw cały batch jako pending
```

Źródło atomowości multi-path updates:
https://firebase.google.com/docs/database/rest/save-data

**Decyzja D-R3-02:** granica potwierdzenia (ack) telemetryki będzie granicą całego batcha, nie pojedynczej próbki.

## 11.3. `set()` vs `update()` — istotna różnica

`PUT`/`set` pod wskazaną ścieżką zastępuje dane znajdujące się pod tą ścieżką, natomiast PATCH/update zmienia tylko wskazane dzieci.

Dla telemetryki oznacza to:
- pojedynczy rekord może być bezpiecznie zapisany przez `set()` pod `/t<ts>`;
- batch wielu rekordów powinien iść przez `update()` na rodzicu;
- nie wolno robić `set()` całego `/piec/telemetry/1m` z zawartością tylko bieżącego batcha, bo usunęłoby to starsze rekordy spod tego rodzica.

Źródło:
https://firebase.google.com/docs/database/rest/save-data

## 11.4. Idempotencja — timestamp jako klucz + `seq` jako diagnostyka

Proponowany rekord dostaje:

```text
key = t<epoch_seconds>
```

i może dodatkowo zawierać:

```text
seq = rosnący numer próbki
```

`seq` nie służy do adresowania danych. Ma umożliwić wykrycie:
- restartu urządzenia,
- utraty próbek,
- resetu czasu,
- luk w telemetryce.

Przykład diagnostyczny:

```text
seq 1001
seq 1002
seq 1003
seq 1005   ← brak 1004
```

Jeżeli timestamp jest prawidłowy, aplikacja może dodatkowo policzyć spodziewane interwały minutowe.

**Decyzja D-R3-03:** zachować `seq` w rekordzie telemetrycznym, mimo że kluczem pozostaje timestamp.

## 11.5. Problem czasu: trzeba rozdzielić `measurement_ts` i czas dotarcia

Obecny firmware pobiera czas przed wpisaniem próbki. Gdy RTC/NTP nie jest gotowe, zapisuje `czas_unix=0`.

To jest prawidłowe semantycznie dla pomiaru, bo próbka opisuje stan fizyczny w chwili pomiaru.

Nie należy zastępować tego po stronie urządzenia czasem Firebase z momentu zapisu.

Firebase ma mechanizm `ServerValue.TIMESTAMP`, który reprezentuje czas serwera. Może on być używany pomocniczo, ale jest to inny rodzaj czasu niż czas pomiaru.

Źródło:
https://firebase.google.com/docs/database/web/offline-capabilities

**Decyzja D-R3-04:** model rekordu ma logicznie rozróżniać:

```text
measurement_ts  = kiedy zmierzono
server/write time = kiedy Firebase przyjął zapis (opcjonalnie)
```

Nie wymagamy jeszcze zapisu drugiego pola, ale nie będziemy mylić obu znaczeń.

## 11.6. Proponowany kompaktowy rekord firmware

Na podstawie istniejących 14 kolumn historii krótkiej nie ma potrzeby kopiować całej struktury `HistoriaProbka` do telemetryki.

Kandydat:

```cpp
struct TelemetrySample {
    uint32_t ts;          // epoch seconds; 0 = brak pewnego czasu
    uint32_t seq;         // monotoniczny numer próbki
    int16_t  t_zewn_x10;
    int16_t  t_bojler_x10;
    int16_t  t_ogrz_x10;
    int16_t  t_ogrz_sr_x10;
    int16_t  t_powrot_x10;
    int16_t  t_panel_x10;
    int16_t  t_pokoj_x10;
    uint16_t cisnienie_x100;  // do potwierdzenia zakresu/rozdzielczości
    uint8_t  wilgotnosc;
    uint8_t  pompa;
    uint8_t  klapa_proc;
    uint8_t  syberko_proc;
    uint16_t valid_mask;
};
```

Docelowy rozmiar należy sprawdzić przez `sizeof(TelemetrySample)` po wyrównaniu kompilatora. Przy korzystnym ułożeniu będzie to rząd **32 B/próbkę**, czyli około:

```text
1440 próbek × 32 B ≈ 46 KB
```

na pełną dobę w RAM.

Nie jest to jeszcze zatwierdzony ABI rekordu — nazwy i rozdzielczości będą wynikały z rzeczywistych zakresów zmiennych w kodzie.

**Decyzja D-R3-05:** ring ma przechowywać liczby w formie stałej/binarnej; JSON powstaje dopiero przy uploadzie. Dzięki temu producent nie robi formatowania tekstowego co minutę.

## 11.7. `valid_mask` jest ważniejszy niż magiczne wartości

Obecny kod ma kilka sygnałów, które mogą być czasowo niewiarygodne lub niedostępne.

Zamiast kodować np.:

```text
-999 = brak czujnika
```

lepiej przechowywać wartość oraz bit ważności:

```text
valid_mask bit 0 = t_zewn valid
valid_mask bit 1 = t_bojler valid
...
```

To daje aplikacji możliwość odróżnienia:
- rzeczywistego ekstremalnego pomiaru,
- błędu czujnika,
- braku inicjalizacji,
- chwilowej niedostępności.

**Decyzja D-R3-06:** `valid_mask` pozostaje elementem projektu, ale dokładna mapa bitów będzie ustalona po audycie wszystkich źródeł pomiarów.

## 11.8. Klucz dzienny — obecnie preferowany do produkcji, ale jeszcze nie zatwierdzony

Po zestawieniu:
- zapytań zakresowych,
- limitów pojedynczej odpowiedzi,
- retencji,
- potrzeby usuwania całych zakresów,
- ryzyka przypadkowego pobierania szerokiej gałęzi,

wariant dzienny ma obecnie więcej argumentów architektonicznych niż jedna nieskończenie rosnąca lista.

Propozycja produkcyjna:

```text
/piec/telemetry/1m/2026/09/23/
    t10: {...}
    t11: {...}
    ...
```

lub jeszcze prościej:

```text
/piec/telemetry/1m/2026-09-23/
    t<seconds_of_day>: {...}
```

Drugi wariant skraca ścieżkę i pozostawia jeden poziom daty.

Firebase ogranicza głębokość całego drzewa do 32 poziomów, więc oba warianty są technicznie odległe od limitu. Znacznie ważniejsze jest to, aby aplikacja nie czytała całej wielkiej gałęzi zamiast ograniczonego zakresu.

Źródło limitu głębokości i limitów odczytu:
https://firebase.google.com/docs/database/usage/limits

**Decyzja D-R3-07:** do prototypu można zastosować jedną kolekcję, ale przed produkcją wybór zostaje przełączony na schemat dopasowany do retencji; obecnie roboczo preferowany jest podział dzienny.

## 11.9. Security — obecna architektura auth nie powinna zostać skopiowana do telemetryki jako docelowa

Aktualny firmware używa LegacyToken / Database Secret oraz `WiFiClientSecure::setInsecure()`.

Firebase obecnie nadal dokumentuje obsługę legacy secrets, ale wyraźnie zaleca migrację do nowszych metod uwierzytelniania; legacy secret jest długowiecznym credentialem.

Źródło:
https://firebase.google.com/docs/database/rest/auth

Firebase wspiera również custom JWT tokens generowane po stronie serwera. Custom token ma jednoznaczny `uid`, wygasa po maksymalnie godzinie i po wymianie na sesję Firebase tożsamość trafia do `auth` w regułach RTDB.

Źródło:
https://firebase.google.com/docs/auth/admin/create-custom-tokens

### Docelowa idea security

```text
backend / provisioning
       ↓
per-device identity
       ↓
Firebase Auth
       ↓
RTDB Rules
       ↓
/piec/{deviceUid}/telemetry/...
```

To pozwala ograniczyć urządzenie do własnej gałęzi danych i rozdzielić uprawnienia od globalnego sekretu bazy.

**Decyzja D-R3-08:** security migration pozostaje P4 i osobnym projektem, ale schemat telemetryki nie może zakładać, że globalny Database Secret będzie docelowym mechanizmem autoryzacji.

## 11.10. TLS: `setInsecure()` jest niezależnym problemem od auth

Aktualne firmware wywołuje `setInsecure()`, co oznacza brak weryfikacji certyfikatu po stronie `WiFiClientSecure`.

To nie jest to samo zagadnienie co Firebase authentication:

```text
TLS verification = czy łączymy się z właściwym serwerem
Authentication    = czy serwer pozwala nam wykonać operację
```

Docelowo telemetryka powinna mieć oba mechanizmy poprawnie skonfigurowane.

**Decyzja D-R3-09:** nie łączyć naprawy TLS z pierwszym kodem telemetrycznym, ale uwzględnić ją w checklist bezpieczeństwa przed produkcją.

## 11.11. Najnowsza korekta kolejności prac

Po R3 kolejność jest teraz:

```text
P0
 ├─ build truth
 ├─ LittleFS global accounting
 └─ coredump safety

P1
 ├─ diagnostics
 ├─ TelemetrySample
 ├─ TelemetryRing
 └─ Firebase batch writer

P2
 ├─ RTDB daily schema / range queries
 ├─ rules
 ├─ app cache
 └─ retention

P3
 └─ persistent offline spool

P4
 ├─ Firebase auth migration
 ├─ TLS verification
 ├─ FirebaseClient upgrade
 └─ toolchain upgrade
```

---

# 12. Kryteria akceptacji telemetryki — wersja robocza

Firmware nie powinien być uznany za gotowy tylko dlatego, że „rekord pojawił się w Firebase”. Minimalny zestaw testów:

1. **Normal online** — 24 h bez utraty próbki.
2. **Firebase chwilowo niedostępny** — brak restartu, brak lawinowego tworzenia tasków.
3. **Wi-Fi off 1 h** — ring rośnie, a system automatyki nadal działa.
4. **Powrót Wi-Fi** — backlog znika bez duplikatów.
5. **Timeout podczas batch uploadu** — cały batch pozostaje do retry.
6. **Restart w trakcie backlogu** — jawnie dokumentujemy, czy dane z PSRAM są tracone; persistent spool dopiero później rozwiąże tę klasę awarii.
7. **Brak czasu RTC/NTP** — brak fałszywych timestampów.
8. **Błąd pojedynczego czujnika** — `valid_mask` odróżnia błąd od prawdziwej wartości.
9. **24 h pracy** — brak pogorszenia heap/PSRAM i brak narastającego queue backlog.
10. **7 dni pracy** — brak wzrostu użycia pamięci wynikającego z telemetryki.
11. **Pełne RTDB** — test zakresu 1 h / 24 h / 7 d i pomiar payloadu.
12. **Security** — próba zapisu do cudzej gałęzi urządzenia ma zostać odrzucona po wdrożeniu docelowych Rules.


# 13. R4 — audyt rzeczywistej współbieżności LittleFS i korekta modelu blokad

**Data:** 2026-09-23

Ten etap jest ważniejszy niż samo dodanie `usedBytes()`, ponieważ aktualny firmware ma kilka różnych klas dostępu do LittleFS: zapisy, odczyty strumieniowe, operacje wieloetapowe (`remove+rename`) oraz odczyty statystyk/cache.

## 13.1. Nowe ustalenie z upstream `esp_littlefs`

W aktualnym portcie `joltwallet/esp_littlefs` v1.22.3 warstwa VFS posiada własny mutex per kontekst filesystemu (`sem_take(efs)` / `sem_give(efs)`). Jest on używany m.in. przy `esp_littlefs_info()`, `open`, `read`, `write`, `rename`, `unlink`, operacjach katalogowych i innych wywołaniach LittleFS.

Źródło:
https://raw.githubusercontent.com/joltwallet/esp_littlefs/v1.22.3/src/esp_littlefs.c

W szczególności `get_total_and_used_bytes()` pobiera mutex przed `lfs_fs_size()`, więc w tej wersji wrapper sam serializuje obliczenie `usedBytes()` na poziomie konkretnej partycji.

### Wniosek

Nie wolno już w planie pisać bezwarunkowo:

> „LittleFS.usedBytes() jest samo w sobie niewątkowe i zawsze wymaga naszego mutexa.”

Prawidłowe rozróżnienie brzmi:

```text
warstwa VFS / esp_littlefs
    └─ serializuje pojedyncze operacje lfs_*

logika aplikacji
    └─ nadal może wymagać mutexa do TRANSAKCJI:
       open → read/write → close
       remove → rename
       odczyt cache → operacja → aktualizacja cache
       snapshot kilku plików
```

**Otwarte P0:** nie znamy jeszcze dokładnej wersji `esp_littlefs`, która jest faktycznie dostarczana przez używany pakiet Arduino-ESP32 3.3.8 / pioarduino 55.03.38. Nie wolno podstawiać wersji 1.22.3 jako pewnika. Weryfikacja wersji frameworkowego komponentu zostaje elementem `build truth`.

---

## 13.2. Audyt call-site'ów wykazał, że obecny `logMutex` nie chroni całej logiki plikowej

W `main_centrala (3).cpp` znaleziono m.in. następujące klasy:

### Chronione aplikacyjnie

- `logFlushDoFS()` — zapis `log_b.txt`, cache rozmiaru i `close()` są wykonywane pod `logMutex`.
- `zapiszLogKrytyczny()` — zapis `log_krytyczny.txt` pod `logMutex`.
- `zapiszLogUstawien()` — zapis `log_ustawien.txt` pod `logMutex`.
- `historiaFlushDoFS()` — zapis `hist_short.csv` pod `logMutex`.
- `historiaDlugaFlushDoFS()` — zapis `hist_long.csv` pod `logMutex`.
- rotacja `log_b → log_a` — `remove+rename` pod `logMutex`.
- `logWyczysc()` — kasowanie `log_a/log_b` pod `logMutex`.
- początek i zakończenie pobrania `/panel_firmware.bin` — operacje metadanych (`remove/open`, `remove/rename`) pod `logMutex`.

### Nadal nieobjęte tym samym mutexem podczas całego cyklu

1. `sendTelegramDocument()` otwiera i czyta `log_a.txt` / `log_b.txt` bez `logMutex`.
2. `sendTelegramDocumentHistKrotka()` czyta `hist_short.csv` bez `logMutex`.
3. `sendTelegramDocumentHistDluga()` czyta `hist_long.csv` bez `logMutex`.
4. `sendTelegramDocumentUstawien()` czyta `log_ustawien.txt` bez `logMutex`.
5. endpoint `/panel-ota.bin` wykorzystuje `request->send(LittleFS, ...)` bez własnej blokady aplikacyjnej.
6. `/api/fs-view` wykonuje `exists/open/read/close` bez `logMutex`.
7. część `/api/fs-download` i `/api/fs-delete` działa poza wspólną transakcją dla całej operacji.
8. upload `/api/fs-upload` otwiera plik pod `logMutex`, ale trzyma uchwyt pomiędzy kolejnymi callbackami HTTP; następne `write()` są blokowane pojedynczo.
9. `pobierzFirmwarePanelaZGithub()` otwiera `.tmp` pod `logMutex`, następnie wykonuje długi strumieniowy zapis bez tego mutexa, a na końcu robi `remove+rename` pod mutexem.
10. `sendTelegramCoredump()` wykonuje odczyt pliku bez `logMutex`; obecnie jest to znacznie mniej ryzykowne, ponieważ producent coredumpu działa podczas `setup()`, przed startem zadań, ale docelowo katalog coredumpów również powinien należeć do modelu FS ownership.

---

## 13.3. Znaleziona poważniejsza luka: `logTrimKeepTail()` może utracić świeżo dopisane dane

`logTrimKeepTail()` najpierw:

```text
open źródła
read/seek/kopiowanie do *.tmp
close źródła
```

bez `logMutex`, a dopiero później bierze `logMutex` na:

```text
remove źródła
rename *.tmp → źródło
```

Jeżeli inny kontekst dopisze dane do tego samego pliku pomiędzy kopiowaniem a `remove+rename`, istnieje scenariusz:

```text
T0  trim czyta stary stan
T1  writer dopisuje nowe dane
T2  trim usuwa oryginalny plik
T3  trim wstawia snapshot z T0

=> dane z T1 zostają utracone
```

To nie jest już problem wyłącznie „czy LittleFS się wysypie”. To problem **spójności danych aplikacyjnych**.

### Decyzja D-R4-01

Przed persistent telemetry spool trzeba uporządkować operacje typu:

```text
snapshot/copy → replace
```

tak, aby snapshot był logicznie atomowy względem writerów.

Nie oznacza to automatycznie „trzymaj mutex przez cały długi zapis”. Preferowany wzorzec będzie zależał od konkretnego pliku:

- dla małych plików: możliwa pełna transakcja pod mutexem;
- dla dużych plików: snapshot wersji / kontrola generacji / specjalny writer-owner;
- dla plików telemetrycznych: osobny append-only spool, bez `remove+rename` na każdą próbkę.

---

## 13.4. `usedBytes()` pozostaje właściwą metryką pełnego zużycia, ale nie może być jedyną polityką miejsca

`LittleFS.usedBytes()` raportuje zajętość obliczaną przez filesystem, a nie prostą sumę rozmiarów użytkowych plików. Upstream `esp_littlefs` ogranicza wynik do rzeczywistego rozmiaru filesystemu po przeliczeniu bloków.

Dodatkowo README `esp_littlefs` wskazuje, że świeżo sformatowany LittleFS ma już zajęte dwa bloki i operuje blokami 4096 B na ESP32.

Źródło:
https://github.com/joltwallet/esp_littlefs

Dlatego docelowy model powinien przechowywać oba rodzaje informacji:

```text
FS_TOTAL_BYTES
FS_USED_BYTES          ← realny stan filesystemu
FS_FREE_BYTES
FS_RESERVED_BYTES      ← rezerwa polityki aplikacji
FS_TELEMETRY_QUOTA
```

A suma `File.size()` ma pozostać metryką diagnostyczną per plik, nie zastępować `FS_USED_BYTES`.

---

## 13.5. Nowa architektura blokad FS — wersja robocza

Nie wprowadzamy jeszcze mechanicznego `xSemaphoreTake(fsMutex)` wokół każdego `LittleFS.*`.

Zamiast tego rozdzielamy trzy poziomy:

### Poziom A — pojedyncze wywołanie filesystemu

Pozostawiamy ochronę realizowaną przez aktualny framework/esp_littlefs, po wcześniejszym potwierdzeniu jego wersji.

### Poziom B — transakcja aplikacyjna

Wspólny mutex aplikacyjny jest potrzebny, gdy kilka operacji musi logicznie stanowić jedną całość:

```text
exists + open + size + read + close
remove + rename
open + write + update cache + close
snapshot kilku plików
```

### Poziom C — długie streamy sieciowe

Nie trzymamy mutexa aplikacyjnego przez:

```text
LittleFS read
      ↓
TLS/TCP/Telegram/HTTP
      ↓
LittleFS read
      ↓
TLS/TCP/...
```

To blokowałoby producentów logów/historii na czas transmisji.

Preferowany model:

```text
FS mutex
   ↓
read mały chunk
   ↓
release
   ↓
network send
   ↓
FS mutex
   ↓
read następny chunk
```

Dla operacji wymagających snapshotu można dodatkowo użyć wersji/generacji pliku albo tymczasowego snapshotu, zamiast utrzymywać mutex przez całą transmisję.

---

## 13.6. Wpływ na telemetrykę

To wzmacnia wcześniejszą decyzję, aby telemetryka **nie pisała bezpośrednio na LittleFS co minutę**.

Docelowo:

```text
ONLINE
sensor → TelemetryRing PSRAM → Firebase

OFFLINE / duży backlog
sensor → TelemetryRing → okresowy page/spool zapisany do LittleFS

ONLINE ponownie
LittleFS spool → Firebase → dopiero po potwierdzeniu zwolnienie page
```

Dzięki temu codzienna ścieżka telemetryczna nie bierze udziału w skomplikowanych transakcjach istniejącego loggera.

---

## 13.7. Nowa lista P0 po R4

```text
P0.1  build truth — wygenerowany sdkconfig + wersja esp_littlefs
P0.2  pełna mapa FS call-site'ów
P0.3  naprawa logTrimKeepTail() / innych snapshot→replace race
P0.4  realny FS_USED/FS_FREE + polityka rezerwy
P0.5  bezpieczna archiwizacja coredumpu
P0.6  diagnostyka heap/PSRAM/stack/Firebase queue
```

Dopiero po tym:

```text
P1.1 TelemetrySample
P1.2 TelemetryRing
P1.3 wspólny Firebase writer
P1.4 batching
P1.5 idempotent retry
```

---

## 13.8. Ryzyko wersji komponentu — nowe wymaganie testowe

Ponieważ zachowanie `esp_littlefs` zależy od wersji frameworkowego komponentu, test instalacyjny powinien zebrać:

```text
pio package list
framework Arduino version
esp_littlefs component/version
ESP-IDF version
```

oraz z logu/build artifacts:

```text
sdkconfig.<env>
partitions.csv z buildu
firmware ELF
```

Nie będziemy zmieniać platformy tylko po to, żeby „mieć nowszy LittleFS”. Najpierw identyfikacja obecnego komponentu, następnie test regresyjny.

---

## 13.9. R4 — status

**Zakończone:**
- audyt bezpośrednich call-site'ów LittleFS;
- rozdzielenie bezpieczeństwa pojedynczej operacji od atomowości logiki aplikacji;
- wykrycie race w `logTrimKeepTail()`;
- doprecyzowanie przyszłego modelu FS mutex + krótkie chunki;
- potwierdzenie, że `usedBytes()` powinno być realną metryką filesystemu, ale nie jedynym limitem.

**Nie zamknięte:**
- dokładna wersja `esp_littlefs` w obecnym pioarduino/Arduino-ESP32;
- kompletna mapa wszystkich endpointów `/api/fs-*`;
- implementacja poprawek.

**Następny research:** wersja komponentów + pełna mapa tasków i ich stosów + audyt dokładnych miejsc wejścia do Firebase, tak aby można było zaprojektować writer telemetryczny bez żadnej konkurencji z `fbApp.loop()`.

---

# 14. R5 — AUDYT FIREBASE + HARMONOGRAMU TASKÓW (23.09.2026)

## 14.1. Cel kroku

Sprawdzić, czy planowana telemetryka może zostać dołączona do istniejącej ścieżki Firebase bez:

- zwiększenia ryzyka TASK_WDT/IWDT,
- blokowania `loopTask` na Core 1,
- tworzenia drugiego `fbApp.loop()`,
- przepełnienia kolejki `AsyncClientClass`,
- utraty priorytetu dla `/piec/status` i `/piec/cmd`.

---

## 14.2. Faktyczny układ tasków w obecnym źródle

Zidentyfikowane jawne taski użytkownika:

| Task | Core | Priorytet | Stack | Rola |
|---|---:|---:|---:|---|
| `loopTask` | 1 wg `sdkconfig.defaults` | 1 w Arduino-ESP32 | domyślnie 8192 B, do potwierdzenia w buildzie | sterowanie / scheduler / pętla Arduino |
| `fbLoopWork` | 1 | 1 | 8192 B | ograniczone oczekiwanie `fbApp.loop()` |
| `dnsLookup` | 1 | 1 | 4096 B | pomocniczy DNS |
| `tgTask` | 0 | 1 | 8192 B | Firebase status/cmd + Telegram + logi |
| `tgPollTask` | 0 | 1 | 8192 B | Telegram long-poll |
| `historiaTask` | 0 | 1 | 8192 B | flush historii do FS |

Źródło tworzy `fbLoopWork` przez:

```cpp
xTaskCreatePinnedToCore(fbLoopWorkerTaskFn, "fbLoopWork", 8192,
                        ctx, 1, &worker, 1);
```

To jest istotne: `fbLoopWork` siedzi na tym samym Core 1 co `loopTask` i ma ten sam priorytet `1`.

---

## 14.3. Potwierdzenie z Arduino-ESP32

Arduino-ESP32 definiuje `ARDUINO_RUNNING_CORE=1` dla konfiguracji CORE 1, a `loopTask` jest tworzony jako task FreeRTOS z priorytetem `1`.

Źródła:
- `arduino-esp32/Kconfig.projbuild` — wybór `ARDUINO_RUNNING_CORE` i domyślny stack loopTask 8192 B.
- `arduino-esp32/cores/esp32/main.cpp` — `xTaskCreateUniversal(loopTask, ..., 1, ..., ARDUINO_RUNNING_CORE)`.

**Wniosek:** przy obecnym `sdkconfig.defaults` architektura rzeczywiście ustawia główną pętlę sterującą na Core 1, a `fbLoopWork` jest tworzony na Core 1 również z priorytetem 1.

---

## 14.4. Nowe P0/P1: worker Firebase może oddziaływać na loopTask

Obecny projekt został zbudowany po to, żeby długie `fbApp.loop()` nie blokowało `tgTask` na Core 0. Jednak `fbLoopWork` przeniesiono na Core 1, gdzie znajduje się `loopTask`.

W `fbPracaPetli()` występuje:

```cpp
while (...) {
    fbApp.loop();
    applyTcpKeepalive(...);
    applyFbSockTimeouts(...);
    vTaskDelay(10 ms);
}
```

Kluczowe jest to, że `vTaskDelay()` następuje **dopiero po powrocie z `fbApp.loop()`**.

Jeżeli `fbApp.loop()` wejdzie w długie blokujące połączenie/socket operation, `fbLoopWork` może przez ten okres pozostawać wykonywalny na Core 1 bez jawnego ustąpienia sterowania.

Nie należy więc jeszcze uznawać komentarza „trzyma ruch TLS poza pętlą sterującą” za dowiedziony gwarant architektoniczny. Jest to hipoteza wymagająca pomiaru.

### Test wymagany przed telemetryką

Podczas sztucznego:

- DNS timeout,
- TCP connect timeout,
- TLS handshake timeout,
- serwera zamykającego połączenie,
- braku odpowiedzi Firebase,

logować równolegle:

```text
loop heartbeat / scheduler jitter
fbLoopWorker start
fbLoopWorker finish
czas trwania fbApp.loop
Core 1 idle / task runtime
TWDT reset / panic
```

Interesuje nas szczególnie maksymalna luka pomiędzy kolejnymi wykonaniami sekcji sterowania na Core 1.

---

## 14.5. FirebaseClient: FIFO i `taskCount()`

Dokumentacja `AsyncClientClass` mówi, że zadania asynchroniczne trafiają do kolejki FIFO. Klasa udostępnia również:

```cpp
size_t taskCount() const
```

czyli liczbę zadań oczekujących/obsługiwanych w kolejce.

Najnowsza dokumentacja biblioteki zaleca sprawdzanie poziomu kolejki przed dokładaniem kolejnych zapisów. W dyskusji autora biblioteki wskazano również domyślny limit kolejki dla ESP32 oraz koszt pamięci oczekujących zadań.

**Ważne zastrzeżenie:** w tym środowisku nie mam jeszcze lokalnie pobranego źródła dokładnie wersji `2.2.9`, więc nie zapisuję wartości limitu kolejki jako faktu dla obecnego buildu. Trzeba ją odczytać z faktycznie użytej paczki FirebaseClient.

### Decyzja

Telemetryka musi posiadać własną bramkę:

```text
czy WiFi?
↓
circuit breaker?
↓
worker zajęty?
↓
poziom AsyncClient queue?
↓
czy jest budżet iteracji?
↓
dopiero enqueue batch telemetryczny
```

Nie wolno robić bezwarunkowego `Database.*()` co 60 s.

---

## 14.6. Nie dodajemy kolejnego Firebase tasku

Pozostaje decyzja:

```text
1 x WiFiClientSecure
1 x AsyncClientClass
1 x FirebaseApp
1 x istniejąca ścieżka fbApp.loop()
```

Telemetryka korzysta z tego samego kanału co status/komendy.

Nie tworzymy:

```text
TelemetryFirebaseClient
TelemetryFirebaseTask
TelemetryFirebaseApp
```

Powodem nie jest tylko RAM. Drugi klient oznacza drugi model współbieżności, drugi SSL socket i nowy zestaw stanów reconnect/auth/error.

---

## 14.7. Najważniejsza decyzja dotycząca harmonogramu telemetryki

Po analizie `tgTaskFn()` nie rekomenduję dodania prostego trzeciego bloku:

```cpp
if (every 60s) {
    sendTelemetry();
}
```

za `checkFirebaseCommands()`.

Obecnie jedna iteracja może kolejno wykonać:

1. drenowanie kolejki Telegram,
2. alarmowe powiadomienia Telegram,
3. `sendStatusToFirebase()` — limit 6000 ms,
4. `checkFirebaseCommands()` — limit 5000 ms,
5. `fbApp.loop()`.

Kod już posiada `TG_ITER_BUDGET_MS=10000`, ale autor komentarza słusznie zauważa, że jest to bramka przed wejściem do funkcji, a pojedynczy call może sam przekroczyć resztę budżetu.

Dodanie trzeciej operacji sieciowej bez dodatkowej reguły ponownie otworzyłoby drogę do sumowania czasów.

### Zalecany model

W pierwszej wersji telemetryki obowiązuje:

```text
MAKSIMUM JEDEN NOWY REQUEST FIREBASE
NA ITERACJĘ tgTaskFn
```

czyli telemetryka jest konkurentem statusu/komendy, a nie trzecim obowiązkowym wywołaniem.

Priorytet:

```text
1. istniejące bezpieczeństwo/sterowanie
2. /piec/status
3. /piec/cmd
4. telemetryka 1m
5. pozostałe operacje niekrytyczne
```

Jeżeli w danej iteracji wykonano status albo command request, telemetryka może zostać odłożona bez utraty próbki, bo próbka pozostaje w `TelemetryRing`.

---

## 14.8. Dodatkowa korzyść ring buffer

Powyższa reguła jest bezpieczna właśnie dlatego, że telemetryka nie musi być wysłana natychmiast.

Przykład:

```text
T=12:00  sample #720
T=12:00  status request
T=12:00  telemetry -> NIE, odłożona
T=12:03  command request
T=12:03  telemetry -> NIE, odłożona
T=12:06  brak status/cmd -> batch telemetry
```

Dla pomiaru 1/min opóźnienie kilku minut jest normalnym zachowaniem i nie powinno wpływać na sterowanie piecem.

---

## 14.9. Batch jako jedna operacja Firebase

Dla wielu próbek preferowany jest jeden wielościeżkowy update rodzica telemetryki, np. logicznie:

```text
/piec/telemetry/1m/t<timestamp1>
/piec/telemetry/1m/t<timestamp2>
/piec/telemetry/1m/t<timestamp3>
...
```

zebrane w jednym `update<object_t>()`.

Firebase Realtime Database obsługuje wielościeżkowy update atomowo: wszystkie wskazane ścieżki są stosowane w ramach jednego PATCH/update.

To ogranicza liczbę requestów i dobrze pasuje do ring → batch → ack.

---

## 14.10. Semantyka ACK batcha

Pierwsza implementacja ma działać jako transakcja logiczna:

```text
ring
 ↓
peek N
 ↓
build batch
 ↓
Firebase update
 ↓
SUCCESS → usuń N z ring
FAIL/TIMEOUT → nie usuwaj N
```

Nie wolno usuwać elementów z ringa przed otrzymaniem potwierdzenia.

Dzięki deterministic key retry tej samej próbki zapisuje ją pod tą samą ścieżką, więc retry jest idempotentny.

---

## 14.11. Nie używać `String` w producerze

`historiaZapiszProbke()` pozostaje jedynym producentem telemetryki.

Producer:

```text
odczyt już istniejącego snapshotu
↓
TelemetrySample fixed-size
↓
krótka sekcja krytyczna
↓
ring write
```

Nie tworzymy JSON-a w tej części.

JSON powstaje dopiero przy pobieraniu batcha do wysyłki.

---

## 14.12. Diagnostyka telemetryki

Minimalny zestaw liczników:

```text
telemetry_sample_total
telemetry_ring_used
telemetry_ring_high_water
telemetry_ring_dropped
telemetry_batch_count
telemetry_batch_samples
telemetry_upload_success
telemetry_upload_fail
telemetry_upload_timeout
telemetry_upload_ms_max
telemetry_oldest_pending_ts
telemetry_newest_ts
firebase_queue_max_seen
firebase_telemetry_skip_budget
firebase_telemetry_skip_status
firebase_telemetry_skip_cmd
firebase_telemetry_skip_worker
```

Szczególnie ważny jest `telemetry_ring_dropped` — po restarcie nie może wyglądać jak normalne „0”, jeśli ring był pełny.

---

## 14.13. Proponowane API modułu telemetrycznego

To jeszcze NIE jest implementacja; to kontrakt do późniejszego kodowania.

```cpp
struct TelemetrySample;

bool telemetryInit();
bool telemetryPush(const TelemetrySample& sample);
size_t telemetryPending();
size_t telemetryPeek(TelemetrySample* out, size_t maxCount);
void telemetryCommit(size_t count);
void telemetryRollback(size_t count);
```

Dodatkowo osobna funkcja warstwy Firebase:

```cpp
bool telemetryTryUploadBatch(uint16_t maxSamples);
```

Ta funkcja nie ma prawa tworzyć własnego tasku.

---

## 14.14. `taskCount()` — zasada użycia

Jeżeli wersja FirebaseClient użyta w buildzie potwierdzi dostępność `taskCount()`, będziemy mierzyć:

```cpp
const size_t q = fbAsyncClient.taskCount();
```

przed enqueue telemetryki.

Nie ustawiam jeszcze konkretnego progu `q`, ponieważ powinien on wynikać z:

- faktycznego limitu biblioteki,
- ilości pamięci taska kolejki,
- obecnych status/cmd requestów,
- czasu ich kończenia.

Pierwszy eksperyment powinien mierzyć `q` w zdrowym firmware, zanim ustawimy twardy watermark.

---

## 14.15. R5 — decyzje zamknięte

**Zamknięte:**

- telemetryka korzysta ze wspólnego `AsyncClientClass`;
- nie ma osobnego Firebase tasku;
- nie ma drugiego `fbApp.loop()`;
- ring jest źródłem kolejki próbek;
- jedna iteracja `tgTaskFn` nie powinna inicjować więcej niż jednego nowego requestu Firebase;
- status/komendy mają pierwszeństwo nad telemetryką;
- telemetrykę można bezpiecznie odłożyć o kilka iteracji;
- batch ma być potwierdzany przed usunięciem próbek z ringa;
- retry używa deterministic timestamp key;
- `taskCount()` będzie wykorzystane po potwierdzeniu wersji API w faktycznej paczce.

## 14.16. R5 — otwarte

1. Faktyczny priorytet/stack `loopTask` w **wygenerowanym buildzie**, nie tylko w defaults.
2. Czy `fbLoopWork` na Core 1 powoduje mierzalne opóźnienia `loopTask` podczas timeoutów.
3. Dokładna wersja FirebaseClient w `.pio/libdeps` oraz domyślny `FIREBASE_ASYNC_QUEUE_LIMIT` tej wersji.
4. Minimalny i maksymalny bezpieczny batch telemetryki.
5. Czy bezpieczniejsza będzie migracja `fbLoopWork` na Core 0, czy obniżenie jego priorytetu — nie podejmujemy bez testu.

## 14.17. Nowa lista priorytetów

```text
P0.1  build truth / sdkconfig.<env>
P0.2  wersja esp_littlefs + FirebaseClient z realnego builda
P0.3  test wpływu fbLoopWork na loopTask Core 1
P0.4  naprawa FS snapshot/replace races
P0.5  pełne FS_USED/FREE + reserve
P0.6  bezpieczna archiwizacja coredump
P0.7  diagnostyka heap/PSRAM/stack/Firebase queue

P1.1  TelemetrySample
P1.2  TelemetryRing
P1.3  jeden-request-per-iteration gate
P1.4  batch update
P1.5  idempotent retry
P1.6  pomiary 1/5/10/20 próbek

P2    RTDB schema + time-range queries + app cache
P3    persistent offline spool
P4    security hardening
P5    niezależna aktualizacja FirebaseClient/toolchain
```

## 14.18. Źródła R5

- Arduino-ESP32 `Kconfig.projbuild`: https://github.com/espressif/arduino-esp32/blob/master/Kconfig.projbuild
- Arduino-ESP32 `cores/esp32/main.cpp`: https://github.com/espressif/arduino-esp32/blob/master/cores/esp32/main.cpp
- FirebaseClient `AsyncClientClass` docs: https://github.com/mobizt/FirebaseClient/blob/main/resources/docs/async_client.md
- FirebaseClient repository / working principle: https://github.com/mobizt/FirebaseClient
- FirebaseClient discussion on queue level and `taskCount()`: https://github.com/mobizt/FirebaseClient/discussions/330
- Firebase Realtime Database REST update/atomic multi-location update: https://firebase.google.com/docs/database/rest/save-data

---

# 15. R6 — PERSISTENT OFFLINE SPOOL, FLASH WEAR I ODBUDOWA PO RESTARTCIE (23.09.2026)

## 15.1. Cel

Zaprojektować przyszły spool telemetryczny tak, aby awaria zasilania, reset, pełny flash albo dłuższy brak internetu nie powodowały:

- utraty całego backlogu,
- konieczności przepisywania dużych fragmentów jednego pliku,
- niekontrolowanego zużycia flash,
- blokowania `loopTask`,
- pomieszania próbek z różnych okresów czasu.

Ten etap pozostaje P3 i **nie jest jeszcze implementowany**.

---

## 15.2. Aktualna konfiguracja LittleFS

W `sdkconfig.defaults` znaleziono:

```text
CONFIG_LITTLEFS_BLOCK_CYCLES=512
CONFIG_LITTLEFS_PAGE_SIZE=256
CONFIG_LITTLEFS_CACHE_SIZE=512
CONFIG_LITTLEFS_LOOKAHEAD_SIZE=128
CONFIG_LITTLEFS_READ_SIZE=128
CONFIG_LITTLEFS_WRITE_SIZE=128
CONFIG_LITTLEFS_USE_MTIME=y
```

To jest wartościowa informacja projektowa, ale nadal nie jest dowodem konfiguracji finalnego firmware — actual build truth pozostaje `sdkconfig.<env>`.

`BLOCK_CYCLES=512` należy traktować jako parametr mechanizmu wear-levelingu LittleFS, a **nie jako prostą gwarancję liczby zapisów całej partycji**.

---

## 15.3. Dlaczego jeden nieskończenie rosnący `telemetry.bin` jest złym pierwszym projektem

Pierwotnie kuszący model:

```text
telemetry.bin
[stare próbki][...][nowe próbki]
                     ↑ append
```

staje się problemem, kiedy najstarsze dane zostają potwierdzone przez Firebase.

Nie chcemy robić:

```text
ACK pierwszych 5000 próbek
↓
truncate początku
↓
przepisanie pozostałych 10000 próbek
```

bo oznacza to dodatkowy ruch flash i skomplikowaną operację podczas normalnej pracy.

---

## 15.4. Preferowany model — immutable pages

Rekomendowany model:

```text
/coredumps/                  ← osobny mechanizm
/telemetry_spool/
    page_000123.bin
    page_000124.bin
    page_000125.bin
```

Każda strona jest:

1. tworzona,
2. dopisywana tylko do przodu,
3. zamykana po osiągnięciu ustalonego rozmiaru albo przy kontrolowanym flushu,
4. po zamknięciu traktowana jako logicznie immutable,
5. wysyłana od najstarszej do najmłodszej,
6. kasowana dopiero po potwierdzeniu całej zawartości.

To eliminuje konieczność usuwania prefiksu jednego dużego pliku.

---

## 15.5. Rozmiar strony — jeszcze nie zamykamy

Sensowny zakres eksperymentalny:

```text
32 KiB
48 KiB
64 KiB
```

Ostateczna wartość ma wynikać z:

- rzeczywistego rozmiaru `TelemetrySample`,
- liczby próbek na batch Firebase,
- czasu zapisu do LittleFS,
- maksymalnego dopuszczalnego opóźnienia flushu,
- wymaganej długości offline backlogu.

Nie kopiujemy automatycznie rozmiaru partycji coredumpu 64 KiB — podobieństwo jest tylko praktyczne, nie architektoniczne.

---

## 15.6. Orientacyjne wymagania pojemności

Dla orientacyjnego `TelemetrySample` 32 B:

```text
1 minuta:       32 B
1 dzień:    46 080 B  (~45 KiB)
7 dni:     322 560 B  (~315 KiB)
30 dni:  1 382 400 B  (~1.32 MiB)
365 dni: 16 819 200 B (~16.0 MiB)
```

Dla 40 B:

```text
1 dzień:    57 600 B
7 dni:     403 200 B
30 dni:  1 728 000 B (~1.65 MiB)
365 dni: 21 024 000 B (~20.0 MiB)
```

To pokazuje ważną rzecz:

**persistent spool 7–30 dni jest technicznie możliwy na obecnej partycji, ale roczny spool lokalny nie jest.**

Te wartości są payload-only. Dochodzą nagłówki, CRC, metadane stron oraz inne pliki obecnego firmware.

---

## 15.7. Obecna partycja pozostawia ograniczony, ale użyteczny budżet

LittleFS ma:

```text
9.875 MiB
```

ale przed przyszłym spool'em już istnieją:

```text
coredumpy: maks. 1.25 MiB wg aktualnego limitu 20 × 64 KiB
hist_long: ~1.1 MiB wg komentarzy źródłowych
hist_short
logi
log_ustawien
panel_firmware.bin
```

oraz nieznany jeszcze rzeczywisty rozmiar zajęcia logów po długiej pracy.

Dlatego spool nie dostaje z góry całych pozostałych megabajtów.

Potrzebujemy polityki:

```text
FS total
- reserved for system/critical data
- current history/log budget
- coredump reserve
- panel firmware reserve
= telemetry spool quota
```

Dopiero rzeczywiste pomiary pozwolą ustawić liczbową wartość quota.

---

## 15.8. Odporność na power loss

Każda strona powinna mieć logiczny format z co najmniej:

```text
HEADER
    magic
    format_version
    page_sequence
    first_sample_sequence
    record_size
    record_count / capacity
    header_crc

RECORD × N
    sample sequence
    measurement timestamp
    TelemetrySample payload
    record_crc

FOOTER (po zamknięciu)
    committed marker
    last_sample_sequence
    record_count
    page_crc / footer_crc
```

Nie zakładamy, że ostatni `File.write()` albo zamknięcie pliku oznacza, że ostatnie bajty musiały fizycznie znaleźć się w flashu przed utratą zasilania.

Po restarcie:

```text
scan page
↓
check header
↓
scan records
↓
stop at first invalid/incomplete CRC
↓
use last known good record
↓
page marked open → recover/close or discard tail
```

To pozwala zaakceptować utratę co najwyżej ostatniego częściowo zapisanego fragmentu zamiast całego pliku.

---

## 15.9. Nie potrzebujemy flash-write na każdą minutę

Źródłem telemetryki jest RAM ring 1/min.

To daje rozdzielenie:

```text
sample cadence = 60 s

nie oznacza:

flash cadence = 60 s
```

W trybie online flash spool może nie być używany w ogóle.

W trybie offline można:

```text
ring
↓
krótki batch
↓
append do aktualnej page
```

co zmniejsza liczbę operacji flash w stosunku do zapisu każdej próbki osobno.

---

## 15.10. Offline nie powinien oznaczać „natychmiast zapisuj wszystko na flash”

Rekomendacja:

```text
WiFi zdrowe
    → PSRAM ring → Firebase

krótkotrwały brak WiFi
    → dalej gromadź w PSRAM

ring zbliża się do watermarku
    → zamień najstarsze próbki na page LittleFS

długi offline
    → utrzymuj page spool aż do quota

WiFi wraca
    → replay page oldest-first
```

To jest znacznie bezpieczniejsze od zapisywania każdej próbki na LittleFS tylko dlatego, że chwilowo zniknęła sieć.

---

## 15.11. Kolejność replay

Spool ma być wysyłany:

```text
najstarsza zamknięta page
        ↓
      batch
        ↓
Firebase ACK
        ↓
usuń page dopiero po potwierdzeniu jej całej zawartości
        ↓
następna page
```

Nie wolno usuwać strony po częściowym sukcesie pojedynczego requestu, jeżeli nie mamy wewnętrznego checkpointu dokładnie po potwierdzonym batchu.

Pierwsza wersja powinna celowo być prostsza:

```text
page = jednostka atomowego replay
```

Nowsza wersja może wprowadzić checkpoint wewnątrz page, jeśli testy wykażą potrzebę.

---

## 15.12. Chronologia i czas RTC/NTP

Istnieje istotny przypadek graniczny:

```text
czas poprawny
↓
telemetria ma epoch
↓
restart
↓
RTC/NTP jeszcze niezsynchronizowane
↓
czas = 0 / nieznany
```

Aktualny firmware już ma zasadę:

```text
czas_unix = 0
```

gdy czas nie jest wiarygodny.

Nie wolno wtedy generować fałszywego klucza Firebase udającego poprawny epoch.

Spool musi więc przechować **zarówno informację o czasie, jak i lokalną kolejność zapisu**.

Proponowany model:

```text
sample_sequence = monotoniczna kolejność lokalna
measurement_ts   = epoch lub 0
```

`sample_sequence` nie powinien być zapisywany do NVS co minutę — to niepotrzebny flash wear.

Po restarcie można odbudować kolejność z metadanych page/file sequence, a dla runtime PSRAM używać licznika RAM.

---

## 15.13. Problem korekty zegara

Nie zakładamy, że RTC/NTP nigdy nie cofnie zegara.

Przykład:

```text
12:00:00
12:01:00
12:02:00
NTP correction
11:59:50
```

Dlatego timestamp **nie powinien być jedynym kluczem wewnątrz spoola**.

Firebase nadal może mieć deterministic key oparty o czas dla normalnych próbek, ale lokalny spool potrzebuje osobnej kolejności/ID.

To chroni nas przed przypadkowym uznaniem dwóch różnych rekordów za ten sam tylko dlatego, że zegar wykonał korektę.

---

## 15.14. Quota behavior — musimy mieć jawny tryb degradacji

Jeżeli:

```text
LittleFS == quota telemetry spool
```

nie wolno kasować w ciemno:

```text
historia
coredump
log krytyczny
```

żeby zrobić miejsce telemetryce.

Priorytet danych:

```text
1. critical/system recovery
2. coredump
3. critical logs/settings
4. operational history
5. telemetry backlog
6. niekrytyczne duże artefakty
```

To jest opis priorytetu przechowywania danych, a nie kolejność kasowania wdrażana już teraz.

W pierwszej implementacji quota telemetryczna powinna po prostu zatrzymać dalsze odkładanie i zwiększyć licznik:

```text
telemetry_spool_dropped
```

zamiast ryzykować usuwanie innych danych.

---

## 15.15. Struktura katalogu

Nie mieszamy spoolu z logami:

```text
/telemetry_spool/
```

Każda page ma numer sekwencyjny, np.:

```text
page_00000001.bin
page_00000002.bin
...
```

Numer strony powinien być wyznaczany w sposób odporny na reset. Nie zakładamy po prostu `największy numer + 1`, jeśli katalog może zostać częściowo uszkodzony.

Do rozstrzygnięcia pozostaje, czy:

- numer page będzie częścią nagłówka + nazwy,
- czy dodatkowo będzie utrwalany mały indeks w NVS,
- czy boot scan katalogu zawsze wystarczy.

Preferowany jest wariant bez częstego NVS:

```text
katalog + nagłówki CRC = źródło prawdy
```

---

## 15.16. Wear test — wymagany przed P3

Test ma mierzyć nie tylko „czy działa”.

Potrzebujemy:

```text
1 h online
12 h online
24 h online
24 h offline
7 dni cyklu online/offline
power loss podczas write
power loss podczas page close
power loss podczas rename/create
power loss podczas replay
pełna quota
uszkodzony pierwszy rekord page
uszkodzony środek page
uszkodzony footer
```

Po każdym teście:

```text
liczba próbek wygenerowanych
liczba próbek odzyskanych
liczba wysłanych
liczba zdublowanych
liczba zgubionych
rozmiar FS
czas operacji FS
restart count
WDT count
```

---

## 15.17. R6 — decyzje zamknięte

- persistent spool pozostaje P3;
- nie projektujemy jednego stale przycinanego `telemetry.bin`;
- preferujemy immutable pages/files;
- page jest zamykana i później replayowana oldest-first;
- skasowanie page dopiero po potwierdzeniu całej jej zawartości;
- CRC nagłówka i rekordów jest wymagane;
- restart ma kończyć skan na pierwszym uszkodzonym/niepełnym rekordzie, nie odrzucać całego archiwum;
- telemetryka nie może przejąć miejsca z coredump/logów krytycznych bez jawnej polityki quota;
- online telemetryka nie wymaga ciągłych zapisów na LittleFS;
- brak wiarygodnego czasu jest legalnym stanem i nie może generować fałszywego epoch;
- timestamp nie może być jedyną lokalną kolejnością danych.

## 15.18. R6 — otwarte

1. finalny rozmiar `TelemetrySample`;
2. finalny rozmiar page;
3. finalna quota telemetryczna;
4. sposób indeksowania page po restarcie;
5. czy i jak utrwalać page sequence w NVS;
6. zachowanie `esp_littlefs` przy power loss na testowanym buildzie;
7. rzeczywisty czas zapisu batch/page;
8. rzeczywista pojemność pozostająca po logach/historii/coredumpach/panel firmware.

## 15.19. Status po R6

Architektura jest teraz rozdzielona na trzy poziomy:

```text
LEVEL 1 — normal online
sensor → PSRAM ring → Firebase

LEVEL 2 — chwilowy brak sieci
sensor → PSRAM ring

LEVEL 3 — długi offline / ring pressure
sensor → PSRAM ring → immutable LittleFS pages
                         ↓
                    replay oldest-first
```

To pozwala utrzymać prostą ścieżkę normalnej pracy i używać flash jako bufora awaryjnego, a nie jako głównego loggera telemetrycznego.

---

# 16. R7 — MODEL `TelemetrySample`: PRECYZJA, STALE VALUES I FLAGI WIARYGODNOŚCI (23.09.2026)

## 16.1. Źródło danych

Jedynym producentem nadal pozostaje `historiaZapiszProbke()`.

Obecny `HistoriaProbka` przechowuje 7 temperatur, pompę, ciśnienie, wilgotność, klapę, syberko i epoch.

Jednak `/api/status` ujawnia jeszcze:

```text
t_trociny
dym
dym_swiezy
dym_wlaczony
tryb_serwa
mieszadlo
rozpalanie
alarm_ogrzewanie
alarm_panel
pompa
```

Dlatego telemetryka nie powinna być mechaniczną kopią `HistoriaProbka`. Jest osobnym, kompaktowym modelem obserwacji urządzenia.

---

## 16.2. Problem ze specjalnymi wartościami

W kodzie występuje realna semantyka „ostatniej znanej wartości”. Przykład czujnika dymu:

```text
czujnikDymuOdczyt = poprzedniaWartoscCzujnikaDymu
czujnikDymuSwiezyOdczyt = false
```

w czasie, gdy czujnik jest nieaktywny, rozgrzewa się lub bieżący odczyt ADC jest nieważny.

Podobny problem trzeba przeanalizować dla temperatur DS18B20 i wilgotności DHT.

W szczególności **nie wolno stosować samego zakresu liczbowego jako flagi nieważności**.

Przykład:

```text
-1°C może być prawidłową temperaturą zewnętrzną
```

więc `-1` nie może być globalnym sentinel'em „brak danych”.

---

## 16.3. Dwa poziomy jakości danych

Proponuję rozróżnić:

```text
sensor_valid
    = wartość jest użyteczna / znana

sensor_fresh
    = wartość pochodzi z aktualnego cyklu pomiarowego
```

To pozwala reprezentować:

```text
valid=1, fresh=1
    → świeży poprawny pomiar

valid=1, fresh=0
    → ostatnia znana wartość, obecny cykl jej nie zmierzył

valid=0, fresh=0
    → brak wiarygodnej wartości
```

To jest ważniejsze niż oszczędzenie kilku bajtów rekordu.

---

## 16.4. Kandydat na kompaktowy rekord

Po analizie obecnych pól sensowny kandydat to około **36 B bez dodatkowego lokalnego sequence number**:

```cpp
struct TelemetrySample {
    uint32_t ts;              // epoch; 0 = brak wiarygodnego czasu

    int16_t  temp_x10[8];     // °C × 10
                              // zewn, bojler, ogrzewanie,
                              // ogrzewanie_sr, powrot, panel,
                              // pokoj, trociny

    uint16_t pressure_x10;    // hPa × 10
    uint16_t humidity_x10;    // % × 10
    uint16_t smoke_adc;       // 0..4095 wg obecnego kodu

    uint8_t  klapa_proc;      // 0..100/zakres rzeczywisty po konwersji
    uint8_t  syberko_proc;    // 0..100/zakres rzeczywisty po konwersji

    uint16_t state_flags;     // pompa, alarmy, tryb serwa itd.
    uint16_t sensor_valid;    // 1 bit / obserwowany kanał
    uint16_t sensor_fresh;    // 1 bit / obserwowany kanał
};
```

Przy naturalnym wyrównaniu struktury oczekiwany rozmiar to około 36 B; **rozmiar musi zostać sprawdzony przez `static_assert(sizeof(TelemetrySample) == ...)` po faktycznej definicji**.

---

## 16.5. Mapa 11 kanałów jakości

Pierwsza wersja może zarezerwować bity dla:

```text
0  t_zewn
1  t_bojler
2  t_ogrz
3  t_ogrz_sr
4  t_powrot
5  t_panel
6  t_pokoj
7  t_trociny
8  cisnienie
9  wilgotnosc
10 dym
```

Pozostałe bity pozostają zarezerwowane pod przyszłe kanały.

Nie próbujemy zakładać, że każdy kanał ma dokładnie tę samą semantykę świeżości.

---

## 16.6. Dlaczego skala ×10

Aktualna historia krótkoterminowa zapisuje temperatury z jedną cyfrą po przecinku.

Ciśnienie w historii również jest zapisywane z jedną cyfrą po przecinku.

Dlatego:

```text
int16 = wartość × 10
```

zachowuje obecną granularność bez używania 32-bitowych `float` w każdym polu.

Dla temperatur daje to szeroki zapas zakresu w stosunku do zastosowania centrali.

`humidity_x10` jest celowo nieco dokładniejszy niż obecny CSV/API, bo nie powiększa rekordu istotnie, a pozwala później analizować bez konieczności zmiany formatu.

---

## 16.7. Ciśnienie

Źródłem jest `cisnienieOdczytane`, które trafia do historii i `/api/status`.

W telemetryce proponuję:

```text
pressure_x10 = round(cisnienieOdczytane * 10)
```

ale dopiero po ustaleniu, czy aplikacja potrzebuje pełnej obecnej precyzji API (2 miejsca), czy wystarcza precyzja historii (1 miejsce).

Na dziś preferowana jest zgodność z historią, nie z surowym JSON-em statusu.

---

## 16.8. Czujnik dymu

Obecny kod dokumentuje zakres ADC:

```text
0..4095
```

oraz rozróżnia:

```text
dym_swiezy=true/false
czujnik aktywny temperaturowo / nieaktywny
```

W telemetrii zachowujemy:

```text
smoke_adc
sensor_valid bit DYM
sensor_fresh bit DYM
state_flag smoke-enabled
```

Dzięki temu wykres nie pomyli:

```text
wartość 700 zmierzona teraz
```

z:

```text
wartość 700 odziedziczona z poprzedniego pomiaru
```

---

## 16.9. Alarmy nie powinny być osobnymi rekordami co minutę

Stan alarmowy jest już częścią `state_flags`.

Kandydat:

```text
bit 0  pompa
bit 1  alarm CO
bit 2  alarm panelu
bit 3  alarm dymu
bit 4  czujnik dymu aktywny
bit 5  czujnik dymu ma świeży odczyt
bit 6-7 tryb serwa
bit 8  mieszadło aktywne
bit 9  rozpalanie aktywne
bit 10 pompa manual override
```

Nie zamykamy jeszcze dokładnej mapy bitów, ponieważ trzeba przejrzeć wszystkie stany sterownika pod kątem tego, czy są stanem „obserwowanym”, czy tylko chwilowym stanem implementacji.

---

## 16.10. Zdarzenia alarmowe — osobny kanał

Czasowa próbka 1/min pokazuje stan, ale nie zastępuje logu zdarzeń.

Docelowo rozdzielamy:

```text
/piec/telemetry/1m/...
    → pomiary okresowe

/piec/events/...
    → zmiany alarmów, restart, WDT, OTA, utrata/powrót WiFi,
      synchronizacja czasu, overflow telemetryki itd.
```

To pozwala nie zwiększać rozmiaru rekordu 1/min tylko dlatego, że chcemy znać dokładne momenty zdarzeń.

---

## 16.11. Event + telemetryka przy alarmie

Nie musimy wybierać tylko jednego.

Przy zmianie alarmu:

```text
event record
+
aktualna następna / ostatnia próbka okresowa
```

Event może zawierać snapshot najważniejszych wartości albo sequence wskazujący do telemetryki.

To jest przyszły etap P2/P3 — nie zmieniamy jeszcze istniejącej logiki alarmowej.

---

## 16.12. Sequence number

`TelemetrySample` nie musi zawierać trwałego sequence number.

W runtime może wystarczyć:

```text
TelemetrySample.ts
```

a dla persistent spool sequence można użyć wrappera:

```cpp
struct TelemetrySpoolRecord {
    uint64_t local_seq;
    TelemetrySample sample;
    uint32_t crc;
};
```

Jednak nawet ten wrapper pozostaje projektem do testu — 64-bitowy licznik nie musi być konieczny, jeśli page sequence + indeks rekordu zapewnią wystarczającą unikalność.

Najważniejsza zasada pozostaje:

**nie zapisujemy licznika sequence do NVS co minutę.**

---

## 16.13. Co zrobić z próbką bez czasu

Aktualny firmware świadomie używa:

```text
czas_unix = 0
```

gdy RTC/NTP nie jest wiarygodny.

Telemetry sample może więc istnieć z:

```text
ts = 0
sensor data = valid
```

Taka próbka nie może być automatycznie zapisana jako:

```text
1970-01-01...
```

ani pod sztucznym „teraz” serwera.

W persistent spool zachowujemy próbkę lokalnie. Po odzyskaniu czasu możemy wysłać ją tylko wtedy, gdy przyjmujemy jasno zdefiniowaną politykę dotyczącą jej rzeczywistego czasu pomiaru. Nie wolno przypisać jej fałszywego epoch bez dodatkowych informacji.

---

## 16.14. Wniosek dotyczący skali rekordu

Nawet jeśli finalny rekord urośnie z 32 B do 36–44 B, wpływ na pojemność jest mały w stosunku do obecnej partycji.

Dla 36 B:

```text
1 min:      36 B
1 dzień:    51 840 B
7 dni:     362 880 B
30 dni:  1 555 200 B
365 dni: 18 921 600 B
```

Najważniejsza nie jest więc minimalizacja każdego bajtu, ale zachowanie informacji o jakości pomiaru.

---

## 16.15. R7 — decyzje zamknięte

- `TelemetrySample` będzie osobnym typem, nie kopią istniejącego structu historii;
- telemetryka obejmie 8 temperatur, ciśnienie, wilgotność, ADC dymu, pozycje i flagi stanu;
- wartości numeryczne będą przechowywane kompaktowo, preferowane skale ×10 zamiast `float`;
- jakość pomiaru musi być reprezentowana osobno od samej wartości;
- `valid` i `fresh` są odrębnymi pojęciami;
- wartości `-1`, `0` itp. nie będą globalnymi sentinelami nieważności;
- alarmy okresowo trafią do `state_flags`, a zmiany alarmów docelowo również do `/events`;
- brak czasu (`ts=0`) jest prawidłowym stanem danych, a nie powodem do odrzucenia próbki;
- lokalna kolejność spoola nie będzie realizowana zapisem sequence do NVS co minutę.

## 16.16. R7 — otwarte

1. dokładna funkcja mapowania „fresh/valid” dla każdego z 11 kanałów;
2. finalna mapa `state_flags`;
3. dokładna precyzja ciśnienia wymagana przez aplikację;
4. `static_assert(sizeof(TelemetrySample))` po implementacji;
5. zasada obsługi próbek z `ts=0` po odzyskaniu czasu;
6. czy `local_seq` ma być 32/64-bit, czy wystarczy page+index.

---

# 17. R8 — MODEL RTDB, ZAPYTANIA CZASOWE, PARTYCJONOWANIE I RETENCJA (23.09.2026)

## 17.1. Cel

Wybrać strukturę Firebase Realtime Database, która pasuje do:

- 1 próbki/minutę;
- zakresowych wykresów w aplikacji;
- idempotentnego retry;
- przyszłej retencji;
- małego zużycia RAM centrali;
- prostych reguł Firebase;
- możliwości obsługi więcej niż jednego dnia danych bez ogromnego jednorazowego odczytu.

---

## 17.2. Nie pobieramy całej historii przy każdym wejściu do aplikacji

Dla 1-minutowej telemetrii:

```text
1 dzień     1 440 rekordów
7 dni      10 080 rekordów
30 dni     43 200 rekordów
365 dni   525 600 rekordów
```

Aplikacja powinna pobierać wyłącznie zakres potrzebny do aktualnego widoku i następnie trzymać lokalny cache.

Przykład:

```text
użytkownik otwiera wykres 24h
        ↓
pobierz tylko 24h
        ↓
SQLite/local cache
        ↓
zoom / scroll → korzysta z cache
```

Nie projektujemy aplikacji jako klienta, który przy każdym odświeżeniu pobiera rok danych.

---

## 17.3. Preferowany model: partycjonowanie po dniu

Robocza struktura:

```text
/piec/
    status
    cmd
    telemetry/
        1m/
            2026-09-23/
                t<timestamp>
                t<timestamp>
                ...
            2026-09-24/
                t<timestamp>
                ...
```

Dzień jest jednostką organizacyjną i retencyjną.

Korzyści:

```text
24h wykres
    → jeden mały węzeł dnia

7 dni
    → siedem niezależnych odczytów

retencja
    → dzień można usuwać jako całość

diagnostyka
    → uszkodzenie/konflikt jednego dnia nie miesza się z całością historii
```

Nie oznacza to, że Firebase traktuje dzień jak fizyczny plik — to wyłącznie organizacja drzewa danych.

---

## 17.4. Klucz rekordu

Preferowany:

```text
t<epoch>
```

np. logicznie:

```text
t1760000000
```

albo w przyszłości, gdy potrzebna będzie większa rozdzielczość:

```text
t<epoch_ms>
```

Klucz powinien mieć stałą długość w danym formacie, dzięki czemu porządek kluczy odpowiada porządkowi czasu.

Nie stosujemy Firebase push IDs dla okresowej próbki 1/min, ponieważ push ID rozwiązuje problem unikalności/chronologii generowanej przez klienta, którego tutaj nie potrzebujemy.

---

## 17.5. Zaleta `orderByKey`

Jeżeli timestamp jest częścią klucza, aplikacja może używać porządku klucza zamiast dodatkowego pola indeksowanego przez `.indexOn`.

Wariant:

```text
orderByKey()
startAt("t...")
endAt("t...")
```

jest prosty i naturalnie pasuje do danych już posortowanych po czasie.

To redukuje liczbę dodatkowych decyzji schematu względem modelu:

```text
record.ts
record.value...
```

z dodatkowym `orderByChild("ts")`.

Jeżeli finalny klient będzie potrzebował innych indeksów, dodamy je później świadomie.

---

## 17.6. `startAt` / `endAt`

Firebase RTDB obsługuje zapytania zakresowe z `startAt()` i `endAt()` oraz ograniczanie wyników.

Dzięki partycjonowaniu typowe zapytanie aplikacji staje się:

```text
każdy dzień z zakresu
    ↓
startAt(begin-of-day-range)
endAt(end-of-day-range)
    ↓
merge w aplikacji
```

W aplikacji można połączyć wyniki z kilku dni w jeden lokalny zakres.

---

## 17.7. Nie przenosimy agregacji godzinowej do centrali na siłę

Obecna `historiaDlugaBufor` ma zupełnie inną semantykę i jest historycznym mechanizmem UI.

Cloud telemetry nie musi kopiować jej formatu 35 kolumn.

Pierwsza wersja chmury:

```text
1m = surowy, skompaktowany snapshot
```

Aplikacja może z niego wyliczyć:

```text
5 min
15 min
1 h
1 dzień
```

na potrzeby wykresu.

Dopiero gdy pomiary produkcyjne pokażą, że pobieranie np. 90 dni × 1/min jest zbyt duże, wprowadzimy drugi model agregatów po stronie serwera.

---

## 17.8. Nie tworzymy jednocześnie `1m`, `5m`, `15m`, `1h`

Nie chcemy od początku utrzymywać:

```text
telemetry/1m
telemetry/5m
telemetry/15m
telemetry/1h
```

bo każde dodatkowe drzewo oznacza:

- kolejne zapisy;
- kolejne retry;
- więcej miejsca;
- dodatkową logikę spójności;
- dodatkowy model retencji.

Pierwsza wersja powinna mieć **jedną rozdzielczość źródłową**.

---

## 17.9. Payload dokumentu

Roboczo:

```json
{
  "t": 1760000000,
  "temp": {
    "zewn": 8.2,
    "bojler": 62.4,
    "ogrz": 71.1,
    "ogrz_sr": 69.8,
    "powrot": 48.2,
    "panel": 32.4,
    "pokoj": 21.4,
    "trociny": 74.7
  },
  "pressure": 1018.3,
  "humidity": 54.2,
  "smoke": 431,
  "klapa": 35,
  "syberko": 20,
  "state": 5,
  "valid": 2047,
  "fresh": 2043
}
```

To jest **reprezentacja logiczna**, nie format wire ustalony już na teraz.

Na centrali payload powinien być generowany z kompaktowego rekordu, bez wcześniejszego trzymania takiego JSON-a w każdej próbce.

---

## 17.10. Pole `t` a klucz timestamp

Można mieć jednocześnie:

```text
t<epoch>      ← klucz do kolejności/query
"t": epoch    ← wartość w rekordzie
```

Duplikacja jednego pola kosztuje kilka bajtów, ale upraszcza klienta i diagnostykę.

Alternatywnie można usunąć `t` z payloadu i używać wyłącznie klucza.

Do decyzji po testach API/app.

Preferencja: **na początek pozostawić `t` także w payloadzie**, bo ułatwia eksport danych oraz diagnostykę pojedynczego rekordu.

---

## 17.11. Sample bez wiarygodnego czasu

Nie wkładamy rekordów `ts=0` pod normalny klucz typu:

```text
t0000000000
```

ponieważ taki rekord wyglądałby jak realny początek epoki.

Roboczo:

```text
/piec/telemetry/unclocked/<boot>/<seq>
```

albo — jeszcze prościej w pierwszej wersji — próbka pozostaje wyłącznie w lokalnym buforze do czasu rozwiązania polityki czasu.

To jest otwarte, ale zasada jest zamknięta:

**brak czasu nie może zostać po cichu zamieniony na fałszywą datę.**

---

## 17.12. Problem zegara cofającego się

Jeżeli RTC/NTP skoryguje zegar wstecz, klucz timestamp może ponownie wystąpić.

Przy jednej próbce/minutę deterministic key ma dobrą własność idempotencji dla retry tej samej próbki, ale nie rozwiązuje automatycznie konfliktu dwóch różnych próbek o identycznym timestampie.

Dlatego potrzebujemy testu:

```text
normal clock
→ NTP sync
→ ręczna korekta / symulacja cofnięcia
→ kolejne próbki
```

Dopiero test określi, czy:

```text
timestamp-only key
```

jest wystarczający, czy potrzebny będzie suffix sequence.

Na dziś timestamp-only pozostaje preferowany ze względu na prostotę query.

---

## 17.13. Idempotencja retry

Dla zwykłego rekordu:

```text
timestamp = X
```

retry zapisuje dokładnie:

```text
/piec/telemetry/1m/YYYY-MM-DD/tX
```

a więc nie tworzy nowego dziecka.

Dla batcha logicznie:

```text
update {
    "1m/2026-09-23/tX": {...},
    "1m/2026-09-23/tY": {...},
    "1m/2026-09-23/tZ": {...}
}
```

To pasuje do wcześniej ustalonego modelu `ring → batch → ACK`.

---

## 17.14. Retencja — projektujemy dzień jako jednostkę kasowania

Jeżeli zostanie ustalona np. retencja N dni:

```text
najstarszy dzień poza N
    ↓
usuń jeden węzeł dnia
```

To jest prostsze niż usuwanie pojedynczych dzieci z jednego ogromnego węzła telemetrycznego.

Finalny mechanizm automatycznego usuwania wymaga oddzielnej decyzji, gdzie wykonywana jest polityka retencji:

```text
cloud/backend
albo
inne kontrolowane zadanie administracyjne
```

Nie chcemy implementować kasowania retencji w ESP32, ponieważ wtedy awaria/offline urządzenia mieszałaby transport z polityką przechowywania danych.

---

## 17.15. Jeden dzień jako naturalny rozmiar operacyjny

Dla 1/min jest:

```text
1 440 rekordów / dzień
```

Przy orientacyjnym payloadzie 36 B daje to około:

```text
51.8 KiB payloadu/dzień
```

bez narzutów JSON/RTDB.

To jest wygodna jednostka do:

- testów;
- eksportu;
- pobierania zakresowego;
- retencji;
- debugowania.

---

## 17.16. Koszt storage telemetryki względem obecnego statusu

Przy 36 B/sample:

```text
telemetry 1m:
~51.8 KiB/dzień
~1.48 MiB / 30 dni
~18.0 MiB / rok
```

To nadal nie obejmuje narzutów Firebase/JSON/TLS/billing.

Dla porównania obecny status sterownika jest wysyłany dużo częściej (około co 15 s) i według obecnego audytu ma około 650 B payloadu.

Wniosek projektowy:

**nie trzeba poświęcać informacji telemetrycznej tylko po to, żeby oszczędzić kilka bajtów w próbce.**

Największe oszczędności warto najpierw szukać w sposobie transportu i batchingu.

---

## 17.17. Batch i partycja dnia

Batch nie musi oznaczać jednego dnia.

W normalnym przypadku:

```text
batch samples
    ↓
wszystkie z bieżącej page/day
    ↓
jedno update
```

Przy granicy północy:

```text
... 23:59
00:00 ...
```

preferowane jest wykonanie dwóch logicznych grup update:

```text
day A
 day B
```

albo dwóch requestów, jeśli uprości to implementację.

Nie będziemy budować jednego wielkiego multi-location object przekraczającego dzień tylko dla oszczędzenia requestu.

---

## 17.18. Zasada dla aplikacji mobilnej

Repozytorium danych powinno udostępniać aplikacji:

```text
getTelemetry(rangeStart, rangeEnd)
```

a wewnątrz:

```text
split range → days
query each day
merge
sort by timestamp
cache
```

Aplikacja nie powinna wiedzieć, jak centrala buforuje dane w PSRAM/LittleFS.

To jest ważne rozdzielenie:

```text
ESP32 transport/storage
≠
app data repository
```

---

## 17.19. Eksport CSV

Przygotowanie danych do CSV powinno odbywać się poza firmware, np. w aplikacji/backendzie.

Nie tworzymy:

```text
Firebase payload → CSV string → LittleFS
```

na centrali.

Lokalne CSV pozostaje mechanizmem obecnej historii i diagnostyki.

Cloud telemetry jest osobnym źródłem danych.

---

## 17.20. Multi-device — nie zmieniamy teraz istniejących ścieżek

Obecny firmware używa:

```text
/piec/status
/piec/cmd
```

Nie robimy teraz migracji istniejącego API do:

```text
/devices/<id>/...
```

w ramach telemetryki, bo byłaby to osobna zmiana kompatybilności aplikacji i reguł bezpieczeństwa.

Jednocześnie przyszły model multi-device musi rezerwować przestrzeń na identyfikację urządzenia.

To trafia do P4/security + późniejszej migracji.

---

## 17.21. R8 — decyzje zamknięte

- podstawowa chmurowa rozdzielczość = 1 próbka/min;
- preferowane partycjonowanie po dniu;
- klucz rekordu zawiera timestamp;
- retry korzysta z deterministycznego klucza;
- query aplikacji jest zakresowe, nie „cała historia”;
- aplikacja ma lokalny cache/repository;
- nie utrzymujemy od razu wielu równoległych rozdzielczości (`1m/5m/15m/1h`);
- agregacja pozostaje na początku po stronie aplikacji;
- `ts=0` nie trafia pod fałszywy normalny epoch;
- retencja jest polityką backend/cloud, nie logiką sterownika;
- obecnych `/piec/status` i `/piec/cmd` nie migrujemy razem z telemetryką.

## 17.22. R8 — otwarte

1. timestamp seconds vs milliseconds;
2. finalny format klucza `t...`;
3. czy `t` powtarzać w payloadzie;
4. polityka dla `ts=0`;
5. dokładna polityka retencji;
6. finalny batch crossing midnight;
7. dokładna implementacja repository/cache w aplikacji;
8. czy przyszła multi-device migracja będzie wymagała nowego root path.

## 17.23. Źródła R8

- Firebase Realtime Database REST retrieve/query semantics: https://firebase.google.com/docs/database/rest/retrieve-data
- Firebase Realtime Database data structuring / denormalization: https://firebase.google.com/docs/database/web/structure-data
- Firebase Realtime Database indexing: https://firebase.google.com/docs/database/security/indexing-data
- Firebase Realtime Database limits: https://firebase.google.com/docs/database/usage/limits

---

# 18. R9 — START LITTLEFS, AUTOMATYCZNE FORMATOWANIE I DEFINICJA „REALNEJ” POJEMNOŚCI (23.09.2026)

## 18.1. Nowe odkrycie P0

W `setup()` obecny kod robi:

```cpp
if (!LittleFS.begin(false)) {
    if (LittleFS.begin(true)) {
        littlefsReady = true;
    }
}
```

Pierwsze `begin(false)` jest próbą zwykłego mountu bez formatowania.

Jeżeli mount się nie powiedzie, druga próba `begin(true)` wykonuje ścieżkę formatowania.

Kod sam opisuje to jako:

```text
„pierwszy mount nieudany, formatuje LittleFS (jednorazowo)”
```

To może być wygodne przy świeżej instalacji, ale w firmware działającym produkcyjnie jest bardzo niebezpieczne jako automatyczny fallback.

---

## 18.2. Dlaczego jest to szczególnie groźne dla telemetryki

Scenariusz:

```text
awaria / brownout / niepełny zapis / błąd mountu
            ↓
restart
            ↓
LittleFS.begin(false) → FAIL
            ↓
LittleFS.begin(true) → FORMAT
            ↓
spool telemetryczny znika
logi znikają
historia plikowa znika
coredumpy archiwalne znikają
```

Nawet jeśli bieżący coredump z poprzedniego crashu będzie później zapisany ponownie, **archiwum wcześniejszych dowodów może zostać skasowane**.

Dla systemu, którego celem jest diagnostyka awarii, jest to zbyt agresywna polityka recovery.

---

## 18.3. Zalecana zmiana semantyki

Rozdzielamy:

```text
mount
```

od:

```text
format
```

### Normalny boot

```text
LittleFS.begin(false)
```

Jeżeli działa:

```text
normalna praca
```

### Mount failure

Nie formatujemy automatycznie.

Zamiast tego:

```text
littlefsReady = false
fs_mount_error = true
log/telemetry spool nie dotykają partycji
system działa dalej w trybie ograniczonym
```

oraz zapisujemy diagnostykę poza LittleFS (Serial + RTC_NOINIT/NVS, zależnie od dostępnej ścieżki).

---

## 18.4. Kiedy format może być dozwolony

Format powinien być operacją **jawnie zatwierdzoną**, np.:

```text
factory reset

lub

pierwszy boot świeżego urządzenia

lub

celowa migracja filesystemu z rozpoznaną zmianą formatu
```

Nie powinien być uruchamiany tylko dlatego, że jedna próba mountu się nie udała.

---

## 18.5. Marker wersji filesystemu

Do rozważenia:

```text
NVS:
fs_format_version = X
```

ale marker nie powinien być jedynym dowodem poprawności FS.

Lepszy model:

```text
NVS / factory state
        ↓
czy format jest dozwolony?
        ↓
mount
        ↓
sprawdzenie obecności oczekiwanych plików/katalogów
        ↓
normalna praca
```

Przy zmianie schematu:

```text
old version
    ↓
kontrolowana migracja
    ↓
nowy version
```

a nie:

```text
mount fail → format
```

---

## 18.6. Coredump a kolejność startu

Obecna kolejność jest zasadniczo dobra z punktu widzenia diagnostyki:

```text
WDT
↓
LittleFS mount
↓
historia/log initialization
↓
rozpoznanie resetu
↓
archiwizacja coredumpu
↓
dalszy hardware setup
↓
taski
```

Najbardziej ryzykownym elementem jest więc nie samo położenie `archiwizujCoredumpJesliCrash()`, tylko fakt, że potencjalnie destrukcyjny `begin(true)` występuje **przed** archiwizacją.

Po zmianie polityki mount:

```text
mount fail
↓
NIE FORMATUJ
↓
archiwizacja coredumpu tylko jeśli FS rzeczywiście jest dostępny
↓
raport „coredump nie mógł zostać zapisany na FS”
```

Dodatkową kopią pozostają mechanizmy poza FS, które obecny kod już ma (RTC/diagnostic state/Serial).

---

## 18.7. „9.875 MiB” nie jest jeszcze realnym limitem danych użytkownika

`partitions.csv` określa rozmiar partycji:

```text
0x9E0000 = 10 354 688 B = 9.875 MiB
```

Ale firmware po mount wykonuje:

```cpp
g_logFsTotalBytes = LittleFS.totalBytes();
```

I właśnie ta wartość powinna być podstawą quota użytkownika.

Różnica:

```text
partition size
    ≠
usable LittleFS totalBytes()
```

Filesystem potrzebuje własnych struktur/metadanych i rzeczywista pojemność użytkowa może być mniejsza od surowego zakresu partycji.

Dlatego wcześniejsze wyliczenia 7/30 dni są **orientacyjnym sizingiem na podstawie rozmiaru partycji**, a nie gwarancją dostępnego miejsca dla plików.

Finalne quota muszą korzystać z runtime:

```text
LittleFS.totalBytes()
LittleFS.usedBytes()
```

plus zarezerwowanego headroomu.

---

## 18.8. Jedna metryka runtime do diagnostyki

Po mount powinno być logowane:

```text
fs_total = LittleFS.totalBytes()
fs_used  = LittleFS.usedBytes()
fs_free  = total - used
```

oraz:

```text
fs_quota_telemetry
fs_reserved_system
fs_reserved_coredump
fs_reserved_panel
```

W przyszłości aplikacja diagnostyczna może wyświetlać:

```text
FS: 37% użyte
telemetry spool: 4.2% quota
coredump reserve: 1.25 MB
```

zamiast tylko rozmiaru logów A+B.

---

## 18.9. Nie ufamy wyłącznie cache'om plików

Obecny kod utrzymuje wiele:

```text
g_logASize
g_logBSize
g_logKrytycznySize
g_logUstawienSize
g_histShortSize
g_histLongSize
g_panelFirmwareSize
```

To jest użyteczne do szybkich operacji per-file, ale nie może stać się jedynym źródłem prawdy o filesystemie.

Docelowo:

```text
LittleFS.usedBytes()
        ↓
real FS guard

File.size()
        ↓
diagnostyka/cache konkretnego pliku
```

Cache może być chwilowo nieaktualny; globalny limit filesystemu musi być liczony z rzeczywistego FS state albo świadomie synchronizowanego modelu transakcyjnego.

---

## 18.10. Recovery po mount failure

Jeżeli mount nie działa, firmware powinien nadal móc:

```text
sterować piecem

rejestrować reset/WDT w RTC_NOINIT

raportować błąd przez Serial

próbować sieci / Telegram wg polityki
```

ale nie powinien udawać:

```text
FS OK
telemetry persistent OK
```

W diagnostyce potrzebujemy jednoznacznego stanu:

```text
FS_MOUNT_OK
FS_MOUNT_FAIL
FS_FORMAT_REQUIRED
FS_QUOTA_CRITICAL
FS_IO_ERROR
```

---

## 18.11. R9 — decyzje zamknięte

- automatyczny `begin(true)` po mount failure jest uznany za P0 do zmiany przed persistent telemetry;
- mount i format muszą zostać rozdzielone semantycznie;
- normalny boot nie powinien kasować danych tylko dlatego, że mount raz się nie udał;
- finalne quota muszą opierać się na `LittleFS.totalBytes()/usedBytes()`, nie na samym rozmiarze partycji;
- cache rozmiaru plików ma być wtórny wobec realnego stanu filesystemu;
- stan FS musi być jawnie raportowany diagnostycznie;
- telemetry spool nie może zakładać, że 9.875 MiB z CSV to 9.875 MiB danych użytkownika.

## 18.12. R9 — otwarte

1. procedura jawnego formatowania po wdrożeniu;
2. marker/wersjonowanie formatu FS;
3. zachowanie firmware podczas mount failure przez dłuższy okres;
4. czy możliwe jest bezpieczne ponowienie mountu po kilku sekundach bez formatowania;
5. dokładna runtime wartość `LittleFS.totalBytes()` na urządzeniu.

---

# 19. R10 — WARSTWA EVENTÓW: CRASH, WDT, ALARMY, WIFI, OTA I DIAGNOSTYKA (23.09.2026)

## 19.1. Cel

Oddzielić dane ciągłe od zdarzeń:

```text
TELEMETRIA 1/min
    → pomiary do wykresów

EVENTS
    → momenty zmian i stany wyjątkowe

COREDUMP
    → binarny artefakt diagnostyczny

LOGI
    → lokalna historia/debug, nie ciągły strumień do RTDB
```

## 19.2. Obecna diagnostyka już dostarcza danych do eventu cloud

`CrashDiagState` zawiera m.in.:

```text
bootCounter
twdtIsrCount
TWDT current task/core names
op / stage / detail tasków
uptimeMs
seq
freeHeap
largestBlock
stackHwmWords
```

`CrashReportEntry` dodaje:

```text
resetReason
streak
previousBootCounter
coredumpSize
previousDiag
```

Nie trzeba więc wysyłać całego `log_a.txt` ani coredumpu do RTDB, aby mieć wartościowy ślad diagnostyczny.

## 19.3. Coredump nie należy do RTDB

RTDB dostaje metadata:

```text
reset_reason
boot
streak
coredump_size
coredump_available
```

Binarna zawartość dumpa pozostaje osobnym artefaktem. W przyszłości może dostać osobny transport obiektowy, ale nie dokładamy jej do time-series.

## 19.4. Event ID musi być deterministyczny

Roboczy kandydat:

```text
b<bootCounter>e<eventSeq>
```

Retry tego samego eventu używa tego samego klucza. To daje tę samą właściwość idempotencji, którą mamy dla telemetryki.

## 19.5. Zdarzenia, które warto rejestrować

Pierwszy backlog:

```text
boot
crash/panic
TASK_WDT
nieoczekiwany reset
LittleFS mount failure
LittleFS IO error
telemetry overflow
telemetry spool quota reached
WiFi lost/restored
Firebase timeout/circuit state
OTA start/success/failure
alarm CO on/off
alarm panel on/off
alarm smoke on/off
```

Nie wszystkie są częścią pierwszej implementacji. Lista definiuje model docelowy.

## 19.6. Nie streamujemy wszystkich logów

Obecne źródło ma dużo logów debugowych. Przesyłanie każdej linii do Firebase byłoby innym systemem niż telemetryka i mnożyłoby requesty oraz retry.

Zasada:

```text
DEBUG → lokalnie
INFO  → tylko wybrane zdarzenia
WARN/ERR/CRIT → event dla zdefiniowanych klas
```

Event jest semantycznym rekordem, nie kopią konsoli.

## 19.7. Konflikt z istniejącą CrashReportQueue

Obecna `rtcCrashReportQueue` jest konsumowana przez `wyslijZalegleRaportyCrash()`, a wpis jest usuwany po sukcesie Telegrama. Nie wolno wprowadzić drugiego konsumenta, który usuwa ten sam element po sukcesie Firebase.

Poprawny model wymaga jednego z dwóch wariantów:

```text
A) delivery flags:
   telegram_sent
   firebase_sent
   ↓
   usuń dopiero gdy oba kanały potwierdzone

B) osobne kolejki/kopie dla kanałów
```

Wariant A wymaga zmiany wersji struktur `RTC_NOINIT`, więc nie mieszamy go z pierwszym wdrożeniem telemetryki 1/min.

## 19.8. Event po restarcie

Po starcie już istnieją:

```text
esp_reset_reason()
rtcCrashStreak
previousDiag
coredumpSize
```

Możemy więc stworzyć cloud event typu `restart` albo `crash` bez dodatkowego odczytywania sprzętu.

## 19.9. Event + telemetryka

Przy zmianie alarmu nie trzeba zwiększać rekordu 1/min o duże pole tekstowe.

Lepsze rozdzielenie:

```text
telemetry → stan okresowy
event     → dokładny moment i przyczyna zmiany
```

W event można dodatkowo wstawić mały snapshot najważniejszych wartości albo sequence powiązanej próbki telemetrycznej.

## 19.10. Event upload też obowiązuje „one request per iteration”

Event nie jest wyjątkiem od ograniczeń Firebase. Musi korzystać z tej samej polityki co status/cmd/telemetryka:

```text
jedna nowa transakcja Firebase / iterację tgTaskFn
```

Priorytet eventu krytycznego może być wyższy od telemetryki okresowej, ponieważ telemetryka może poczekać, a event crash/WDT ma wartość diagnostyczną zaraz po odzyskaniu sieci.

## 19.11. R10 — decyzje zamknięte

- telemetryka i eventy są dwoma różnymi modelami danych;
- crash metadata może trafić do RTDB bez binary coredumpu;
- coredump pozostaje osobnym artefaktem;
- event ID ma być deterministic;
- nie streamujemy wszystkich logów;
- istniejąca `CrashReportQueue` nie może mieć dwóch niezależnych konsumentów usuwających te same rekordy;
- event upload dzieli tę samą bramkę requestów Firebase.

## 19.12. R10 — otwarte

1. finalny event schema;
2. osobna kolejka eventów vs delivery flags w CrashReportEntry;
3. kolejność priorytetów `crash/event/status/cmd/telemetry`;
4. sposób obsługi eventów bez wiarygodnego czasu;
5. późniejszy transport binary coredumpu.

---

# 20. R11 — AUTHENTICATION, TLS I GRANICE BEZPIECZEŃSTWA TELEMETRII (23.09.2026)

## 20.1. Stan obecny wykryty w źródle

Obecny Firebase używa:

```text
WiFiClientSecure
LegacyToken
Firebase Database Secret / legacy credential
fbSSLClient.setInsecure()
```

oraz ma statyczny fallback credential w firmware. Wartości sekretów nie są kopiowane do dokumentacji projektu.

To jest osobny problem hardeningu, nie część minimalnego wdrożenia telemetryki.

## 20.2. Najważniejsze rozdzielenie: TLS vs authentication

Są tu dwa niezależne mechanizmy:

```text
TLS verification
    → czy rozmawiamy z właściwym serwerem?

authentication/authorization
    → co dane urządzenie może czytać/zapisywać?
```

`setInsecure()` osłabia pierwszy poziom.

Legacy database secret / szerokie credential osłabia drugi poziom, bo pojedynczy sekret nie powinien być traktowany jako docelowa tożsamość urządzenia produkcyjnego.

Nie naprawiamy jednego przez drugi.

## 20.3. Dlaczego telemetryka pogarsza skutki błędu auth

Po dodaniu telemetryki zakres danych urządzenia rośnie z:

```text
status
command
```

do:

```text
status
command
telemetry history
events
```

Dlatego reguły Firebase muszą być projektowane przed uruchomieniem długiej historii cloud, jeśli dane mają być udostępniane innym użytkownikom/aplikacjom.

## 20.4. Docelowy model tożsamości

Roboczo preferowany jest model:

```text
device identity
        ↓
Firebase Auth identity
        ↓
RTDB rules ograniczające urządzenie do własnego namespace
```

np. logicznie:

```text
/devices/<deviceUid>/status
/devices/<deviceUid>/telemetry/1m/...
/devices/<deviceUid>/events/...
/devices/<deviceUid>/cmd/...
```

Nie wdrażamy tej migracji razem z pierwszym telemetry release, ponieważ zmienia istniejące `/piec/status` i `/piec/cmd` oraz wymaga migracji aplikacji.

## 20.5. Per-device credential

Nie chcemy jednego wspólnego sekretu dla wszystkich central.

Docelowo każda centrala powinna mieć własną tożsamość / credential, dzięki czemu kompromitacja jednego urządzenia nie daje automatycznie dostępu do wszystkich innych urządzeń.

Sposób provisioningu pozostaje otwarty:

```text
factory provisioning
local AP/setup
backend-issued short-lived credential
Firebase Auth user identity
```

Do wyboru po audycie aplikacji/backendu.

## 20.6. Command path ma większe znaczenie niż read-only telemetry

`/piec/cmd` steruje fizycznym urządzeniem.

Dlatego docelowa polityka bezpieczeństwa powinna rozdzielać:

```text
read telemetry
write telemetry (device only)
read/write status
write command
```

Urządzenie nie powinno przyjmować komend tylko dlatego, że credential jest ważny — rules/backend powinny dodatkowo ograniczać konkretną ścieżkę i operację.

## 20.7. TLS verification

Obecne:

```cpp
fbSSLClient.setInsecure();
```

Docelowo należy przejść na weryfikację certyfikatu serwera, np. przez odpowiedni CA/certificate bundle wspierany przez używaną wersję Arduino-ESP32.

Nie wpisujemy teraz konkretnego certyfikatu „na ślepo”, ponieważ rotacja CA/certyfikatu i wsparcie danej wersji frameworka muszą zostać sprawdzone dla faktycznego toolchainu.

## 20.8. Sekrety nie mogą zostać w fallbacku firmware

Current source zawiera credential fallback.

Docelowo:

```text
fallback development credential
        → USUNIĘTY z produkcji
```

oraz:

```text
sekret provisioningowy
        → indywidualny dla urządzenia
        → nie logowany
        → nie wysyłany w telemetry payload
```

## 20.9. Telemetry payload nie zawiera sekretów

Niezależnie od auth payload telemetryczny ma zakaz zawierania:

```text
WiFi password
Firebase secret/token
Telegram bot token
API credentials
private keys
```

Do eventów można zapisywać wyłącznie klasę błędu i identyfikator operacji.

## 20.10. Audit reguł przed produkcją

Przed otwarciem cloud telemetry dla aplikacji trzeba przetestować co najmniej:

```text
device A → own telemetry: ALLOW
device A → device B telemetry: DENY
app user → allowed device read: ALLOW
app user → other device read: DENY
app user → telemetry write: DENY
unauthorized command: DENY
device → own command result/status as intended
```

To jest test logiczny rules, nie test firmware.

## 20.11. R11 — decyzje zamknięte

- security hardening jest osobną fazą;
- TLS verification i authentication traktujemy jako dwa różne mechanizmy;
- nie zwiększamy uprawnień credential tylko po to, by dodać telemetrykę;
- docelowo tożsamość ma być per-device;
- command path wymaga ostrzejszej kontroli niż zwykłe dane telemetryczne;
- sekrety nie trafiają do telemetry/event payload;
- migracja auth nie jest częścią pierwszego telemetry commit.

## 20.12. R11 — otwarte

1. docelowy mechanizm Firebase Auth;
2. provisioning per-device credential;
3. CA/certificate strategy dla Arduino-ESP32 3.3.x;
4. finalny namespace multi-device;
5. migracja `/piec/status` i `/piec/cmd`;
6. test rules przed produkcją.

---

# 21. R12 — MATRYCA TESTÓW, GATE'Y RELEASE I KRYTERIA „PASS” (23.09.2026)

## 21.1. Cel

Telemetryka nie może być uznana za gotową tylko dlatego, że:

```text
firmware się kompiluje
Firebase dostał jeden rekord
```

Potrzebujemy dowodu działania w warunkach normalnych, błędów sieci, timeoutów, restartów i pełnego filesystemu.

---

## 21.2. Gate 0 — baseline bez telemetryki

Przed pierwszą zmianą funkcjonalną zachować artefakty:

```text
main source SHA256
platformio.ini SHA256
partitions.csv SHA256
board JSON SHA256
sdkconfig.defaults SHA256
firmware ELF
firmware BIN
sdkconfig.<env>
```

oraz log startowy:

```text
WDT config
PSRAM status
LittleFS total/used
firmware version
Firebase init status
WiFi status
```

**PASS:** istniejący firmware działa bez zmian w zachowaniu.

---

## 21.3. Gate 1 — build truth

Musimy zamknąć:

```text
Arduino-ESP32 exact version
ESP-IDF exact version
esp_littlefs exact version
FirebaseClient exact version
actual sdkconfig
actual partition table
```

**PASS:** żadna decyzja P0 nie opiera się wyłącznie na `sdkconfig.defaults`.

---

## 21.4. Gate 2 — filesystem

Testy:

```text
normal mount
restart
power loss podczas flush
power loss podczas rename
multiple writers
HTTP read while write
Telegram read while write
pełny/niemal pełny FS
mount failure bez automatycznego formatowania
```

**PASS:** brak utraty istniejących danych przy nieoczekiwanym mount/IO failure, poza dokładnie zdefiniowaną tolerancją ostatniego niezatwierdzonego fragmentu.

---

## 21.5. Gate 3 — coredump

Celowo wywołany crash:

```text
crash
↓
reboot
↓
image_check
↓
archive
↓
verify file size
↓
parse ELF
```

Powtórzyć przy różnej liczbie tasków i w warunkach zajętego FS.

**PASS:** źródłowy coredump nigdy nie jest kasowany przed udanym, zweryfikowanym archiwizowaniem.

---

## 21.6. Gate 4 — TelemetrySample

Test statyczny:

```cpp
static_assert(sizeof(TelemetrySample) == EXPECTED);
```

Test logiczny:

```text
normal values
negative temperature
max position
0 pressure/humidity where legitimate
invalid sensor
stale sensor
smoke disabled
smoke fresh
alarm on/off
```

**PASS:** wartości nie są mylone z sentinelami błędu.

---

## 21.7. Gate 5 — ring buffer

Test na urządzeniu:

```text
push 1
push N
peek N
commit N
rollback N
wrap-around
full
overflow
producer/consumer interleave
```

Pomiar:

```text
czas push
czas peek
czas commit
critical-section duration
PSRAM free before/after
```

**PASS:** brak `String`, malloc/free i blokujących operacji w producerze.

---

## 21.8. Gate 6 — Firebase queue

W normalnej pracy monitorować:

```text
taskCount()
batch size
upload duration
queue max
retry count
```

Wymusić:

```text
status + command + telemetry due w tej samej iteracji
Firebase timeout
worker occupied
network disconnect
server Connection: close
```

**PASS:** telemetryka odracza się bez utraty danych i nie tworzy drugiego `fbApp.loop()`.

---

## 21.9. Gate 7 — timing i loopTask

To jest krytyczny test obecnej architektury:

```text
fbLoopWork Core 1 / priority 1
loopTask   Core 1 / priority 1
```

Podczas sztucznego timeoutu mierzyć:

```text
max loop gap
max scheduler gap
FB worker duration
control jitter
WDT events
```

**PASS:** opóźnienie sterowania mieści się w ustalonej granicy bezpieczeństwa systemu.

Jeżeli nie, kolejny krok to osobny eksperyment:

```text
worker Core 0
vs
worker priority change
```

Nigdy nie testujemy obu zmian naraz.

---

## 21.10. Gate 8 — batch sizing

Testować minimum:

```text
1 sample
5 samples
10 samples
20 samples
```

Dla każdego:

```text
payload bytes
JSON build time
Firebase request duration
peak DRAM
peak PSRAM
queue impact
WDT margin
```

**PASS:** wybór batch size wynika z pomiaru, nie z arbitralnej liczby.

---

## 21.11. Gate 9 — online soak

Minimalny test:

```text
24 h
48 h
```

Dłuższy test docelowy:

```text
7 dni
```

Monitorować:

```text
restarts
WDT
heap minimum
largest heap block
PSRAM minimum
stack HWM
Firebase queue HWM
ring high-water
telemetry drops
FS used
FS free
```

**PASS:** brak trendu degradacji pamięci i brak nieoczekiwanego wzrostu kolejki/spoola.

---

## 21.12. Gate 10 — offline soak

Wymusić brak sieci:

```text
15 min
1 h
6 h
24 h
7 dni — docelowo
```

Sprawdzić:

```text
ring occupancy
spool pages
FS quota
log rotation
history writes
WDT
```

Po powrocie sieci:

```text
oldest-first replay
no duplicate logical events
no missing acknowledged samples
normal telemetry resumes
```

---

## 21.13. Gate 11 — power loss

Power cut w losowych punktach:

```text
during sample push
during JSON build
during Firebase request
during spool write
during page close
during file create/rename
during replay
```

Po każdym restarcie automatycznie sprawdzić:

```text
page CRC
record CRC
last sequence
number generated
number recovered
number uploaded
```

**PASS:** uszkodzenie ostatniej operacji nie niszczy poprzednio zatwierdzonych danych.

---

## 21.14. Gate 12 — FS quota

Doprowadzić FS do:

```text
70%
80%
90%
95%
critical
```

Sprawdzić, że kolejność ochrony działa zgodnie z projektem:

```text
coredump/critical data protected
telemetry spool stops at quota
no silent destructive delete
status reports FS state
```

---

## 21.15. Gate 13 — RTDB integration

Sprawdzić:

```text
one sample
batch same day
batch crossing midnight
time range query
retry same batch
duplicate same key
ts=0 policy
clock rollback
```

**PASS:** retry nie tworzy logicznych duplikatów, a zapytania zwracają kompletny zakres.

---

## 21.16. Gate 14 — app integration

Aplikacja musi testować:

```text
24h
7d
30d
empty range
missing day
partial day
invalid/stale sensor
alarm event
```

**PASS:** repozytorium aplikacji nie zależy od sposobu buforowania telemetryki w ESP32.

---

## 21.17. Gate 15 — security

Przed produkcją:

```text
TLS verification
auth rules
device isolation
command authorization
secret rotation
no credentials in logs
no credentials in telemetry
```

**PASS:** urządzenie nie wymaga produkcyjnego database-wide secret hardcoded w firmware.

---

## 21.18. Final release checklist

Release telemetryki może zostać oznaczony jako gotowy dopiero, gdy:

```text
[ ] build truth captured
[ ] FS mount safe
[ ] coredump safe
[ ] TelemetrySample static_assert
[ ] ring tests PASS
[ ] Firebase one-request gate PASS
[ ] loopTask timing PASS
[ ] batch size measured
[ ] 48h soak PASS
[ ] offline replay PASS
[ ] power-loss tests PASS
[ ] FS quota PASS
[ ] RTDB range/retry PASS
[ ] app cache PASS
[ ] security review PASS
```

---

## 21.19. R12 — najważniejsza zasada

Każda zmiana ma przechodzić przez: 

```text
CODE
 ↓
BUILD
 ↓
UNIT / LOCAL TEST
 ↓
DEVICE TEST
 ↓
FAULT INJECTION
 ↓
SOAK
 ↓
REVIEW
 ↓
NEXT CHANGE
```

Nie robimy jednego dużego „telemetry commit”, który jednocześnie zmienia toolchain, auth, FS, Firebase i aplikację.

## 21.20. Stan całego research planu po R12

```text
P0  build truth / FS / coredump / timing
P1  ring + telemetry transport
P2  RTDB + app repository/cache + events
P3  persistent spool
P4  security/auth/TLS + multi-device migration
P5  niezależny upgrade toolchain/FirebaseClient
```

Każdy z tych poziomów ma już zdefiniowane ryzyka i osobny zakres testów.



## 21.21. R13 — scheduler, jitter próbkowania i brak catch-up

### Źródło
Audyt `main_centrala (3).cpp`, sekcje schedulera, `historiaZapiszProbke()` i `loop()`.

### Ustalenia
Scheduler jest prostą pętlą `millis()` wykonywaną z `loop()`:

```text
loop()
  -> wykonajZaplanowaneZadania()
  -> wifiLoop()
```

Dla każdego zadania warunek ma postać:

```cpp
teraz - ostatnieWywolanie >= interwalMs
```

Po spełnieniu warunku kod **najpierw** ustawia:

```cpp
ostatnieWywolanie = teraz;
```

a dopiero potem wykonuje funkcję zadania.

### Konsekwencja 1 — brak catch-up
Jeżeli `loopTask` zostanie zablokowany przez 8 minut, a zadanie ma interwał 60 s, po odzyskaniu sterowania zadanie nie wykona ośmiu zaległych próbek. Wykona tylko jedną próbkę, a następny termin będzie liczony od chwili wykonania testu schedulera.

Dlatego lokalna historia i przyszła telemetria **nie mogą obiecywać regularnej osi czasu na podstawie samego interwału zadania**.

### Konsekwencja 2 — opóźnienie zadania nie przesuwa się bez końca
Ponieważ `ostatnieWywolanie` jest ustawiane przed wywołaniem funkcji, długie wykonanie samej funkcji nie powoduje natychmiastowego „nadrobienia” kolejnego uruchomienia. To stabilizuje scheduler, ale również oznacza, że rzeczywisty okres może być większy od konfiguracji 60 s.

### Konsekwencja 3 — wiele zadań jest wykonywanych serialnie
W jednym przebiegu `wykonajZaplanowaneZadania()` wszystkie zadania, które są zaległe w kolejności slotów, mogą zostać wykonane jedno po drugim. W obecnym firmware są to zarówno zadania szybkie (20–50–112 ms), jak i zadania mogące wykonywać I/O/czujniki.

To wzmacnia wcześniejszy wniosek: telemetria nie może być kolejnym blokującym etapem schedulera.

### Konsekwencja 4 — pierwsza próbka
Wszystkie zadania są dodawane z:

```cpp
ostatnieWywolanie = 0
```

więc zadanie `historiaZapiszProbke` spełnia warunek już przy pierwszym odpowiednio działającym przebiegu schedulera. Oznacza to, że pierwsza próbka historii nie jest automatycznie próbką „po pełnych 60 sekundach”.

### Decyzja telemetryczna
`TelemetrySample` powinien mieć dwa niezależne pojęcia czasu:

```text
wall-clock timestamp — do zapytań RTDB i wykresów
monotonic/sample sequence — do diagnostyki odstępów i restartów
```

Minimalnie proponujemy:

```text
boot_counter
sample_seq
sample_ts
```

`sample_seq` rośnie dla każdej utworzonej próbki i resetuje się wraz z nowym bootem tylko wtedy, gdy to uprości implementację; lepszym wariantem jest para `boot_counter + sample_seq`, która jednoznacznie opisuje kolejność próbek w obrębie urządzenia.

Dodatkowo przy każdym zapisie warto policzyć lokalnie:

```text
sample_delta_ms = mono_now - previous_sample_mono
```

Nie musi to trafiać do każdego rekordu RTDB; wystarczy jako metryka diagnostyczna i materiał do eventu przy dużej dziurze.

### Reguła wykrywania dziur
Nie będziemy tworzyć sztucznych próbek, aby „wypełnić” okres, w którym `loopTask` nie działał.

Zamiast tego:

```text
rzeczywista próbka
      ↓
rzeczywisty timestamp
      ↓
seq
      ↓
jeżeli delta przekracza próg → event GAP / SCHEDULER_DELAY
```

To zachowuje prawdę pomiarową. Sztuczne kopiowanie poprzedniej temperatury dawałoby fałszywe dane.

### Test R13
Do testów urządzenia dodać pomiar:

```text
sample_count
sample_delta_min
sample_delta_max
sample_delta_p50
sample_delta_p95
sample_delta_p99
scheduler_late_ms
```

przynajmniej dla soaków 24 h / 48 h.

**PASS:** telemetria zawiera tylko realnie wykonane próbki; brak mechanizmu catch-up tworzącego fikcyjne dane; duże przerwy są wykrywalne diagnostycznie.

### Status R13
```text
DONE — mechanizm schedulera poznany wystarczająco do projektu telemetryki.
OPEN — dokładny próg GAP/SCHEDULER_DELAY ustalimy po pomiarach na sprzęcie.
```


## 21.22. R14 — wiarygodność zegara: RTC/NTP i ponowna walidacja

### Źródło
Audyt `main_centrala (3).cpp`, `pobierzCzas()`, `RTC()`, `zadanieSyncNTP()` i `historiaZapiszProbke()`.

### Ustalenia
Firmware ma trzy logiczne stany źródła czasu:

```text
1. fizyczny RTC (DS1307) — g_rtcGotowy
2. systemowy zegar zsynchronizowany przez NTP — g_rtcNtpZsynchronizowany
3. brak wiarygodnego czasu — DateTime(0) / czas_unix = 0
```

`historiaZapiszProbke()` już poprawnie nie zapisuje pozornego czasu, gdy oba źródła są niedostępne:

```cpp
p.czas_unix = (g_rtcGotowy || g_rtcNtpZsynchronizowany) ? now.unixtime() : 0;
```

To jest dobry wzorzec do zachowania w telemetrii.

### Znalezione ograniczenie
`g_rtcGotowy` jest ustawiane podczas `setup()` na wynik inicjalizacji RTC i w całym pliku nie ma późniejszego przypisania `false` po uruchomieniu.

W konsekwencji bieżąca implementacja **nie ma mechanizmu ponownej walidacji fizycznego RTC po starcie**. Jeżeli urządzenie wystartuje z prawidłowym RTC, późniejsze problemy komunikacyjne z układem są poza zakresem obecnej flagi `g_rtcGotowy`.

Nie wyciągamy z samego kodu wniosku, jaki dokładnie będzie zwrócony czas przy każdej możliwej awarii DS1307 — to wymaga testu sprzętowego. Stwierdzony fakt jest węższy: kod telemetryczny nie może traktować `g_rtcGotowy=true` jako wiecznej gwarancji świeżego odczytu I2C.

### NTP
`zadanieSyncNTP()`:

```text
co 5 s sprawdza możliwość pierwszej synchronizacji
po udanym sync czeka RTC_NTP_RESYNC_MS = 24 h
po sync z NTP, jeżeli RTC jest dostępny, wykonuje Zegar.adjust(...)
```

Na płytce bez sprawnego RTC `pobierzCzas()` może użyć systemowego czasu NTP przez `getLocalTime()`.

### Ważna konsekwencja dla kluczy RTDB
NTP może skorygować czas. Nie możemy więc projektować idempotencji tak, jakby `epoch` był niezmiennym numerem sekwencyjnym.

Jeżeli kluczem rekordu będzie wyłącznie:

```text
t<epoch_seconds>
```

to korekta zegara może teoretycznie spowodować kolizję z wcześniejszym rekordem o tym samym timestampie albo rekordy w kolejności innej niż kolejność fizycznego pomiaru.

### Decyzja projektowa
Rozdzielamy:

```text
IDENTITY / IDEMPOTENCE
    boot_counter + sample_seq

CZAS POMIARU
    sample_ts

JAKOŚĆ CZASU
    time_source / time_valid
```

Pierwsza wersja może nadal używać dziennego katalogu RTDB, np.:

```text
/piec/telemetry/1m/YYYY-MM-DD/<record_id>
```

ale `record_id` nie powinien zależeć wyłącznie od zegara.

Przykładowy model:

```text
record_id = b<boot>_s<seq>
{
  "ts": 1770000000,
  "time_source": "RTC",
  ...
}
```

Wtedy zapytania aplikacji wykonujemy po polu `ts`, a nie po alfabetycznym kluczu rekordu. To wymaga odpowiedniego `.indexOn` dla `ts` na poziomie właściwej gałęzi RTDB.

### Status czasu
Proponowany enum:

```text
0 = UNKNOWN
1 = RTC
2 = NTP
```

Nie będziemy wyliczać `RTC` tylko dlatego, że `g_rtcGotowy` jest `true`, jeżeli w kolejnych testach sprzętowych okaże się, że potrzebna jest rzeczywista walidacja odczytu. Na ten moment jest to wyłącznie stan deklarowany przez istniejący firmware.

### Test R14
Testy:

```text
A — boot z poprawnym RTC
B — boot bez RTC + późniejszy NTP
C — boot bez sieci i bez RTC
D — restart po utracie NTP
E — korekta NTP do przodu
F — korekta NTP do tyłu
G — przekroczenie północy podczas pracy
H — długotrwała praca z RTC + dobowa resynchronizacja
```

Sprawdzić:

```text
czy nie powstają duplikaty record_id
czy seq pozostaje rosnący
czy ts może iść chwilowo wstecz
czy aplikacja umie sortować po ts
czy brak czasu nie tworzy rekordów z epoką 0 jako pozornie poprawnych
```

**PASS:** identyfikator rekordu jest niezależny od korekty zegara, a `ts=0/UNKNOWN` nigdy nie jest przedstawiane aplikacji jako prawidłowa data 1970/2000.

### Status R14
```text
DONE — zasady wiarygodności czasu określone.
OPEN — zachowanie DS1307 przy awarii po starcie wymaga testu sprzętowego.
OPEN — ostateczny format record_id wybierzemy po R15 (model zapytań RTDB).
```


## 21.23. R15 — ACK, timeout i własność danych requestu Firebase

### Źródło
Audyt bieżącej implementacji `fbCzekajImpl()`, `sendStatusToFirebase()` oraz istniejącego modelu `AsyncResult` w `main_centrala (3).cpp`, uzupełniony dokumentacją FirebaseClient dotyczącą kolejki zadań asynchronicznych.

### Ustalenia
Obecny status korzysta z następującego modelu:

```text
build payload
  ↓
object_t
  ↓
Database.set()
  ↓
fbCzekajNaWynikZLimitem()
  ↓
AsyncResult
  ├── isError()  → porażka
  ├── isResult() → ACK/sukces
  └── brak obu   → lokalny timeout
```

Dla telemetryki zachowujemy dokładnie tę semantykę:

```text
PUSH/UPDATE wysłane ≠ próbka potwierdzona

dopiero isResult() → commit batchu z ringa
```

### Krytyczne rozróżnienie
`fbCzekajImpl()` ma zewnętrzny limit. Po jego przekroczeniu funkcja wywołująca może wrócić do schedulera, ale worker `fbLoopWork` może jeszcze żyć i kontynuować `fbApp.loop()` do swojego wewnętrznego limitu.

Kod celowo oznacza taki worker jako `porzucony`, a `fbLoopWorkerZajety` pozostaje aktywne aż worker sam skończy. To jest poprawne jako strażnik przed drugim równoległym `fbApp.loop()`.

### Konsekwencja dla telemetryki
Nie wolno przyjąć:

```text
timeout → request anulowany
```

Prawidłowy model jest:

```text
czas zewnętrzny minął
      ↓
TG nie czeka dalej
      ↓
worker nadal kończy kontrolowane okno
      ↓
Firebase pozostaje zablokowany dla kolejnych operacji
      ↓
telemetry batch NIE jest commitowany
      ↓
ring pozostaje nietknięty
```

To chroni przed utratą próbek, ale oznacza też, że po timeoutcie nie możemy natychmiast próbować kolejnego batchu.

### Własność bufora requestu
Obecny `sendStatusToFirebase()` tworzy `object_t` i bufor JSON lokalnie, następnie uruchamia request i czeka. Po powrocie zwalnia bufor PSRAM.

Dla telemetryki nie zakładamy z góry, że `Database.update()` skopiuje wszystkie dane dokładnie w momencie wywołania. Implementacja ma być zbudowana tak, aby:

```text
payload/object_t żył co najmniej do zakończenia kontrolowanego oczekiwania
```

a w przypadku timeoutu lifetime danych musi być zweryfikowany testem z realnym opóźnieniem sieciowym.

Nie należy zwalniać pamięci zarezerwowanej wyłącznie dla telemetrycznego requestu „na ślepo” w chwili zewnętrznego timeoutu, dopóki nie potwierdzimy własności danych przez używaną wersję FirebaseClient.

### Decyzja
W pierwszej implementacji uploader telemetryki będzie miał jawny obiekt stanu:

```text
TelemetryUploadState
  batch_first_seq
  batch_count
  payload_buffer
  request_started_ms
  waiting_for_ack
  timed_out
```

Ring nie przesunie `tail` przed `isResult()`.

### Model commit/rollback

```text
PEEK N rekordów
     ↓
budowa batchu
     ↓
Database.update()
     ↓
┌───────────────┬──────────────────┐
│ isResult()    │ error/timeout    │
│               │                  │
│ commit tail   │ tail bez zmian   │
│ N rekordów    │ retry później    │
└───────────────┴──────────────────┘
```

Jeżeli request zakończy się timeoutem, ale Firebase faktycznie przyjął dane, ponowienie ma być bezpieczne dzięki deterministycznemu `record_id`.

### Ważna decyzja: idempotencja ponad „exactly once”
Nie będziemy próbować uzyskać nierealistycznego modelu `exactly once` na poziomie transportu.

Model docelowy:

```text
at-least-once delivery
+
deterministic record_id
+
idempotent overwrite/update
```

Wtedy awaria pomiędzy serwerem a lokalnym ACK może spowodować retransmisję, ale nie powinna utworzyć drugiej logicznej próbki.

### Test R15
Fault injection:

```text
1. opóźnij odpowiedź Firebase > limit zewnętrzny
2. pozwól workerowi dokończyć
3. sprawdź taskCount()/worker state
4. sprawdź, czy ring nadal ma batch
5. pozwól na kolejny retry
6. sprawdź RTDB pod kątem duplikatu
7. powtórz przy zerwaniu TCP w różnych momentach
```

Dodatkowo test pamięci:

```text
przed requestem
po request success
po error
po timeout
po porzuconym workerze
```

### PASS R15
```text
- brak utraty batchu po timeout
- brak równoległego fbApp.loop()
- retry po timeout jest możliwy
- retransmisja nie tworzy logicznych duplikatów
- brak wycieku PSRAM/DRAM po 1000 kolejnych prób
```

### Status R15
```text
DONE — semantyka ACK/timeout przyjęta do projektu.
OPEN — zachowanie lifetime payloadu w dokładnej wersji FirebaseClient używanej w środowisku musi być potwierdzone testem runtime.
```


## 21.24. R16 — świeżość i pochodzenie wartości pomiarowych

### Źródło
Audyt `Czujnik_DS()`, `odczytajTemperature()`, `cisnienie()`, `wilgotnosc()` i `pozar()` w `main_centrala (3).cpp`.

### Ustalenia
Próbka telemetryczna powstaje co nominalnie 60 s, ale dane wejściowe mają różne częstotliwości i różne mechanizmy fallbacku.

| Kanał | Źródło | Nominalne odświeżanie | Zachowanie przy błędzie |
|---|---|---:|---|
| temperatury DS18B20 | `Czujnik_DS()` | 2816 ms | filtr trzyma ostatnią dobrą wartość albo `-1` bez historii |
| ciśnienie | `cisnienie()` | scheduler 5000 ms | zachowuje ostatnią wartość, jeśli nowy `readPressure()` da `NaN` |
| wilgotność | `wilgotnosc()` | scheduler 3000 ms | po błędzie DHT używa poprzedniej wartości |
| dym | `pozar()` | scheduler 4992 ms | w wielu fazach celowo pozostaje ostatnia wartość + `dym_swiezy=false` |
| pozycje klapy/syberka | stan aktuatorów | znacznie częściej niż 60 s | stan bieżący |
| pompa | stan logiczny/przekaźnik | znacznie częściej niż 60 s | stan bieżący |

### Najważniejsze odkrycie
Dla części kanałów wartość przechowywana w zmiennej globalnej może być prawidłową „ostatnią znaną wartością”, ale **nie musi być świeżym pomiarem wykonanym w tej samej chwili co próbka telemetryczna**.

Najbardziej jawny przykład jest już w kodzie dla dymu:

```text
dym = ostatnia wartość
swiezy = false
```

Dla DS18B20, ciśnienia i wilgotności informacja o świeżości nie jest natomiast wystarczająco reprezentowana w obecnych globalnych zmiennych.

### Ryzyko dla chmury
Jeżeli telemetryka wyśle:

```json
{"cisnienie": 1.42}
```

bez informacji o świeżości, aplikacja może uznać, że `1.42` zostało zmierzone dokładnie w czasie `ts` próbki, mimo że kod mógł właśnie wykorzystać wartość z wcześniejszego udanego pomiaru.

To jest różnica między:

```text
measurement value
```

a:

```text
last known value
```

Nie wolno jej zatracić przy projektowaniu warstwy telemetrycznej.

### Decyzja
Nie będziemy wysyłać osobnego timestampu dla każdego czujnika w każdym rekordzie — byłoby to niepotrzebnie duże.

Zamiast tego w firmware dodamy lokalne znaczniki ostatniego poprawnego odczytu:

```text
last_ok_ms[CHANNEL]
```

lub równoważny mechanizm o mniejszym koszcie RAM.

Przy tworzeniu próbki:

```text
age = monotonic_now - last_ok_ms[channel]
```

oraz wynikową klasyfikację:

```text
VALID + FRESH
VALID + STALE
INVALID / UNKNOWN
```

### Dlaczego nie wystarczy jedna globalna flaga
Kanały mają różne cykle i różne naturalne opóźnienia:

```text
DS18B20  ~2.8 s
DHT      ~3 s
BMP      ~5 s
MQ/dym   stanowo + rozgrzewanie + duty cycle
```

Jeden wspólny próg „świeże = młodsze niż X sekund” nie jest dobrym modelem, zwłaszcza dla czujnika dymu pracującego celowo w cyklu OFF/stabilizacja/ADC.

### Pierwsza wersja reprezentacji
Pozostaje mały bitmapowy model:

```text
sensor_valid_bits
sensor_fresh_bits
```

Dla przykładowych 11 kanałów daje to po 2 bajty na grupę.

Semantyka:

```text
valid=1 fresh=1 -> wartość jest świeża i poprawna
valid=1 fresh=0 -> wartość jest poprawna, ale ostatnia znana
valid=0          -> brak wiarygodnej wartości
```

Jeżeli kanał nie ma jeszcze żadnego udanego pomiaru, nie będziemy używać arbitralnej wartości liczbowej jako substytutu „braku danych”.

### Uwaga o filtrze DS18B20
`odczytajTemperature()` ma własny filtr wiarygodności i może zwrócić `ostatniaDobra`, gdy bieżący surowy odczyt został odrzucony.

To oznacza, że przy telemetryce:

```text
wartość zwrócona przez odczytajTemperature()
```

jest wartością używaną przez sterowanie, ale jej świeżość musi być oceniona niezależnie od tego, czy liczba wygląda rozsądnie.

Nie należy ustawiać `fresh=true` tylko dlatego, że funkcja zwróciła liczbę.

### Uwaga o wilgotności
`wilgotnosc()` po błędzie DHT podstawia poprzednią wartość do `wilgotnoscOdczytanaLok`, więc telemetryka może otrzymać poprawnie wyglądającą liczbę bez świeżego odczytu DHT.

Dodatkowo funkcja liczy wilgotność skorygowaną na podstawie temperatury zewnętrznej. Ta temperatura również może być wartością ostatnią dobrą po filtrze DS18B20.

Dlatego nie wolno utożsamiać:

```text
wilgotnoscOdczytana != NaN
```

z:

```text
DHT22 odpowiedział w tym cyklu
```

### Decyzja dla aplikacji
Aplikacja nie powinna rysować wartości `STALE` identycznie jak `FRESH` bez możliwości rozróżnienia. Najlepiej przechowywać stan jakości w modelu domenowym i używać go w wykresach/diagnostyce.

Na pierwszym etapie nie trzeba zmieniać sposobu prezentacji — wystarczy, że dane w chmurze zachowają informację potrzebną do takiej prezentacji w przyszłości.

### Test R16
Dla każdego kanału wymusić:

```text
1. poprawny pomiar
2. zatrzymanie/błąd źródła
3. kilka kolejnych próbek telemetrycznych
4. ponowny poprawny pomiar
```

Sprawdzić, czy otrzymamy:

```text
FRESH → STALE → FRESH
```

a nie:

```text
FRESH → FRESH → FRESH
```

przy tej samej wartości trzymanej w globalnej zmiennej.

**PASS:** aplikacja może odróżnić „zmierzone teraz” od „ostatnia znana wartość”. Żadna awaria czujnika nie jest maskowana przez samą obecność liczby.

### Status R16
```text
DONE — potrzeba reprezentacji świeżości i validity potwierdzona.
OPEN — dokładne progi STALE dla poszczególnych kanałów ustalić na podstawie ich cykli i zachowania sprzętu.
OPEN — implementację timestampów last_ok_ms zaprojektować tak, aby nie dokładała blokad ani alokacji do ścieżki 60-sekundowej.
```


## 21.25. R17 — kodowanie danych telemetrycznych i wersjonowanie schematu

### Cel
Ustalić format rekordu, który jest:

```text
mały
jednoznaczny
bez NaN/Infinity
łatwy do walidacji
stabilny dla aplikacji
możliwy do rozszerzania bez migracji całej historii
```

### Problem z kopiowaniem statusu
Obecny `/piec/status` jest tworzony jako JSON tekstowy przez wiele konkatenacji `String` i zawiera wartości bieżącego stanu.

Nie chcemy skopiować tego formatu 1:1 do każdego rekordu telemetrycznego, ponieważ status ma inny cel:

```text
status = aktualny snapshot urządzenia
telemetry = seria obserwacji w czasie
```

### Decyzja: integer scaling dla pomiarów
Dla wielkości fizycznych preferowany jest zapis skalowany:

```text
temperatura -> temp_x10
ciśnienie   -> pressure_x10
wilgotność  -> humidity_x10
```

Przykład:

```text
23.7 °C -> 237
1.42    -> 14  (jeżeli jednostką bazową pozostaje bar i skala x10)
56.0 %  -> 560
```

Jednostki muszą być zapisane jawnie w kontrakcie schematu. Nie wolno zakładać jednostki na podstawie nazwy `pressure` czy `temp`.

### Dlaczego nie float/NaN
W obecnym kodzie istnieją miejsca, w których czujnik może tymczasowo dać `NaN`, po czym kod zatrzymuje ostatnią dobrą wartość. Telemetria nie powinna wysyłać:

```json
{"humidity": NaN}
```

ani używać tekstowych sentinelów typu:

```text
-999
-9999
```

jako uniwersalnego znaczenia „brak danych”.

Brak wartości ma być opisany bitmapą `valid`/`fresh`, a liczba może pozostać wartością ostatnią znaną, gdy taki stan jest celowy.

### Proponowany model pól
Wewnętrzny `TelemetrySample` pozostaje zwarty, np.:

```text
uint32_t boot_counter
uint32_t sample_seq
uint32_t ts

int16_t  temp_x10[8]
uint16_t pressure_x10
uint16_t humidity_x10
uint16_t smoke_adc

uint8_t  klapa_proc
uint8_t  syberko_proc
uint16_t state_flags
uint16_t sensor_valid_bits
uint16_t sensor_fresh_bits

uint8_t  schema_version
uint8_t  time_source
```

Dokładny layout i `sizeof()` pozostają do zatwierdzenia po kompilacji; każda zmiana musi mieć `static_assert`.

### JSON w RTDB
Na przewodzie rekord może wyglądać logicznie jak:

```json
{
  "v": 1,
  "seq": 1234,
  "ts": 1770000000,
  "time": 1,
  "t": [237, 721, 64, 61, 520, 310, 226, 703],
  "p": 14,
  "h": 560,
  "sm": 421,
  "k": 50,
  "s": 90,
  "st": 3,
  "ok": 2047,
  "fr": 2046
}
```

Są to na razie **nazwy projektowe**, nie finalny kontrakt API.

### Decyzja: krótka nazwa pola jest dopuszczalna
Ponieważ rekordów mogą być setki tysięcy, redukcja nazw z:

```text
boiler_temperature
outside_temperature
pressure
humidity
```

do:

```text
t
p
h
```

może oszczędzać znaczącą ilość transferu i pamięci po stronie serwera.

Warunek: aplikacja musi mieć centralny mapper/DTO i jawny dokument schematu. Nie dopuszczamy sytuacji, w której skrót `p` raz znaczy pressure, a po zmianie firmware power.

### Wersjonowanie
Każdy rekord powinien mieć:

```text
v = schema_version
```

Wersję zwiększamy, gdy zmienia się znaczenie, jednostka lub struktura pola w sposób niekompatybilny.

Dodanie opcjonalnego pola może pozostać w tej samej wersji, jeżeli stary klient nadal poprawnie interpretuje rekord bez tego pola.

### Nie mieszamy wersji w jednym batchu bez potrzeby
Uploader powinien budować batch z rekordów jednej wersji schematu. Ponieważ ring powstaje w jednym firmware, normalna praca będzie spełniała ten warunek automatycznie.

Przy OTA granica wersji jest naturalnie widoczna przez `v`.

### Uwaga o jednostkach
Obecny kod ma przykłady, w których nazwa zmiennej nie jest najlepszym kontraktem jednostki, np. `cisnienieOdczytane` powstaje z:

```cpp
bmp.readPressure() / 100 + 18
```

Dlatego dokument telemetryczny musi jawnie podać:

```text
pressure_x10: bar * 10
```

lub faktyczną jednostkę, po potwierdzeniu źródłowej skali.

Nie będziemy „zgadywać” jednostki na podstawie nazwy.

### Kompatybilność aplikacji
Repozytorium danych aplikacji powinno mieć dekoder:

```text
schema v1 -> model domenowy
schema v2 -> model domenowy
...
```

oraz ignorować nieznane pola. Nie może być wymogu aktualizacji aplikacji dokładnie w tej samej sekundzie co OTA centrali, chyba że zmiana jest jawnie oznaczona jako niekompatybilna.

### Test R17

```text
1. firmware v1 zapisuje 100 próbek
2. OTA do v2 dodaje nowe pole
3. v2 zapisuje kolejne 100 próbek
4. aplikacja czyta zakres obejmujący oba formaty
5. urządzenie wraca do offline/retry
6. wykonuje batch mieszczący się w granicy przejścia
```

Sprawdzić:

```text
czy v1 jest nadal czytelne
czy v2 jest czytelne
czy brak pola opcjonalnego nie powoduje błędu
czy zmiana jednostki zwiększa wersję
czy żaden rekord nie zawiera NaN/Infinity
```

**PASS:** schema jest jawny, wartości numeryczne są bezpieczne do JSON/RTDB, aplikacja rozumie co najmniej dwa kolejne schematy podczas migracji OTA.

### Status R17
```text
DONE — kierunek kodowania i wersjonowania przyjęty.
OPEN — finalne skróty pól i jednostki zatwierdzić w kontrakcie RTDB przed implementacją.
OPEN — potwierdzić faktyczną jednostkę `cisnienieOdczytane` na podstawie biblioteki BMP280 i obecnej matematyki sterownika.
```


## 21.26. R18 — spójność snapshotu między rdzeniami

### Źródło
Audyt współdzielonych zmiennych w `main_centrala (3).cpp`, schedulera Core 1, `fbLoopWork`/Telegram Core 0 oraz callbacków `AsyncWebServer`.

### Ustalenia
`historiaZapiszProbke()` wykonuje większość odczytu źródłowych wartości w jednym miejscu na Core 1. To jest korzystne, bo wszystkie wartości temperatur DS18B20 są aktualizowane przez `Czujnik_DS()` również na ścieżce schedulera.

Jednak część stanu może być ustawiana z innych kontekstów. Przykład bezpośrednio potwierdzony w kodzie:

```text
/api/mieszadlo-manual
    ↓
callback AsyncWebServer
    ↓
digitalWrite(...)
    ↓
mieszadloAktywnyStan = true/false
```

Podobny model występuje dla komend obsługujących stan pompy i docelowe ustawienia serw.

### Ryzyko
Telemetryka odczytująca kolejno:

```text
pompa
klapa
syberko
mieszadlo
alarmy
tryb
```

nie gwarantuje formalnie, że wszystkie pola opisują identyczną chwilę logiczną, jeżeli któreś z nich zostanie zmienione przez drugi kontekst w trakcie budowania snapshotu.

Nie oznacza to automatycznie błędu na poziomie fizycznego ESP32 dla pojedynczych wyrównań pamięci — problemem projektowym jest brak wspólnego kontraktu atomowego dla całego snapshotu.

### Najważniejsze rozróżnienie
Chcemy mieć:

```text
SNAPSHOT CONTROL
= stan zaobserwowany przez sterowanie w jednym przebiegu

SNAPSHOT TELEMETRY
= kopia tego stanu przeznaczona do zapisania
```

Nie chcemy blokować całej logiki centrali mutexem tylko po to, żeby telemetryka skopiowała kilkanaście pól.

### Decyzja — nie robimy globalnego mutexa na cały model
Na pierwszym etapie preferowany jest model:

```text
1. odczyt źródeł do lokalnego TelemetrySample
2. bardzo krótka sekcja dla pól wymagających wspólnego locka, tylko jeżeli istnieje już naturalny mutex
3. koniec snapshotu
4. ring / JSON / FS poza sekcją krytyczną
```

Nie będziemy obejmować:

```text
String
LittleFS
Firebase
formatowania JSON
```

żadnym lockiem snapshotowym.

### Preferencja dla istniejących źródeł prawdy
Dla pompy obecna funkcja:

```cpp
pompaJestWlaczona()
```

czyta bezpośrednio stan wyjścia, więc jest lepszym źródłem bieżącego stanu niż duplikowana globalna flaga. To podejście należy zachować.

Dla temperatur DS18B20 źródłem pozostają wartości przefiltrowane przez `odczytajTemperature()`.

Dla dymu koniecznie zachowujemy osobno:

```text
dym

dym_fresh
```

a nie tylko liczbę ADC.

### Potencjalna sekwencja snapshotu

```text
historiaZapiszProbke()
        │
        ├─ pobierz czas
        ├─ pobierz temperatury
        ├─ pobierz pressure/humidity + freshness
        ├─ pobierz dym + freshness
        ├─ pobierz stan pompy/serw/alarmów
        │
        └─ TelemetrySample gotowy
                 ↓
          zero dalszych odczytów globalnych
```

To jest istotne: po utworzeniu `TelemetrySample` uploader nie powinien wracać do globalnych zmiennych po kilku sekundach. Zapisuje dokładnie snapshot, który został utworzony.

### Czy potrzebny jest sequence lock?
Na obecnym etapie — **nie jako warunek startowy**.

Jeżeli testy pokażą, że potrzebujemy formalnie atomowego zestawu pól zmienianych z kilku tasków, wtedy można wprowadzić mały version counter/seqlock dla wybranych grup stanu.

Nie chcemy wprowadzać go prewencyjnie do kilkudziesięciu miejsc kodu, ponieważ zwiększyłoby to promień zmiany i utrudniło walidację sterownika.

### Test R18
Test z szybkim przełączaniem:

```text
pompa ON/OFF w pobliżu czasu próbki
serwo zmiana pozycji w pobliżu czasu próbki
alarm ON/OFF w pobliżu czasu próbki
mieszadło ON/OFF w pobliżu czasu próbki
```

Równocześnie:

```text
generować telemetrykę
wysyłać status
obsługiwać HTTP/Firebase commands
```

Następnie porównać rekord telemetryczny z logiem zdarzeń.

### PASS R18
```text
- rekord przedstawia spójny logicznie snapshot
- nie występują niemożliwe kombinacje stanów
- uploader nie czyta ponownie globali po utworzeniu próbki
- brak długiego mutexa obejmującego FS/Firebase
```

### Status R18
```text
DONE — granica między capture i transportem ustalona.
OPEN — lista dokładnych pól wymagających locka zależy od finalnego `TelemetrySample` i zostanie zamknięta przed implementacją.
```


## 21.27. R19 — budżet sieciowy i liczba requestów

### Źródło
Parametry istniejącego firmware oraz wyliczenia na podstawie kodu:

```text
FB status interval = 15 s
FB command polling = 7 s
telemetry sample = 60 s nominalnie
```

Status ma około 650 B payloadu w obecnym kodzie.

### Wyliczenie requestów
Przy ciągłej pracy 24 h:

```text
status:
86400 / 15 = 5760 requestów/dobę

polling komend:
86400 / 7 ≈ 12343 cykle GET/dobę

telemetry:
86400 / 60 = 1440 próbek/dobę
```

Jeżeli telemetryka będzie grupowała 10 próbek/request:

```text
1440 / 10 = 144 requesty/dobę
```

Przy 20 próbkach/request:

```text
1440 / 20 = 72 requesty/dobę
```

### Najważniejszy wniosek
Koszt telemetryki nie powinien być liczony tylko przez:

```text
liczba bajtów na próbkę
```

Trzeba liczyć jednocześnie:

```text
request count
payload bytes
czas TLS/TCP
czas `fbApp.loop()`
ilość oczekujących tasków AsyncClient
wpływ na Core 1 / loopTask
```

Obecny polling Firebase komend jest już znacznie częstszy niż potrzebowałaby sama telemetria.

### Decyzja: telemetryka ma być batchowana od początku
Nie wdrażamy wariantu:

```text
1 próbka = 1 request
```

Przy takim modelu mielibyśmy dodatkowe:

```text
1440 requestów/dobę
```

czyli ponad 10 razy więcej requestów niż przy batchu 10.

Pierwszy zakres testowy:

```text
N = 5
N = 10
N = 20
```

Bez założenia z góry, który wariant wygra.

### Decyzja: batch ma ustępować status/command
Priorytet sieciowy:

```text
1. operacje bezpieczeństwa / wymagane sterowanie
2. status
3. command polling
4. telemetry backlog
5. opcjonalne dane pomocnicze
```

W praktyce status i komendy są już częścią jednej ścieżki Firebase, więc telemetryka dostaje **jedno dodatkowe okno**, a nie własny niezależny harmonogram sieciowy.

### Backlog nie może powodować burstu bez limitu
Po 6 godzinach offline telemetryka może mieć około:

```text
6 * 60 = 360 próbek
```

Po 24 h:

```text
1440 próbek
```

Po odzyskaniu Wi-Fi nie wolno wykonać:

```text
for (wszystkie zaległe próbki)
    update();
```

bez ograniczeń.

Potrzebny jest budżet:

```text
max telemetry requests / iteration
max samples / request
max telemetry time / TG iteration
max telemetry bytes / request
```

### Ochrona przed „catch-up storm”
Po powrocie sieci uploader powinien działać stopniowo:

```text
status/command
    ↓
telemetry batch
    ↓
krótki yield
    ↓
ponowna iteracja
    ↓
kolejny batch
```

Nie budujemy osobnego wątku, który opróżnia cały ring tak szybko, jak tylko może.

### Priorytet świeżych danych
Przy backlogu nie ma sensu wybierać losowych rekordów. Ring/spool ma pracować FIFO:

```text
najstarsza próbka → najpierw
najmłodsza próbka  → później
```

Dzięki temu aplikacja odzyskuje pełną oś czasu bez dziur powodowanych przez wybieranie tylko najnowszych rekordów.

### Konflikt status vs telemetry
Istniejący kod ma udokumentowany przypadek, w którym status i GET/DELETE komendy mogą wystąpić w tej samej iteracji i sumarycznie zbliżyć się do granicy WDT.

Dlatego telemetryka nie może działać według zasady:

```text
jeśli due -> zawsze wyślij
```

Musi mieć:

```text
tryTelemetry()
    -> sprawdź budżet
    -> sprawdź worker busy
    -> sprawdź circuit breaker
    -> sprawdź taskCount/queue
    -> dopiero wtedy jeden batch
```

### Metryki do pomiaru
Dodać:

```text
telemetry_requests
telemetry_batches
telemetry_samples_sent
telemetry_samples_retried
telemetry_samples_dropped
telemetry_bytes
telemetry_max_request_ms
telemetry_avg_request_ms
telemetry_backlog_peak
firebase_queue_peak
```

oraz korelację z:

```text
loop scheduler gap
WDT
free heap / largest block
PSRAM free / largest block
```

### Test R19
Dla każdej wielkości batchu:

```text
5 / 10 / 20
```

wykonać:

```text
normalna sieć
Wi-Fi RTT/latencja podwyższona
chwilowy brak sieci
pełna utrata sieci 1 h
pełna utrata sieci 24 h
powrót sieci
```

Mierzyć czas pełnego opróżnienia backlogu i wpływ na loopTask.

### PASS R19
```text
- telemetryka nie zwiększa liczby Firebase requestów liniowo do liczby próbek
- brak burstu po powrocie sieci
- brak blokowania status/command
- brak wzrostu queue ponad ustalony limit
- brak WDT podczas opróżniania backlogu
```

### Status R19
```text
DONE — budżet requestów określony.
OPEN — końcowy batch size ustalić pomiarami.
OPEN — maksymalny czas telemetryki w iteracji TG dopasować do rzeczywistych czasów status/command.
```


## 21.28. R20 — utrata danych zależnie od rodzaju awarii

### Źródło
Audyt `RTC_NOINIT_ATTR`, `rtcCrashReportQueue`, `TelemetryRing` (planowany), LittleFS i bieżącego przepływu coredump/boot.

### Ustalenia
Bieżąca diagnostyka wykorzystuje `RTC_NOINIT_ATTR` do przechowania części informacji przez zwykłe restarty programu:

```text
soft reset
watchdog
panic
esp_restart()
```

ale sam kod jednoznacznie zaznacza, że pamięć RTC nie jest trwała po prawdziwym odcięciu zasilania.

To ma bezpośrednie znaczenie dla telemetryki.

### Macierz niezawodności

| Zdarzenie | PSRAM ring | RTC_NOINIT | LittleFS | coredump |
|---|---|---|---|---|
| normalny restart | tracony | zwykle zachowany | zachowany | jeśli był zapisany, zachowany |
| TASK WDT / panic | tracony | diagnostyka zachowana | zachowany | powinien być zapisany do partycji coredump |
| `esp_restart()` | tracony | zachowany | zachowany | brak nowego dumpa, jeśli restart był kontrolowany |
| utrata Wi-Fi | zachowany | zachowany | zachowany | n/d |
| utrata zasilania | tracony | tracony | zwykle zachowany | zależnie od momentu zapisu |
| korupcja FS | zachowany | zachowany | zagrożony | źródłowy coredump może być zagrożony |

Tabela opisuje architekturę, a nie gwarancję fizycznej odporności flash na każdą awarię zasilania.

### Najważniejszy wniosek
Sam ring w PSRAM **nie zapewnia bezstratnej historii telemetrycznej**.

Jeżeli V1 ma wyłącznie:

```text
TelemetryRing w PSRAM
```

to po dowolnym restarcie tracimy próbki, które:

```text
jeszcze nie zostały potwierdzone przez Firebase
```

Tak samo po zaniku zasilania nie mamy sposobu na odzyskanie ich z RAM.

### Nie należy tego maskować
Nie będziemy po restarcie tworzyć syntetycznych rekordów typu:

```text
„brak Wi-Fi przez 37 minut”
```

na podstawie samego uptime, jeżeli nie mamy rzeczywistych próbek.

Aplikacja powinna widzieć rzeczywistą lukę w osi czasu.

### V1 — jawna gwarancja
Dla pierwszej wersji proponowana gwarancja brzmi:

```text
online + sprawny firmware + brak restartu
    → telemetryka jest buforowana i retryowalna

restart / power loss przed trwałym zapisem
    → możliwa utrata niepotwierdzonego backlogu RAM
```

To jest uczciwszy kontrakt niż pozorne „bezstratna telemetria”.

### V2 — persistent spool
Jeżeli wymaganie biznesowe brzmi:

```text
„po zaniku zasilania chcę odzyskać wszystkie próbki ostatnich X godzin/dni”
```

to persistent spool jest konieczny.

Jego odpowiedzialność powinna być dokładnie zdefiniowana:

```text
RAM ring
    ↓
normalna praca / szybki backlog

LittleFS spool
    ↓
awaryjne przechowanie przy długim offline
    lub wysokim watermarku RAM

Firebase
    ↓
ACK
```

### Współpraca z coredumpem
Coredump i telemetryczny spool konkurują o tę samą partycję LittleFS.

Dlatego polityka musi gwarantować minimalną przestrzeń dla:

```text
coredump
log_krytyczny
```

nawet gdy telemetryczny backlog rośnie.

Nie wolno dopuścić do sytuacji:

```text
24h offline
→ telemetry.bin zajmuje FS
→ coredump nie może zostać zapisany
→ tracimy diagnostykę najważniejszego zdarzenia
```

### Priorytet danych trwałych
Proponowany porządek ochrony przestrzeni:

```text
P0 coredump / diagnostyka crash
P0 log_krytyczny
P1 niezbędne dane konfiguracyjne
P1 historia lokalna
P2 telemetry spool
P3 dane pomocnicze / cache
```

To nie oznacza automatycznego kasowania niższej kategorii — przed implementacją trzeba ustalić konkretne kwoty i politykę trimowania.

### Test R20
Wykonać osobno:

```text
A. reboot programowy przy pełnym ringu
B. TASK WDT przy pełnym ringu
C. panic przy pełnym ringu
D. odcięcie zasilania w trakcie zapisu spool page
E. odcięcie zasilania po zapisaniu page, przed ACK Firebase
F. odcięcie zasilania po ACK, przed lokalnym commit
```

Po każdym zdarzeniu:

```text
policz utracone próbki
policz duplikaty
sprawdź coredump
sprawdź integralność spool
sprawdź kolejność seq
```

### PASS R20
Dla V1:

```text
- utrata danych po restarcie jest jawna i wykrywalna
- brak fałszywych próbek zastępczych
- crash diagnostyka ma priorytet nad telemetrycznym backlogiem
```

Dla V2:

```text
- zapis zakończonej strony spool jest odporny na restart
- niepotwierdzone rekordy mogą zostać bezpiecznie ponowione
- potwierdzone rekordy nie są ponawiane bez potrzeby
```

### Status R20
```text
DONE — granice gwarancji V1/V2 określone.
OPEN — wymagany poziom „bez utraty po power loss” musi zostać zatwierdzony przed implementacją persistent spool.
```

---

## 21.29. Stan po R20

Badanie nie jest jeszcze zakończone. Obecnie za zamknięte/wyjaśnione uznajemy:

```text
R1–R20  architektura, FS, coredump, scheduler, czas, jakość danych,
        Firebase, batching, schema, bezpieczeństwo, awarie
```

Następne obszary researchu przed pierwszym kodem telemetryki:

```text
R21  finalny kontrakt record_id + RTDB query/index
R22  dokładny layout TelemetrySample + static_assert
R23  wybór batch size na podstawie payloadu i pamięci
R24  formalna polityka FS quota/reserve
R25  strategia OTA/migracji schema
R26  plan testów sprzętowych + fault injection krok po kroku
```

---

# R21–R26 — GŁĘBSZY RESEARCH: kontrakt danych, RTDB, ring, flash i testy

Data rundy: 2026-09-23
Status: **RESEARCH IN PROGRESS / bez zmian w firmware**

## R21. FINALIZACJA IDENTYFIKACJI REKORDU I MODELU RTDB

### Fakty z dokumentacji
Firebase Realtime Database obsługuje zapytania zakresowe (`startAt`, `endAt`) i pozwala deklarować indeksy przez `.indexOn`. Dokumentacja zaleca indeksowanie pól używanych w zapytaniach przed uruchomieniem produkcyjnym. Multi-location / `update()` pozwala zapisać wiele ścieżek jednym żądaniem. Firebase podaje również limit 16 MB dla pojedynczego write request przez SDK oraz limit ok. 1000 operacji zapisu/s na pojedynczą instancję. Aktualna skala centrali jest od tych limitów bardzo daleka.

Źródła:
- Firebase Security Rules / `.indexOn`: https://firebase.google.com/docs/database/security
- Firebase performance / indexing / SSL reuse: https://firebase.google.com/docs/database/usage/optimize
- Firebase limits: https://firebase.google.com/docs/database/usage/limits
- FirebaseClient `Database.update<object_t>()`: https://github.com/mobizt/FirebaseClient/blob/main/resources/docs/realtime_database.md

### Korekta wcześniejszego założenia
Nie należy polegać wyłącznie na timestampie jako nazwie klucza rekordu. Obecny firmware może mieć nieznany czas (`czas_unix == 0`), a korekta RTC/NTP może spowodować cofnięcie lub przeskok zegara. Sam `t<unix>` jest więc dobrym kluczem sortującym tylko wtedy, gdy założymy poprawny i monotonicznie zachowujący się czas.

### Decyzja projektowa
Rozdzielamy:

1. **tożsamość rekordu** — unikalna i stabilna,
2. **czas pomiaru** — pole `ts`, używane do wykresów i zapytań,
3. **kolejność lokalna** — `seq`, używana do diagnostyki utraty/retry.

Proponowany rekord:

```json
{
  "id": "bXXXXXXXX-sNNNNNN",
  "ts": 1790160000,
  "seq": 1234,
  "tz": 0,
  "f": 1,
  "tzv": 1,
  "tbo": 56.7,
  "tog": 44.2,
  "tpow": 39.8,
  "tpan": 62.0,
  "tpok": 21.1,
  "p": 1018.4,
  "h": 47,
  "kp": 35,
  "sp": 0,
  "pm": 1
}
```

Nazwy są tylko robocze — dokładny kontrakt zostanie zamknięty po R22/R23.

### Lepszy podział węzłów
Zamiast jednej nieograniczonej lokalizacji:

```text
/piec/telemetry/1m
```

preferujemy logiczne partycjonowanie po dniu:

```text
/piec/telemetry/1m/YYYY/MM/DD/<record_id>
```

Przykład:

```text
/piec/telemetry/1m/2026/09/23/b7A31F902-s001234
```

Powód: łatwiejsza retencja (usunięcie całego dnia), mniejsze zakresy zapytań, prostsze testowanie i mniejsze ryzyko przypadkowego pobrania całego długiego przebiegu.

### Zapytanie aplikacji
Aplikacja powinna pobierać dzień po dniu:

```text
orderByChild = ts
startAt = <from>
endAt   = <to>
```

z indeksem:

```json
".indexOn": ["ts"]
```

Nie opieramy UI na `orderByValue`; dokumentacja Firebase wskazuje, że sortowanie po child/indeksie jest właściwym sposobem dla rosnących danych, a indeksowanie redukuje transfer i obciążenie zapytań.

### Server timestamp
Firebase RTDB może zapisywać serwerowy timestamp poprzez wartość `{".sv":"timestamp"}`. Ten timestamp powinien być traktowany jako **czas przyjęcia/zapisu przez serwer**, a nie jako czas pomiaru. Dla telemetryki zachowujemy własne `ts` pomiarowe. Opcjonalne pole `server_ts` może być dodane wyłącznie do diagnostyki synchronizacji zegara.

Źródła:
- https://firebase.google.com/docs/database/web/offline-capabilities
- https://firebase.google.com/docs/reference/rest/database

### Wniosek R21
**record_id ≠ timestamp.** Timestamp jest atrybutem zapytania; identyfikator musi być stabilny również przy korekcie zegara i retry.

---

## R22. EXACT `TelemetrySample` — rozmiar, wyrównanie i semantyka

### Obserwacja z kodu
`HistoriaProbka` w aktualnym `main_centrala (3).cpp` ma 7 pól `float`, 1 `bool`, 2 kolejne `float` oraz 2 `int` i `uint32_t`. Przy typowym wyrównaniu ARM/Xtensa daje to około **52 B**, a nie 56 B z części wcześniejszych szacunków. To jest ważna korekta budżetu.

Nie kopiujemy tego structu do telemetryki.

### Dlaczego nie `float` dla wszystkiego
Dla temperatur do 0.1°C, ciśnienia do 0.1 hPa/bar (po finalnym ustaleniu jednostki), wilgotności 1% i pozycji 1% można użyć fixed-point.

Przykładowo:

```cpp
struct TelemetrySample {
  uint32_t ts;          // Unix seconds, 0 = unknown
  uint32_t seq;         // monotonic within boot/session
  int16_t  t_zewn_x10;
  int16_t  t_bojler_x10;
  int16_t  t_ogrz_x10;
  int16_t  t_powrot_x10;
  int16_t  t_panel_x10;
  int16_t  t_pokoj_x10;
  int16_t  cisnienie_x10;
  int8_t   wilgotnosc;
  uint8_t  klapa_proc;
  uint8_t  syberko_proc;
  uint8_t  flags;
};
```

Do policzenia po `static_assert` jest dokładny rozmiar, ale taki wariant celuje w ok. **32 B** bez `String` i bez paddingu zależnego od przypadkowej kolejności pól.

### Flagi jakości
Minimalny `flags` powinien rozróżniać co najmniej:

```text
BIT0 TIME_VALID
BIT1 T_ZEWN_VALID
BIT2 T_BOJLER_VALID
BIT3 T_OGRZ_VALID
BIT4 T_POWROT_VALID
BIT5 T_PANEL_VALID
BIT6 T_POKOJ_VALID
BIT7 HUMIDITY_VALID
```

Jeżeli liczba flag okaże się za duża, można przejść na 2 bajty jakości.

### Krytyczna semantyka FRESH vs STALE
Obecna historia zapisuje aktualne zmienne stanu. Nie mamy prawa zakładać, że każda taka wartość była zmierzona dokładnie w tej minucie.

Dlatego telemetryka powinna przechowywać stan jakości pomiaru:

```text
FRESH  = nowy odczyt wykonany w wymaganym oknie
STALE  = użyto ostatniej poprawnej wartości
INVALID = brak wiarygodnej wartości
```

W JSON nie wysyłamy `NaN`, `inf` ani niejawnych specjalnych wartości IEEE. Zamiast tego pole jest albo liczbą i ma flagę valid, albo jest pominięte/ustawione wg finalnego kontraktu.

### Czas
Aktualny firmware świadomie zapisuje `czas_unix=0`, kiedy nie ma wiarygodnego RTC/NTP. Telemetryka musi zachować tę semantykę i nie udawać poprawnego czasu.

### V1 kontrakt danych
Proponowany minimalny zestaw:

```text
czas pomiaru
sekwencja
6 temperatur
ciśnienie
wilgotność
pozycja klapy
pozycja syberka
stan pompy
flagi jakości
wersja schematu
```

Wersja schematu nie powinna być wersją firmware. To osobny kontrakt, np.:

```text
schema = 1
fw = v3.10.6
```

### Wniosek R22
Największą oszczędność daje **compact fixed-point + flags**, nie dalsze zmniejszanie częstotliwości próbkowania.

---

## R23. BATCH — nie 5 „na sztywno”, tylko limitowany kosztowo

### Fakty
FirebaseClient udostępnia `Database.update<object_t>()` jako PATCH/multi-path update. Firebase podaje dla SDK limit pojedynczego write request 16 MB; nasz batch będzie o rzędy wielkości mniejszy.

Źródła:
- https://github.com/mobizt/FirebaseClient/blob/main/resources/docs/realtime_database.md
- https://firebase.google.com/docs/database/usage/limits

### Budżet
Przy 32 B binarnej próbki:

```text
1440 × 32 B = 46 080 B / 24h
```

JSON zwiększa rozmiar przewodowy, ale nadal pozostajemy w setkach KB/dzień, nie dziesiątkach MB.

Dla orientacji, jeżeli jedna próbka JSON ma ~150 B:

```text
150 × 1440 = 216 000 B/dzień
≈ 211 KiB/dzień
≈ 6.3 MiB / 30 dni
```

To jest szacunek payloadu aplikacyjnego, **nie prognoza dokładnego kosztu przechowywania Firebase**.

### Batch 5/10/20
Przy założeniu ~150 B/rekord:

```text
5  → ~750 B danych + narzut JSON
10 → ~1.5 KB
20 → ~3 KB
```

Każdy z tych rozmiarów jest technicznie mały. O wyborze nie powinien więc decydować limit Firebase, tylko:

```text
czas fbApp.loop()
czas TLS
DRAM low-watermark
kolejka AsyncClient
wpływ na tgTask / loopTask
```

### Nowa polityka
Nie ustawiamy „batch=5” jako finalnego wymagania przed pomiarem.

Wprowadzamy trzy progi:

```text
TARGET_BATCH = 5
MAX_BATCH    = 10
EMERGENCY    = 1
```

ale parametry pozostają konfiguracyjne do chwili zakończenia testów A/B/C.

### Zasada backpressure
Jeżeli:

```text
fbAsyncClient.taskCount() >= HIGH_WATERMARK
```

telemetryka **nie dokłada kolejnych requestów**.

Najpierw istniejące zadania muszą zejść z kolejki.

Jeżeli backlog telemetryczny rośnie przez brak Wi-Fi, nowe próbki dalej trafiają do RAM-ringu, natomiast uploader jest blokowany przez circuit breaker/backpressure.

### Wniosek R23
Najbezpieczniejszy pierwszy eksperyment to **5 próbek/batch**, ale nie jako niezmienialna architektura. Test 5 vs 10 powinien zostać wykonany na realnym sprzęcie.

---

## R24. TELEMETRY RING — poprawa wcześniejszego projektu współbieżności

### Istotna korekta
W jednej z wcześniejszych wersji researchu padło uproszczenie, że SPSC ring może działać bez blokady tylko dlatego, że ma jednego producenta i jednego konsumenta.

Nie przyjmujemy tego jako bezwarunkowej zasady.

Aktualny ESP-IDF FreeRTOS na ESP32-S3 jest wielordzeniowy. Samo wyłączenie przerwań na jednym rdzeniu nie chroni wspólnej pamięci przed drugim rdzeniem. ESP-IDF implementuje odpowiednie sekcje krytyczne poprzez `portMUX_TYPE` spinlock. Sekcje powinny być bardzo krótkie i nie mogą zawierać operacji blokujących ani alokacji.

Źródło:
- https://docs.espressif.com/projects/esp-idf/en/v5.5/esp32/api-reference/system/freertos_idf.html

### Decyzja
Ring dostaje własny:

```cpp
static portMUX_TYPE telemetryMux = portMUX_INITIALIZER_UNLOCKED;
```

W sekcji krytycznej:

```text
push:
  sprawdzenie full
  copy struct
  head++
  count++

pop/copy:
  sprawdzenie empty
  copy struct do lokalnego batch buffer
  tail++
  count--
```

Poza sekcją krytyczną:

```text
JSON
malloc
String
Firebase
LittleFS
logowanie
```

### Polityka pełnego ringu
Nie nadpisujemy najstarszej próbki „po cichu”.

Preferowana polityka:

```text
if full:
    drop_newest = false
    drop_oldest = true
    telemetryDropped++
    telemetryGapCounter++
```

czyli utrata jest jawnie liczona, a ring zachowuje najnowszy stan.

Dla centrali CO jest to sensowniejsze operacyjnie niż pozostawienie bardzo starego backlogu kosztem bieżących pomiarów.

### 24h ring
Przy 1440 × 32 B:

```text
46 080 B
```

nawet 2880 × 32 B:

```text
92 160 B
```

jest nadal bardzo małe względem dostępnego PSRAM.

### Nowa decyzja
**V1 = 1440 rekordów jako nominalny ring 24h.**

Opcja zwiększenia do 2880 nie wymaga zmiany architektury; zależy od późniejszych danych z testów.

---

## R25. LittleFS / persistent spool — architektura odporniejsza na power loss

### Fakty
LittleFS został zaprojektowany dla systemów embedded właśnie pod kątem odporności struktur FS na utratę zasilania i ograniczonego zużycia flash. Sam port `esp_littlefs` opisuje LittleFS jako fail-safe filesystem. Jednocześnie projekt LittleFS podkreśla, że system musi radzić sobie z power loss w dowolnym momencie operacji zapisu oraz z wear leveling.

Źródła:
- https://github.com/joltwallet/esp_littlefs
- https://github.com/littlefs-project/littlefs/blob/master/DESIGN.md

### Ważna uwaga
LittleFS nie oznacza, że **nasz format aplikacyjny** automatycznie jest atomowy.

Jeżeli zrobimy:

```text
append record A
append record B
power loss
```

musimy umieć odtworzyć, gdzie kończy się ostatni kompletny rekord aplikacyjny.

### Proponowany format V2
Nie jeden wielki `telemetry.bin`, ale zamknięte segmenty:

```text
/coredumps/...
/telemetry/seg_000123.bin
/telemetry/seg_000124.bin
/telemetry/seg_000125.bin
```

Każdy segment:

```text
HEADER
  magic
  format_version
  segment_seq
  first_record_seq
  last_record_seq
  record_count
  header_crc

RECORD × N
  record_len
  record_seq
  ts
  payload
  record_crc

FOOTER
  magic
  record_count
  last_record_seq
  segment_crc
```

### Recovery
Po starcie:

```text
scan segment files
→ sort by segment_seq
→ validate header
→ scan records until first bad/truncated record
→ truncate/ignore incomplete tail
→ determine last valid record
→ resume append into new segment
```

Nie potrzebujemy skanować całej wielomegabajtowej historii do RAM.

### Rotacja
Segment np. 16–64 KiB daje kilka zalet:

```text
- małe operacje FS
- szybka walidacja
- możliwość usunięcia całego segmentu po ACK
- proste recovery
```

Finalna wielkość segmentu zostanie ustalona po pomiarze LittleFS.

### Wear
Najważniejsza zasada: **nie zapisujemy flash co minutę bez potrzeby**.

Jeżeli telemetria przez cały czas online trafia wyłącznie do PSRAM, flash spool jest używany tylko przy długim offline/backpressure.

To jest dużo lepsze dla zużycia flash niż stałe „mirrorowanie” każdej próbki na LittleFS.

### Priorytet miejsca
Zachowujemy wcześniejszy model:

```text
P0 coredump
P0 log_krytyczny
P1 konfiguracja
P1 historia
P2 telemetry spool
P3 cache
```

Telemetry spool nie ma prawa blokować miejsca potrzebnego do zapisania crash dumpa.

---

## R26. BUDŻET LITTLEFS — korekta i formalny model

### Aktualna partycja
Z `partitions.csv`:

```text
spiffs offset = 0x620000
spiffs size   = 0x9E0000
```

co daje:

```text
10 354 688 B
≈ 9.875 MiB
```

### Maksymalne znane obszary
Z obecnej architektury:

```text
hist_short       ~0.08–0.15 MiB
hist_long        ~1.1–1.2 MiB
coredumps        ~1.25 MiB (20 × 64 KiB)
panel firmware   do ~1–2 MiB wg historii projektu
logi             zmienne
settings         zmienne
```

Nie wolno jednak sumować tych wartości jako „dokładnego wykorzystania”. Są to limity logiczne / obserwowane rozmiary.

### Nowy model accounting
W runtime potrzebujemy dwóch niezależnych wartości:

```text
physical_used = wynik filesystemu / rzeczywistej pojemności
logical_used  = suma plików, które znamy
```

Dodatkowo:

```text
critical_reserve
telemetry_budget
```

Policy:

```text
telemetry may use space only if
physical_free > critical_reserve
```

oraz:

```text
critical_reserve
    >= space required for one valid coredump
    + minimum headroom for log_krytyczny
```

Finalne liczby dopiero po pomiarze rzeczywistego filesystemu na urządzeniu.

### Ważna korekta do wcześniejszego researchu
Nie należy przenosić mechanicznie modelu „20% wolnego” z ogólnych zaleceń na ten projekt. Dla LittleFS dostępne miejsce ma własną charakterystykę, a aplikacja ma kilka niezależnych konsumentów flash.

Rezerwę definiujemy z wymagania funkcjonalnego, nie z arbitralnego procenta.

---

# R27. Bezpieczeństwo RTDB — telemetryka musi być jednokierunkowo ograniczona

## Fakty
Firebase Security Rules pozwalają definiować osobne `.read`, `.write`, `.validate` oraz `.indexOn`. Reguły są nakładane na serwerze. `.validate` może wymuszać strukturę, typy i zakresy danych; jeżeli walidacja jednego zapisu wielościeżkowego nie przejdzie, cała operacja zostaje odrzucona.

Źródła:
- https://firebase.google.com/docs/database/security
- https://firebase.google.com/docs/rules/data-validation

## Konsekwencja
Telemetryka nie powinna współdzielić z komendami luźnej reguły typu:

```text
/piec/**  write=true
```

bo wtedy endpoint telemetryczny może potencjalnie stać się kanałem ingerencji w stan sterownika.

Docelowo logicznie:

```text
/piec/status      ← urządzenie → cloud
/piec/telemetry   ← urządzenie → cloud
/piec/events      ← urządzenie → cloud
/piec/cmd         ← cloud/app → urządzenie
```

Reguły powinny rozdzielać uprawnienia do tych gałęzi.

### Walidacja telemetryki
Docelowe `.validate` powinno ograniczać przynajmniej:

```text
ts                  integer
schema              integer
seq                 integer
temperatury         number w fizycznym zakresie
cisnienie           number w zakresie
wilgotnosc          0..100
klapa/syberko       0..100
pompa               boolean/0..1
```

Pozwala to odrzucać uszkodzone payloady także wtedy, gdy urządzenie ma błąd serializacji.

### Legacy Secret
Obecne używanie LegacyToken/Database Secret i `setInsecure()` pozostaje **P0/P1 security hardening**, ale nie mieszamy migracji z implementacją telemetryki.

---

# R28. Aktualizacja wersji — osobny eksperyment

Na dzień 2026-09-23 najnowsze znalezione wydanie FirebaseClient to **v2.2.13**, wydane 13 lipca 2026. Release note mówi m.in. o poprawce sporadycznych HTTP 400 przy zamykaniu wcześniej używanego połączenia przez serwer.

Źródło:
- https://github.com/mobizt/FirebaseClient/releases

Obecny projekt ma przypięte `mobizt/FirebaseClient @ ^2.2.9`.

### Decyzja
Nie robimy jednocześnie:

```text
FirebaseClient upgrade
+
telemetry implementation
```

Najpierw baseline na obecnej wersji, potem ewentualnie osobny A/B upgrade.

---

# R29. FAULT-INJECTION MATRIX — testy muszą badać semantykę, nie tylko crash

| Test | Zdarzenie | Oczekiwane zachowanie | PASS |
|---|---|---|---|
| T1 | WiFi OFF 1h | ring rośnie, sterowanie działa | brak WDT/resetu |
| T2 | WiFi OFF 24h | ring dochodzi do limitu, drop liczony | żadnego cichego dropu |
| T3 | WiFi OFF + powrót | backlog jest wysyłany | brak duplikatów |
| T4 | Firebase timeout | rekord nie jest uznany za ACK | późniejszy retry możliwy |
| T5 | HTTP 400 | circuit breaker/backoff | sterowanie nie blokuje się |
| T6 | reset po enqueue | próbki RAM mogą zniknąć — strata jawna | licznik gap/boot diagnostyka |
| T7 | power loss podczas spool write | ostatni rekord może być niepełny | recovery bez błędów parsera |
| T8 | power loss po ACK | rekord nie może powodować uszkodzenia następnego segmentu | idempotencja |
| T9 | pełny LittleFS | telemetryka się zatrzymuje | coredump nadal możliwy |
| T10 | coredump + pełny spool | priorytet coredump | dump zachowany |
| T11 | RTC invalid | `ts=0`, flaga invalid | brak fałszywej daty |
| T12 | RTC correction | record IDs nadal unikalne | brak overwrite przypadkowych próbek |
| T13 | reboot co kilka godzin | nowy boot/session | brak kolizji record_id |
| T14 | Firebase task queue wysokie | telemetryka nie dołącza kolejnych requestów | backpressure |
| T15 | batch 5 vs 10 | pomiar WDT/RAM/latency | wybór na podstawie danych |

---

# R30. Kryteria produkcyjne — dopiero wtedy telemetryka jest „gotowa”

Nie wystarczy:

```text
build OK
Firebase pokazuje dane
```

Wymagamy:

```text
1. 72h stabilnej pracy
2. brak nowych WDT/panic/resetów względem baseline
3. brak monotonicznego wycieku DRAM
4. brak monotonicznego wycieku PSRAM
5. brak rosnącej bez kontroli kolejki Firebase
6. brak niekontrolowanego wzrostu LittleFS
7. jawne telemetryDropped == 0 podczas testu online
8. brak duplikatów w RTDB
9. brak rekordów z fałszywym timestampem
10. pozytywny test power-loss spool
11. pozytywny test coredump przy wysokim zajęciu FS
12. zweryfikowane zakresy zapytań aplikacji
```

---

# Zaktualizowana mapa decyzji

```text
                    SENSORY / STAN
                           │
                     co ~60 sekund
                           │
                 historiaZapiszProbke()
                           │
          ┌────────────────┴───────────────┐
          │                                │
     historia local                   TelemetrySample
          │                                │
       LittleFS                         PSRAM ring
                                           │
                                backpressure / circuit breaker
                                           │
                                    istniejący Firebase
                                           │
                                  AsyncClient / fbApp.loop
                                           │
                                  update() multi-path
                                           │
                            /piec/telemetry/1m/YYYY/MM/DD/
                                           │
                                  Mobile range queries
                                           │
                                        SQLite

        LittleFS persistent spool (V2)
                 ↑ tylko gdy wymagany
                 │
       segment + CRC + recovery
                 │
        nigdy kosztem coredumpu
```

# Status po R30

### ZAMKNIĘTE

```text
- jeden Firebase pipeline
- brak osobnego TelemetryTask w V1
- PSRAM ring
- compact sample zamiast historii 1:1
- timestamp jako pole, nie jedyna tożsamość
- daily RTDB partitioning jako kierunek
- `.indexOn=ts`
- batch z backpressure
- jawny FRESH/STALE/INVALID
- LittleFS spool jako V2
- segmentacja spool + CRC/recovery
- coredump ma wyższy priorytet niż spool
- osobny upgrade FirebaseClient
- fault-injection matrix
```

### OTWARTE

```text
- dokładny record_id / boot_id
- finalny sizeof(TelemetrySample)
- dokładna jednostka ciśnienia w telemetry API
- sposób pozyskania świeżości każdego źródła
- finalny batch 5/10
- HIGH_WATERMARK taskCount
- finalny LittleFS critical_reserve
- realny rozmiar coredump ELF na tej konfiguracji
- czy V1 wymaga trwałego spoolu od dnia 1
```

### NASTĘPNY RESEARCH

```text
R31  przejście po wszystkich źródłach sensorów i określenie FRESH/STale
R32  formalny kontrakt JSON/RTDB + przykładowe Rules
R33  analiza generated sdkconfig / build artifacts
R34  dokładne pomiary sizeof() i budżetu PSRAM/DRAM
R35  projekt state machine uploader'a
R36  projekt segmentu spool + recovery state machine
```

## Źródła tej rundy

1. Espressif ESP-IDF FreeRTOS / critical sections: https://docs.espressif.com/projects/esp-idf/en/v5.5/esp32/api-reference/system/freertos_idf.html
2. Espressif ESP32-S3 external RAM: https://docs.espressif.com/projects/esp-idf/en/v5.5/esp32s3/api-guides/external-ram.html
3. Espressif watchdogs: https://docs.espressif.com/projects/esp-idf/en/v5.5/esp32s3/api-reference/system/wdts.html
4. Firebase RTDB limits: https://firebase.google.com/docs/database/usage/limits
5. Firebase RTDB performance: https://firebase.google.com/docs/database/usage/optimize
6. Firebase Security Rules: https://firebase.google.com/docs/database/security
7. Firebase validation: https://firebase.google.com/docs/rules/data-validation
8. Firebase server timestamps: https://firebase.google.com/docs/database/web/offline-capabilities
9. Firebase REST server values: https://firebase.google.com/docs/reference/rest/database
10. FirebaseClient RTDB API: https://github.com/mobizt/FirebaseClient/blob/main/resources/docs/realtime_database.md
11. FirebaseClient releases: https://github.com/mobizt/FirebaseClient/releases
12. esp_littlefs: https://github.com/joltwallet/esp_littlefs
13. LittleFS design / power loss / wear: https://github.com/littlefs-project/littlefs/blob/master/DESIGN.md

---

# R31–R36 — JESZCZE GŁĘBSZE WEJŚCIE W KOD I KONTRAKT NIEZAWODNOŚCI

Data: 2026-09-23
Status: **research kontynuowany**

## R31. MAPA ŚWIEŻOŚCI KAŻDEGO ŹRÓDŁA DANYCH

### Źródła z aktualnego kodu

`historiaZapiszProbke()` pobiera snapshot raz na 60 s, ale źródła są odświeżane dużo częściej:

```text
Czujnik_DS         2816 ms
wilgotnosc         3000 ms
cisnienie          5000 ms
obliczanie_srednia 2224 ms
RTC                2000 ms
pozycje serw       20 ms podczas ruchu
```

Czyli sam fakt, że próbka telemetrii powstaje raz na minutę, nie oznacza, że wszystkie pola mają wspólną „świeżość 60 s”.

### DS18B20
Aktualna funkcja `odczytajTemperature()` ma dwa poziomy filtracji:

```text
zakres fizyczny / spurious 85°C
          ↓
FiltrWiarygodnosci
          ↓
ostatnia dobra wartość
```

`FiltrWiarygodnosci` może zwrócić ostatnią dobrą wartość po błędzie lub odrzuconym skoku. Oznacza to, że sama liczba nie mówi, czy została faktycznie zmierzona w bieżącym cyklu.

### Ciśnienie
`cisnienie()` odrzuca `NaN`, ale pozostawia poprzednią wartość. Obecnie nie istnieje znacznik wieku tej wartości.

### Wilgotność — realna uwaga jakościowa
W przypadku błędu DHT aktualny kod robi:

```cpp
wilgotnoscOdczytanaLok = poprzedniaWilgotnosc;
```

ale `poprzedniaWilgotnosc` jest ustawiana jako `wilgotnoscSkorygowana`, a nie bezpośrednio jako ostatni surowy wynik DHT. W efekcie `wilgotnoscOdczytana` może po błędzie DHT reprezentować wartość po korekcji, a nie dokładnie ostatni surowy pomiar DHT.

**To jest osobny bug jakości danych w istniejącym firmware.** Telemetria nie powinna go maskować.

### Decyzja
Dla telemetryki wprowadzamy metadata świeżości niezależne od wartości:

```text
lastFreshMs[źródło]
lastFreshTs[źródło] (opcjonalnie)
quality[źródło]
```

Zasada:

```text
fresh read accepted  → aktualizuj lastFreshMs
fallback / hold      → NIE aktualizuj lastFreshMs
telemetry snapshot   → oblicz age_ms
```

Przykładowa semantyka:

```text
FRESH      age <= 2 × nominalny interwał źródła
STALE      age > 2 × nominalny interwał, ale istnieje ostatnia dobra wartość
INVALID    brak żadnego dobrego odczytu
```

Granice `2×` są propozycją do testu, a nie jeszcze wymaganiem produkcyjnym.

### Wniosek
Najważniejszy parametr jakości telemetryki nie jest „wartość”, tylko para:

```text
wartość + wiek/quality
```

---

## R32. KONTRAKT JSON/RTDB — WERSJONOWANIE I WALIDOWALNOŚĆ

### Docelowy dokument logiczny

```json
{
  "schema": 1,
  "fw": "v3.10.6",
  "ts": 1790160000,
  "seq": 1234,
  "boot": "A1B2C3D4",
  "q": 255,
  "tz": 18,
  "tb": 567,
  "to": 442,
  "tp": 398,
  "tn": 620,
  "tr": 211,
  "p": 1018.4,
  "h": 47,
  "k": 35,
  "s": 0,
  "m": 1
}
```

To tylko kontrakt roboczy; nazwy i jednostki finalizujemy po R34.

### Dlaczego integer fixed-point
Stałoprzecinkowa reprezentacja:

```text
tb=567 → 56.7°C
```

eliminuje część problemów związanych z wielkością JSON i jednoznacznie określa precyzję.

### `schema` ≠ `fw`

```text
schema = kontrakt danych
fw     = wersja oprogramowania
```

Zmiana UI lub poprawka WDT nie musi zmieniać schematu telemetryki.

### Rules
Firebase Security Rules mają osobną kategorię `.validate`, dzięki czemu można sprawdzać obecność pól i ich typ/range po uzyskaniu zgody `.write`. Przy multi-path update niepoprawny rekord może spowodować odrzucenie całej operacji — dlatego firmware powinno walidować batch lokalnie przed wysłaniem.

Źródła:
- https://firebase.google.com/docs/database/security
- https://firebase.google.com/docs/rules/data-validation

### Nowy wymóg implementacyjny
Firmware nie może tworzyć batcha częściowo, wysyłać go i dopiero potem wykrywać własny błąd serializacji.

Wymagany przepływ:

```text
snapshot
→ validate local ranges
→ serialize
→ verify buffer length
→ enqueue one Firebase task
```

---

## R33. GENERATED `sdkconfig` — KLUCZOWE USTALENIA Z `sdkconfig.defaults`

Aktualny plik `sdkconfig.defaults` zawiera m.in.:

```text
CONFIG_SPIRAM=y
CONFIG_SPIRAM_MODE_OCT=y
CONFIG_SPIRAM_SPEED=80
CONFIG_SPIRAM_USE_MALLOC=y
CONFIG_SPIRAM_MALLOC_ALWAYSINTERNAL=4096
CONFIG_SPIRAM_TRY_ALLOCATE_WIFI_LWIP=y
```

oraz:

```text
CONFIG_ESP_INT_WDT=y
CONFIG_ESP_INT_WDT_TIMEOUT_MS=300
CONFIG_ESP_INT_WDT_CHECK_CPU1=y
CONFIG_ESP_TASK_WDT_EN=y
CONFIG_ESP_TASK_WDT_INIT=y
CONFIG_ESP_TASK_WDT_PANIC=y
CONFIG_ESP_TASK_WDT_TIMEOUT_S=5
CONFIG_ESP_TASK_WDT_CHECK_IDLE_TASK_CPU0=y
```

oraz:

```text
CONFIG_ESP_COREDUMP_ENABLE=y
CONFIG_ESP_COREDUMP_ENABLE_TO_FLASH=y
CONFIG_ESP_COREDUMP_DATA_FORMAT_ELF=y
CONFIG_ESP_COREDUMP_CHECKSUM_CRC32=y
CONFIG_ESP_COREDUMP_CHECK_BOOT=y
CONFIG_ESP_COREDUMP_MAX_TASKS_NUM=64
CONFIG_ESP_COREDUMP_STACK_SIZE=1792
```

oraz:

```text
CONFIG_FREERTOS_HZ=1000
CONFIG_FREERTOS_TASK_CREATE_ALLOW_EXT_MEM=y
```

### Bardzo istotna obserwacja
W konfiguracji jest:

```text
ALLOW_EXT_MEM = y
```

ale nie ma:

```text
PLACE_TASK_STACKS_IN_EXT_RAM = y
```

To jest zgodne z kierunkiem obecnego projektu: taski tworzone normalnie nie powinny automatycznie lądować ze stosami w PSRAM.

ESP-IDF wyraźnie ostrzega, że stosy umieszczone w PSRAM mają szczególne ograniczenia podczas flash erase/write, OTA i deep sleep. Aktualny projekt powinien nadal trzymać task stacks w DRAM.

Źródło:
- https://docs.espressif.com/projects/esp-idf/en/v5.5/esp32s3/api-guides/external-ram.html

### Nowa obserwacja o alokatorze
`CONFIG_SPIRAM_MALLOC_ALWAYSINTERNAL=4096` oznacza, że standardowy `malloc()` preferuje pamięć wewnętrzną dla alokacji mniejszych niż 4096 B i zewnętrzną dla większych, z fallbackiem do drugiej puli.

To oznacza, że **mały/średni JSON batch budowany przez zwykły `String` może nadal konsumować cenny DRAM**, nawet jeśli PSRAM jest praktycznie pusty.

Źródło:
- https://github.com/espressif/esp-idf/blob/master/components/esp_psram/Kconfig.spiram.common

### Decyzja
W telemetryce:

```text
ring data        → PSRAM
batch JSON       → jawnie alokowany bufor PSRAM
task stack       → DRAM
krótkie lokalne   → DRAM
```

Nie polegamy na tym, że `malloc()` „sam wybierze dobrze”.

### Ostateczny warunek R33
Przed zmianą firmware trzeba zdobyć wygenerowany:

```text
.pio/build/esp32-s3-n16r8/sdkconfig.esp32-s3-n16r8
```

albo odpowiednik faktycznie generowany przez bieżące środowisko.

Bez niego nie deklarujemy, że `sdkconfig.defaults` jest konfiguracją końcową buildu.

---

## R34. DOKŁADNY BUDŻET `TelemetrySample`

### Punkt wyjściowy
Aktualny `HistoriaProbka` ma logicznie:

```text
6? / 7? temperatur
ciśnienie
wilgotność
pompa
klapa
syberek
czas
```

i z uwagi na align/padding nie jest dobrym binarnym kontraktem telemetrycznym.

### Docelowy binarny sample
Preferowany kierunek:

```cpp
struct TelemetrySample {
    uint32_t ts;
    uint32_t seq;
    uint32_t boot;
    int16_t  t_zewn_x10;
    int16_t  t_bojler_x10;
    int16_t  t_ogrz_x10;
    int16_t  t_powrot_x10;
    int16_t  t_panel_x10;
    int16_t  t_pokoj_x10;
    int16_t  cisnienie_x10;
    int8_t   wilgotnosc;
    uint8_t  klapa_proc;
    uint8_t  syberko_proc;
    uint8_t  pompa;
    uint16_t quality;
};
```

To daje orientacyjnie **36 B** przy naturalnym wyrównaniu, ale finalny rozmiar ma być potwierdzony przez:

```cpp
static_assert(sizeof(TelemetrySample) == EXPECTED_SIZE);
static_assert(offsetof(TelemetrySample, ts) == 0);
```

Nie wpisujemy `EXPECTED_SIZE` „na oko”; najpierw kompilacja testowa.

### Budżet 24h
Jeżeli sample = 36 B:

```text
1440 × 36 = 51 840 B
```

48 h:

```text
103 680 B
```

7 dni w RAM byłoby:

```text
362 880 B
```

czyli nadal możliwe w PSRAM, ale 24h daje wystarczający margines i ogranicza bezcelowe zajęcie pamięci.

### Wniosek
Nie potrzebujemy agresywnej kompresji. Najpierw prosty fixed-point i stały struct.

---

## R35. STATE MACHINE UPLOADERA — finalny model pracy

### Stany

```text
IDLE
  ↓
CHECK_GATE
  ↓
COPY_BATCH
  ↓
BUILD_JSON
  ↓
ENQUEUE_FIREBASE
  ↓
WAIT_RESULT
  ├── SUCCESS → COMMIT_POP
  ├── RETRYABLE_ERROR → BACKOFF
  └── HARD_ERROR → CIRCUIT_OPEN
```

### Krytyczna zasada
**Nie usuwamy próbek z ring dopóki Firebase nie potwierdzi sukcesu.**

Nie:

```text
pop
→ send
```

tylko:

```text
peek/copy
→ send
→ success
→ advance tail
```

Dzięki temu timeout nie powoduje automatycznej utraty próbki.

### Co z timeoutem, kiedy worker może dalej żyć
Obecny model `fbLoopWork` może przestać czekać po osiągnięciu limitu, podczas gdy rzeczywisty request może jeszcze kończyć się w bibliotece.

Dlatego telemetryka potrzebuje statusu:

```text
IN_FLIGHT
```

i nie może wystartować drugiego batcha, dopóki poprzedni request nie zostanie rozstrzygnięty albo bezpiecznie uznany przez istniejącą infrastrukturę za zakończony.

### Wniosek
Nie robimy prostego:

```cpp
if (timeout) retryImmediately();
```

bo moglibyśmy mieć dwa logicznie równoległe wysłania tego samego batcha.

Retry musi respektować rzeczywisty stan `fbLoopWorker`/`AsyncResult`.

---

## R36. PERSISTENT SPOOL — MASZYNA ODPORNA NA RESET

### Segmenty
Preferowany zakres do testu:

```text
32 KiB segment
```

Nie jest to jeszcze wartość finalna.

### Rekord

```text
magic
version
len
seq
boot
ats
payload
crc32
```

`ats` = acquisition timestamp.

### Segment state

```text
OPEN
SEALED
ACKED
```

Do usunięcia nadaje się tylko:

```text
SEALED + wszystkie rekordy ACK
```

### Power loss
Power loss w dowolnym miejscu:

```text
HEADER            → segment ignoruj/odtwórz
RECORD header     → przerwij skan
RECORD payload    → CRC fail → przerwij skan
RECORD CRC        → dopisz tylko rekordy do poprzedniego valid offset
FOOTER            → segment uznany za sealed
```

Nie wymagamy od filesystemu, aby rozumiał semantykę naszego rekordu.

### Dlaczego segmenty
Kasowanie pojedynczych rekordów powodowałoby:

```text
fragmentację
więcej metadata writes
trudniejszy recovery
```

Kasowanie całych segmentów jest prostsze i dobrze współgra z LittleFS.

### V2 nie zaczyna się od pliku
Zanim implementujemy spool, musimy mieć test laboratoryjny:

```text
1000 power-loss injection
```

przerywanych losowo na etapach zapisu.

Nie oznacza to literalnego 1000 fizycznych odłączeń ręcznie — test harness musi pozwolić deterministycznie przerywać zapis w symulacji/na urządzeniu.

### Wniosek R36
Persistent spool jest małym systemem storage, a nie „dopisywaniem Stringa do pliku”.

---

# R37. NOWY PRIORYTET — DOWODZENIE POPRAWNOŚCI CZASU

Aktualny firmware ma sprzętowy DS1307 oraz ścieżkę NTP. `historiaZapiszProbke()` zapisuje `czas_unix=0`, gdy żadne źródło nie jest uznane za wiarygodne.

To jest dobra semantyka, ale telemetryka powinna dodatkowo odróżnić:

```text
TIME_UNKNOWN
TIME_RTC
TIME_NTP
TIME_CORRECTED
```

Proponowane 2 bity `time_source` w `quality`:

```text
00 unknown
01 RTC
10 NTP
11 corrected/synchronized
```

Nie należy wysyłać lokalnej godziny jako podstawowego pola zapytaniowego. RTDB przechowuje `ts` w Unix seconds, a UI wykonuje konwersję strefy czasowej.

Firebase udostępnia również server timestamp, ale należy go traktować jako czas serwera zapisu, nie czas wykonania pomiaru.

Źródła:
- https://firebase.google.com/docs/database/web/offline-capabilities
- https://firebase.google.com/docs/reference/rest/database

---

# R38. NOWY PRIORYTET — DAILY SHARDING vs MONTHLY SHARDING

Po przeanalizowaniu zakresów zapytań i retencji mamy dwie możliwości:

### Daily

```text
/telemetry/1m/2026/09/23/...
```

+ bardzo proste kasowanie retencji
+ małe zakresy odczytu
+ łatwe debugowanie
− więcej pathów

### Monthly

```text
/telemetry/1m/2026/09/...
```

+ mniej pathów
− większe węzły
− trudniejsze częściowe kasowanie

### Decyzja
**Daily jest obecnie preferowane.**

Jedno zapytanie obejmujące tydzień oznacza maksymalnie 7 osobnych odczytów zamiast pobrania ogromnego drzewa. Aplikacja może scalać wynik i zapisywać do SQLite.

To jest świadome przesunięcie części pracy z RTDB do repozytorium aplikacji.

---

# R39. BUDŻET SIECI — POPRZEDNI STATUS vs TELEMETRIA

Obecny status centrali jest wysyłany około co 15 s i ma według wcześniejszego pomiaru około 650 B JSON.

Orientacyjnie:

```text
86400 / 15 = 5760 statusów/dzień
5760 × 650 B ≈ 3.74 MB/dzień payloadu status
```

Telemetryka 1/min przy około 150 B/rekordzie:

```text
1440 × 150 B ≈ 216 KB/dzień payloadu
```

Wniosek:

**Telemetria nie jest obecnie głównym konsumentem payloadu.**

Nie powinniśmy optymalizować jej kosztem stabilności systemu. Większą przyszłą oszczędność może dać optymalizacja statusu — ale to osobny projekt.

---

# R40. KONCOWA ZASADA ARCHITEKTURY V1

Po R1–R40 obowiązuje następująca zasada:

```text
                     CONTROL LOOP
                           │
                         60 s
                           │
                  create telemetry sample
                           │
                   short PSRAM critical
                           │
                     PSRAM ring
                           │
                ┌──────────┴───────────┐
                │                      │
           normal online          offline/backlog
                │                      │
           shared Firebase        RAM first
                │                      │
          one in-flight batch   spool only V2
                │                      │
             ACK                  segmented FS
                │                      │
          commit ring             CRC/recovery
```

### Absolutnie nie robimy

```text
❌ drugi FirebaseApp
❌ drugi AsyncClientClass
❌ drugi niezależny TLS worker
❌ Firebase request co 60 s dla każdej próbki
❌ pop przed ACK
❌ String jako storage ring
❌ wielki telemetry.bin bez segmentów
❌ telemetry spool bez quota
❌ kasowanie coredump source bez verify
❌ używanie timestampu jako jedynej tożsamości
❌ ładowanie całej historii 8000 rekordów do jednego Stringa w nowym module
```

### Następny blok researchu

```text
R41  dokładne mapowanie wszystkich sensorów + freshness timestamps
R42  generated sdkconfig/build artifacts
R43  kodowy proof-of-concept record_id
R44  exact JSON size dla batch 5/10
R45  analiza aktualnego fbLoopWorker i taskCount w źródle biblioteki
R46  formalny LittleFS quota calculator
R47  security rules draft
R48  test harness fault-injection
```

---

# R41–R48 — AUDYT IMPLEMENTACYJNY: sensory, worker Firebase, JSON, quota, rules, fault harness

Data: 2026-09-23

## R41. SENSOR → FRESHNESS: FINALNA MAPA

### Potwierdzone w kodzie

```text
Czujnik_DS             2816 ms
wilgotnosc             3000 ms
cisnienie              5000 ms
obliczanie_srednia     2224 ms
historiaZapiszProbke  60000 ms
```

### Wymagane znaczniki
Dla temperatur DS18B20:

```text
lastAcceptedFreshMs[7]
lastAcceptedFreshValue[7]
```

Aktualizowane tylko po przejściu przez `odczytajTemperature()` i zaakceptowaniu wartości przez filtr.

Dla BMP/DHT:

```text
pressureLastFreshMs
humidityLastFreshMs
```

Nie aktualizujemy znacznika przy fallbacku.

### Aktuatory
`pompa`, `klapa`, `syberek` nie są traktowane jak czujniki z freshness w tym samym sensie. Są to bieżące stany sterownika. Dla nich właściwe są:

```text
state
state_change_seq / lastChangeMs (opcjonalnie)
```

Nie należy udawać, że np. `klapa=35` ma „wiek pomiaru” jak DS18B20.

### Problem wilgotności
Błąd fallbacku opisany w R31 pozostaje osobnym taskiem jakości danych. Nie rozwiązujemy go przez telemetrykę, ale telemetryka musi mieć flagę, która pozwoli aplikacji wykryć, że wartość jest fallbackiem.

### Wniosek
W `TelemetrySample` potrzebujemy przede wszystkim **globalnego bitowego quality mask**, a nie 11 osobnych timestampów — znaczniki czasu źródeł zostają w firmware do wyliczenia jakości, a do RTDB wysyłamy wynik jakości.

---

## R42. `sdkconfig.defaults` — realne implikacje dla telemetryki

### Ustalone

```text
CONFIG_SPIRAM_MALLOC_ALWAYSINTERNAL=4096
```

Zgodnie z Kconfig ESP-IDF, dla standardowego `malloc()` alokacje poniżej progu preferują internal RAM, a większe preferują PSRAM, z fallbackiem do drugiej puli.

Źródło:
https://github.com/espressif/esp-idf/blob/master/components/esp_psram/Kconfig.spiram.common

### Konsekwencja
Nie wystarczy napisać:

```cpp
String json;
```

i zakładać, że JSON trafi do PSRAM.

Przy batchu ~1–4 KB może zostać zużyty DRAM.

### Decyzja
Do telemetryki stosujemy wzorzec:

```text
PSRAM fixed ring
PSRAM explicit JSON buffer
DRAM worker stack
DRAM control state
```

W kodzie należy mierzyć przed/po serializacji:

```text
free_internal
largest_internal
free_psram
largest_psram
```

---

## R43. `fbLoopWorker` — dokładny punkt integracji

Aktualny kod ma centralny mechanizm:

```text
fbLoopWorkerZajety()
        ↓
fbCzekajImpl()
        ↓
xTaskCreatePinnedToCore(..., "fbLoopWork", 8192, ..., 1, ..., 1)
        ↓
fbApp.loop()
```

Worker działa na Core 1 i priorytecie 1.

### Krytyczne zachowanie
Po przekroczeniu zewnętrznego limitu wywołujący może wrócić, ale worker może nadal przebywać w `fbApp.loop()`.

Dlatego istniejąca flaga:

```text
fbLoopWorkerZajety = true
```

jest faktycznym **single-flight gate**.

### Decyzja
Telemetryka nie może tworzyć własnego „timeout + retry” niezależnie od tego mechanizmu.

Musi respektować:

```text
worker idle → można uruchomić
worker busy → nie uruchamiać kolejnego Firebase path
```

### Nowy wymóg
Wprowadzić w warstwie telemetrycznej stan:

```text
TEL_FIREBASE_IN_FLIGHT
```

a nie tylko:

```text
lastSendMillis
```

---

## R44. EXACT JSON SIZE — pierwszy model liczbowy

Dla roboczego payloadu fixed-point i nazw skróconych, symulacja minified JSON daje orientacyjnie:

```text
1 record  ≈ 194 B
5 records ≈ 966 B
10 records ≈ 1931 B
20 records ≈ 3861 B
```

Są to **wartości modelowe**, nie jeszcze rzeczywisty payload FirebaseClient.

Nie uwzględniają:

```text
HTTP headers
TLS overhead
library metadata
path
possible object_t copies
```

### Wniosek
Nawet batch 10 znajduje się w obszarze kilku KB, więc limit Firebase 16 MB dla SDK nie jest czynnikiem ograniczającym. Najważniejszymi zmiennymi pozostają czas wykonania i pamięć.

Źródło limitu:
https://firebase.google.com/docs/database/usage/limits

### Test obowiązkowy
Na urządzeniu:

```text
serialize 1/5/10/20
measure len()
measure DRAM delta
measure PSRAM delta
measure max fbApp.loop elapsed
```

---

## R45. `AsyncClientClass` — task queue jako mechanizm backpressure

Dokumentacja FirebaseClient pokazuje, że `Database.set()`, `push()` i `update()` przyjmują `AsyncClientClass` oraz `AsyncResult`/callback. W praktyce oznacza to, że request jest zadaniem klienta asynchronicznego, a nie synchronicznym „wyślij i zapomnij”.

Źródło:
https://github.com/mobizt/FirebaseClient/blob/main/resources/docs/realtime_database.md

### Decyzja
`taskCount()` wykorzystujemy jako **metrykę**, nie jako jedyny lock.

Reguła:

```text
worker busy                 → no new telemetry
telemetry request in-flight → no new telemetry
queue above HIGH            → no new telemetry
```

To trzy różne stany, których nie należy sprowadzać do jednej flagi.

### Telemetry statistics

```text
firebaseEnqueued
firebaseSuccess
firebaseRetryableError
firebaseHardError
firebaseTimeout
firebaseSkippedBusy
firebaseSkippedQueueHigh
```

---

## R46. LITTLEFS QUOTA CALCULATOR — model zamiast arbitralnego 20%

### Wejście

```text
TOTAL = 10 354 688 B
```

### Rezerwaty

```text
RESERVE_COREDUMP
RESERVE_CRITICAL_LOG
RESERVE_CONFIG
RESERVE_HISTORY
```

### Dostępny telemetry budget

```text
TELEMETRY_BUDGET =
    TOTAL
  - RESERVE_COREDUMP
  - RESERVE_CRITICAL_LOG
  - RESERVE_CONFIG
  - RESERVE_HISTORY
  - SAFETY_MARGIN
```

### Konieczna własność

```text
TELEMETRY_SPOOL_USED <= TELEMETRY_BUDGET
```

Nie wystarczy sprawdzać:

```text
LittleFS.totalBytes() - LittleFS.usedBytes()
```

w jednym przypadkowym miejscu i traktować tego jako decyzji politycznej. Potrzebujemy również wiedzieć, ile przestrzeni wolno telemetryce zająć.

### Priorytet

```text
coredump > critical log > config > history > telemetry spool
```

---

## R47. DRAFT SECURITY RULES — kierunek, NIE do wgrania jeszcze

Robocza struktura:

```json
{
  "rules": {
    "piec": {
      "$device": {
        "telemetry": {
          ".read": "auth != null && auth.uid == $device",
          ".write": "auth != null && auth.uid == $device",
          ".indexOn": ["ts"]
        },
        "status": {
          ".write": "auth != null && auth.uid == $device"
        },
        "events": {
          ".write": "auth != null && auth.uid == $device"
        },
        "cmd": {
          ".read": "auth != null && auth.token.role == 'controller'"
        }
      }
    }
  }
}
```

To **nie jest jeszcze gotowe do produkcji**. Przede wszystkim musimy znać docelowy model auth (`uid`, claimy, aplikacja mobilna, urządzenie).

### Bardzo ważna zasada
Nie używamy ogólnego:

```text
/piec/.write = true
```

bo nadrzędna reguła może przyznać dostęp, którego bardziej szczegółowa reguła nie cofnie. Firebase wyraźnie dokumentuje, że reguły działają jak OR między nakładającymi się ścieżkami.

Źródło:
https://firebase.google.com/docs/rules/basics

### Walidacja
Telemetryka powinna mieć `.validate` zgodny ze schematem, aby odrzucać:

```text
NaN / złe typy
wartości poza zakresem
brak required fields
zły schema
```

---

## R48. FAULT-INJECTION HARNESS — architektura testu

### Poziom 1: logiczny
Bez fizycznego odłączania zasilania:

```text
force Firebase timeout
force HTTP 4xx
force HTTP 5xx
force WiFi unavailable
force full ring
force queue high
force stale sensor
force invalid time
```

### Poziom 2: flash

```text
interrupt immediately after write start
interrupt after record payload
interrupt after CRC
interrupt after footer
```

### Poziom 3: urządzenie

```text
software restart
Task WDT
panic
external power cut
brownout
```

### Rejestr wyników
Każdy test zapisuje:

```text
boot_id
before_seq
after_seq
records_generated
records_sent
records_missing
duplicates
ring_dropped
spool_recovered
coredump_recovered
```

### PASS

```text
No silent loss.
No duplicate logical records after retry.
No corruption of control state.
No coredump loss caused by telemetry.
No uncontrolled filesystem growth.
```

---

# NOWA MAPA R1–R48

Badanie przeszło z etapu „czy telemetria jest możliwa?” do etapu:

```text
jak zagwarantować jej poprawność
przy istniejących ograniczeniach centrali?
```

Najważniejsze obecnie ryzyka techniczne:

```text
P0  generated sdkconfig ≠ potwierdzony build config
P0  LittleFS accounting/quotas
P0  coredump verify-before-erase
P0  Firebase single-flight / timeout semantics
P1  freshness source metadata
P1  humidity fallback quality bug
P1  taskCount/backpressure
P1  exact JSON memory footprint
P1  record_id / boot identity
P2  persistent spool
P2  auth migration / TLS verification
```

## Następny blok

```text
R49  przeanalizować cały kod tworzenia status JSON pod kątem reużycia serializacji
R50  zaprojektować finalny `TelemetrySample` + enum/bitmask jakości
R51  zaprojektować boot_id bez nadmiernego zużycia NVS
R52  formalny record_id i daily path
R53  state machine commit/ACK dla ring
R54  konkretny quota algorithm LittleFS
R55  test matrix 24/48/72h + fault injection
R56  dopiero po zamknięciu R49–R55: szkic zmian w firmware
```

---

# R49. STATUS JSON — NIE REUŻYWAĆ KONTRAKTU `/piec/status` JAKO TELEMETRII

**Status: ZAMKNIĘTE — observation + design decision**

## Źródło prawdy: aktualny `main_centrala (3).cpp`

`sendStatusToFirebase()` buduje duży, bieżący snapshot urządzenia i wysyła go do:

```text
/piec/status
```

W payloadzie znajdują się m.in. temperatury, wilgotność, ciśnienie, dym, klapa, syberko, pompa, alarmy, tryb serwa, ustawienia, firmware, `uptime` i `updatedAt`.

Kluczowa obserwacja z kodu:

```cpp
"uptime": millis() / 1000
"updatedAt": millis()
```

czyli `updatedAt` nie jest timestampem Unix. Jest monotonicznym czasem od startu urządzenia.

### Decyzja

Nie wolno używać:

```text
/piec/status.updatedAt
```

jako czasu wykresów, synchronizacji próbek ani jako źródła kolejności historycznej.

Telemetria ma własne pola:

```text
capture_ts      = Unix timestamp wykonania próbki, jeśli czas wiarygodny
capture_mono_ms = millis() z chwili pobrania próbki
```

oraz flagę:

```text
TIME_VALID
```

Dzięki temu klient może odróżnić:

```text
realny czas ścienny
```

od:

```text
czas monotoniczny od restartu
```

## Budżet sieciowy

Przy obecnych parametrach status jest wysyłany nominalnie co 15 s.

```text
86400 / 15 = 5760 operacji/dobę
```

Przy obecnym przybliżeniu ~650 B payloadu daje to około:

```text
5760 × 650 B ≈ 3.74 MB/dobę
```

To tylko payload aplikacyjny, bez TLS/HTTP/protokołów niższych warstw.

Telemetria 1/min nie powinna kopiować całego statusu.

### Decyzja

Status pozostaje osobnym mechanizmem V1. Nie refaktoryzujemy go podczas wdrażania telemetryki.

---

# R50. FINALNY KANDYDAT `TelemetrySample` — FIXED POINT, STAŁY ROZMIAR, BEZ `String`

**Status: KANDYDAT V1 — wymaga jeszcze finalnej weryfikacji zakresów wszystkich pól**

## Cel

Rekord ma być:

- mały,
- kopiowalny `memcpy`,
- pozbawiony dynamicznej alokacji,
- niezależny od formatu JSON,
- stabilny ABI między modułami firmware,
- prosty do zapisu do RAM-ring oraz później do spool.

## Proponowana reprezentacja

Kandydat:

```cpp
struct TelemetrySample {
    uint32_t capture_ts;       // 0 = czas niewiarygodny
    uint32_t capture_mono_ms;  // monotoniczny czas od boot
    uint32_t boot_id;          // diagnostyczny numer bootu
    uint32_t sample_seq;       // sekwencja w ramach bootu

    int16_t  t_zewn_x10;
    int16_t  t_bojler_x10;
    int16_t  t_ogrz_x10;
    int16_t  t_ogrz_sr_x10;
    int16_t  t_powrot_x10;
    int16_t  t_panel_x10;
    int16_t  t_pokoj_x10;
    int16_t  t_trociny_x10;

    uint8_t  wilgotnosc_pct;
    uint16_t cisnienie_x100;
    uint16_t dym_raw;

    uint8_t  klapa_proc;
    uint8_t  syberko_proc;
    uint8_t  pompa;

    uint16_t quality;
    uint8_t  schema_ver;
};
```

Na typowej architekturze 32-bitowej odpowiada to około **48 B** po wyrównaniu struktury.

```text
1440 próbek × 48 B = 69 120 B ≈ 67.5 KiB
```

To jest bardzo mały koszt względem dostępnego PSRAM.

### Dlaczego fixed-point

Nie przechowujemy `float` w ring jako kontraktu transportowego.

Przykładowo:

```text
23.4 °C → 234
1.23 bar → ustalona jednostka ×100
```

Zalety:

- deterministyczny rozmiar,
- brak problemu reprezentacji `NaN` w JSON,
- łatwa walidacja zakresu,
- prostszy CRC dla przyszłego spoola,
- brak zależności od formatowania `float`.

### Otwarte pytanie

`cisnienie` jest obecnie liczone w kodzie przez:

```cpp
bmp.readPressure() / 100 + 18
```

Trzeba potwierdzić domenowe znaczenie `+18` i jednostkę przed zamrożeniem nazwy pola. Nie wolno zakopać tej korekty wewnątrz telemetryki bez metadanych/schema.

### Decyzja

`TelemetrySample` nie może być kopią `HistoriaProbka`. Historia lokalna i telemetryka mają różne kontrakty.

---

# R51. JAK ROBIĆ `record_id` — NVS NIE POWINNO BYĆ ŹRÓDŁEM GWARANCJI UNIKALNOŚCI

**Status: ZAMKNIĘTE — ważna korekta wcześniejszego projektu**

## Problem

Pierwotny pomysł:

```text
NVS boot_seq++
sample_seq++
record_id = boot_seq + sample_seq
```

nie daje ścisłej gwarancji unikalności po zaniku zasilania dokładnie podczas zapisu `boot_seq`.

Przykład:

```text
NVS = 10
boot A ustala 11
power-loss dokładnie podczas commit
NVS po recovery nadal = 10
boot B ponownie ustala 11
```

Jeżeli boot A zdążył już wygenerować dane, identyfikator oparty wyłącznie o `boot_seq` może się powtórzyć.

## NVS pozostaje przydatne

Aktualny firmware już używa `Preferences config` / NVS do konfiguracji. Oficjalna dokumentacja ESP-IDF podaje maksymalną długość klucza 15 znaków i wskazuje NVS jako magazyn odpowiedni dla wielu małych wartości. NVS ma własny mechanizm zarządzania stronami i wpisami. [ESP-IDF NVS](https://docs.espressif.com/projects/esp-idf/en/stable/esp32s3/api-reference/storage/nvs_flash.html)

NVS nie powinno jednak dostawać nowego zapisu co minutę.

## Nowa konstrukcja

Rozdzielamy trzy pojęcia:

### 1. `boot_id`

Numer diagnostyczny firmware — może pozostać jako wartość NVS/RTC i służyć do korelacji logów i crashów.

### 2. `boot_nonce`

64-bitowy losowy nonce ustalany raz na boot.

### 3. `sample_seq`

32-bitowy licznik RAM zaczynający się od 0 na dany boot.

Rekord:

```text
boot_nonce + sample_seq
```

staje się źródłem tożsamości telemetrycznej.

### Praktyczna postać

Na ścieżce urządzenia możemy używać:

```text
b<16-hex>-s<8-hex>
```

np.:

```text
b7A12...E4-s0000012C
```

Dokładna szerokość tekstu zostanie zamrożona razem z implementacją.

### Po co nonce, skoro istnieje `boot_id`?

Bo nonce rozwiązuje praktyczny problem torn-write NVS bez zapisu NVS na każdą próbkę.

ESP32-S3 ma sprzętowy RNG. Dokumentacja ESP-IDF rozróżnia sytuację z aktywnym RF, gdzie `esp_random()` dostarcza prawdziwą entropię, od okresu bez aktywnego źródła RF; dokumentacja wskazuje również, że bootloader zasila stan RNG entropią potrzebną do startu. Dla nonce generowanego po uruchomieniu Wi-Fi możemy użyć aktywnego źródła RF. [ESP-IDF Random Number Generation](https://docs.espressif.com/projects/esp-idf/en/v5.5/esp32s3/api-reference/system/random.html)

### Ważne zastrzeżenie

To nie jest matematyczny dowód unikalności jak monotoniczny licznik sprzętowy.

To jest praktyczna konstrukcja:

```text
device_id + 64-bit boot_nonce + sample_seq
```

z kolizją nonce o pomijalnym prawdopodobieństwie przy prawidłowo działającym RNG.

Nie będziemy pisać dokumentacji, że jest to "absolutnie gwarantowane".

## Decyzja

NVS:

```text
boot_id → diagnostyka
```

RAM:

```text
sample_seq
```

RNG:

```text
boot_nonce
```

Dane historyczne:

```text
record_id = boot_nonce + sample_seq
```

To jest korzystniejsze dla żywotności flash niż zapis licznika NVS co minutę.

---

# R52. `ACK / COMMIT` — RING NIE MOŻE „ZAPOMNIEĆ” O PRÓBCE PRZED POTWIERDZENIEM

**Status: ZAMKNIĘTE**

## Stan logiczny

Ring ma co najmniej:

```text
head
 tail
 inflight_count
```

oraz stan transportu:

```text
IDLE
BATCH_BUILT
REQUEST_SENT
WAIT_RESULT
COMMITTED
RETRY_WAIT
```

### Krytyczna zasada

`tail` oznacza:

```text
najstarszy rekord, który nie ma jeszcze potwierdzonego commit
```

Nie wolno przesuwać `tail` w chwili:

```text
Database.update(...)
```

ani:

```text
HTTP request accepted locally
```

Dopiero po jednoznacznym wyniku:

```text
AsyncResult.isResult()
&& success
```

możemy logicznie skonsumować batch.

Firebase dokumentuje, że wielościeżkowy `update()` może aktualizować wiele lokalizacji jedną operacją, a wielościeżkowe aktualizacje są wykonywane atomowo. [Firebase Realtime Database](https://firebase.google.com/docs/database/android/read-and-write)

## Retry

Przy:

```text
HTTP/network timeout
5xx
rozłączenie
brak wyniku
```

nie usuwamy rekordów z ring.

Ponowimy:

```text
ten sam batch
te same record_id
```

To daje idempotencję na poziomie danych.

### Nie stosować

```text
push()
```

w retry, bo każda próba może utworzyć nowy klucz.

Preferencja:

```text
set(record_id)
```

lub:

```text
update(multi_path)
```

z deterministycznym `record_id`.

FirebaseClient oficjalnie udostępnia zarówno `set(..., AsyncResult&)`, jak i `update<object_t>(..., AsyncResult&)`. [FirebaseClient Realtime Database docs](https://github.com/mobizt/FirebaseClient/blob/main/resources/docs/realtime_database.md)

## Single-flight

W V1:

```text
max 1 batch telemetryki w locie
```

Nie uruchamiamy drugiego uploadu tylko dlatego, że pierwsza funkcja timeoutowała lokalnie.

W poprzednim requestcie może jeszcze pracować `fbLoopWorker`.

Dlatego telemetryka musi mieć jawny stan:

```text
request_inflight
worker_busy
async_task_count
```

i dopiero po faktycznym zakończeniu ścieżki można uruchomić kolejny batch.

---

# R53. RTDB — DAILY SHARDING + CZAS JAKO POLE, NIE JAKO JEDYNA TOŻSAMOŚĆ

**Status: KANDYDAT V1 — wysoka pewność architektoniczna**

## Proponowana ścieżka

```text
/piec/telemetry/1m/YYYY/MM/DD/<record_id>
```

Rekord:

```json
{
  "v": 1,
  "ts": 1780000000,
  "mono": 123456789,
  "seq": 300,
  "q": 0,
  "te": 234,
  "tb": 612,
  "to": 540,
  "tos": 538,
  "tr": 421,
  "tp": 301,
  "trh": 225,
  "rh": 48,
  "p": 10132,
  "dym": 810,
  "kl": 57,
  "sy": 33,
  "pom": 1
}
```

Nazwy są celowo krótkie w kontrakcie sieciowym. Ostateczna mapa pól musi być zapisana w jednej tabeli schema.

## Dlaczego dzień zamiast jednej globalnej tablicy

Przy 1 próbce/min:

```text
1 dzień  = 1 440 rekordów
30 dni   = 43 200 rekordów
365 dni  = 525 600 rekordów
```

Jeden dzień to mały, naturalny zakres dla klienta.

Nie potrzebujemy jednego stale rosnącego węzła:

```text
/piec/telemetry/1m
```

którego wielkość z czasem rośnie bez ograniczenia.

## Query

Firebase RTDB obsługuje filtrowanie po wartości dziecka przez `orderByChild`, `startAt`, `endAt`. `.indexOn` pozwala przygotować indeks dla pól, po których aplikacja często wykonuje zapytania. [Firebase Security / Indexes](https://firebase.google.com/docs/database/security)

Telemetria powinna więc mieć:

```text
.indexOn: ["ts"]
```

na odpowiednim poziomie węzła dziennego.

### Nie używamy timestampu jako jedynego klucza

Dwa rekordy mogą mieć ten sam `ts` przy:

- szybkim ponowieniu,
- ręcznym teście,
- korekcie zegara,
- dwóch próbkach w jednej sekundzie,
- zmianie sposobu próbkowania w przyszłości.

`ts` jest więc:

```text
pole do sortowania/zakresów
```

a nie:

```text
primary key
```

## Unsynced time

Jeżeli `capture_ts == 0`:

nie należy wpychać rekordu do:

```text
/piec/telemetry/1m/2000/01/01
```

bo rok 2000 jest technicznym fallbackiem `DateTime((uint32_t)0)`, a nie prawdziwą datą pomiaru.

Preferowany model V1:

```text
/piec/telemetry/unsynced/<record_id>
```

z:

```text
q |= TIME_INVALID
mono = ...
```

Kiedy czas stanie się wiarygodny, nowe próbki trafiają już do shardów czasowych. Nie przepisujemy automatycznie starych rekordów tylko dlatego, że NTP właśnie się zsynchronizował.

---

# R54. LITTLEFS — `usedBytes()` JAKO AUTORYTAT, SUMA PLIKÓW JAKO DIAGNOSTYKA

**Status: ZAMKNIĘTE**

## Obserwacja z kodu

Obecny `logFsSizeGuard()` liczy:

```text
log_a
+ log_b
+ log_krytyczny
+ panel firmware
```

pomijając m.in.:

```text
hist_short
hist_long
log_ustawien
/coredumps/*
```

Jednocześnie w setupie kod już zbiera rozmiary wszystkich tych plików do osobnych cache'y.

## Problem architektoniczny

Suma `File.size()` jest:

```text
LOGICAL_USED
```

natomiast:

```cpp
LittleFS.usedBytes()
```

jest bliższa rzeczywistemu zużyciu przestrzeni FS i powinna być źródłem decyzji quota.

Arduino-ESP32 udostępnia `LittleFS.totalBytes()` i `LittleFS.usedBytes()`, a implementacja opiera te informacje o stan samego systemu plików. [arduino-esp32 LittleFS](https://github.com/espressif/arduino-esp32/blob/master/libraries/LittleFS/src/LittleFS.cpp)

### Decyzja

Rozdzielić:

```text
PHYSICAL_USED = LittleFS.usedBytes()
PHYSICAL_TOTAL = LittleFS.totalBytes()
```

od:

```text
LOGICAL_LOGS
LOGICAL_HISTORY
LOGICAL_PANEL
LOGICAL_COREDUMPS
LOGICAL_SPOOL
```

Suma logiczna służy do diagnostyki i raportowania. Quota bezpieczeństwa ma bazować na realnym `usedBytes()` + zarezerwowanych progach.

## Quota

Nie przyjmujemy arbitralnie „20% wolnego”.

Model:

```text
TOTAL
- RESERVE_CRITICAL
- RESERVE_HISTORY
- RESERVE_PANEL_FW
- RESERVE_COREDUMP
- RESERVE_SPOOL
= budżet operacyjny
```

Wartość rezerwy ustalimy po pomiarze realnych rozmiarów na urządzeniu.

## Coredump archive

Aktualnie:

```text
20 × 64 KiB = 1 310 720 B
≈ 1.25 MiB
```

To musi być traktowane jako jawna część budżetu LittleFS, a nie „darmowy” katalog.

---

# R55. LITTLEFS MOUNT — KONIEC AUTOMATYCZNEGO FORMATOWANIA PO BŁĘDZIE

**Status: ZALECENIE P0**

Aktualny startup robi:

```cpp
LittleFS.begin(false)
```

a przy porażce:

```cpp
LittleFS.begin(true)
```

Arduino-ESP32 dokumentuje, że `begin(true)` pozwala sformatować partycję, gdy mount się nie powiedzie. [arduino-esp32 LittleFS](https://github.com/espressif/arduino-esp32/blob/master/libraries/LittleFS/src/LittleFS.cpp)

## Konsekwencja

Przy przyszłym persistent telemetry spool:

```text
mount error
→ format
→ telemetry spool znika
→ historia znika
→ logi znikają
→ coredump archive znika
```

To jest przeciwne celowi telemetryki diagnostycznej.

## Decyzja

Produkcja:

```text
begin(false)
    ↓ fail
critical event
    ↓
NO AUTOMATIC FORMAT
```

Formatowanie:

```text
jawna akcja administracyjna
```

lub specjalny, jednoznaczny first-boot/factory-reset flow.

Nie chcemy, żeby zwykła korupcja po zaniku zasilania była interpretowana jako „pusty nowy dysk”.

---

# R56. COREDUMP — BEZPIECZNY FLOW `CHECK → COPY → VERIFY → ERASE`

**Status: P0 DESIGN**

## Aktualny kod

`archiwizujCoredumpJesliCrash()`:

1. sprawdza reset jako crash,
2. robi `esp_core_dump_image_get()`,
3. kopiuje dane po 1024 B,
4. zapisuje je do LittleFS,
5. zamyka plik,
6. kasuje partycję źródłową.

Dwa problemy są już potwierdzone w kodzie:

### Problem 1

Brak:

```cpp
esp_core_dump_image_check()
```

### Problem 2

Wartość zwracana przez:

```cpp
f.write(...)
```

nie jest sprawdzana.

## Bezpieczny algorytm

```text
esp_core_dump_image_check()
        ↓ OK
esp_core_dump_image_get()
        ↓
create /coredumps/<temp>
        ↓
read raw flash chunk
        ↓
write chunk
        ↓
verify write count
        ↓
repeat
        ↓
close
        ↓
verify file size == dump size
        ↓
optional final file validation
        ↓
rename temp → final
        ↓
ONLY NOW
esp_core_dump_image_erase()
```

Jeżeli którakolwiek faza zawiedzie:

```text
source dump remains intact
```

ESP-IDF dokumentuje checksum core dumpów; CRC32 daje niższy koszt obliczeniowy i pamięciowy od SHA-256, podczas gdy ELF pozwala zachować bogatsze informacje, ale generuje większy plik. [ESP-IDF Core Dump](https://docs.espressif.com/projects/esp-idf/en/v5.5/esp32/api-guides/core_dump.html)

## 64 KiB

Obecny partition:

```text
0x10000 = 65536 B
```

Jest sensownym punktem wyjścia, ale ELF + `MAX_TASKS_NUM=64` nie gwarantuje, że każdy crash zmieści się bez obcięcia.

Dokumentacja ESP-IDF wskazuje, że maksymalna liczba task snapshotów wpływa na zawartość dumpa, a ELF jest większy od binary. [ESP-IDF Core Dump](https://docs.espressif.com/projects/esp-idf/en/release-v5.4/esp32/api-guides/core_dump.html)

### Test obowiązkowy

Nie zmieniać partycji w ciemno.

Uruchomić kontrolowany crash:

```text
/testcrash TAK
```

następnie:

```text
archiwizacja
↓
size
↓
CRC
↓
OFFLINE `esp-coredump` z dokładnie tym ELF
```

Dopiero wynik realnego dumpa pozwoli określić, czy:

```text
64 KiB = OK
```

czy:

```text
64 KiB = ograniczenie diagnostyki
```

---

# R57. FIREBASE SINGLE-FLIGHT — `taskCount()` JAKO TELEMETRIA TRANSPORTOWA

**Status: ZAMKNIĘTE ARCHITEKTONICZNIE; TEST IMPLEMENTACYJNY WYMAGANY**

FirebaseClient dokumentuje, że `AsyncClientClass` posiada FIFO dla zadań asynchronicznych. Dokumentacja opisuje również `taskCount()` jako informację o liczbie zadań oraz `stopAsync()` do zatrzymania/usunięcia zadań. [FirebaseClient](https://github.com/mobizt/FirebaseClient)

## Aktualny projekt

Istnieje już jeden:

```text
AsyncClientClass fbAsyncClient(fbSSLClient)
```

i jeden worker:

```text
fbLoopWork
```

### Decyzja

Telemetryka używa tego samego klienta.

Nie tworzymy:

```text
fbTelemetryClient
fbTelemetryApp
fbTelemetryLoop
TelemetryTask
```

## Backpressure

Przed utworzeniem batcha telemetrycznego sprawdzamy:

```text
fbLoopWorkerZajety()
taskCount()
circuit breaker
WiFi
```

V1:

```text
jeżeli worker busy → nie dodawaj telemetrycznego requestu
jeżeli kolejka > ustalony limit → nie dodawaj kolejnego
jeżeli circuit open → ring czeka
```

Nie ustalamy arbitralnie dużego limitu kolejki.

Przewidywany limit V1:

```text
1 telemetry request in-flight
```

a obecne inne requesty Firebase pozostają własnym ruchem systemu.

## Współdzielenie Core 1

`fbLoopWork` jest przypięty do Core 1 z priorytetem 1.

To oznacza konkurencję o ten sam rdzeń/priorytet z częścią głównej pracy Arduino.

Nie jest to dowód, że system będzie niestabilny.

Jest to jednak parametr, który trzeba mierzyć:

```text
loop jitter
scheduler delay
control-cycle duration
WDT margin
```

przed i po telemetryce.

---

# R58. JAKOŚĆ DANYCH — `VALID`, `STALE`, `SIMULATED`, `TIME_INVALID`

**Status: ZAMKNIĘTE KIERUNKOWO**

Aktualna historia zapisuje bieżące zmienne:

```text
temperatura...
cisnienieOdczytane
wilgotnoscOdczytana
pozycjaKlapa
pozycjaSyberek
pompa
```

Nie każda z nich musi być świeżym pomiarem dokładnie w momencie próbkowania historii.

Przykład z kodu:

```text
DS18B20 invalid
→ retain last good

DHT22 error
→ lokalny fallback
```

## Szczególna obserwacja dotycząca DHT

Kod obecnie robi:

```cpp
if (!isnan(wilgotnoscOdczytanaLok))
    poprzedniaWilgotnosc = wilgotnoscSkorygowana;
else
    wilgotnoscOdczytanaLok = poprzedniaWilgotnosc;
```

To jest **co najmniej semantycznie niejednoznaczne**, ponieważ fallback przechowuje wartość z `wilgotnoscSkorygowana`, a później podstawia ją jako `wilgotnoscOdczytanaLok`.

Nie nazywamy tego jeszcze jednoznacznie błędem funkcjonalnym bez pełnego audytu korekcji RH, ale telemetryka nie może ukryć tej różnicy.

## Quality bitmask

Kandydat:

```text
Q_TIME_VALID
Q_VALID_TEMP_OUT
Q_STALE_TEMP_OUT
Q_VALID_TEMP_BOILER
Q_STALE_TEMP_BOILER
Q_VALID_HUMIDITY
Q_STALE_HUMIDITY
Q_SENSOR_ERROR
Q_FILTER_HELD
Q_SIMULATED
Q_RANGE_REJECTED
```

Dokładne rozmieszczenie bitów zostanie zminimalizowane po finalnej mapie wszystkich sensorów.

### Zasada

Nie chcemy 20 stringów:

```json
"humidity_status":"sensor_error"
```

w każdej próbce.

Lepiej:

```text
q = bitmask
```

oraz ewentualnie osobny `age` tylko tam, gdzie naprawdę potrzebny.

---

# R59. RING SIZE — 24 H JAKO V1, NIE „NIESKOŃCZONY BUFFER”

**Status: KANDYDAT V1**

Przy:

```text
1 sample / minute
1440 samples
~48 B/sample
```

otrzymujemy:

```text
~69 KB netto struktury
```

plus niewielki narzut sterujący.

## Semantyka

Ring jest buforem:

```text
recent unsent history
```

a nie:

```text
permanent archive
```

### Gdy ring pełny

Najstarsza próbka może zostać usunięta **wyłącznie**, gdy polityka systemu jawnie dopuszcza loss.

W normalnym V1:

```text
head == tail po pełnym
→ telemetryOverflow
→ recordDropped++
→ nie ukrywamy problemu
```

Nie wolno po cichu nadpisywać najstarszych danych bez licznika utraty.

## Dlaczego nie 7 dni w RAM

7 dni:

```text
10080 × 48 B ≈ 483.8 KiB
```

Technicznie mieści się w PSRAM, ale nie daje trwałości i zaczyna mieszać dwie funkcje:

```text
RAM cache
```

oraz:

```text
offline archive
```

7/30 dni będzie zadaniem dla późniejszego persistent spool.

---

# R60. PERSISTENT SPOOL — SEGMENTY, NIE JEDEN ROSNĄCY PLIK

**Status: V2 DESIGN**

## Dlaczego segmenty

Jeden plik:

```text
telemetry.bin
```

i usuwanie pierwszych rekordów oznacza trudną gospodarkę miejscem i potencjalnie kosztowne przepisywanie.

Lepszy model:

```text
tele_0001.bin
tele_0002.bin
tele_0003.bin
...
```

Każdy segment:

```text
HEADER
RECORD
RECORD
RECORD
...
COMMIT
```

## Rekord

Kandydat:

```text
magic
format_ver
record_len
record_id
sample payload
crc32
```

## Recovery

Po starcie:

```text
scan segments oldest→newest
↓
sprawdź magic/version/len
↓
sprawdź CRC
↓
znajdź ostatni poprawny record
↓
odrzuć tylko uszkodzony suffix
↓
odtwórz head/tail
```

Nie potrzebujemy osobnego indeksu zapisującego się co minutę.

## ACK

Segment wolno skasować dopiero gdy:

```text
WSZYSTKIE rekordy segmentu = COMMITTED
```

Dzięki temu deletion jest operacją całego pliku, a nie przesuwaniem danych wewnątrz.

LittleFS zostało zaprojektowane z mechanizmami power-loss recovery i dynamic wear leveling, ale aplikacyjny spool nadal musi posiadać własny CRC/commit, aby po przerwaniu zapisu odróżnić pełne rekordy od częściowo zapisanej końcówki. [littlefs](https://github.com/littlefs-project/littlefs)

---

# R61. RTDB LIMITS — TELEMETRIA JEST DALEKO PONIŻEJ LIMITÓW, ALE QUERY/RETENTION MAJĄ ZNACZENIE

**Status: ZAMKNIĘTE**

Oficjalna dokumentacja Firebase podaje m.in.:

```text
write rate:                 1000 writes/s
SDK single write request:   16 MB
bytes written:              64 MB/min
```

oraz maksymalny czas wykonywania pojedynczego query 15 min. Multi-path update podlega limitowi rozmiaru requestu. [Firebase RTDB Limits](https://firebase.google.com/docs/database/usage/limits)

Dla jednego urządzenia:

```text
1 sample/min
```

to:

```text
0.0167 write/s
```

a przy batchu 10:

```text
~6 batchy/godz
```

czyli skala jest praktycznie pomijalna względem globalnego limitu zapisu.

Problemem nie jest więc maksymalny throughput Firebase.

Problemem są:

```text
ciągłość po WAN failure
query size
retention
koszt RAM/TLS/request
kolejka AsyncClient
```

## Ważniejszy wniosek

Nie optymalizujemy V1 pod limity globalne Firebase.

Optymalizujemy pod:

```text
czas blokowania ESP32
```

oraz:

```text
liczbę requestów
```

---

# R62. SECURITY RULES — TELEMETRYKA NIE MOŻE OTWORZYĆ `/piec/cmd`

**Status: P0 SECURITY DESIGN**

Firebase Security Rules rozróżniają:

```text
.read
.write
.validate
.indexOn
```

i umożliwiają warunkowanie dostępu przez `auth.uid`, `auth.token` oraz zawartość `data/newData`. `.validate` pozwala egzekwować strukturę i typ danych. [Firebase Security Rules](https://firebase.google.com/docs/database/security) [Rules conditions](https://firebase.google.com/docs/database/security/rules-conditions)

## Docelowy model

Urządzenie:

```text
WRITE /piec/devices/<device>/telemetry/**
READ  minimum necessary
NO WRITE /piec/<device>/cmd
```

Aplikacja użytkownika:

```text
READ telemetry
WRITE cmd — tylko z odpowiednią rolą/claim
```

Nie może być tak, że token używany przez firmware umożliwia:

```text
write całego /piec
```

bo wtedy awaria firmware, wyciek sekretu albo kompromitacja urządzenia staje się kompromitacją całej bazy.

## Istniejący stan

Firmware obecnie używa:

```text
LegacyToken / Database Secret
fbSSLClient.setInsecure()
```

To zostaje w osobnym workstreamie security hardening i **nie jest mieszane z pierwszą implementacją telemetryki**.

### Decyzja

Telemetryka musi od początku mieć taką strukturę ścieżek, aby późniejsza migracja auth nie wymagała przenoszenia danych:

```text
telemetry
status
cmd
```

jako trzy różne domeny bezpieczeństwa.

---

# R63. TEST MATRIX — KAŻDY WAŻNY INVARIANT MA MIEĆ SWÓJ TEST

**Status: ZAMKNIĘTE — wejście do implementation gate**

## Test A — normalna praca

```text
24 h
1440 nominalnych próbek
```

PASS:

```text
seq ciągły
0 drop
0 duplicate logical id
WDT 0
control loop unchanged
```

## Test B — WAN OFF

```text
WiFi connected
Internet unavailable
```

PASS:

```text
sterowanie działa
ring rośnie
Firebase request nie blokuje sterowania
brak task explosion
```

## Test C — WAN return

```text
WAN OFF przez 30–60 min
WAN ON
```

PASS:

```text
backlog jest wysłany
kolejność rekordów zachowana
retry nie tworzy duplikatów
```

## Test D — worker timeout

Wymusić:

```text
blokadę DNS / TCP / TLS
```

PASS:

```text
control task nie dostaje WDT
brak drugiego fbLoopWork
brak use-after-free
```

## Test E — power loss podczas spool write

V2:

```text
losowy moment power cut
```

PASS:

```text
prefix rekordów jest poprawny
uszkodzony suffix jest odrzucony
starsze rekordy pozostają
```

## Test F — power loss podczas coredump archive

PASS:

```text
źródłowy coredump pozostaje do następnego bootu
lub gotowy plik archiwalny istnieje w całości
```

Nigdy:

```text
source erased + partial archive
```

## Test G — ring overflow

Wymusić brak WAN na czas dłuższy niż ring capacity.

PASS:

```text
overflow licznika > 0
jawny alarm
brak fałszywej informacji o kompletności historii
```

## Test H — clock invalid → NTP sync

PASS:

```text
ts=0 + TIME_INVALID przed sync
correct YYYY/MM/DD po sync
brak próbek wrzuconych sztucznie do 2000/01/01
```

## Test I — sensor stale

Wymusić brak ważnych DS18B20/DHT22.

PASS:

```text
wartość może pozostać last-good
quality mówi STALE/ERROR
```

Nigdy:

```text
last-good prezentowany jako nowy pomiar bez oznaczenia
```

---

# R64. IMPLEMENTATION GATE — NIE ZMIENIAMY C++ PRZED SPEŁNIENIEM TYCH WARUNKÓW

**Status: PLAN GOTOWY DO PRZEJŚCIA W IMPLEMENTACJĘ PO JESZCZE JEDNYM AUDYCIE**

Przed pierwszym commitem telemetrycznym musimy mieć zamknięte:

```text
[ ] actual generated sdkconfig.<env>
[ ] dokładny zakres/własności wszystkich pól TelemetrySample
[ ] pressure +18 opisane domenowo
[ ] freshness source dla każdego pola
[ ] final quality bitmask
[ ] final boot_nonce generation point
[ ] final record_id encoding
[ ] FS physical quota algorithm
[ ] coredump safe-copy flow
[ ] single-flight Firebase test
[ ] RTDB rules draft
[ ] 24h baseline metrics
```

## Zasada zmian

Pierwsza implementacja ma być jednym logicznym pakietem:

```text
TelemetrySample
+
TelemetryRing
+
producer w historiaZapiszProbke()
+
shared Firebase uploader
```

Bez jednoczesnej zmiany:

```text
platformio platform
Arduino core
FirebaseClient version
Firebase auth
TLS verification
partition layout
```

Każda z tych zmian osobno zwiększałaby przestrzeń błędów i utrudniała przypisanie regresji.

---

# AKTUALIZACJA MAPY — R1–R64

Projekt jest obecnie na poziomie:

```text
RESEARCH / DESIGN
          ↓
INVARIANTS + FAILURE SEMANTICS
          ↓
CONCRETE DATA CONTRACT
          ↓
IMPLEMENTATION GATE
```

Najważniejsze ustalone zasady:

```text
1. Jeden producer próbek: historiaZapiszProbke().
2. Jeden ring PSRAM.
3. Jeden shared Firebase client.
4. Jeden in-flight telemetry batch.
5. Nie przesuwamy tail przed COMMIT.
6. Retry używa tych samych record_id.
7. Timestamp ≠ primary key.
8. boot_nonce + sample_seq → telemetry identity.
9. boot_id/NVS → diagnostyka, nie per-minute uniqueness.
10. status.updatedAt nie jest czasem Unix.
11. Quality bitmask opisuje świeżość/ważność.
12. LittleFS quota bazuje na fizycznym usedBytes().
13. LittleFS mount failure nie formatuje automatycznie danych.
14. Coredump: CHECK → COPY → VERIFY → ERASE.
15. Persistent spool dopiero jako V2.
16. RTDB telemetry shardowana po dniu.
17. `/status`, `/telemetry`, `/cmd` są oddzielnymi domenami bezpieczeństwa.
18. Żadnego toolchain/library upgrade w tym samym commicie.
```

## NOWY NASTĘPNY BLOK RESEARCHU

```text
R65  dokładna inwentaryzacja wszystkich pól sensorów → freshness age
R66  zakresy i jednostki → final fixed-point schema
R67  dokładna kolejność inicjalizacji boot_nonce / WiFi / telemetry
R68  pomiar task stack high-water + Core 1 contention baseline
R69  formalny payload batcha i maksymalny rozmiar JSON
R70  draft RTDB Security Rules + `.validate` schema
R71  quota/reserve calculator na realnym LittleFS
R72  final implementation checklist + rollback strategy
```

**Nie wykonywać jeszcze zmian w firmware przed R65–R72.**

---

# R65. SENSOR → FRESHNESS: INWENTARYZACJA ŹRÓDEŁ I CZĘSTOTLIWOŚCI

**Status: ZAMKNIĘTE DLA OBECNEGO KODU**

## Źródło prawdy

Aktualne zadania sensorowe są rejestrowane następująco:

```text
Czujnik_DS()          ~2816 ms
wilgotnosc()          ~3000 ms
cisnienie()           5000 ms
RTC()                 2000 ms
historiaZapiszProbke() 60000 ms
```

Wartość telemetryczna nie jest więc „nowym odczytem z każdego czujnika o 12:00:00”.

Jest:

```text
snapshot stanu dostępnego w chwili wykonania historii
```

## DS18B20

`Czujnik_DS()` wywołuje kilka instancji `odczytajTemperature()`.

Zakresy ochronne zapisane w kodzie:

```text
ogrz                -   0 .. 160 °C
panel               - -30 .. 160 °C
pokoj               - -50 ..  50 °C
bojler              -   0 .. 160 °C
zewn                - -30 ..  50 °C
trociny             - -30 .. 120 °C
powrot              - -30 .. 120 °C
```

Dodatkowo istnieje filtr rate-of-change. Gdy skok jest niewiarygodny, funkcja zwraca ostatnią dobrą wartość.

### Konsekwencja

W obecnym interfejsie:

```cpp
float odczytajTemperature(...)
```

nie da się wywnioskować z samej zwróconej liczby, czy:

```text
odczyt = świeży
```

czy:

```text
odczyt = ostatnia dobra wartość po odrzuceniu
```

### Decyzja implementacyjna

Nie będziemy zmieniać wszystkich wywołań automatyki na nowy typ w pierwszym patchu.

Dodamy warstwę metadata równolegle do istniejących floatów:

```text
value
last_valid_ms
quality
```

a obecne floaty pozostaną kontraktem dla automatyki.

Pozwoli to telemetryce dowiedzieć się:

```text
czy wartość została odświeżona
```

bez ryzyka dużej regresji w logice sterowania.

## DHT22

`wilgotnosc()` wykonuje `read_dht()` co ~3 s.

W przypadku błędu ustawia lokalny odczyt na `NAN`, a następnie używa poprzedniej wartości.

To oznacza, że telemetryka musi rozróżniać:

```text
RH świeżo odczytane
```

i:

```text
RH odziedziczone z poprzedniego poprawnego odczytu
```

### Uwaga jakościowa

Obecny kod przechowuje `poprzedniaWilgotnosc = wilgotnoscSkorygowana` przed późniejszym przeliczeniem bieżącego `wilgotnoscSkorygowana`.

Dlatego nie zakładamy jeszcze bez dodatkowego testu, że fallback jest dokładnie „ostatnią surową wartością DHT”.

**Nie traktujemy tego jako potwierdzonej awarii sterowania.**

Traktujemy jako wymaganie dokumentacji semantyki RH.

## Ciśnienie

`cisnienie()` wykonywane co 5 s.

Jeżeli wynik `bmp.readPressure()` nie jest poprawny, zostaje ostatnia wartość dobra.

Kod obecnie wykonuje domenową korektę:

```text
pressure_hpa = BMP/100 + 18
```

Przed implementacją finalnego pola `p` należy potwierdzić:

```text
czy +18 jest offsetem kalibracyjnym
jaka dokładnie jest jednostka
czy offset jest częścią kalibracji urządzenia
czy powinien być przeniesiony do konfiguracji
```

### Decyzja

Nie zmieniamy korekcji podczas wdrożenia telemetryki.

Telemetryka ma odwzorowywać aktualne zachowanie i nazwać jednostkę jednoznacznie.

---

# R66. FIXED-POINT SCHEMA — FINALNA DECYZJA O ZAKRESACH

**Status: DRAFT V1**

## Temperatury

Do temperatur używamy:

```text
int16_t × 10
```

czyli:

```text
-3276.8 .. +3276.7 °C
```

co wielokrotnie przewyższa aktualne zakresy programowe.

Nie potrzebujemy osobnego sentinel `-32768`, ponieważ stan błędu/ważności znajduje się w `quality`.

## Wilgotność

Nie używamy `uint8_t` bez dodatkowej analizy korekcji, ponieważ `wilgotnoscSkorygowana` jest wynikiem obliczeń, a nie bezpośrednim ograniczeniem sprzętowym 0–100.

W V1 preferencja:

```text
int16_t rh_x10
```

i walidacja po stronie producenta/firmware.

Daje to:

```text
±3276.7 %
```

czyli duży margines na błąd obliczeń, ale nadal tylko 2 B.

## Ciśnienie

Preferencja:

```text
uint16_t pressure_x10
```

z jednostką:

```text
hPa × 10
```

po potwierdzeniu semantyki `+18`.

## Dym

`czujnikDymuOdczyt` jest wartością surową ADC w zakresie odpowiadającym 12-bitowemu odczytowi, więc:

```text
uint16_t
```

wystarcza.

Stan świeżości jest już istniejącą zmienną:

```text
czujnikDymuSwiezyOdczyt
```

i powinien zostać włączony do jakości telemetrycznej.

## Pozycje

```text
klapa   uint8_t
syberko uint8_t
pompa   uint8_t/bool
```

Wartości są procentowe / binarne i mieszczą się w 1 B.

## Wynik modelu pamięci

Kandydat około:

```text
48 B / sample
```

Ring 24h:

```text
69 120 B netto
```

czyli około:

```text
67.5 KiB
```

plus metadata ring.

---

# R67. `BOOT_NONCE` — MOMENT GENEROWANIA I SEMANTYKA

**Status: ZAMKNIĘTE**

## Cel

Nonce nie ma oznaczać „sekundy startu”.

Ma oznaczać:

```text
konkretną sesję boot firmware
```

## Wygenerowanie

Nie generować nowego nonce przy każdej próbce.

Schemat:

```text
setup
 ↓
uruchomienie potrzebnych źródeł entropii
 ↓
generuj 64-bit boot_nonce
 ↓
nie zmieniaj aż do restartu
```

ESP32-S3 posiada RNG. Oficjalna dokumentacja rozróżnia okres aktywnego źródła RF od czasu, gdy dostępna jest tylko wcześniej zainicjalizowana entropia; dla zastosowania telemetrycznego preferujemy generowanie nonce po uruchomieniu ścieżki Wi-Fi, gdy sprzętowe źródło RF jest aktywne. [ESP-IDF Random Number Generation](https://docs.espressif.com/projects/esp-idf/en/v5.5/esp32s3/api-reference/system/random.html)

## Device identity

Firmware już działa jako konkretne urządzenie. ESP-IDF udostępnia fabrycznie programowany base MAC z eFuse i API `esp_read_mac()`. [ESP-IDF MAC](https://docs.espressif.com/projects/esp-idf/en/stable/esp32s3/api-reference/system/misc_system_api.html)

Nie musimy jednak umieszczać pełnego MAC-a w każdym `record_id`, ponieważ urządzenie jest już kontekstem ścieżki `/piec/...`.

## Ostateczna tożsamość

```text
device context
+
boot_nonce
+
record_seq
```

`boot_id` może istnieć równolegle jako diagnostyka crashów.

---

# R68. CORE 0 / CORE 1 — BASELINE PRZED TELEMETRIĄ

**Status: TEST GATE**

## Obecna topologia

```text
Core 0:
  tgTask
  tgPollTask
  historiaTask

Core 1:
  loopTask / scheduler
  fbLoopWork
  dnsLookup worker
```

`tgTask`, `tgPollTask` i `historiaTask` tworzone są z 8192 słów stosu i przypięte do Core 0.

`fbLoopWork` jest tworzony z 8192 słów stosu i przypięty do Core 1.

## Konsekwencja

Telemetria ma:

```text
producer = Core 1
uploader/orchestration = Core 0
network worker = istniejący Core 1
```

Sama operacja dodania rekordu do ring musi być bardzo krótka.

Najdroższe rzeczy:

```text
JSON
TLS
HTTP
LittleFS
String
```

nie mogą trafić do sekcji producenta w Core 1.

## Metryki baseline

Przed pierwszą zmianą C++ należy zebrać:

```text
loop iteration duration
TG iteration duration
scheduler jitter dla historii
stack HWM loopTask
tgTask
tgPollTask
historiaTask
fbLoopWork
free internal heap
largest internal block
free PSRAM
largest PSRAM block
```

oraz:

```text
FB queue taskCount()
```

w stanie:

```text
WAN OK
WAN OFF
WAN RETURN
```

## Cel

Po telemetryce nie może pojawić się wzrost:

```text
control-loop latency
```

który zmienia zachowanie automatyki.

Nie ustalamy tu jeszcze arbitralnej liczby milisekund jako PASS; najpierw musimy zmierzyć realny baseline tej wersji firmware.

---

# R69. PAYLOAD BATCH — 5 / 10 / 20 SAMPLES JAKO EKSPERYMENT, NIE DOGMAT

**Status: TEST PARAMETRYCZNY**

## Cel

Przy 1 próbce/minutę pojedynczy upload co minutę jest funkcjonalnie możliwy, ale zwiększa liczbę TLS/HTTP operacji.

Proponujemy benchmark:

```text
batch = 5
batch = 10
batch = 20
```

Dla rekordów ~48 B binary i ~150–250 B JSON netto na rekord orientacyjny payload będzie rzędu:

```text
5  → ~0.75–1.25 KB
10 → ~1.5–2.5 KB
20 → ~3–5 KB
```

Są to wartości projektowe do pomiaru, a nie gwarantowany rozmiar finalnego JSON.

## V1 start

Preferowany pierwszy test:

```text
10 próbek/request
1 request in-flight
```

Dlaczego 10:

```text
mały payload
mało requestów
krótki recovery backlogu
łatwe debugowanie
```

### Backlog math

Przy 30 minutach offline:

```text
30 samples
```

czyli:

```text
3 batch'e po 10
```

Przy 24 godzinach:

```text
1440 samples
144 batch'e po 10
```

Jeżeli V1 osiąga około jednego zakończonego requestu co ~15 s w warunkach dobrego WAN, teoretyczny czas opróżnienia 24h backlogu byłby około:

```text
144 × 15 s = 2160 s ≈ 36 min
```

To jest **tylko model idealny**. Realna wartość musi uwzględnić status, command polling, circuit breaker, opóźnienia i dostępny budżet TG.

## Zasada

Nie próbujemy opróżnić całego backlogu w jednej iteracji `tgTask`.

Maksymalnie:

```text
1 telemetry batch / TG iteration
```

lub mniej, gdy `TG_ITER_BUDGET_MS` nie pozwala.

---

# R70. RTDB RULES + VALIDATION — SCHEMA MA BYĆ WYMUSZANE PO STRONIE SERWERA

**Status: DRAFT DO TESTÓW FIREBASE EMULATOR / DEV PROJECT**

## Minimalny układ

```text
/piec
  /status
  /cmd
  /telemetry
    /1m
      /v1
        /YYYY
          /MM
            /DD
              /<record_id>
  /events
```

## Uprawnienia

Docelowo:

```text
device → write telemetry własnego urządzenia
device → brak write cmd
app user → read telemetry
app authorized role → write cmd
```

Firebase oficjalnie pozwala wykorzystywać `auth.uid`, custom claims w `auth.token`, zawartość `data/newData` oraz `.validate` do egzekwowania dostępu i struktury. [Firebase Security Rules Conditions](https://firebase.google.com/docs/database/security/rules-conditions)

## `.validate`

Dla telemetryki chcemy wymusić m.in.:

```text
v == 1
required fields exist
numeric type
range limits
```

Nie należy jednak na tym etapie robić reguły zbyt sztywnej dla pól diagnostycznych, które mogą być nieobecne przy błędzie sensora.

Przykładowo:

```text
q może mówić STALE
```

ale wartość nadal musi mieć poprawny typ.

Alternatywnie pole może być `null`, lecz wtedy trzeba jawnie zaprojektować regułę i klienta.

### Decyzja

V1 preferuje:

```text
wartość zawsze ma poprawny fixed-point type
q mówi, czy jest aktualna
```

zamiast mieszaniny:

```text
number | null | "NAN" | "ERR"
```

To upraszcza aplikację mobilną.

---

# R71. FILESYSTEM QUOTA — ALGORYTM OCHRONY PRZED SAMOZAGŁADĄ

**Status: DESIGN READY**

## Fakturowanie

Źródło fizyczne:

```text
used = LittleFS.usedBytes()
total = LittleFS.totalBytes()
```

Źródło logiczne:

```text
sum(logs)
sum(history)
panel fw
coredumps
spool
```

## Model rezerwy

Proponowana polityka:

```text
CRITICAL_FREE_MIN
```

zamiast samego `% used`.

Dodatkowo każdy subsystem ma własną deklarowaną quota:

```text
Q_HISTORY
Q_COREDUMP
Q_PANEL_FW
Q_LOGS
Q_TELEMETRY
```

## Priorytet przy braku miejsca

Nie kasować automatycznie danych sterowania/konfiguracji.

Priorytet retencji:

```text
1. konfiguracja / integralność systemu
2. możliwość zapisania kolejnego crash dumpa
3. log krytyczny
4. bieżąca historia
5. telemetry spool
6. starsze logi operacyjne
```

Dokładne priorytety muszą być jeszcze skonfrontowane z istniejącymi wymaganiami logów.

### Szczególny warunek

Telemetryczny spool **nigdy nie może doprowadzić do sytuacji**:

```text
LittleFS nearly full
→ coredump archive impossible
```

Dlatego quota spoola musi być hard capem, a nie „bierz wszystko co wolne”.

---

# R72. FINAL IMPLEMENTATION CHECKLIST + ROLLBACK

**Status: PRE-IMPLEMENTATION GATE**

## Przed zmianą firmware

```text
[ ] zachowany baseline main/platform/partitions/sdkconfig.defaults
[ ] zachowany generated sdkconfig.<env>
[ ] baseline stack/heap/CPU measurements
[ ] pressure +18 opisane
[ ] sensor freshness metadata zaprojektowana
[ ] final quality bitmask
[ ] boot_nonce strategy
[ ] final record_id
[ ] final schema v1
[ ] batch benchmark 5/10/20
[ ] single-flight semantics test
[ ] RTDB dev rules
[ ] LittleFS quota implementation design
[ ] coredump safe-copy implementation design
```

## Kolejność commitów

### Commit A — diagnostics only

Dodajemy wyłącznie:

```text
heap/PSRAM metrics
stack HWM
Firebase taskCount
telemetry counters placeholder
```

PASS → dopiero następny commit.

### Commit B — data metadata only

```text
freshness timestamps
quality state
boot_nonce/sample_seq
```

Bez Firebase upload.

PASS → test 24h.

### Commit C — RAM ring

```text
producer
ring
overflow counters
```

Bez sieci.

PASS → test restart/WDT.

### Commit D — Firebase single batch

```text
one request
one in-flight
same record IDs on retry
```

PASS → WAN fault injection.

### Commit E — batch/backlog

```text
10 records
retry/backoff
backlog drain
```

PASS → 24/48/72h.

### Commit F — LittleFS/coredump hardening

Osobno, aby problemy storage nie były mylone z telemetryką sieciową.

### Commit G — persistent spool V2

Dopiero po udowodnieniu, że RAM-ring + Firebase V1 spełniają wymagania.

### Commit H — security

Osobno:

```text
auth migration
TLS verification
rules hardening
secret removal
```

### Commit I — library/toolchain upgrade

Osobno:

```text
FirebaseClient
pioarduino
Arduino-ESP32
```

## Rollback

Każdy commit telemetryczny musi dać się wycofać bez:

```text
zmiany partycji
utraty historii
utraty ustawień
zmiany automatyki
```

W szczególności V1 nie może wymagać migracji `hist_short.csv` ani `hist_long.csv`.

---

# AKTUALIZACJA MAPY — R1–R72

Stan projektu:

```text
R1–R48  feasibility + architecture
R49–R64 concrete contracts + failure semantics
R65–R72 implementation gate preparation
```

Najważniejsza aktualna architektura:

```text
                   SENSOR STATE
                        │
                        ▼
              historiaZapiszProbke()
                        │
          ┌─────────────┴─────────────┐
          ▼                           ▼
   local history                 TelemetrySample
                                          │
                                          ▼
                                    RAM Ring PSRAM
                                          │
                                          ▼
                                     tgTask Core 0
                                          │
                                  single-flight gate
                                          │
                                          ▼
                                  fbLoopWork Core 1
                                          │
                                          ▼
                                      Firebase
                                          │
                                          ▼
                              /telemetry/1m/v1/YYYY/MM/DD
```

## Najważniejsze invariants

```text
I1  telemetry producer nie blokuje sterowania siecią/FS.
I2  jeden AsyncClient Firebase.
I3  jeden fbApp.loop path.
I4  maksymalnie jeden telemetry request in-flight.
I5  tail przesuwa się dopiero po commit.
I6  retry używa tych samych record_id.
I7  timestamp nie jest jedynym identyfikatorem.
I8  last-good ≠ fresh — quality musi to powiedzieć.
I9  physical FS usedBytes() jest źródłem quota.
I10 coredump source nie jest kasowany przed zweryfikowanym backupem.
I11 mount error nie formatuje automatycznie danych produkcyjnych.
I12 persistent spool ma twardą quota i nie zjada rezerwy crash/log.
I13 status i telemetry mają niezależne kontrakty.
I14 upgrade biblioteki/toolchain nie jest częścią telemetrycznego patcha.
```

## Następny research

Po R72 pozostaje jeszcze przed implementacją jeden bardzo konkretny audyt:

```text
R73–R80
  dokładna mapa wszystkich sensor-state globals
  ↓
  przygotowanie tabeli source → timestamp → quality
  ↓
  finalny JSON schema v1
  ↓
  finalny C++ memory layout
  ↓
  test harness dla fault injection
  ↓
  dopiero potem pierwszy kod telemetryczny
```

**Na tym etapie nadal NIE zmieniamy firmware.**

---

# R73. SOURCE → UPDATE → FRESHNESS MAP (DEEP AUDIT)

**Status: research complete**

## Cel

Przejście od ogólnego modelu `TelemetrySample` do dokładnego kontraktu pochodzenia danych. Nie kopiujemy bezpośrednio globalnych floatów bez informacji o tym, kiedy były ostatnio rzeczywiście zmierzone.

## Źródła obserwowane w aktualnym `main_centrala (3).cpp`

| Pole telemetryczne | Globalna zmienna / funkcja | Mechanizm aktualizacji | Nominalna częstotliwość | Ważna semantyka |
|---|---|---|---:|---|
| temperatura zewnętrzna | `temperaturaNaZewnatrz` / `Czujnik_DS()` | DS18B20 + `odczytajTemperature()` + filtr wiarygodności | ~2816 ms | po nieudanym odczycie funkcja może pozostawić poprzednią wartość albo w części awaryjnej ustawić `-1`; sama wartość nie mówi, czy jest świeża |
| temperatura bojlera | `temperaturaBojlera` / `Czujnik_DS()` | DS18B20 + filtr | ~2816 ms | jw. |
| temperatura ogrzewania | `temperaturaOgrzewania` / `Czujnik_DS()` | DS18B20 + filtr | ~2816 ms | jw. |
| średnia temperatura ogrzewania | `temperaturaOgrzewaniaSrednia` / `obliczanie_srednia()` | pochodna z cyklu pompy | ~2224 ms | **nie jest bezpośrednim pomiarem**; ma osobną semantykę i może mieć dłuższy wiek |
| temperatura powrotu | `temperaturaOgrzewania_Powrot` / `Czujnik_DS()` | DS18B20 + filtr | ~2816 ms | jw. |
| temperatura panelu | `temperaturaPaneluSlonecznego` / `Czujnik_DS()` | DS18B20 + filtr | ~2816 ms | jw. |
| temperatura pokoju | `temperaturaPomieszczenia` / `Czujnik_DS()` | DS18B20 + filtr | ~2816 ms | jw. |
| temperatura trocin | `temperaturaOgrzewania_Trociny` / `Czujnik_DS()` | DS18B20 + filtr | ~2816 ms | jw. |
| wilgotność surowa | `wilgotnoscOdczytana` / `wilgotnosc()` | `read_dht()` albo symulacja | ~3 s / interwał dynamiczny | przy błędzie DHT pozostaje wartość z poprzedniego stanu; bez osobnego wieku nie można odróżnić starej wartości od świeżej |
| wilgotność skorygowana | `wilgotnoscSkorygowana` / `wilgotnosc()` | wyliczana z wilgotności i temp. zewnętrznej | ~3 s / interwał dynamiczny | **wartość pochodna**, nie drugi niezależny sensor |
| ciśnienie | `cisnienieOdczytane` / `cisnienie()` | BMP280; przy NaN zachowuje poprzednią wartość | 5 s | aktualny wzór to `(bmp.readPressure()/100)+18`; znaczenie `+18` pozostaje otwartym punktem domenowym |
| dym | `czujnikDymuOdczyt` / `pozar()` | ADC zależny od duty-cycle czujnika | okresy ON/OFF + stabilizacja | istnieje już jawna flaga `czujnikDymuSwiezyOdczyt`; to wzorzec, który należy rozszerzyć na inne źródła |
| pompa | `pompaJestWlaczona()` | odczyt fizycznego GPIO (`digitalRead`) | snapshot | bieżący stan wykonawczy, nie „decyzja automatyki” |
| klapa | `pozycjaKlapa` | `serwoTick()` / `zlecServoRuch()` | tick ~20 ms | pozycja może być stanem logicznym/estymowanym, nie feedbackiem pozycji fizycznej |
| syberko | `pozycjaSyberek` | `serwoTick()` / `zlecServoRuch()` | tick ~20 ms | jw. |
| mieszadło | `mieszadloAktywnyStan` | automat ON/OFF | ~500 ms | rzeczywisty stan przekaźnika wg logiki programu |
| rozpalanie | `rozpalanieAktywne` | stan przejściowy / override | event-driven | nie jest konfiguracją; istniejący kod celowo nie zapisuje go do NVS |
| alarm CO | `alarmOgrzewanieWlaczone` | logika temperatury | event-driven | stan alarmu, który należy logować również jako event |
| alarm panelu | `alarmPanelWlaczone` | logika temperatury | event-driven | jw. |
| alarm dymu | `czyAlarmAktywny` | logika `pozar()` | event-driven | jw. |
| tryb serwa | `TrybSerwa` | konfiguracja | event/config | stan trybu, nie pomiar |

## Decyzja

Telemetryka V1 nie będzie udawała, że każdy globalny float jest świeżym pomiarem tylko dlatego, że funkcja `historiaZapiszProbke()` została wywołana.

Dodajemy metadane źródłowe w RAM:

```text
last_valid_ms[source]
last_attempt_ms[source]     // tylko tam, gdzie sensowne
quality[source]
```

`historiaZapiszProbke()` wykonuje snapshot, ale **nie ustala świeżości na podstawie samego momentu zapisu historii**.

## Minimalne stany jakości

```text
UNKNOWN   = nigdy nie było poprawnego pomiaru
FRESH     = aktualny pomiar wykonany w zaakceptowanym wieku
STALE     = pokazujemy ostatnią poprawną wartość, ale jej wiek przekracza próg
INVALID   = ostatnia próba była niepoprawna i nie ma wartości, której można ufać
SIMULATED = wartość pochodzi z jawnej symulacji
```

`STALE` nie oznacza automatycznie `INVALID`: dla diagnostyki ważne jest zachowanie ostatniej dobrej wartości oraz jej wiek.

## Progi freshness

Nie wpisujemy jeszcze arbitralnych sekund do kodu. Progi będą parametrem dokumentowanym per source; wartość pierwsza do testu:

```text
fresh_limit = max(3 × nominal_interval, 2 s)
```

ale **nie jest to jeszcze finalna wartość produkcyjna**. Dla źródeł event-driven i dymu próg musi być inny.

---

# R74. FINAL TELEMETRY DATA CONTRACT V1 — DRAFT

**Status: draft, przed kodem**

## Zasada

`TelemetrySample` nie jest kopią `HistoriaProbka`. Jego zadaniem jest opisanie stanu sterownika w jednym punkcie czasu oraz jakości tego snapshotu.

## Warstwa binarna w RAM / spool

Proponowany układ logiczny:

```cpp
struct TelemetrySample {
    uint64_t sessionNonce;
    uint32_t sampleSeq;
    uint32_t unixTs;          // 0 = brak wiarygodnego czasu
    uint32_t monoMs;          // diagnostyka / ordering lokalny

    int16_t tZewnX10;
    int16_t tBojlerX10;
    int16_t tOgrzX10;
    int16_t tOgrzSrX10;
    int16_t tPowrotX10;
    int16_t tPanelX10;
    int16_t tPokojX10;
    int16_t tTrocinyX10;

    int16_t rhX10;
    int16_t pressureX10;
    uint16_t dym;

    uint8_t klapaPct;
    uint8_t syberkoPct;

    uint16_t stateBits;
    uint16_t qualityBits;

    uint8_t ageZewnS;
    uint8_t ageBojlerS;
    uint8_t ageOgrzS;
    uint8_t ageOgrzSrS;
    uint8_t agePowrotS;
    uint8_t agePanelS;
    uint8_t agePokojS;
    uint8_t ageTrocinyS;
    uint8_t ageRhS;
    uint8_t agePressureS;
    uint8_t ageDymS;
};
```

To jest **układ logiczny**, nie finalne ABI C++: `static_assert(sizeof(...))` i `alignas` zostaną ustalone po pomiarze kompilatorem.

## Dlaczego fixed-point

Zamiast `float` przechowujemy temperatury i wielkości zmiennoprzecinkowe jako integer × 10. Korzyści:

- deterministyczny rozmiar rekordu,
- brak serializacji `NaN` w normalnym kanale danych,
- stabilne porównania,
- prostszy CRC/spool,
- brak zależności od reprezentacji IEEE w warstwie storage.

Wartości poza domeną powinny być oznaczane `qualityBits`, a nie kodowane jako magiczne `-999` bez definicji.

## `stateBits`

Pierwszy draft:

```text
bit 0  pump
bit 1  mixer
bit 2  rozpalanie
bit 3  alarm CO
bit 4  alarm panel
bit 5  alarm dym
bit 6  TrybSerwa bit0
bit 7  TrybSerwa bit1
bit 8  telemetry time valid
bit 9  smoke fresh
bit 10 RTC present
bit 11 NTP synchronized
```

Pozostałe bity zarezerwowane.

## `qualityBits`

Nie powielamy 11 osobnych enumów jako `uint8_t`, tylko używamy 2-bitowych pól w jednym `uint32_t`/`uint64_t` (finalny wybór po liczbie źródeł):

```text
00 UNKNOWN/INVALID
01 FRESH
10 STALE
11 SIMULATED
```

Jeżeli projekt będzie potrzebował rozróżnienia `INVALID` i `UNKNOWN`, rozszerzymy encoding przed V1; nie będziemy wciskać dwóch znaczeń do jednego stanu po cichu.

## Dym

`dym` + `dym_swiezy` z obecnego `/api/status` pozostaje wzorcem. W telemetryce stwierdzenie „nieswieży” musi być zachowane przy każdym rekordzie, który zawiera ostatnią wartość ADC.

---

# R75. SNAPSHOT CONSISTENCY / MULTICORE

**Status: research complete**

ESP-IDF FreeRTOS dla ESP32-S3 jest SMP; samo wyłączenie przerwań na jednym rdzeniu nie gwarantuje wyłączności wobec drugiego rdzenia. Dla współdzielonych struktur należy stosować sekcje krytyczne ze spinlockiem, a sekcje muszą być krótkie i nie mogą wykonywać blokujących API. citeturn465628search0

## Obserwacja z obecnego kodu

`historiaZapiszProbke()` już ma poprawny wzorzec dla historii:

```text
pobierzCzas()              // przed critical
copy globalnych wartości   // krótka sekcja krytyczna
wyjście z critical
CSV/String/FS              // poza critical
```

To jest dobry punkt wyjścia dla telemetryki.

## Ale telemetryka nie może kopiować wszystkiego pod `historiaMux`

`historiaMux` chroni historię, nie jest uniwersalnym lockiem dla całego modelu sterowania. W V1:

1. odczytujemy czasy/quality przed snapshotem,
2. pobieramy wartości,
3. dla struktur wielopolowych wymagających spójności stosujemy ich własny spinlock/atomowy mechanizm,
4. poza lockiem wykonujemy kodowanie i transport.

## Czy potrzebujemy seqlock dla wszystkich sensorów?

Na tę chwilę **nie**.

Większość wartości to pojedyncze `float`, `int`, `byte`, `bool`, które na tej platformie są wystarczająco proste do snapshotu, natomiast ryzyko niespójności jest większe dla:

- zestawu `pozycjaKlapa` + `pozycjaSyberek` + `ruch*.aktywny`,
- zestawu alarmów, jeżeli snapshot ma mieć semantykę „jednego momentu”,
- par `value + timestamp + quality` dla jednego sensora.

Najlepszy model to aktualizacja **jednego małego obiektu stanu źródła jako całości**, a nie osobne zapisy trzech globali.

## Decyzja

Nie dodajemy globalnego „mega-locka” obejmującego cały sterownik. Telemetryczny snapshot ma być tani i lokalny.

---

# R76. SESSION NONCE / RECORD ID — FORMALIZACJA

**Status: decyzja koncepcyjna**

## Cel

Retry tego samego batcha musi zapisać dokładnie te same rekordy. Restart firmware nie może z dużym prawdopodobieństwem wygenerować tych samych ID.

## Odrzucone podejście

```text
record_id = unix_timestamp
```

Odrzucone, bo:

- RTC może być niewiarygodny,
- NTP może skorygować zegar,
- reboot może powtórzyć sekundę,
- kilka próbek może mieć ten sam `unixTs`.

## Odrzucone jako jedyne źródło unikalności

```text
bootCounter z NVS + sampleSeq
```

Aktualny projekt słusznie używa NVS dla konfiguracji, ale nie chcemy zapisywać NVS przy każdej minucie tylko po to, aby budować ID. Power-loss dokładnie w czasie commit NVS komplikuje gwarancję monotoniczności.

## Proponowany model

Sesja firmware:

```text
sessionNonce : 64-bit random
sampleSeq    : uint32_t, zaczyna się od 1 i rośnie w RAM
```

ID na wire:

```text
<hex(sessionNonce)>-<hex(sampleSeq)>
```

Przykład formatu (nie konkretna wartość):

```text
7F3A9C12D4E5A6B1-00000127
```

## Ważne ograniczenie

Nie twierdzimy, że 64-bitowy random daje matematyczną gwarancję absolutnej unikalności. Daje bardzo małe prawdopodobieństwo kolizji, a bezpieczeństwo systemu opiera się także na:

```text
idempotent write
+ deterministic retry
+ device path
+ server validation
```

## Źródło entropy

ESP32-S3 ma sprzętowy RNG `esp_random()` / `esp_fill_random()`. Dokumentacja Espressif wskazuje, że prawdziwa entropia jest gwarantowana m.in. przy aktywnym RF (Wi-Fi/Bluetooth); poza aktywnym źródłem entropy wynik może być tylko pseudolosowy. citeturn875598search1

Dlatego:

- `sessionNonce` generujemy po uruchomieniu Wi-Fi albo po jawnej inicjalizacji źródła entropy,
- nie traktujemy bardzo wczesnego RNG jako kryptograficznego źródła bez sprawdzenia warunków.

## Praktyczna poprawka

Jeżeli telemetryka zaczyna buforowanie przed Wi-Fi, nonce może zostać pobrany po wcześniejszym wygenerowaniu entropy albo po starcie RF. Nie wolno czekać z działaniem całego sterownika tylko na nonce.

## Wniosek

`bootCounter` pozostaje w diagnostyce crash/WDT.
`sessionNonce + sampleSeq` jest identyfikacją telemetryczną.
Oba mechanizmy mają różne cele i nie powinny być ze sobą sztucznie łączone.

---

# R77. FIREBASE SINGLE-FLIGHT STATE MACHINE

**Status: decyzja architektoniczna**

FirebaseClient opisuje `AsyncClientClass` jako kolejkę FIFO. Udostępnia `taskCount()` oraz `stopAsync()`. Dokumentacja biblioteki potwierdza również, że asynchroniczne zadanie przechowuje przygotowane dane żądania w kolejce. citeturn465628search2turn465628search5

## V1 nie będzie kolejką „bez limitu”

Stan telemetryczny:

```text
IDLE
  ↓
PREPARE
  ↓
IN_FLIGHT
  ├── SUCCESS → COMMIT
  ├── TRANSIENT_ERROR → RETRY_WAIT
  └── HARD_ERROR → BLOCK/DIAG
```

Nie pozwalamy na:

```text
sample every 60s
→ enqueue forever
→ Firebase queue grows
→ RAM falls
```

## Jedna operacja telemetryczna

V1:

```text
telemetry_inflight == true
→ nie twórz kolejnego requestu
```

Nawet jeżeli `taskCount()` zwraca 0/1, własny stan in-flight pozostaje źródłem semantyki. `taskCount()` jest diagnostyką/głównym bezpiecznikiem, nie jedynym mechanizmem poprawności.

## Timeout

Timeout callera NIE oznacza automatycznie, że request przestał istnieć. Obecna infrastruktura `fbLoopWorker` została właśnie zaprojektowana z myślą o takim przypadku.

Dlatego telemetryka musi zachować batch jako `IN_FLIGHT` aż do jednoznacznego rozstrzygnięcia przez wspólną ścieżkę Firebase.

## Priorytet operacji

Aktualny `tgTaskFn()` ma faktyczną kolejność:

```text
Telegram alarm/commands
→ Firebase status
→ Firebase commands
→ SD resend
→ weather
```

Telemetryka nie może wejść przed bezpieczeństwo/komendy.

Proponowany punkt V1:

```text
Firebase commands
→ telemetry pump
→ SD resend / weather
```

ale tylko gdy:

```text
TG_ITER_HAS_BUDGET == true
&& !fbBlockedThisIter
&& WiFi connected
&& fbLoopWorker not busy
```

To jest propozycja do benchmarku, nie jeszcze kod.

---

# R78. BATCH PAYLOAD / MEMORY STRATEGY

**Status: draft + benchmark required**

Biblioteka FirebaseClient udostępnia `Database.update<object_t>()` do patchowania wielu pól jednocześnie. citeturn875598search3

## Dlaczego batch, a nie 10 × set()

Dla dziesięciu próbek/minuty:

```text
10 osobnych requestów
```

oznacza 10 handshake/task/queue interactions, podczas gdy jeden multi-child update może przekazać batch w jednym zadaniu.

## Model

```text
/piec/telemetry/1m/v1/YYYY/MM/DD
    {
      "recordA": {...},
      "recordB": {...},
      ...
    }
```

Każdy `record_id` jest osobnym dzieckiem.

## Bufor

Nie używamy `String` dla całego batcha.

Proponowany eksperymentalny bufor:

```text
PSRAM 8–16 KB
```

z dynamicznym rozmiarem dopiero po pomiarach.

Powód: w obecnym `sdkconfig.defaults` małe alokacje są preferowane w pamięci wewnętrznej, więc „po prostu malloc” nie daje gwarancji PSRAM. W obecnym projekcie istnieje już `psramAllocSafe()` jako jawny wzorzec.

## Ostateczny serializer

Nie ustalam jeszcze, czy pozostanie:

```text
manual JSON writer
```

czy:

```text
object_t
```

ponieważ trzeba zmierzyć:

- RAM peak,
- czas przygotowania,
- rozmiar payloadu,
- czas wykonania requestu,
- zachowanie przy timeout.

FirebaseClient pokazuje bezpośredni wzorzec `object_t("{...}")`; jest więc to funkcjonalnie dostępne. citeturn875598search3

---

# R79. RTDB SECURITY / VALIDATION / SCHEMA HARDENING

**Status: research complete; produkcyjne rules nadal osobny etap**

Firebase Security Rules mogą definiować `.read`, `.write`, `.validate` i `.indexOn`; `.validate` nie kaskaduje i działa tylko dla danych nie-null. citeturn465628search1

Zapytania mogą być ograniczane także przez `query.*`, w tym `orderByChild`, `startAt`, `endAt`, `limitToFirst` i `limitToLast`. citeturn465628search3

## Schemat

```text
/piec/status
/piec/cmd
/piec/telemetry/1m/v1/YYYY/MM/DD/<record_id>
/piec/events/v1/YYYY/MM/DD/<event_id>
```

## Dlaczego `v1` w ścieżce

Zmiana:

```text
field meaning
scale
quality encoding
```

nie może wymagać interpretowania starych danych nowym dekoderem bez jawnej wersji.

## Rules — zasada

Telemetryka urządzenia powinna móc pisać wyłącznie do swojej przestrzeni.

Aplikacja mobilna powinna mieć odrębne uprawnienia do odczytu.

Komendy nie mogą dostać się poprzez szeroki write do całego `/piec`.

## Obecny problem security

Kod używa Legacy Database Secret i `setInsecure()`. Firebase zaleca aktualizację REST authentication z legacy tokens, które są długowiecznymi poświadczeniami. FirebaseClient wspiera krótsze tokeny, w tym Custom Token/ID Token/Access Token. citeturn350641search10turn350641search0

To pozostaje osobnym etapem security.

## Potencjalny kontrakt `.validate`

Wymagania, które warto sprawdzić po stronie serwera:

```text
v == 1
record_id is string
record fields have expected types
seq > 0
scale stays in declared range
unknown extra fields rejected where practical
```

Nie próbujemy jednak kodować całej logiki biznesowej sterownika w Security Rules.

---

# R80. IMPLEMENTATION GATE — FINAL PRE-CODE TEST MATRIX

**Status: research gate**

## A. Data correctness

```text
[ ] sample with valid RTC
[ ] sample before RTC/NTP
[ ] sample after NTP sync
[ ] RTC correction backwards
[ ] DHT failed 1 cycle
[ ] DHT failed 10 cycles
[ ] BMP failed
[ ] one DS18B20 bus unavailable
[ ] one DS18B20 sensor invalid
[ ] smoke sensor OFF/stale
[ ] simulated sensor
```

PASS: żadna wartość nie jest oznaczona jako świeża bez świeżego pomiaru.

## B. Queue correctness

```text
[ ] WiFi OFF 1h
[ ] WiFi OFF 24h
[ ] repeated Firebase timeout
[ ] taskCount high
[ ] worker busy
[ ] caller timeout while worker continues
[ ] transient 5xx
[ ] auth error
[ ] malformed response
```

PASS: brak niekontrolowanego wzrostu queue; brak podwójnego requestu tego samego batcha.

## C. Storage correctness

```text
[ ] ring empty
[ ] ring half-full
[ ] ring full
[ ] ring overrun
[ ] LittleFS near quota
[ ] spool segment rotation
[ ] power loss during append
[ ] power loss during segment close
[ ] power loss during delete
```

PASS: po restarcie tylko poprawnie zatwierdzone rekordy trafiają do odczytania.

## D. Crash / WDT

```text
[ ] panic with coredump
[ ] coredump full filesystem
[ ] coredump partial write simulation
[ ] WDT during telemetry prepare
[ ] WDT during telemetry network wait
[ ] repeated crash loop
```

PASS: coredump ma wyższy priorytet niż telemetry spool i źródłowy dump nie jest kasowany po nieudanym backupie.

## E. Control-plane regression

```text
[ ] pump reaction timing unchanged
[ ] servo tick jitter bounded
[ ] DS read period unchanged
[ ] Telegram long poll unaffected
[ ] Firebase commands still execute
[ ] OTA unchanged
```

PASS: telemetry nie zmienia zachowania automatyki.

---

# AKTUALIZACJA MAPY — R73–R80

Po tej rundzie mamy zamknięte:

```text
R73  source/freshness map
R74  TelemetrySample V1 draft
R75  multicore snapshot strategy
R76  sessionNonce + sampleSeq identity
R77  Firebase single-flight state machine
R78  batch + memory strategy
R79  RTDB security/schema hardening
R80  pre-code fault/test matrix
```

## Następny blok researchu

```text
R81–R88
  exact record_id encoding
  exact FirebaseClient object_t / lifetime behavior
  exact status/command/telemetry priority interaction
  exact telemetry insertion point in tgTaskFn()
  exact batch size benchmark methodology
  exact FS quota formula
  coredump parser/toolchain verification
  final design freeze before Commit A
```

**Nadal bez zmian w firmware.**

---

# R81. EXACT RECORD_ID ENCODING

**Status: decision ready**

## Final wire representation

Rekomendowany format:

```text
<16 hex chars sessionNonce>-<8 hex chars sampleSeq>
```

czyli dokładnie 25 znaków ASCII, np. formatowo:

```text
0123456789ABCDEF-00000001
```

Nie używamy:

```text
unix timestamp
millis()
Firebase push key
NVS boot counter
```

jako jedynego ID.

## Własności

```text
sessionNonce = 64-bit session identifier
sampleSeq    = monotonic in-session sequence
```

Retry tego samego batcha tworzy identyczne klucze.

Restart tworzy nową sesję.

`sampleSeq` może zostać wyzerowany przy restarcie bez ryzyka kolizji tak długo, jak nowa sesja ma inny nonce.

## Dodatkowa ochrona

Każdy rekord ma także:

```text
seq
unixTs
```

więc aplikacja może wykrywać dziury w kolejności niezależnie od kolejności JSON.

## Ważne

Nie zakładamy, że kolejność dzieci RTDB odpowiada kolejności próbek. Firebase REST zwraca filtrowane wyniki bez gwarancji kolejności JSON; aplikacja ma sortować po `ts`/`seq`. citeturn663117search2

---

# R82. FIREBASECLIENT OBJECT LIFETIME / PAYLOAD OWNERSHIP

**Status: research complete; test required**

FirebaseClient opisuje async task jako element FIFO zawierający przygotowane dane HTTP, w tym payload. citeturn663117search4

Biblioteka pokazuje użycie:

```cpp
Database.update<object_t>(
    aClient,
    path,
    object_t("{...}"),
    aResult
);
```

co potwierdza, że obiekt tworzony lokalnie może być przekazany do asynchronicznego requestu. citeturn663117search3

## Konsekwencja

Nie musimy przechowywać ogromnego `String` jako globalnego bufora tylko po to, by przeżyć kolejkę.

Ale nie będziemy opierać bezpieczeństwa wyłącznie na interpretacji implementacji biblioteki. Przed Commit D wykonywany będzie test:

```text
local object_t
→ async update
→ lokalny obiekt znika
→ request kończy się poprawnie
```

## Preferowany model V1

```text
TelemBatch batchSnapshot
        ↓
JsonWriter/object_t
        ↓
Database.update<object_t>()
        ↓
object_t może zostać zwolniony
```

Nie wolno:

```text
pointer do lokalnego char[]
→ request async
→ char[] znika
```

chyba że test z konkretną wersją FirebaseClient dowiedzie, że biblioteka wykonała własną kopię.

## Wniosek

Warstwa telemetryczna ma mieć własną abstrakcję `TelemetryEncodedBatch`, aby serializer można było zmienić między manual JSON i `object_t` bez zmiany semantyki kolejki.

---

# R83. DOKŁADNY PUNKT INTEGRACJI Z `tgTaskFn()`

**Status: decision ready**

## Aktualna kolejność

Kod ma obecnie ochronny priorytet:

```text
Telegram / alarmy
Firebase status
Firebase command
SD resend
weather
```

Telemetryka nie może wejść przed obsługę komend.

## Punkt V1

Wprowadzamy telemetryczny pump **po `checkFirebaseCommands()`**, a przed operacjami niekrytycznymi (`SD resend`, weather).

```text
Firebase status
      ↓
Firebase command
      ↓
Telemetry pump
      ↓
SD resend
      ↓
weather
```

## Guardy

Telemetry pump wykonuje request tylko gdy:

```text
WiFi connected
&& fbAppReady
&& !fbBlockedThisIter
&& !fbLoopWorkerZajety()
&& TG_ITER_HAS_BUDGET(tgIterStartMs)
&& telemetry_inflight == false
```

oraz:

```text
fbAsyncClient.taskCount() == 0
```

lub jawnie zaakceptowane minimum wynikające z istniejącego requestu. Nie ustawiamy `taskCount() == 0` jako globalnej gwarancji, bo `fbApp.loop()`/auth ma własny lifecycle.

## Dlaczego po komendach

Komenda sterująca jest interakcją użytkownika z urządzeniem. Opóźnienie komendy ma wyższy priorytet niż opóźnienie wpisu archiwalnego.

---

# R84. ADAPTIVE BATCHING — LEPSZY MODEL NIŻ SZTYWNE 10/MIN

**Status: proposal for benchmark**

Sam warunek:

```text
ring >= 10 → send 10
```

daje za duże opóźnienie świeżej telemetrii przy normalnym połączeniu: pierwsza próbka może czekać kilka minut tylko po to, żeby wypełnić batch.

## Lepszy model

Dwa wyzwalacze:

```text
BACKLOG_TRIGGER
TIME_TRIGGER
```

Przykładowe parametry testowe:

```text
BATCH_MAX = 10
MAX_SAMPLE_LATENCY = 120 s
```

Algorytm:

```text
if backlog >= 10:
    send up to 10
else if oldest sample age >= 120 s:
    send all available (1..9)
else:
    don't send
```

W normalnej pracy 2 próbki mogą zostać wysłane razem co około 2 minuty, zamiast wykonywać 1440 requestów/dobę.

Przy awarii sieci po powrocie backlog może być drenowany batchami do 10.

## Konsekwencja

„1-minutowa telemetryka” opisuje **rozdzielczość danych**, a nie koniecznie częstotliwość requestów HTTP.

To jest ważne rozdzielenie projektu.

## Benchmark

Porównujemy:

```text
batch 2
batch 5
batch 10
batch 20
```

dla:

```text
payload bytes
RAM peak
worker duration
CPU Core1 utilization
WDT margin
Firebase task queue depth
```

Start produkcyjny: `10` jako górny limit, ale bez zatwierdzania go bez testu.

---

# R85. LITTLEFS QUOTA — MATEMATYKA Z REZERWĄ

**Status: architecture complete; constants pending measurement**

## Fizyczny total

```text
LITTLEFS_TOTAL = 10,354,688 B
```

Źródłem fizycznej informacji jest `LittleFS.totalBytes()/usedBytes()`, nie suma ręcznie znanych plików.

## Rezerwa crash

Aktualny projekt przechowuje maksymalnie 20 coredumpów × 64 KiB:

```text
1,310,720 B = 1.25 MiB
```

Do bezpiecznego projektu quota należy przyjąć co najmniej:

```text
COREDUMP_RESERVE >= 1.25 MiB
```

i dodatkowy margines operacyjny.

## Model dynamiczny

Zamiast:

```text
TELEMETRY_MAX_BYTES = stała
```

lepiej:

```text
used_nontelemetry = physical_used - telemetry_used
available_for_telemetry =
    TOTAL
    - used_nontelemetry
    - emergency_reserve
```

oraz dodatkowo:

```text
TELEMETRY_HARD_CAP
```

aby telemetryka nigdy nie próbowała wypełnić całej partycji.

## Kolejność priorytetów

```text
system/config
coredump emergency reserve
critical logs
normal history
telemetry spool
noncritical old logs
```

Ostateczna rezerwa `emergency_reserve` wymaga pomiaru istniejącego systemu logów; nie wpisujemy arbitralnej liczby tylko dlatego, że wygląda bezpiecznie.

---

# R86. COREDUMP VERIFICATION — TOOLCHAIN TRUTH

**Status: design required before code**

## Co wiemy z kodu

Startup robi:

```text
esp_reset_reason()
→ archiwizujCoredumpJesliCrash()
→ reszta setup()
```

Dzięki temu coredump jest obsługiwany bardzo wcześnie.

## Co musi zostać poprawione

Obecnie brakuje pełnego łańcucha:

```text
image_check
→ safe copy
→ write-count verification
→ close
→ size verification
→ rename
→ erase source
```

## Test parsera

Nie zamrażamy komendy parsera „na pamięć”. Musi zostać pobrana z dokładnie tej wersji ESP-IDF/pioarduino, która została zbudowana dla środowiska.

PASS oznacza jednocześnie:

```text
flash coredump exists
archive file exists
archive size matches
ELF/backtrace parser accepts archive
source partition is erased only after successful verification
```

---

# R87. FINAL SCHEMA V1 — PROJEKT KONTRAKTU

**Status: near-freeze**

## Root

```text
/piec
  /status
  /cmd
  /telemetry
  /events
```

## Telemetry

```text
/piec/telemetry/1m/v1/YYYY/MM/DD/<record_id>
```

Rekord zawiera:

```text
v
id
ts
seq
state
quality
age
measurements
```

## Dlaczego `ts` jako pole rekordu

Aplikacja może wykonywać query:

```text
orderByChild("ts")
startAt(T0)
endAt(T1)
limitToFirst(N)
```

Firebase dokumentuje te mechanizmy oraz zaleca indeksowanie pól często używanych do query przez `.indexOn`. citeturn465628search1turn663117search1

## Dlaczego dzienne shardy

Aplikacja nigdy nie musi odpytywać całej historii urządzenia. Zakres np. 7 dni może rozbić na 7 małych zapytań.

Firebase dopuszcza duże wartości przechowywania, ale limity pojedynczego query/operacji i koszt przetwarzania rosną z wielkością gałęzi. Oficjalne limity obejmują m.in. 16 MB pojedynczego zapisu SDK oraz 64 MB/minutę zapisanych danych. citeturn663117search0

W naszym zastosowaniu jesteśmy wielokrotnie poniżej tych limitów; ważniejsza od limitu sprzętowego jest przewidywalność klienta mobilnego i koszt query.

---

# R88. DESIGN FREEZE CHECK — CO JESZCZE MUSI BYĆ UDOWODNIONE

**Status: pre-Commit A**

## Udowodnione koncepcyjnie

```text
[OK] jeden producer
[OK] jeden AsyncClient
[OK] jeden fbApp.loop path
[OK] single-flight telemetry
[OK] timestamp ≠ identity
[OK] sessionNonce + seq
[OK] freshness metadata
[OK] fixed-point storage
[OK] adaptive batching model
[OK] dynamic FS quota
[OK] coredump priority
[OK] daily RTDB shards
```

## Nadal wymagają eksperymentu

```text
[TEST] exact object_t lifetime
[TEST] batch 2/5/10/20
[TEST] RAM peak
[TEST] Core1 CPU interference
[TEST] maximum Firebase worker duration
[TEST] timeout + abandoned worker
[TEST] duplicate retry
[TEST] power loss around spool segment boundary
[TEST] coredump actual size on real firmware
[TEST] parser acceptance of archived ELF
[TEST] actual LittleFS free-space curve
[TEST] 24/48/72h run
```

## Brakujące dane domenowe

```text
[OPEN] znaczenie +18 w ciśnieniu
[OPEN] docelowy okres retencji RTDB
[OPEN] maksymalna akceptowalna latencja telemetryki
[OPEN] czy potrzebna jest historia alarmów jako osobna gałąź events
[OPEN] jak długo urządzenie musi działać bez sieci bez utraty danych
```

Nie rozwiązujemy tych punktów przez zgadywanie. Wartości zostaną ustalone na podstawie wymagań i testów.

---

# AKTUALIZACJA MAPY — R81–R88

```text
R81  exact record_id
R82  FirebaseClient payload ownership
R83  exact tgTask integration point
R84  adaptive batching
R85  dynamic LittleFS quota
R86  coredump toolchain verification
R87  RTDB schema near-freeze
R88  final design-freeze gate
```

## Następny blok

```text
R89–R96
  build-truth / generated sdkconfig
  actual binary size & headroom
  exact sensor freshness implementation cost
  exact C++ struct size/alignment
  Firebase payload size calculation from schema
  backlog-drain timing model
  fault-injection harness design
  Commit A acceptance checklist
```

**Stan: nadal NIE zmieniamy firmware.**

# R89. BUILD-TRUTH — WERYFIKACJA RZECZYWISTEGO SDKCONFIG

**Status: BLOCKED BY MISSING BUILD ARTIFACT**

## Sprawdzenie dostarczonych artefaktów

W `/mnt/data` nie ma:

```text
sdkconfig.esp32-s3-n16r8
sdkconfig
firmware .elf
firmware .bin
firmware .map
```

Jest wyłącznie:

```text
sdkconfig.defaults
```

oraz źródła/config projektu.

## Wniosek

Nie wolno oznaczyć wartości z `sdkconfig.defaults` jako „rzeczywisty build config”.
PlatformIO dokumentuje, że `sdkconfig.<env>` jest wygenerowanym artefaktem zawierającym pełną scaloną konfigurację dla środowiska. ESP-IDF również rozróżnia pliki defaults od wygenerowanego `sdkconfig`. 

## Co możemy stwierdzić teraz

```text
[KNOWN] sdkconfig.defaults zawiera konfigurację coredump/PSRAM/WDT
[UNKNOWN] które defaults zostały faktycznie przyjęte
[UNKNOWN] wartości wynikowe po dependency resolution Kconfig
[UNKNOWN] finalny CONFIG_ESP_COREDUMP_MAX_TASKS_NUM
[UNKNOWN] finalny CONFIG_SPIRAM_MALLOC_ALWAYSINTERNAL
[UNKNOWN] finalny CONFIG_TASK_WDT_TIMEOUT_S
```

## Gate

Przed Commit A potrzebny jest artefakt:

```text
.pio/build/esp32-s3-n16r8/sdkconfig.esp32-s3-n16r8
```

lub odpowiednik wygenerowany przez aktualny build.

**PASS:** finalny `sdkconfig.<env>` zostaje zapisany do dokumentacji z SHA-256.

# R90. FIRMWARE HEADROOM — PARTYCJA VS RZECZYWISTY BIN

**Status: PARTITION BUDGET KNOWN / BINARY HEADROOM BLOCKED**

## Partycja aplikacji

`partitions.csv` definiuje:

```text
app0 = 0x300000 = 3,145,728 B = 3 MiB
app1 = 0x300000 = 3,145,728 B = 3 MiB
```

To daje dokładnie 3 MiB przestrzeni na każdy obraz OTA.

ESP-IDF wymaga, aby obraz aplikacji mieścił się w odpowiednim app partition; sam build może wykonać size-check, ale nie mamy tutaj wygenerowanego obrazu do pomiaru. 

## Nie wolno teraz podać procentowego headroomu firmware

Brakuje:

```text
firmware.bin size
ELF size report
text/data/rodata/bss
map
```

Dlatego nie przyjmujemy np. „zostało 20%” bez dowodu.

## Kryterium

Po baseline build zapisujemy:

```text
APP_SLOT = 3,145,728 B
BIN_SIZE = rzeczywisty rozmiar .bin
HEADROOM = APP_SLOT - BIN_SIZE
HEADROOM_PCT = HEADROOM / APP_SLOT * 100
```

Dodatkowo porównujemy `main_centrala (3).cpp` przed i po telemetryce oraz raport komponentów. ESP-IDF zaleca pomiar `size`, `size-components` i `size-files` przy analizie wzrostu obrazu.

**PASS dla Commit A:** telemetryka nie powoduje przekroczenia slotu i wzrost obrazu jest zmierzony, a nie szacowany z rozmiaru źródła.

# R91. TELEMETRYSAMPLE — RZECZYWISTY KOSZT ABI

**Status: measured**

Draft z R74 został skompilowany niezależnie w C++17 z tym samym układem typów.

```text
sizeof(TelemetrySample) = 64 B
```

### Layout

```text
sessionNonce          offset  0  size 8
sampleSeq             offset  8  size 4
unixTs                offset 12  size 4
monoMs                offset 16  size 4
10 × int16            offset 20  size 20
uint16 dym            offset 40  size 2
klapa + syberko       offset 42  size 2
stateBits+qualityBits offset 44  size 4
11 × age uint8        offset 48  size 11
padding/alignment                 5
----------------------------------
TOTAL                              64 B
```

Ważna korekta względem wcześniejszego szybkiego szacunku: 64 B, nie 56 B. Powodem jest 10 pól `int16_t` (8 temperatur + RH + pressure) oraz wyrównanie całej struktury do 8 B.

### RAM ring

Przy 1440 rekordach:

```text
1440 × 64 B = 92,160 B = 90 KiB
```

Dla 2880 rekordów (48 h):

```text
184,320 B = 180 KiB
```

Dla 10-record batch snapshot:

```text
640 B + serializer overhead
```

To jest mały koszt względem obecnego PSRAM; ring nie wymaga jednak 48 h w V1, jeśli wymagania przewidują tylko backlog krótkotrwały.

### static_assert

Przed kodem produkcyjnym:

```cpp
static_assert(sizeof(TelemetrySample) == 64, "TelemetrySample ABI changed");
```

oraz `offsetof()` dla pól krytycznych, jeżeli format binarny spool zostanie zamrożony.

# R92. PAYLOAD JSON — RZECZYWISTY SZACUNEK

**Status: measured model; final benchmark pending**

Dla draftowego rekordu V1, minified JSON i reprezentatywnych wartości:

```text
record ≈ 256 B
```

Przykładowy rekord zawiera:

```text
v,id,ts,seq,mono
8 temperatur/temperaturowych kanałów
rh,p,dym
klapa,syberko
state,quality
11 age values
```

Batch 10 rekordów z tym samym schema:

```text
≈ 2,521 B
≈ 2.52 KiB
≈ 252 B/record średnio
```

### Ważna konsekwencja

Limit batcha powinien być dwuwymiarowy:

```text
MAX_RECORDS
MAX_PAYLOAD_BYTES
```

Nie wystarczy:

```text
if count >= 10
```

Docelowo serializer kończy batch przed przekroczeniem np. konserwatywnego limitu testowego. Konkretna wartość zostanie wybrana po pomiarze `AsyncClient`/TLS/RAM, nie na podstawie limitu Firebase.

### Sieć — order of magnitude

Przy 1,440 rekordach/dobę:

```text
256 B × 1,440 ≈ 369 KiB/day payload-only
```

Batch 10 nie zmienia ilości danych aplikacyjnych, tylko zmniejsza liczbę operacji HTTP.

Dla 30 dni:

```text
≈ 10.8 MiB payload-only
```

To nadal nie obejmuje HTTP/TLS overhead i nie jest miarą kosztu Firebase.

### Decyzja

V1 zaczyna od:

```text
BATCH_MAX_RECORDS = 10
```

ale z obowiązkowym:

```text
BATCH_MAX_PAYLOAD_BYTES
```

Wartość byte-limit zostanie zamrożona po benchmarku.

# R93. BACKLOG DRAIN MODEL

**Status: model zamknięty; parametry transportu do benchmarku**

## Napływ

Dla próbkowania co 60 s:

```text
λ = 1 record/min
```

czyli:

```text
60 records/hour
1,440 records/day
```

## Normalny batch

Przy `BATCH_MAX_RECORDS = 10` wystarczy średnio jeden udany batch na 10 minut, aby backlog nie rósł.

Jeżeli średni czas od rozpoczęcia jednego batcha do gotowości następnego jest mniejszy niż 10 minut, system jest stabilny w sensie samej przepustowości.

## Backlog po offline

Dla czasu offline `T` godzin:

```text
backlog ≈ 60 × T records
```

Przykłady:

```text
1 h   = 60
6 h   = 360
12 h  = 720
24 h  = 1,440
48 h  = 2,880
```

RAM ring 1440 rekordów nie zapewnia więc 48 h odporności na brak sieci; zapewnia około 24 h przy idealnym wypełnieniu i bez innych strat.

## Drain time

Jeżeli skuteczność transportu wynosi `B` rekordów na udany request, a średni interwał zakończenia requestu to `Δt` minut:

```text
drain_rate = B / Δt records/min
```

Warunek stabilności:

```text
drain_rate > 1 record/min
```

Przykładowo:

```text
10 records / 60 s  = 10/min  → backlog 24h ≈ 144 min idealnie
10 records / 30 s  = 20/min  → backlog 24h ≈ 72 min idealnie
10 records / 10 s  = 60/min  → backlog 24h ≈ 24 min idealnie
```

To są czasy matematyczne bez retry, auth, scheduler jitter i konfliktu z innymi Firebase requestami. Nie są obietnicą runtime.

## Safety rules

Backlog drain nie może:

```text
blokować sterowania
wypierać komendy
wypierać statusu bezpieczeństwa
otwierać drugiego fbLoopWorker
przekraczać TG_ITER_BUDGET
```

Jeżeli drain trwa zbyt długo, wracamy do normalnej pracy i backlog kontynuuje się później.

## Ważna decyzja

Nie stosujemy agresywnego „drain as fast as possible”.

Stosujemy:

```text
normal operation priority
        >
control/commands/status
        >
telemetry drain
```

Telemetryka ma być eventual-consistent, a nie kosztem automatyki.

# R94. PSRAM / RAM HEADROOM DLA RINGA

**Status: budget measured; runtime headroom pending real build**

## Telemetry ring

Przy `sizeof(TelemetrySample)=64 B`:

```text
1440 samples = 92,160 B = 90 KiB
2880 samples = 184,320 B = 180 KiB
```

To jest koszt samego storage rekordu, bez mutexów, indeksów i ewentualnych struktur pomocniczych.

## Względem obecnego projektu

Obecne duże bufory PSRAM są już rzędu ~1.3 MiB (krótka historia, długa historia, log ring). Dodanie 90 KiB jest więc małym przyrostem względnym.

Nie wolno jednak zamienić tego w założenie „PSRAM jest nieskończony”. Kryterium runtime:

```text
PSRAM free
PSRAM largest block
PSRAM minimum-ever
```

przed i po utworzeniu telemetry ring.

## Wewnętrzny DRAM

Telemetryka nie może przenieść dużych tymczasowych JSON-ów do DRAM przez przypadek. W `sdkconfig.defaults` znajduje się:

```text
CONFIG_SPIRAM_MALLOC_ALWAYSINTERNAL=4096
```

co oznacza preferowanie pamięci wewnętrznej dla małych alokacji; oficjalna dokumentacja opisuje ten próg jako preferencję allocator'a, a nie gwarancję lokalizacji. 

Dlatego duży serializer/buffer będzie alokowany jawnie jako PSRAM (`ps_malloc`/capability allocator), a struktury wymagające internal memory pozostaną w DRAM.

## PASS

Po starcie baseline i telemetry:

```text
internal largest block nie spada poniżej ustalonego minimum
PSRAM largest block nie degraduje się w czasie
brak narastającego heap leak
```

Minimalne kryterium musi zostać ustalone z pomiaru baseline, nie arbitralnie.

# R95. FAULT-INJECTION / ACCEPTANCE MATRIX DLA COMMIT A

**Status: test matrix frozen**

## A. Transport

```text
T1 WiFi OFF podczas przygotowania batcha
T2 WiFi OFF po rozpoczęciu requestu
T3 timeout przed wysłaniem
T4 timeout po możliwym wysłaniu
T5 Firebase 5xx
T6 auth failure
T7 worker busy
T8 caller timeout + worker continues
T9 retry tego samego batcha
```

PASS:

```text
brak utraty potwierdzonych rekordów
brak niekontrolowanego duplikowania
brak drugiego concurrent fbLoopWorker
```

## B. Ring

```text
R1 empty
R2 one sample
R3 batch full
R4 1440 samples
R5 overrun
R6 producer/consumer simultaneous access
```

PASS:

```text
head/tail są spójne
count nie przekracza capacity
dropped counter rośnie jawnie przy overrun
```

## C. Time

```text
C1 RTC invalid
C2 NTP sync after boot
C3 RTC correction backward
C4 RTC correction forward
C5 millis wrap model
```

PASS:

```text
record_id nie zmienia się po korekcie czasu
sampleSeq rośnie monotonicznie w sesji
ts może się korygować bez kolizji identity
```

## D. Memory

```text
M1 low internal heap
M2 fragmented PSRAM
M3 serializer allocation failure
M4 ring allocation failure
M5 repeated 24/48/72 h cycles
```

PASS:

```text
brak crash
brak permanentnego leak
telemetry failure nie zatrzymuje automatyki
```

## E. Flash / coredump

```text
F1 LittleFS nearly full
F2 power loss during spool append
F3 power loss after append before commit marker
F4 power loss during segment close
F5 coredump backup with full FS
F6 partial write simulation
```

PASS:

```text
niezatwierdzony rekord nie wraca jako poprawny
źródłowy coredump nie jest kasowany po błędnym backupie
telemetry quota nie narusza reserve coredump
```

## F. Control-plane regression

```text
P1 command latency
P2 status latency
P3 scheduler jitter
P4 pump reaction
P5 servo timing
P6 OTA
P7 Telegram
```

PASS:

```text
telemetry nie zmienia ustalonego zachowania sterownika
```

# R96. GATE WEJŚCIA W COMMIT A

**Status: NEAR-GO — jeden blokujący artefakt buildowy**

## Commit A nie może jeszcze zmieniać Firebase

Commit A ma być wyłącznie fundamentem telemetryki:

```text
TelemetrySample
TelemetryRing
snapshot/freshness metadata
record identity
diagnostic counters
static_assert
```

Bez:

```text
nowego Firebase endpointu
nowego auth
persistent spool
zmiany platform/toolchain
zmiany FirebaseClient
zmiany status interval
```

## Warunki wejścia

### Must-have

```text
[BLOCKER] generated sdkconfig.<env> dostępny
[BLOCKER] baseline firmware .bin/.elf dostępny
[BLOCKER] baseline size report zapisany
[OK] partition layout znany
[OK] TelemetrySample layout = 64 B draft
[OK] ring budget policzony
[OK] JSON budget policzony
[OK] backlog model policzony
[OK] fault matrix gotowa
```

### Commit A acceptance

Po zmianie:

```text
firmware builds
firmware fits app0/app1
no new WDT
no new heap failure
TelemetrySample static_assert PASS
ring producer test PASS
snapshot consistency PASS
no Firebase behavior change
no RTDB writes introduced
```

## Baseline artefacts, które trzeba zachować

```text
sdkconfig.<env>
firmware.bin
firmware.elf
.map (jeśli dostępny)
size report
partition table binary/report
git/source hash
```

## Kryterium zatrzymania

Jeżeli po Commit A którykolwiek z poniższych pogarsza się bez wyjaśnienia:

```text
internal minimum heap
PSRAM minimum heap
largest block
stack high-water mark
scheduler timing
WDT
binary size
```

commit zostaje cofnięty/zatrzymany przed integracją Firebase.

## FINAL R89–R96

```text
R89  generated sdkconfig truth       BLOCKED: brak artefaktu
R90  firmware headroom               BLOCKED: brak BIN/ELF
R91  TelemetrySample sizeof          MEASURED: 64 B
R92  JSON payload                    MODEL: ~256 B/record, ~2.52 KiB/10
R93  backlog drain                   MODEL CLOSED
R94  PSRAM budget                    MEASURED MODEL
R95  fault injection                 MATRIX FROZEN
R96  Commit A gate                   DEFINED / waiting baseline build
```

## Następny krok

Nie zmieniać jeszcze firmware na podstawie brakującego build-truth. Najpierw wykonać jeden czysty baseline build środowiska `esp32-s3-n16r8`, zachować wygenerowane artefakty i dopiero wtedy rozpocząć Commit A.

# R97. BASELINE BUILD — PRÓBA WYKONANIA I TWARDY BLOCKER

**Data:** 2026-09-23

## Cel

Wykonać pierwszy czysty baseline buildu dla dokładnie:

```text
env = esp32-s3-n16r8
platform = pioarduino 55.03.38
framework = Arduino
board = esp32-s3-n16r8
partitions = partitions.csv
```

Baseline ma być punktem odniesienia dla R89/R90 i późniejszego Commit A.

## Wynik próby

**STATUS: BLOCKED BEFORE COMPILATION**

Środowisko wykonawcze nie zawiera:

```text
pio
idf.py
xtensa-esp32s3-elf-gcc
```

Nie znaleziono również lokalnego cache/toolchainu PlatformIO, który pozwoliłby wykonać build bez pobierania zależności.

Próba instalacji PlatformIO przez `pip` została wykonana, ale środowisko kontenera nie ma działającego dostępu DNS do PyPI. Nie zmieniono przez to projektu ani wersji platformy.

## Drugi, niezależny blocker: niepełny snapshot projektu

W dostarczonym zestawie plików brakuje elementów, do których bezpośrednio odwołuje się `platformio.ini`/źródło:

```text
src/main_centrala.cpp
boards/esp32-s3-n16r8.json
scripts/patch_ds18b20.py
lib/dhtESP32-rmt/dhtESP32-rmt.h
lib/dhtESP32-rmt/dhtESP32-rmt.cpp
```

Obecnie:

```text
main_centrala (3).cpp       → istnieje w /mnt/data, ale nazwa nie odpowiada build_src_filter
esp32-s3-n16r8.json         → istnieje w /mnt/data, ale nie w katalogu boards/
platformio.ini              → istnieje
partitions.csv              → istnieje
sdkconfig.defaults          → istnieje
TELEMETRIA_RESEARCH_PLAN.md → istnieje
```

Szczególnie istotna jest lokalna biblioteka `dhtESP32-rmt`, ponieważ bieżący firmware inkluduje ją bezpośrednio, a `platformio.ini` dokumentuje ją jako prywatną zależność projektu, nie jako `lib_deps`.

## Co zostało zweryfikowane przed zatrzymaniem

```text
[OK] platformio.ini wskazuje env esp32-s3-n16r8
[OK] platform jest przypięty do 55.03.38
[OK] custom partitions.csv jest wskazany
[OK] board esp32-s3-n16r8.json jest dostępny jako plik wejściowy
[OK] sdkconfig.defaults jest dostępny
[OK] aktualny source main_centrala (3).cpp jest dostępny
[BLOCKED] PlatformIO Core
[BLOCKED] ESP32-S3 toolchain
[BLOCKED] kompletna struktura projektu do kompilacji
[BLOCKED] wygenerowany sdkconfig
[BLOCKED] firmware.bin / firmware.elf / .map
[BLOCKED] raport rozmiaru po linkowaniu
```

## Ważna zasada baseline

Nie wolno produkować „headroom” ani `sdkconfig` z wartości szacowanych z `sdkconfig.defaults`.

R89/R90 pozostają zatem:

```text
R89 generated sdkconfig truth  = BLOCKED
R90 firmware headroom          = BLOCKED
```

Dopóki nie istnieje rzeczywisty wynik linkera dla `esp32-s3-n16r8`.

## Minimalny komplet wymagany do wznowienia baseline

Pełny snapshot projektu musi zawierać co najmniej:

```text
platformio.ini
partitions.csv
sdkconfig.defaults
src/main_centrala.cpp
boards/esp32-s3-n16r8.json
scripts/patch_ds18b20.py
lib/dhtESP32-rmt/*
```

oraz środowisko zdolne uruchomić PlatformIO z dostępem do przypiętego pioarduino 55.03.38 i zależności bibliotek.

## Procedura baseline po odblokowaniu

```text
1. czysty build env esp32-s3-n16r8
2. zachować .pio/build/esp32-s3-n16r8/sdkconfig.esp32-s3-n16r8
3. zachować firmware.bin
4. zachować firmware.elf
5. zachować firmware.map, jeśli generowany
6. wykonać raport size / komponentów / plików
7. zarchiwizować wygenerowaną tablicę partycji
8. policzyć SHA-256 artefaktów
9. dopiero wtedy wyliczyć realny headroom app0/app1
```

## Commit A

Commit A pozostaje zatrzymany. Nie wolno rozpoczynać implementacji telemetryki tylko po to, aby „zobaczyć rozmiar”. Najpierw potrzebny jest prawdziwy baseline.

## Final R97

```text
R97 baseline build = BLOCKED BEFORE COMPILATION
Powód 1 = brak PlatformIO/toolchainu w środowisku
Powód 2 = niepełny snapshot drzewa projektu
Brak zmian w firmware / platformie / Firebase
```

## Następny krok

Dostarczyć pełny snapshot drzewa projektu lub uruchomić baseline w środowisku z PlatformIO, zachowując wygenerowane artefakty dokładnie z `env:esp32-s3-n16r8`.

### R97-A. Preflight reproducibility

Przygotowany skrypt `run_baseline.sh` został uruchomiony również w bieżącym workspace.

Wynik procesu:

```text
exit code = 2
baseline preflight failed; no build was started
```

Braki wykryte automatycznie są identyczne z audytem ręcznym:

```text
src/main_centrala.cpp
boards/esp32-s3-n16r8.json
scripts/patch_ds18b20.py
lib/dhtESP32-rmt/dhtESP32-rmt.h
lib/dhtESP32-rmt/dhtESP32-rmt.cpp
pio
```

Plik z pełnym wynikiem preflight został zachowany jako:

```text
baseline_preflight_result.txt
```

Skrypt baseline jako narzędzie odtwarzalne:

```text
run_baseline.sh
```

Nie wykonano żadnej operacji `pio run`, ponieważ preflight zakończył się wcześniej. Tym samym nie istnieje jeszcze żaden nowy `.pio/build/...` wygenerowany podczas tej próby.

# R98. ARTEFAKT Z UPLOADU — CZĘŚCIOWY BASELINE Z `firmware.map`

**Data:** 2026-09-24  
**Status: PARTIAL BASELINE / EXACT BIN + SDKCONFIG STILL MISSING**

## Co zawiera otrzymany ZIP

ZIP `Nowy folder (2).zip` zawiera rzeczywisty snapshot projektu oraz wynik linkowania:

```text
bootloader.bin
firmware.map
partitions.bin
partitions.csv
platformio.ini
sdkconfig.defaults
src/main_centrala.cpp
boards/esp32-s3-n16r8.json
scripts/patch_ds18b20.py
lib/dhtESP32-rmt/*
src/log_printf_wrap.c
```

Łączny rozmiar rozpakowany ZIP: około 20.2 MB. `firmware.map` ma około 19.0 MiB i zawiera ścieżki `.pio/build/esp32-s3-n16r8/...`, dlatego potwierdza rzeczywisty link z tego środowiska.

## Czego nadal brak

```text
firmware.bin                 [BRAK]
firmware.elf                 [BRAK]
sdkconfig.esp32-s3-n16r8     [BRAK]
```

Bez `firmware.bin` nie wolno podać dokładnego rozmiaru obrazu OTA. Bez wygenerowanego `sdkconfig.<env>` nie wolno uznać `sdkconfig.defaults` za finalną konfigurację Kconfig.

## Co potwierdza `firmware.map`

Najważniejsze sekcje linkera:

```text
.flash.text       0x125f34 = 1,204,020 B
.flash.appdesc    0x0100   =       256 B
.flash.rodata     0x847e0  =   542,688 B
.iram0.text       0x13b97  =    80,791 B
.dram0.data       0x5d6f   =    23,919 B
.dram0.bss        0xa850   =    43,088 B
```

Suma wymienionych ładowalnych sekcji (bez części noload/debug i bez pełnego binarnego narzutu obrazu) wynosi:

```text
1,868,058 B ≈ 1.781 MiB
```

Jest to **wskaźnik rozmiaru linkowanego obrazu**, a nie zastępstwo dla `firmware.bin`. Nie używać tej liczby do formalnego PASS/FAIL względem 3 MiB app slot.

## Co można oszacować już teraz

App slot:

```text
3,145,728 B
```

Wobec sumy powyższych sekcji zostaje orientacyjnie około:

```text
3,145,728 - 1,868,058 = 1,277,670 B
≈ 1.218 MiB
```

ale ten wynik ma status **diagnostyczny, nie kontraktowy**, ponieważ finalny obraz zawiera dodatkowe nagłówki, segmenty, padding/alignment i inne elementy obrazu.

## Decyzja

Nie blokujemy dalszej analizy mapy, ale **nie zamykamy R90**.

Do finalnego PASS potrzebne jest tylko dostarczenie z katalogu:

```text
.pio/build/esp32-s3-n16r8/
```

dwóch plików:

```text
sdkconfig.esp32-s3-n16r8
firmware.bin
```

`firmware.elf` jest bardzo pożądany do pełnego audytu symboli i `idf.py size`, ale nie jest jedynym warunkiem odblokowania podstawowego rozmiaru OTA.

## Najprostsza procedura dla użytkownika Windows

Po zakończonym buildzie należy skopiować tylko:

```text
.pio/build/esp32-s3-n16r8/sdkconfig.esp32-s3-n16r8
.pio/build/esp32-s3-n16r8/firmware.bin
.pio/build/esp32-s3-n16r8/firmware.elf       (jeżeli istnieje)
```

do małego katalogu i ZIP-ować wyłącznie te pliki.

Nie trzeba wysyłać całego `.pio` ani całego projektu.


# R98. BASELINE BUILD — RZECZYWISTY FIRMWARE.BIN + ELF

**Data:** 2026-09-24

## Status

**PARTIAL PASS — BIN/ELF ZWERYFIKOWANE; R89 NADAL CZEKA NA GENERATED SDKCONFIG**

Dostarczono rzeczywiste artefakty buildu:

```text
firmware.bin
firmware.elf
```

### Fingerprinty artefaktów

```text
firmware.bin
size   = 1,852,848 B
sha256 = 8a726abc4d63e899b132de2c0e71be52d40da119aee994d7f1bf5996843fcfb4

firmware.elf
size   = 23,766,148 B
sha256 = 8a995d34565a215e4a2c39c1d1c2507b0175871d8b39e4803b6209a7759daaac
```

## R98.1 — OTA app headroom

Obeczne partycje `app0` i `app1` mają po:

```text
0x300000 = 3,145,728 B = 3 MiB
```

Rzeczywisty `firmware.bin`:

```text
1,852,848 B
```

Zatem:

```text
HEADROOM = 3,145,728 - 1,852,848
         = 1,292,880 B
```

W procentach:

```text
firmware occupancy = 58.90045166 %
free headroom      = 41.09954834 %
```

Czyli aktualny obraz zajmuje około **1.767 MiB** i pozostawia około **1.233 MiB** wolnego miejsca w pojedynczym slocie OTA.

### Wniosek

Na poziomie samego limitu partycji aplikacji nie ma obecnie sygnału, że dodanie telemetryki V1 grozi natychmiastowym przekroczeniem 3 MiB. Nadal obowiązuje jednak zasada: każdy kolejny build musi być mierzony na prawdziwym `firmware.bin`, a nie na podstawie przybliżeń z ELF/map.

Nie ustalam jeszcze arbitralnego „bezpiecznego” progu zapasu. Powinien on uwzględniać realny wzrost kolejnych commitów oraz margines potrzebny na dalszy rozwój firmware.

## R98.2 — ELF / sekcje

`readelf` potwierdził m.in.:

```text
.iram0.text       0x013b97 = 80,791 B
.dram0.data       0x005d6f = 23,919 B
.dram0.bss        0x00a850 = 43,088 B (NOBITS)
.flash.text       0x125f34 = 1,220,404 B
.flash.rodata     0x0847e0 = 542,688 B
```

Wartość `bss` nie powiększa `firmware.bin`, ale zajmuje RAM po uruchomieniu; dlatego nie należy utożsamiać „mieści się w flash” z pełnym headroomem pamięci runtime.

## R98.3 — provenance toolchainu z ELF

`.comment` ELF zawiera:

```text
GCC: (crosstool-NG esp-14.2.0_20260121) 14.2.0
```

a w danych obrazu/ELF występują również oznaczenia:

```text
3.3.8
v5.5.4
```

co jest spójne z wcześniej ustalonym baseline:

```text
pioarduino platform-espressif32 55.03.38
Arduino-ESP32 3.3.8
ESP-IDF 5.5.4
```

Nie traktuję jednak samych stringów ELF jako zamiennika pełnego generated `sdkconfig`.

## R98.4 — czego nadal brakuje

Nadal nie mamy pliku:

```text
sdkconfig.esp32-s3-n16r8
```

Ani `sdkconfig`, ani innego pełnego wygenerowanego wyniku Kconfig.

Dlatego nadal są **UNKNOWN** rzeczy takie jak wynikowe wartości dependency-resolved dla konfiguracji WDT/PSRAM/coredump.

`firmware.bin` + `firmware.elf` zamykają natomiast część R90 dotyczącą rzeczywistego rozmiaru obrazu i OTA headroom.

## R98.5 — decyzja względem Commit A

```text
R90 firmware headroom        = PASS (1,292,880 B / 41.10%)
R89 generated sdkconfig      = BLOCKED
Commit A design gate         = JESZCZE NIEOTWARTY
```

Nie rozpoczynamy jeszcze kodowania telemetryki na podstawie samego BIN/ELF. Pozostaje domknąć build-truth przez wygenerowany `sdkconfig`.

## Następny krok

```text
R99 — pozyskać i zweryfikować sdkconfig.esp32-s3-n16r8
     ↓
porównać Kconfig z sdkconfig.defaults
     ↓
zamknąć R89
     ↓
przygotować baseline size/RAM report
     ↓
dopiero wtedy formalny gate Commit A
```

# R99. WERYFIKACJA LOKALIZACJI GENERATED SDKCONFIG — 24.09.2026

**Status: BLOCKED / FILE LOCATION TO VERIFY**

Użytkownik udostępnił listing:

```text
C:\Users\Rafcio\Documents\PlatformIO\sterownik-co-esp32\.pio\build\esp32-s3-n16r8
```

Listing potwierdza rzeczywisty build i obecność:

```text
firmware.bin        1,852,848 B
firmware.elf       23,766,148 B
firmware.map       19,841,948 B
firmware.factory.bin 1,918,384 B
bootloader.bin        19,984 B
partitions.bin         3,072 B
idedata.json          61,681 B
```

Nie ma natomiast w tym katalogu:

```text
sdkconfig.esp32-s3-n16r8
sdkconfig
```

Nie należy na tej podstawie wnioskować, że finalny Kconfig nie istnieje — najpierw trzeba wykonać lokalne wyszukanie po całym projekcie.

## R99.1 — polecenia diagnostyczne dla użytkownika

Uruchomić w katalogu projektu:

```bat
cd C:\Users\Rafcio\Documents\PlatformIO\sterownik-co-esp32

dir /a /s /b sdkconfig*
dir /a /s /b sdkconfig.h
```

Jeżeli wynik zawiera plik `sdkconfig.esp32-s3-n16r8`, należy przesłać tylko ten plik.

Jeżeli nie ma takiego pliku, należy przesłać mały artefakt:

```text
.pio\build\esp32-s3-n16r8\idedata.json
```

oraz wkleić wynik powyższych dwóch poleceń.

## R99.2 — stan baseline po listing'u

```text
R90 firmware.bin / OTA headroom = PASS
R98 ELF/map provenance          = PASS
R89 generated sdkconfig         = nadal BLOCKED

Nie wykonywać clean/build/upgrade tylko po to, aby „pojawić” sdkconfig.
Najpierw ustalić, czy bieżący sposób budowania generuje ten artefakt i gdzie.
```

## R99.3 — następny gate

```text
odnaleźć sdkconfig / ustalić brak
        ↓
porównać z sdkconfig.defaults
        ↓
zamknąć R89
        ↓
formalny baseline freeze
        ↓
Commit A
```

# R100. WYNIK RZECZYWISTEGO WYSZUKIWANIA SDKCONFIG — 24.09.2026

**Status: GENERATED SDKCONFIG NIE ZNALEZIONY W PROJEKCIE**

Użytkownik wykonał wyszukiwanie PowerShell w katalogu projektu. Wynik dla wzorca `sdkconfig*` zawiera:

```text
<projekt>\sdkconfig.defaults
```

oraz liczne `sdkconfig.defaults` należące do przykładów/bibliotek w `.pio\libdeps` i `managed_components`.

Nie znaleziono:

```text
<projekt>\sdkconfig
<projekt>\sdkconfig.esp32-s3-n16r8
<projekt>\.pio\build\esp32-s3-n16r8\sdkconfig.esp32-s3-n16r8
```

Wyszukiwanie `sdkconfig.h` znalazło wyłącznie nagłówki testowe/symulacyjne w `managed_components`; nie znaleziono wygenerowanego `sdkconfig.h` odpowiadającego aplikacji `esp32-s3-n16r8`.

Wyszukiwanie rekurencyjne po całym drzewie projektu generuje dodatkowo błędy `DirectoryNotFoundException` wewnątrz dużego `sterownik-co-app\node_modules`. Te błędy nie zmieniają faktu, że standardowy katalog `.pio\build\esp32-s3-n16r8` został wcześniej przejrzany i nie zawiera `sdkconfig*`.

## R100.1 — ważne rozróżnienie

Nie należy kopiować żadnego z poniższych plików jako „finalnego sdkconfig”:

```text
managed_components\...\sdkconfig.defaults
.pio\libdeps\...\sdkconfig.defaults
managed_components\...\sdkconfig.h (test/stub)
```

Nie są one konfiguracją wynikową tego firmware.

## R100.2 — co jest już zamknięte

```text
firmware.bin            = 1,852,848 B
OTA app slot            = 3,145,728 B
headroom                = 1,292,880 B = 41.10%
firmware.elf            = dostępny
firmware.map            = dostępny
firmware.factory.bin    = dostępny
partitions.bin          = dostępny
idedata.json             = dostępny
```

## R100.3 — decyzja

R89 pozostaje **BLOCKED**, ale nie ma już sensu dalej przeszukiwać całego drzewa aplikacji metodą rekurencyjną.

Następny krok powinien użyć artefaktu `idedata.json` i/lub metadanych SCons/PlatformIO znajdujących się w `.pio`, aby ustalić, czy finalne wartości Kconfig można wiarygodnie odtworzyć z metadanych buildu. Jeżeli nie, R89 należy oznaczyć jako „not emitted by this PlatformIO build mode” i dokumentować to jako ograniczenie baseline, zamiast generować sztuczny plik.

**Nie wykonywać `menuconfig`, `clean`, upgrade ani zmian `platformio.ini` przed tą analizą.**

## R100.4 — najbliższe polecenie użytkownika

Zamiast przeszukiwać całe 700 MB projektu uruchomić:

```powershell
Get-Content .pio\build\esp32-s3-n16r8\idedata.json -Raw
```

i przesłać wynik lub sam plik `idedata.json`.

Jeżeli plik jest duży, wystarczy przesłać go jako załącznik — ma około 62 KB.

# R101. IDEADATA AUDIT — BUILD METADATA BEZ FINALNEGO KCONFIG

**Data:** 2026-09-24

## Artefakt

```text
.pio/build/esp32-s3-n16r8/idedata.json
```

## Wynik

`idedata.json` jednoznacznie potwierdza rzeczywisty build:

```text
build_type = release
env_name   = esp32-s3-n16r8
PLATFORMIO = 60119
IDF_VER    = v5.5.4
F_CPU      = 240000000L
ARDUINO_VARIANT = esp32s3
BOARD_HAS_PSRAM = yes
```

Wykazuje także rzeczywiste ścieżki bibliotek i komponentów użytych przez build, w tym `FirebaseClient`, `ESPAsyncWebServer`, `AsyncTCP@3.4.10`, `ArduinoJson`, `dhtESP32-rmt`, `ESP_SSLClient`, `joltwallet__littlefs` i komponenty `espcoredump`/`esp_psram`.

## Kconfig

Pełny JSON nie zawiera wpisów `sdkconfig` ani konkretnych makr `CONFIG_*`. `idedata.json` nie jest więc równoważny wygenerowanemu `sdkconfig`.

Status R89 pozostaje:

```text
BLOCKED / NOT ARCHIVED
```

Nie traktujemy `sdkconfig.defaults` jako dowodu finalnych wartości Kconfig.

## R90 — zamknięty baseline obrazu

```text
firmware.bin = 1,852,848 B
OTA slot     = 3,145,728 B
headroom     = 1,292,880 B
headroom     = 41.10%
usage        = 58.90%
```

Fingerprint:

```text
firmware.bin SHA-256 = 8a726abc4d63e899b132de2c0e71be52d40da119aee994d7f1bf5996843fcfb4
firmware.elf SHA-256 = 8a995d34565a215e4a2c39c1d1c2507b0175871d8b39e4803b6209a7759daaac
```

## Decyzja

Baseline rozmiarowy jest przyjęty jako punkt odniesienia dla Commit A.

Baseline finalnego Kconfig pozostaje niezaarchiwizowany i nie może być rekonstruowany z `idedata.json` przez zgadywanie.

### Następny krok

Bez wykonywania nowego buildu sprawdzić katalogi zainstalowanego pakietu ESP32 w `%USERPROFILE%\\.platformio\\packages` pod kątem rzeczywistego `sdkconfig.h`. Jeżeli istnieje wersja odpowiadająca aktualnemu `framework-arduinoespressif32` / `framework-arduinoespressif32-libs`, zarchiwizować ją jako artefakt pomocniczy i zweryfikować kluczowe `CONFIG_*`.

# R102. KCONFIG SEARCH FINALIZATION — BRAK ARCHIWALNEGO SDKCONFIG

**Data:** 2026-09-24

## Wykonany test

Użytkownik przeszukał projekt PowerShell-em pod kątem `sdkconfig*` oraz `sdkconfig.h`, a następnie osobno przeszukał zainstalowany framework ESP32:

```powershell
Get-ChildItem "$env:USERPROFILE\\.platformio\\packages\\framework-arduinoespressif32*" -Recurse -Force -File -Filter "sdkconfig.h" -ErrorAction SilentlyContinue |
    Select-Object -ExpandProperty FullName
```

Wynik dla frameworku:

```text
brak wyników
```

Wcześniejsze przeszukanie projektu wykazało wyłącznie:

```text
sdkconfig.defaults
sdkconfig.defaults w przykładach bibliotek
sdkconfig.h w katalogach test/stub managed_components
```

Nie ma wygenerowanego `sdkconfig` odpowiadającego buildowi `esp32-s3-n16r8`.

## Decyzja

Nie wykonujemy kolejnych poszukiwań `sdkconfig` i nie generujemy sztucznego pliku wynikowego.

R89 otrzymuje końcowy status:

```text
R89 = NOT ARCHIVED / BUILD ARTIFACT UNAVAILABLE
```

Jest to ograniczenie **archiwizacji baseline**, nie dowód na brak lub nieobecność konkretnych funkcji Kconfig w firmware.

## Co pozostaje wiarygodne

R90 jest zamknięte na podstawie rzeczywistego obrazu:

```text
firmware.bin = 1,852,848 B
OTA slot     = 3,145,728 B
headroom     = 1,292,880 B = 41.10%
```

`firmware.elf`, `firmware.map`, `partitions.bin` i `idedata.json` są zachowane jako artefakty baseline.

## Ograniczenie interpretacyjne

Nie wolno na podstawie samego `sdkconfig.defaults` twierdzić, że finalne wartości takich opcji jak:

```text
CONFIG_TASK_WDT_TIMEOUT_S
CONFIG_SPIRAM_MALLOC_ALWAYSINTERNAL
CONFIG_ESP_COREDUMP_MAX_TASKS_NUM
CONFIG_ESP_COREDUMP_ENABLE_TO_FLASH
```

są identyczne w obrazie `firmware.bin`.

Te wartości pozostają **niezweryfikowane na poziomie finalnego Kconfig**.

## Decyzja dla dalszych prac

Nie blokujemy dalej prac telemetrycznych wyłącznie z powodu braku archiwalnego `sdkconfig`, ponieważ:

1. mamy rzeczywiście zlinkowany obraz baseline,
2. znamy dokładny rozmiar slotów OTA,
3. mamy ELF i MAP do analizy wpływu zmian,
4. `idedata.json` identyfikuje env, wersję IDF i zależności,
5. Commit A jest diagnostyczno-danychowy i nie powinien zmieniać ścieżki Firebase ani coredump/storage.

Przy pierwszym kolejnym pełnym buildzie po zmianach należy próbować zachować `sdkconfig`/konfigurację wynikową, jeżeli PlatformIO w tym trybie ją wygeneruje; nie zmieniać konfiguracji tylko po to, aby ją wymusić.

# R103. COMMIT A ENTRY GATE — BASELINE PRZYJĘTY Z JAWNYM CAVEATEM

**Status: READY TO IMPLEMENT**

## Baseline wejściowy

```text
firmware.bin                         1,852,848 B
OTA app slot                         3,145,728 B
headroom                             1,292,880 B (41.10%)
TelemetrySample draft                64 B
ring 1440                            92,160 B (~90 KiB)
representative JSON                 ~256 B/record
batch 10                             ~2.52 KiB payload
```

## Co Commit A może zawierać

Wyłącznie elementy lokalne, bez sieci:

```text
TelemetrySample
TelemetryRing
snapshot/freshness metadata
record identity
diagnostic counters
static_assert(sizeof(TelemetrySample) == 64)
```

## Czego nie dodawać

```text
Firebase endpoint
FirebaseClient upgrade
nowy AsyncClient
nowy FirebaseApp
persistent spool
zmiany auth/TLS
zmiana partitions.csv
zmiana toolchainu
zmiana interwału /piec/status
zmiana automatyki sterowania
```

## Warunek buildowy po Commit A

Pierwszy build po zmianie musi zebrać ponownie:

```text
firmware.bin
firmware.elf
firmware.map
partitions.bin
idedata.json
```

oraz, jeżeli zostanie wygenerowany:

```text
sdkconfig.<env>
```

Należy porównać:

```text
binary size delta
flash.text delta
flash.rodata delta
iram delta
DRAM/static data delta
```

## PASS dla wejścia w Commit B

```text
build PASS
firmware fits 3 MiB
static_assert PASS
ring unit/self-test PASS
snapshot consistency PASS
no Firebase behavior change
no RTDB write
no new WDT/heap regression
```

**Następny krok po R103: implementacja Commit A w aktualnym `main_centrala (3).cpp`, bez zmian w Firebase.**

# R104. COMMIT-SCOPE CONSISTENCY AUDIT — KOREKTA DEFINICJI ETAPÓW

**Data:** 2026-09-24  
**Status:** ZAKOŃCZONE — korekta planu przed implementacją

## Problem

W planie istnieją dwie różne definicje `Commit A`:

1. wcześniejsza, bardziej rygorystyczna sekwencja:

```text
A = diagnostics only
B = metadata/freshness/identity
C = RAM ring
D = Firebase single batch
E = batch/backlog
```

2. późniejsze R103, które rozszerzało `Commit A` aż do `TelemetryRing`, snapshotu i identity.

Takie rozszerzenie utrudniałoby atrybucję regresji. Jeżeli po jednym commicie jednocześnie zmieniłyby się pamięć, synchronizacja i zachowanie ringa, trudniej byłoby wskazać przyczynę problemu.

## Decyzja D-R104-01 — przywrócenie małych, jednoznacznych commitów

Od teraz obowiązuje ścisła kolejność:

```text
Commit A — DIAGNOSTICS ONLY
  heap / largest block / PSRAM
  stack high-water mark
  Firebase taskCount observation
  telemetry diagnostic counters, bez aktywnej telemetryki

Commit B — DATA METADATA ONLY
  TelemetrySample
  freshness timestamps / ages
  quality state
  sessionNonce + sampleSeq
  bez ringa i bez Firebase upload

Commit C — RAM RING ONLY
  TelemetryRing
  producer / peek / commit / rollback
  overflow policy
  bez sieci

Commit D — FIREBASE SINGLE BATCH
  jeden request
  jeden in-flight
  deterministic record_id
  success -> commit ring
  fail/timeout -> rollback

Commit E — BACKLOG / ADAPTIVE BATCH
  batch 2/5/10/20 benchmark
  limity payload bytes
  retry/backoff
  backlog drain
```

## Reinterpretacja R103

R103 pozostaje **gate'em wejściowym do implementacji telemetryki**, ale nie jest już definicją zakresu pojedynczego commitu.

`TelemetrySample=64 B`, model ringa, identity i JSON budget pozostają zamrożonym projektem badawczym. Ich implementację rozdzielamy na B/C.

## Powód techniczny

Mniejsze zmiany dają trzy korzyści:

```text
1. łatwiejszy rollback
2. dokładniejszy pomiar delta BIN/ELF/RAM
3. prostsza identyfikacja regresji WDT / scheduler / heap
```

Nie zmienia się docelowa architektura telemetryki — zmienia się tylko bezpieczna kolejność implementacji.

## Kryterium przejścia A -> B

Najpierw musimy mieć działający build A oraz pomiar runtime bez nowych zapisów RTDB i bez wprowadzania ringa.

---

# R105. KCONFIG PROVENANCE — KOREKTA ZAŁOŻENIA DLA BUILD-U ARDUINO

**Data:** 2026-09-24  
**Status:** ZAKOŃCZONE

## Ustalenie

Obecny projekt ma `framework = Arduino`, a nie projekt `framework = espidf`.

W dostarczonym buildzie `idedata.json` potwierdza m.in.:

```text
build_type = release
env_name   = esp32-s3-n16r8
IDF_VER    = v5.5.4
BOARD_HAS_PSRAM
F_CPU      = 240000000L
```

W tym trybie wcześniejsze założenie:

```text
„musi istnieć projektowy sdkconfig.esp32-s3-n16r8”
```

było zbyt szerokie. Dokumentacja PlatformIO opisuje `sdkconfig.<env>` przede wszystkim dla projektu używającego ESP-IDF build systemu. Arduino-ESP32 może korzystać z prekompilowanych bibliotek/frameworku, w których konfiguracja Kconfig jest częścią pakietu frameworka.

## Co potwierdza lokalny audyt

W katalogu projektu użytkownik nie znalazł:

```text
sdkconfig
sdkconfig.esp32-s3-n16r8
```

W zainstalowanym pakiecie `framework-arduinoespressif32*` nie znaleziono także `sdkconfig.h`.

Nie znaleziono zatem archiwalnego artefaktu, który można bezpiecznie przedstawić jako „finalny sdkconfig tego buildu”.

## Decyzja D-R105-01

R89 zmieniamy z:

```text
BLOCKER IMPLEMENTACJI
```

na:

```text
ARCHIVE GAP / NO FURTHER SEARCH
```

Nie wymuszamy `menuconfig`, nie przełączamy projektu na ESP-IDF, nie dodajemy własnego `sdkconfig` tylko po to, żeby spełnić wymóg dokumentacyjny.

## Co jest źródłem prawdy dla baseline

Na obecnym etapie za baseline przyjmujemy wspólnie:

```text
firmware.bin
firmware.elf
firmware.map
partitions.bin
idedata.json
platformio.ini
partitions.csv
sdkconfig.defaults
```

`sudoconfig.defaults` jest źródłem ustawień wejściowych, ale nie będzie opisywany jako finalny wynik dependency resolution.

## Procedura na przyszłość

Przy kolejnym pełnym buildzie zachowujemy:

```text
build log -v
firmware.bin
firmware.elf
firmware.map
idedata.json
```

Jeżeli narzędzia wygenerują jawny `sdkconfig` lub odpowiedni artefakt konfiguracyjny — również go archiwizujemy. Nie zmieniamy konfiguracji tylko po to, aby taki plik powstał.

## Źródła

- PlatformIO Espressif32 docs: https://docs.platformio.org/en/latest/platforms/espressif32.html
- Arduino-ESP32 `platform.txt`: https://github.com/espressif/arduino-esp32/blob/master/platform.txt

---

# R106. STACK HIGH-WATER MARK — JEDNOSTKA NA ESP32-S3

**Data:** 2026-09-24  
**Status:** ZAKOŃCZONE — ważna korekta diagnostyczna

## Ustalenie źródłowe

Dokumentacja ESP32-S3 dotycząca użycia RAM opisuje `uxTaskGetStackHighWaterMark()` jako wartość minimalnego zapasu stosu mierzoną **w bajtach** na tym targetcie.

Jest to ważne, ponieważ ogólna dokumentacja FreeRTOS/ESP-IDF może opisywać high-water mark w słowach zależnie od warstwy/architektury. Dla raportowania na ESP32-S3 nie wolno automatycznie wykonywać:

```text
returned_value * 4
```

bez potwierdzenia konkretnej deklaracji/implementacji użytej w buildzie.

## Wniosek dla istniejącego firmware

Istniejący stan diagnostyczny ma pole nazwane:

```text
stackHwmWords
```

Nazwa jest potencjalnie myląca dla ESP32-S3. Semantycznie raport powinien być traktowany jako:

```text
stackHwmBytes
```

dopóki inspekcja konkretnego nagłówka/toolchainu nie wykaże inaczej.

## Decyzja D-R106-01

Commit A ma:

```text
reportować HWM jako bytes
nie wykonywać sztucznej konwersji
nie zmieniać jeszcze nazwy historycznego pola, jeśli wymagałoby to niepotrzebnej migracji RTC/logów
```

Jeżeli nazwa zostanie zmieniona, będzie to zmiana czysto diagnostyczna i musi zachować jednoznaczność archiwalnych raportów.

## Znaczenie dla baseline

Przy porównaniu A/B/C będziemy zapisywać:

```text
stack_hwm_current_task_bytes
stack_hwm_low_watermark_bytes
```

oraz — tam, gdzie to możliwe — HWM dla pozostałych tasków.

Nie będziemy porównywać tych liczb z błędną jednostką „words”.

## Źródło

- ESP32-S3 RAM Usage / Stack high-water mark: https://docs.espressif.com/projects/esp-idf/en/release-v5.5/esp32s3/api-guides/performance/ram-usage.html
- ESP-IDF FreeRTOS API: https://docs.espressif.com/projects/esp-idf/en/release-v5.5/esp32/api-reference/system/freertos.html


# R107. SNAPSHOT CONSISTENCY — WŁAŚCICIELSTWO PÓL I MULTI-CORE

**Data:** 2026-09-24  
**Status:** ZAKOŃCZONE — decyzja dla Commit B

## Audyt aktualnego kodu

W `main_centrala.cpp` widać trzy różne klasy danych:

### A. Pomiary temperatur

`Czujnik_DS()` aktualizuje komplet temperatur w jednym miejscu:

```text
temperaturaOgrzewania
temperaturaPaneluSlonecznego
temperaturaPomieszczenia
temperaturaBojlera
temperaturaNaZewnatrz
temperaturaOgrzewania_Trociny
temperaturaOgrzewania_Powrot
```

Jest to dobry kandydat na własność jednego kontekstu wykonania. Snapshot uruchamiany po tej aktualizacji może dostać spójny zestaw wartości pomiarowych bez dokładania globalnego locka do każdej zmiennej.

### B. Pozycje serw

Kod wyraźnie rozdziela:

```text
Core 0 -> docelowaKlapaProcent / docelowaSyberekProcent
Core 1 -> pozycjaKlapa / pozycjaSyberek
```

To jest poprawny wzorzec ownership. Telemetria ma odczytywać **fizyczną pozycję**, a nie oczekiwane polecenie.

### C. Flagi alarmowe

Występują zapisy do:

```text
alarmOgrzewanieWlaczone
alarmPanelWlaczone
czyAlarmAktywny
```

zarówno w logice alarmowej, jak i w ścieżce komend Telegram/Firebase.

Dla tych wartości nie ma obecnie jednego właściciela CPU.

## Wniosek

Nie wolno przyjąć modelu:

```text
„snapshot = kilka odczytów globali z różnych miejsc, więc cały obiekt jest atomowy”
```

To nie wynika z samego faktu, że pojedynczy `bool`/`int` jest mały.

## Decyzja D-R107-01

Commit B dzielimy logicznie na:

```text
measurement snapshot
    -> pola posiadające jednoznacznego właściciela

control/alarm state
    -> tylko pola, dla których kontrakt synchronizacji jest jawnie ustalony
```

Nie wprowadzamy `volatile` jako substytutu synchronizacji.

Dla stanu wielokrotnie zapisywanego z różnych rdzeni obowiązuje jedna z dwóch metod:

```text
A) jeden właściciel stanu + komunikacja między rdzeniami
B) jawny lock / sekwencja snapshotu obejmująca writerów i readera
```

## Preferencja V1

Najmniejszy zakres ryzyka daje:

```text
Commit B:
  pełne metadata/freshness dla pomiarów
  minimalny stan sterownika pochodzący z jednoznacznego ownera

stan alarmowy multi-writer:
  dopiero po domknięciu kontraktu synchronizacji
```

Nie trzeba więc zatrzymywać całej telemetryki z powodu kilku problematycznych flag.

## PASS dla snapshotu

Test powinien wykonywać równocześnie:

```text
Core 1: aktualizacja sensorów
Core 0: komenda zmiany stanu / alarmu
snapshot: odczyt telemetryczny
```

i sprawdzać, że rekord nie przedstawia niemożliwej kombinacji pól.

---

# R108. SPSC RING — SYNCHRONIZACJA I DŁUGOŚĆ SEKCJI KRYTYCZNEJ

**Data:** 2026-09-24  
**Status:** ZAKOŃCZONE — decyzja architektoniczna

## Model

Docelowy TelemetryRing ma jednego producenta i jednego konsumenta:

```text
producer: historiaZapiszProbke()
consumer: istniejąca ścieżka Firebase / writer telemetryczny
```

Jest to klasyczny model SPSC.

## Synchronizacja

ESP-IDF dla systemu SMP na ESP32-S3 używa `portMUX_TYPE` jako właściwego mechanizmu sekcji krytycznej współdzielonej pomiędzy rdzeniami. Sama instrukcja wyłączenia przerwań nie jest równoważna synchronizacji CPU0 <-> CPU1.

Sekcja krytyczna ma pozostać bardzo krótka i nie może wykonywać:

```text
malloc / free
String
I/O
vTaskDelay
network
Firebase
```

## Wariant V1

Najprostszy kontrakt:

```text
peek N
  ↓
kopiuj maks. N * sizeof(TelemetrySample)
  ↓
unlock
  ↓
serializacja/upload poza lockiem
  ↓
commit N po sukcesie
```

Dla:

```text
N = 10
sizeof(TelemetrySample) = 64 B
```

kopiowany fragment to maksymalnie:

```text
640 B
```

To powinno być mierzone na realnym ESP32-S3 jako czas spędzony w sekcji krytycznej, nie oceniane wyłącznie „na oko”.

## Dlaczego nie lock-free atomics na start

Lock-free ring może ograniczyć critical-section time, ale zwiększa liczbę założeń dotyczących:

```text
memory ordering
ABA / wrap-around
publikacji danych
rezerwacji elementu
rollback po błędzie sieci
```

Nie ma uzasadnienia, aby w V1 dodawać tę złożoność przed pomiarem prostszego SPSC.

## Overrun policy

Musimy jawnie wybrać:

```text
DROP_NEWEST
```

albo:

```text
OVERWRITE_OLDEST
```

W pierwszej implementacji preferujemy zachowanie, które **nie ukrywa utraty danych**: każda utrata ma zwiększać `telemetry_ring_dropped`.

Jeżeli wybór policy będzie zależał od UX aplikacji, pozostaje parametrem przed Commit C.

## Invariant

Nigdy:

```text
tail += N
```

przed potwierdzeniem powodzenia uploadu.

---

# R109. SESSION NONCE — ŹRÓDŁO ENTROPII I MOMENT GENEROWANIA

**Data:** 2026-09-24  
**Status:** ZAKOŃCZONE

## Wymaganie

Identity telemetryki ma być:

```text
sessionNonce + sampleSeq
```

Nie używamy timestampu jako jedynego klucza.

## ESP32-S3 RNG

Dokumentacja ESP-IDF opisuje `esp_random()` / `esp_fill_random()` jako źródło sprzętowego RNG, ale gwarancja nie jest identyczna w każdej fazie bootu: po uruchomieniu aplikacji właściwej jakości entropii dostarcza m.in. aktywne radio RF (Wi-Fi/Bluetooth) albo odpowiednio aktywowane źródło entropy.

## Wniosek

Jeżeli `sessionNonce` ma być generowany jako 64-bitowa losowa wartość, naturalnym miejscem dla obecnego projektu jest etap, w którym Wi-Fi/RF jest już uruchomione, ale przed utworzeniem pierwszej próbki telemetrycznej.

Nie ma potrzeby zapisywania nonce do NVS.

## Algorytm V1

```text
uint64_t nonce =
    ((uint64_t)esp_random() << 32) |
    (uint64_t)esp_random();
```

Dodatkowo:

```text
jeżeli nonce == 0 -> wygeneruj ponownie
```

Nonce jest identyfikatorem **sesji**, a nie sekretem uwierzytelniającym.

## `sampleSeq`

```text
start = 1
increment = 1 / każda przyjęta próbka
wrap = traktować jako błąd projektowy, nie normalny przypadek
```

Przy 1440 próbkach/dobę 32-bitowy zakres jest wielokrotnie większy od praktycznego czasu życia sesji.

## Format record_id

Nadal obowiązuje:

```text
<16 hex sessionNonce>-<8 hex sampleSeq>
```

czyli:

```text
25 ASCII znaków
```

Przykład:

```text
0123456789ABCDEF-00000001
```

## Źródło

- ESP32-S3 Random Number Generation: https://docs.espressif.com/projects/esp-idf/en/release-v5.5/esp32s3/api-reference/system/random.html


# R110. COMMIT A — WYKORZYSTANIE ISTNIEJĄCEJ DIAGNOSTYKI ZAMIAST NOWEGO TASKA

**Data:** 2026-09-24  
**Status:** ZAKOŃCZONE — zakres Commit A doprecyzowany

## Co już istnieje w firmware

`diagCheckpoint()` zapisuje dla monitorowanych tasków m.in.:

```text
op
stage
detail
uptimeMs
seq
freeHeap
largestBlock
stackHwmWords
```

Pełny pomiar heap/largest block/HWM wykonywany jest zawsze przy `DIAG_STAGE_BEFORE` oraz okresowo co 16 checkpointów.

Firmware ma także globalny heartbeat zdrowia oraz osobne diagnostyczne informacje dla `tgTask`/Firebase.

## Konsekwencja

Nie ma uzasadnienia dla nowego `DiagnosticsTask`.

Commit A powinien **rozszerzyć istniejący kanał diagnostyczny**, a nie tworzyć drugi scheduler/timer/task.

## Zakres A

Do dodania jako lokalna diagnostyka:

```text
heap internal free
heap internal largest block
PSRAM free
PSRAM largest block
minimum-ever dla obu klas pamięci, jeśli przydatne
stack HWM bieżącego taska
licznik próbek telemetrycznych (na razie 0 / placeholder)
telemetry skipped counters (placeholder)
Firebase queue depth observation
```

## Ważne rozróżnienie

`ESP.getFreeHeap()` i `heap_caps_get_largest_free_block(MALLOC_CAP_8BIT)` opisują zagregowaną dostępność pamięci zgodnie z capability allocatorami; wolna pamięć nie oznacza automatycznie możliwości pojedynczej dużej alokacji, dlatego `largest free block` musi być mierzony osobno.

## Minimalny koszt Commit A

Nie tworzymy jeszcze:

```text
TelemetryRing
TelemetrySample
JSON
Firebase request
persistent spool
```

A więc sam A nie powinien wymagać ~90 KiB PSRAM na ring i nie powinien zmieniać ruchu sieciowego.

## Test A

Baseline należy traktować jako:

```text
cold boot
→ normalna praca ~30 min
→ WiFi/WAN OK
→ zapis heartbeat/diagnostyki
```

oraz jako drugi scenariusz:

```text
normalna praca
→ WiFi OFF
→ 10–30 min
→ WiFi ON
```

Nie oceniamy jeszcze backlogu telemetrycznego; badamy wyłącznie, czy sama warstwa diagnostyczna nie zmienia zachowania systemu.

## PASS

```text
brak nowych restartów
brak wzrostu WDT
brak wycieku pamięci
brak zmiany scheduler latency
brak zmiany status/cmd Firebase
brak RTDB telemetry writes
```

## Źródła

- ESP-IDF Heap API / memory capabilities: https://docs.espressif.com/projects/esp-idf/en/release-v5.5/esp32/api-reference/system/mem_alloc.html
- ESP32-S3 RAM Usage: https://docs.espressif.com/projects/esp-idf/en/release-v5.5/esp32s3/api-guides/performance/ram-usage.html

---

# R111. FIREBASE ASYNC QUEUE — BACKPRESSURE I KOSZT OCZEKUJĄCYCH ZADAŃ

**Data:** 2026-09-24  
**Status:** ZAKOŃCZONE — projekt mechanizmu D/E

## Fakty z biblioteki

`AsyncClientClass` posiada kolejkę zadań i publiczną metodę:

```cpp
size_t taskCount();
```

`Database.update<object_t>()` jest obsługiwanym sposobem wysłania JSON PATCH do RTDB.

W aktualnej dyskusji maintainer biblioteki podał dla ESP32 domyślny limit:

```text
FIREBASE_ASYNC_QUEUE_LIMIT = 10
```

i wskazał orientacyjnie około 1 KB RAM na oczekujące zadanie.

Źródło tego ostatniego parametru jest odpowiedzią maintainera w GitHub Discussion, więc traktujemy go jako **wartość operacyjną do testu**, a nie jako gwarant ABI każdej przyszłej wersji biblioteki.

## Wniosek dla centrali

Nie wolno robić:

```text
1 próbka
↓
1 task
↓
1 task/min
↓
przy offline requesty kumulują się do limitu
```

To byłby błędny model V1.

## Poprawny model

```text
ring PSRAM
   ↓
peek batch
   ↓
jedno Database.update<object_t>()
   ↓
1 task w kolejce
   ↓
sukces -> commit ring
```

Nawet 10 rekordów telemetrycznych tworzy logicznie **jeden request**, a nie dziesięć tasków Firebase.

## High-watermark

Przed enqueue telemetryki odczytujemy:

```cpp
fbAsyncClient.taskCount()
```

i stosujemy zachowawczą politykę:

```text
queue niska     -> telemetry może wejść
queue wysoka    -> telemetry skip/defer
queue pełna     -> żadnego nowego taska
```

Dokładny próg `HIGH_WATERMARK` pozostaje parametrem eksperymentu, bo obecny firmware ma również status/commands i potencjalne taski auth.

## Decyzja D-R111-01

Nie zwiększamy:

```text
FIREBASE_ASYNC_QUEUE_LIMIT
```

tylko po to, żeby „zmieścić telemetrykę”.

Priorytetem jest mała kolejka i backpressure.

## Dodatkowy invariant

Telemetryka nie może wyprzeć:

```text
status
commands
```

z istniejącej kolejki.

W praktyce oznacza to, że uploader telemetryczny musi być uruchamiany dopiero po gate'ach istniejącego `tgTaskFn()` i nigdy nie może „drenować na siłę” niezależnie od reszty Firebase.

## Źródła

- FirebaseClient async client docs: https://github.com/mobizt/FirebaseClient/blob/main/resources/docs/async_client.md
- FirebaseClient RTDB update docs: https://github.com/mobizt/FirebaseClient/blob/main/resources/docs/realtime_database.md
- FirebaseClient maintainer discussion #330: https://github.com/mobizt/FirebaseClient/discussions/330

---

# R112. BATCH PAYLOAD — LICZBA REKORDÓW NIE MOŻE BYĆ JEDYNYM LIMITEM

**Data:** 2026-09-24  
**Status:** ZAKOŃCZONE — kontrakt D/E

## Projekt

Wstępne założenie:

```text
MAX_BATCH_RECORDS = 10
```

pozostaje rozsądne jako górna granica pierwszego eksperymentu.

Jednak nie wystarczy limit rekordów, ponieważ przyszły schemat może zwiększyć rozmiar pojedynczego rekordu.

## Dwa niezależne limity

Uploader będzie podlegał jednocześnie:

```text
max_records
max_payload_bytes
```

Czyli batch kończy się wcześniej, gdy którykolwiek limit zostanie osiągnięty.

## Szacowany aktualny koszt

Dla zamrożonego modelu:

```text
~256 B / rekord
~2.52 KiB / 10 rekordów
```

To jest payload JSON, nie całkowity transfer TLS/HTTP.

## Praktyczna zasada

Serializer nie może najpierw stworzyć ogromnego `String`, a dopiero potem sprawdzać limit.

Docelowo:

```text
peek
→ policz/serializuj rekord po rekordzie
→ gdy następny przekroczy limit, zamknij batch
→ enqueue
```

Duży bufor serializerowy ma być jawnie lokowany w PSRAM, jeżeli będzie potrzebny.

## Dlaczego nie limit 16 MB Firebase

Oficjalny limit pojedynczego write SDK jest wielokrotnie wyższy od naszych potrzeb. W tym projekcie rzeczywistym ograniczeniem są:

```text
RAM
czas requestu
kolejka Firebase
wpływ na tgTask
WDT margin
```

a nie sam maksymalny rozmiar RTDB write.

## Benchmark D/E

Mierzyć dla:

```text
2 / 5 / 10 / 20 rekordów
```

oraz dla payload capów, aby uzyskać:

```text
payload_bytes
serialize_time
enqueue_time
request_duration
RAM low-watermark
```

## Źródła

- Firebase RTDB usage limits: https://firebase.google.com/docs/database/usage/limits
- FirebaseClient RTDB update: https://github.com/mobizt/FirebaseClient/blob/main/resources/docs/realtime_database.md

---

# R113. CROSSES MIDNIGHT — BATCH MOŻE OBEJMOWAĆ DWA SHARDY DNIA

**Data:** 2026-09-24  
**Status:** ZAKOŃCZONE — przypadek brzegowy schema v1

## Problem

Przy:

```text
/piec/telemetry/1m/v1/YYYY/MM/DD/
```

batch może naturalnie zawierać rekordy z:

```text
23:59
00:00
00:01
```

czyli dwóch różnych shardów dnia.

## Wniosek

Nie wolno budować ścieżki całego batcha na podstawie timestampu pierwszego rekordu.

Każdy rekord musi mieć własny:

```text
year
month
day
record_id
```

wyliczony z jego `ts`.

## Dopuszczalny wariant V1

Firebase `update` może przygotować wielościeżkowy PATCH obejmujący oba dni, ponieważ update działa na wielu wskazanych ścieżkach.

Przykładowo logicznie:

```text
updates["/2026/09/24/idA"] = recA
updates["/2026/09/25/idB"] = recB
```

Nie oznacza to dwóch requestów.

## Wariant alternatywny

Można również przeciąć batch na granicy dnia i wykonać dwa requesty, ale nie ma powodu narzucać tego w V1.

Preferujemy:

```text
jedna atomowa operacja

jeśli payload/czas pozostaje w limicie
```

## `ts=0`

Rekord bez wiarygodnego czasu nie ma prawidłowego sharda kalendarzowego.

Dlatego nie wolno mapować:

```text
ts=0 -> 1970/01/01
```

w normalnej ścieżce telemetrycznej.

Taki przypadek wymaga osobnej polityki (`unknown-time` / lokalny spool / drop z licznikiem) i pozostaje jawnie otwarty przed Commit D.

## Decyzja D-R113-01

Generator path nie może zakładać jednego dnia dla całego batcha.

---


# R114. FIREBASE `object_t` — WŁASNOŚĆ PAYLOADU ASYNC

**Data:** 2026-09-24  
**Status:** ZAKOŃCZONE — kontrakt do Commit D

## Ustalenie źródłowe

Dokumentacja FirebaseClient opisuje tryb async jako kolejkę FIFO, w której zadanie zawiera wstępnie przygotowane dane żądania HTTP, w tym payload.

To oznacza, że architektura może tworzyć `object_t`/JSON jako obiekt lokalny podczas enqueue, zamiast wymagać jego życia aż do zakończenia requestu.

## Ważne ograniczenie

Nie wolno jednak z tego wyprowadzać ogólnej gwarancji dla każdego przyszłego wydania biblioteki.

Projekt używa constraint:

```text
mobizt/FirebaseClient @ ^2.2.9
```

więc dokładna wersja rozwiązywana przez PlatformIO musi być traktowana jako element baseline biblioteki, a test Commit D ma potwierdzić rzeczywisty lifetime w naszym buildzie.

## Decyzja D-R114-01

Producent telemetryczny może docelowo działać według schematu:

```text
build JSON
↓
object_t
↓
Database.update<object_t>(...)
↓
koniec lokalnego scope
```

ale przed użyciem tego wzorca w produkcji musi przejść test:

```text
lokalny buffer/object_t zniszczony natychmiast po enqueue
→ request kończy się poprawnie
→ payload nie ulega zmianie
```

## Czego nie robimy

Nie przechowujemy wskaźnika:

```text
char* -> lokalny String
```

i nie zakładamy, że pointer zostanie użyty później przez Firebase.

Bezpieczny kontrakt opiera się na fakcie, że async task przechowuje przygotowane dane żądania, a nie na czasie życia naszego bufora.

## Źródła

- FirebaseClient working principle: https://github.com/mobizt/FirebaseClient
- FirebaseClient AsyncClient docs: https://github.com/mobizt/FirebaseClient/blob/main/resources/docs/async_client.md
- FirebaseClient RTDB update docs: https://github.com/mobizt/FirebaseClient/blob/main/resources/docs/realtime_database.md

---

# R115. JEDEN SSL CLIENT — POTWIERDZENIE KONTRAKTU TRANSPORTOWEGO

**Data:** 2026-09-24  
**Status:** ZAKOŃCZONE

## Stan aktualnego firmware

Kod posiada jeden zestaw obiektów Firebase:

```text
WiFiClientSecure  fbSSLClient
AsyncClientClass  fbAsyncClient(fbSSLClient)
FirebaseApp       fbApp
RealtimeDatabase  fbDatabase
```

Nie tworzymy drugiego klienta SSL dla telemetryki.

## Źródło zewnętrzne

Maintainer FirebaseClient wskazuje, że klient SSL przypisany do `AsyncClientClass` powinien być używany przez ten mechanizm, a nie współdzielony z innym, równoległym kodem.

Wniosek ten jest szczególnie ważny dla naszej centrali, ponieważ obecny firmware ma już własne mechanizmy ochrony przed równoległym wejściem do `fbApp.loop()`.

## Decyzja D-R115-01

Telemetryka:

```text
nie dostaje własnego WiFiClientSecure
nie dostaje własnego AsyncClientClass
nie dostaje własnego FirebaseApp
nie uruchamia drugiego fbApp.loop()
```

Zamiast tego korzysta z istniejącego toru:

```text
fbSSLClient
   ↓
fbAsyncClient
   ↓
fbApp
   ↓
istniejący gate / worker / circuit breaker
```

## Dlaczego to jest ważniejsze niż sama liczba requestów

Aktualny firmware już zawiera guard:

```text
fbLoopWorkerZajety()
```

który ma chronić przed dwoma taskami pracującymi równolegle na tych samych obiektach Firebase.

Dodanie drugiego klienta „dla telemetryki” obchodziłoby tę ochronę i zwiększało liczbę aktywnych połączeń, buforów TLS oraz stanów biblioteki.

## PASS Commit D

W testach musi być udowodnione:

```text
maksymalnie jeden telemetry request in-flight
maksymalnie jeden worker fbApp.loop
brak drugiego SSL client
```

## Źródła

- FirebaseClient working principle: https://github.com/mobizt/FirebaseClient
- Maintainer Discussion #330: https://github.com/mobizt/FirebaseClient/discussions/330

---

# R116. `ts=0` — PRÓBKA BEZ WIARYGODNEGO CZASU

**Data:** 2026-09-24  
**Status:** ZAKOŃCZONE CZĘŚCIOWO — polityka V1 nadal wymaga decyzji produktowej

## Fakty z obecnego firmware

Historia zapisuje:

```text
czas_unix = 0
```

gdy RTC/NTP nie jest wiarygodny.

To jest już ustalona semantyka lokalnej historii i telemetryka nie może zamienić tego na fikcyjny epoch.

## Problem z dziennym shardem

Docelowy normalny path to:

```text
/piec/telemetry/1m/v1/YYYY/MM/DD/<record_id>
```

Nie da się uczciwie wyliczyć `YYYY/MM/DD` dla:

```text
ts = 0
```

## Zabroniona transformacja

Nigdy:

```text
0 -> 1970/01/01
```

w normalnym strumieniu telemetrycznym.

Byłoby to technicznie wygodne, ale semantycznie fałszywe i utrudniłoby zakresowe query aplikacji.

## Kandydaci V1

### Opcja A — `unknown-time`

```text
/piec/telemetry/1m/v1/unknown/<sessionNonce>/<record_id>
```

Zaleta: rekord nie ginie.  
Wada: aplikacja musi obsługiwać osobny strumień poza osią czasu.

### Opcja B — lokalny spool

```text
ts=0 -> ring/spool
→ wysyłka dopiero po synchronizacji czasu
```

To nie rozwiązuje jednak już istniejącego problemu: historyczna chwila pomiaru nadal nie jest znana po synchronizacji, więc nie wolno retroaktywnie wymyślać timestampu.

### Opcja C — drop z licznikiem

```text
ts=0 -> telemetry_drop_unknown_time++
```

Zachowuje czystość cloud time-series, ale świadomie traci próbkę.

## Decyzja tymczasowa

Do czasu decyzji produktowej:

```text
ts=0 = nie wysyłać do normalnego sharda
```

i nie tworzyć fałszywego czasu.

Dokładny wybór A/B/C pozostaje OPEN przed Commit D.

---

# R117. FIRMWARE VERSIONING — TELEMETRYKA MUSI RESPEKTOWAĆ ISTNIEJĄCY CHANGELOG

**Data:** 2026-09-24  
**Status:** ZAKOŃCZONE

## Reguła istniejącego źródła

Aktualny `main_centrala.cpp` ma twardą zasadę:

```text
każda zmiana funkcjonalna
→ bump FIRMWARE_VERSION wg semver
→ nowy wpis na samej górze changelogu
```

Opis wymaga też rozbicia zmian powiązanych na podpunkty `[X.1]`, `[X.2]` itd., gdy jedna wersja zawiera kilka zależnych napraw/zmian.

## Konsekwencja

Każdy telemetryczny commit funkcjonalny jest również zmianą wersji firmware.

Plan wersji:

```text
Commit A diagnostics  -> nowa wersja PATCH/MINOR zależnie od widocznej funkcji
Commit B metadata     -> kolejna wersja
Commit C ring         -> kolejna wersja
Commit D Firebase     -> kolejna wersja
Commit E backlog      -> kolejna wersja
```

Nie będziemy „upychać” kilku etapów pod jednym numerem tylko po to, żeby ograniczyć liczbę wersji.

## Czy A/B/C są MAJOR?

Nie zakładamy automatycznie MAJOR. Klasyfikacja semver ma wynikać z faktycznej kompatybilności:

```text
PATCH  = zmiana bez zewnętrznej zmiany kontraktu
MINOR  = nowa funkcjonalność kompatybilna wstecz
MAJOR  = złamanie istniejącego formatu/API/NVS
```

Dopóki telemetryka V1 nie zmienia istniejących formatów historii/NVS/API, nie ma powodu zakładać MAJOR.

## Decyzja D-R117-01

Przed pierwszą edycją kodu telemetrycznego trzeba wskazać dokładnie:

```text
FIRMWARE_VERSION aktualnej wersji = 3.11.4
wersja Commit A = do ustalenia przed patch
```

Należy też zachować poprzednią wartość jako baseline rollback.

---

# R118. TELEMETRIA A — FINALNY KONTRAKT DIAGNOSTYCZNY PRZED KODEM

**Data:** 2026-09-24  
**Status:** READY — bez zmian w firmware

## Commit A zawiera wyłącznie

```text
A1  internal heap free
A2  internal largest block
A3  PSRAM free
A4  PSRAM largest block
A5  minimum-ever / low-watermark tam, gdzie dostępne
A6  stack HWM jako bytes
A7  Firebase taskCount observation
A8  placeholder telemetry counters
A9  opcjonalny telemetry memory budget report
```

## Commit A nie zawiera

```text
TelemetrySample storage
TelemetryRing
freshness metadata
sessionNonce
sampleSeq
JSON
Database.update
nowy task
persistent spool
new endpoint
Rules/auth/TLS migration
```

## Instrumentacja musi być pasywna

A nie ma prawa:

```text
zmienić kolejności automatyki
zmienić częstotliwości schedulerów
wykonać sieciowego I/O
alokować duże bufory cyklicznie
blokować sekcji krytycznej
```

## Gate A

Po buildzie porównujemy do baseline:

```text
firmware.bin size
flash.text
flash.rodata
iram
data/bss
```

oraz na urządzeniu:

```text
heap free
heap largest
PSRAM free/largest
stack HWM
WDT
scheduler latency
Firebase queue depth
```

## Test minimalny

```text
cold boot
30 min normal network
30 min WiFi OFF
30 min network restored
```

Test nie wprowadza telemetrycznych zapisów do Firebase.

## Exit criteria

```text
build PASS
OTA slot PASS
no RTDB telemetry writes
no WDT regression
no unexplained heap regression
no unexplained stack regression
no scheduler/control regression
```

Dopiero po takim PASS otwieramy Commit B.


# R119. RUNTIME MEMORY BASELINE — INTERNAL DRAM VS PSRAM

**Data:** 2026-09-24  
**Status:** ZAKOŃCZONE — kontrakt pomiarowy

## Problem

`ESP.getFreeHeap()` jest użyteczne jako szybki wskaźnik, ale nie jest wystarczające do oceny telemetryki na ESP32-S3 z OPI PSRAM.

Telemetryka może naruszyć:

```text
internal DRAM
PSRAM
largest allocatable block
```

niekoniecznie zmieniając w tym samym stopniu ogólną wartość free heap.

## Pomiar internal

Dla pamięci wewnętrznej używamy capability allocator:

```cpp
MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT
```

Mierzymy trzy wartości:

```text
free_internal
largest_internal
minimum_internal
```

## Pomiar PSRAM

Dla zewnętrznej pamięci:

```cpp
MALLOC_CAP_SPIRAM
```

analogicznie:

```text
free_psram
largest_psram
minimum_psram
```

## Dlaczego `largest` jest obowiązkowy

Oficjalna dokumentacja heap allocator'a zaznacza, że suma wolnej pamięci może być większa niż największy pojedynczy blok możliwy do zaalokowania z powodu fragmentacji.

Dlatego:

```text
free != allocatable-single-buffer
```

a dla serializerów telemetrycznych właśnie ten drugi parametr jest krytyczny.

## Low-watermark

`heap_caps_get_minimum_free_size()` agreguje low-watermarki poszczególnych regionów. Nie należy przedstawiać go jako „najniższy wspólny moment czasowy wszystkich regionów”. Jest to wartość agregowana, ale bardzo użyteczna jako sygnał degradacji.

## Decyzja D-R119-01

Commit A loguje **parę free + largest + minimum** osobno dla:

```text
INTERNAL
PSRAM
```

Nie zastępujemy tych sześciu liczb jednym `ESP.getFreeHeap()`.

## Źródła

- ESP-IDF Heap Memory Allocation: https://docs.espressif.com/projects/esp-idf/en/latest/esp32/api-reference/system/mem_alloc.html
- ESP32-S3 External RAM: https://docs.espressif.com/projects/esp-idf/en/v5.5/esp32s3/api-guides/external-ram.html

---

# R120. STACK HWM ALL-TASK — METODA ZBIERANIA BEZ ZAŚMIECANIA SCHEDULERA

**Data:** 2026-09-24  
**Status:** ZAKOŃCZONE

## Aktualny stan

`diagCheckpoint()` mierzy HWM bieżącego taska.

To daje dobry sygnał dla:

```text
loopTask
tgTask
tgPollTask
historiaTask
```

ale tylko w momencie, gdy dany task wykonuje checkpoint.

## Metoda pełna

ESP-IDF dokumentuje `uxTaskGetSystemState()` jako mechanizm pozwalający pobrać podsumowanie wszystkich tasków wraz z ich HWM.

To jest właściwe narzędzie do okresowego snapshotu systemowego.

## Nie wolno wykonywać tego zbyt często

Pełny przegląd tasków wymaga bufora na informacje o taskach i jest cięższy niż zwykłe:

```cpp
uxTaskGetStackHighWaterMark(NULL)
```

Dlatego Commit A nie będzie uruchamiał `uxTaskGetSystemState()` w każdej iteracji pętli.

## Decyzja D-R120-01

Profil diagnostyczny:

```text
częste checkpointy
  -> HWM bieżącego taska

rzadki health snapshot
  -> HWM wszystkich tasków
```

Docelowo health snapshot może być wykonywany np. raz na cykl diagnostyczny, a nie co kilka ms. Dokładny interwał pozostaje parametrem implementacyjnym po zmierzeniu kosztu.

## Jednostka

Na ESP32-S3 HWM traktujemy jako:

```text
bytes
```

Nie mnożymy wartości przez rozmiar word.

## Kryterium obserwacji

Dla każdego taska rejestrujemy:

```text
name
current HWM
lowest observed HWM
```

Jeżeli źródłowy API daje tylko aktualny HWM, wartość „lowest observed” utrzymujemy po stronie diagnostyki jako minimum z pomiarów.

## Źródło

- ESP32-S3 RAM Usage: https://docs.espressif.com/projects/esp-idf/en/latest/esp32s3/api-guides/performance/ram-usage.html

---

# R121. `taskCount()` — JEDEN KONTEKST ODCZYTU

**Data:** 2026-09-24  
**Status:** ZAKOŃCZONE

## Problem

`fbAsyncClient` jest używany przez istniejącą architekturę Firebase, która obejmuje `tgTask` oraz pomocniczy worker `fbLoopWork` na innym rdzeniu.

Nie chcemy dodawać nowego cross-core readera tylko dla diagnostyki.

## Decyzja D-R121-01

`taskCount()` ma być odczytywany wyłącznie w tym samym kontekście wykonania, który już obsługuje harmonogram Firebase, czyli w istniejącej ścieżce `tgTask`.

Nie robimy:

```text
loopTask -> fbAsyncClient.taskCount()
producer -> fbAsyncClient.taskCount()
nowy diagnostics task -> fbAsyncClient.taskCount()
```

## Powód

Taki odczyt w A powinien być czystą obserwacją istniejącego klienta, a nie nowym źródłem współbieżności.

To również pozwala mierzyć kolejkę dokładnie przed/po operacji Firebase w późniejszych commitach bez wprowadzania dodatkowego locka tylko dla telemetryki.

## Zakres danych

Minimalnie:

```text
firebase_queue_depth_current
firebase_queue_depth_max_seen
firebase_queue_nonzero_samples
```

oraz osobne liczniki:

```text
telemetry_skip_queue_high
telemetry_skip_worker_busy
```

w późniejszych etapach.

## Ważne

Nie ustawiamy teraz wartości `HIGH_WATERMARK` jako arbitralnej liczby produkcyjnej. Najpierw zbieramy baseline zachowania istniejącej kolejki.

## Źródła

- FirebaseClient AsyncClient: https://github.com/mobizt/FirebaseClient/blob/main/resources/docs/async_client.md
- FirebaseClient queue guidance / maintainer: https://github.com/mobizt/FirebaseClient/discussions/330

---

# R122. DIAGNOSTIC COUNTER OWNERSHIP — ZERO „ATOMOWOŚCI NA SŁOWO”

**Data:** 2026-09-24  
**Status:** ZAKOŃCZONE

## Problem

Licznik typu:

```cpp
uint32_t telemetry_sample_total;
```

staje się problematyczny, jeśli będzie inkrementowany przez więcej niż jeden rdzeń bez określonej synchronizacji.

Samo założenie, że `uint32_t` jest pojedynczym zapisem, nie rozwiązuje problemu kolejności/memory ordering pomiędzy rdzeniami.

## Decyzja D-R122-01

Na start stosujemy ownership:

```text
A — counters diagnosticzne: właściciel tgTask / jeden kontekst

B/C — counters producenta/ringa: owner producenta + jawna synchronizacja
```

Nie będziemy używać wspólnego globalnego licznika z wieloma writerami tylko dlatego, że „ma 32 bity”.

## Dla przyszłego ringa

Do wyboru po benchmarku:

```text
portMUX / krótka sekcja krytyczna
```

lub:

```text
atomics z jawnie opisanym memory ordering
```

ale nie mieszamy metod przypadkowo.

## Korzyść

Commit A pozostaje bardzo prosty:

```text
single owner
→ brak nowego race
→ brak nowego locka
→ łatwy rollback
```

Dopiero Commit C, gdy faktycznie pojawi się producer/consumer, dostanie pełny kontrakt współbieżności.

---


# R123. SERVO UNITS — KRYTYCZNA KOREKTA `klapa_proc` / `syberko_proc`

**Data:** 2026-09-24  
**Status:** ZAKOŃCZONE — schema wymaga korekty nazewnictwa

## Ustalenie

W istniejącej strukturze historii występują pola:

```cpp
int klapa_proc;
int syberko_proc;
```

ale są one zasilane bezpośrednio z:

```cpp
pozycjaKlapa
pozycjaSyberek
```

Tymczasem `procentNaKat()` wykonuje jawne przeliczenie:

```text
procent 0..100
   ↓
kat zakresMin..zakresMax
```

dla:

```text
klapa   0..180°
syberek 0..90°
```

Dodatkowo `/api/status` emituje:

```text
"klapa": pozycjaKlapa
"syberka": pozycjaSyberek
```

czyli również **kąt**, nie procent.

## Wniosek

Nazwa `klapa_proc` / `syberko_proc` w `HistoriaProbka` jest historycznie myląca.
Nie możemy skopiować tej nazwy do cloud schema bez wyjaśnienia jednostki.

## Decyzja D-R123-01

W telemetryce V1 używamy nazw opisujących fizyczną jednostkę:

```text
klapaDeg
syberekDeg
```

z typem:

```text
uint8_t
```

ponieważ zakresy są:

```text
klapa   0..180
syberek 0..90
```

## Czego nie robimy

Nie przeliczamy ponownie:

```text
pozycjaKlapa -> procent
```

tylko po to, żeby nazwa pola telemetrycznego odpowiadała historycznemu `*_proc`.

To dodawałoby transformację, której obecny `/api/status` i historia nie wykonują.

## Semantyka

W chmurze zapisujemy:

```text
aktualna fizyczna pozycja serwa
```

a nie:

```text
ostatnie polecenie procentowe
```

Jest to istotne diagnostycznie: pozycja fizyczna może być w trakcie ruchu inna niż ostatnio zadany procent.

## Korekta TelemetrySample V1

Robocza wersja:

```cpp
uint8_t klapaDeg;
uint8_t syberekDeg;
```

zamiast:

```cpp
uint8_t klapaPct;
uint8_t syberkoPct;
```

## Wpływ na sizeof

Zmiana dotyczy dwóch bajtów o tym samym rozmiarze, więc oczekiwany:

```text
sizeof(TelemetrySample) = 64 B
```

pozostaje niezmieniony.

## Konsekwencja dla aplikacji

Aplikacja nie może interpretować tych pól jako 0–100%.
Zakres to:

```text
klapaDeg   0..180
syberekDeg 0..90
```

Jeżeli UI potrzebuje procentu, przeliczenie wykonuje warstwa aplikacji:

```text
percent = angle / maxAngle * 100
```

zgodnie z rzeczywistym zakresem danego serwa.

---

# R124. WILGOTNOŚĆ — RAW VS DERIVED I FRESHNESS

**Data:** 2026-09-24  
**Status:** ZAKOŃCZONE — decyzja V1

## Ustalenie

Firmware rozróżnia:

```text
wilgotnoscOdczytana
wilgotnoscSkorygowana
wilgotnoscAbsolutna
```

ale obecna historia zapisuje:

```text
wilgotnosc = wilgotnoscOdczytana
```

a nie wartość skorygowaną.

`wilgotnoscOdczytana` pochodzi z `read_dht()` i przy błędzie DHT może zostać zastąpiona ostatnią dostępną wartością.

## Krytyczna semantyka

Sama liczba:

```text
wilgotnosc = 56.2
```

nie mówi, czy:

```text
fresh = true
```

czy:

```text
fresh = false / last-good
```

To jest dokładnie przypadek, dla którego powstały quality/age metadata.

## Decyzja D-R124-01

Telemetryka V1 zachowuje:

```text
rh = wilgotnoscOdczytana
qualityRh
ageRh
```

Nie wprowadzamy do podstawowego 1-minutowego schema równocześnie wszystkich trzech reprezentacji wilgotności.

Wartości:

```text
wilgotnoscSkorygowana
wilgotnoscAbsolutna
```

mogą zostać później dodane jako pola pochodne, jeżeli aplikacja faktycznie ich potrzebuje.

## Dlaczego raw w V1

To zachowuje zgodność semantyczną z istniejącą historią i `/api/status` oraz minimalizuje ryzyko, że cloud time-series zacznie mieszać dane pomiarowe z obliczonymi.

---

# R125. CIŚNIENIE — CLOUD MUSI PRZECHOWYWAĆ WARTOŚĆ Z URZĄDZENIA, NIE „SUROWY BMP”

**Data:** 2026-09-24  
**Status:** ZAKOŃCZONE — otwarty problem domenowy zachowany

## Ustalenie

Aktualna funkcja zapisuje:

```text
cisnienieOdczytane = bmp.readPressure()/100 + 18
```

a `HistoriaProbka` dokumentuje jednostkę jako:

```text
hPa
```

## Konsekwencja

Telemetryka V1 powinna przechowywać:

```text
wartość widzianą przez firmware
```

a nie ponownie czytać BMP ani próbować usuwać stałej `+18` po stronie cloud.

## Jednocześnie

Znaczenie dodatku:

```text
+18 hPa
```

pozostaje domenowym pytaniem otwartym.

Nie znamy z samego kodu wystarczającego dowodu, czy jest to:

```text
świadoma korekcja
kalibracja konkretnego układu
offset historyczny
```

Nie należy jej zmieniać w ramach telemetryki.

## Reprezentacja

Roboczo:

```cpp
int16_t pressureX10;
```

ale przed Commit B trzeba wykonać jawne sprawdzenie zakresu:

```text
finite
mieści się w int16_t * 0.1 hPa
```

i w przypadku wartości spoza zakresu zapisać `INVALID`, zamiast przepełniać liczbę.

---

# R126. TEMPERATURY — FIXED POINT X10 BEZ UTRATY ZAKRESU

**Data:** 2026-09-24  
**Status:** ZAKOŃCZONE

## Zakresy potwierdzone w kodzie

Robocze zabezpieczenia odczytów DS18B20 obejmują m.in.:

```text
ogrz                0..160 °C
panel             -30..160 °C
pokoj             -50..50 °C
bojler              0..160 °C
zewn              -30..50 °C
trociny           -30..120 °C
powrot            -30..120 °C
```

## X10

Reprezentacja:

```text
int16_t temperatureX10
```

daje zakres:

```text
-3276.8 .. +3276.7 °C
```

czyli z ogromnym zapasem względem aktualnych zakresów.

Przy skali X10 zachowujemy:

```text
0.1 °C
```

bez kosztu float w ring/storage.

## Ważna zasada

Do `int16_t` nie wolno wykonywać bezwarunkowego castu:

```cpp
(int16_t)(temperature * 10)
```

bez wcześniejszej kontroli:

```text
isfinite
range
```

Wartość niewiarygodna ma być oznaczona przez quality, nie przez przypadkowe przepełnienie.

## Wniosek

`TelemetrySample` może przechowywać wszystkie temperatury stałoprzecinkowo bez zmiany ich istotnej precyzji dla V1.


# R127. FRESHNESS — LAST ATTEMPT VS LAST GOOD

**Data:** 2026-09-24  
**Status:** ZAKOŃCZONE — kontrakt ustalony

## Cel

Telemetryka nie może wywnioskować świeżości wyłącznie z faktu, że globalna zmienna ma liczbę. Aktualny firmware świadomie trzyma ostatnią dobrą wartość po błędzie odczytu, a więc:

```text
wartość widoczna teraz
!=
czas, kiedy tę wartość rzeczywiście uzyskano
```

## DS18B20 — najważniejszy przypadek

`zastosujFiltrWiarygodnosci()` ma trzy istotne ścieżki:

```text
brak odczytu
    → zwraca ostatnią dobrą wartość

normalny/zaakceptowany odczyt
    → aktualizuje ostatniaDobra

odrzucony skok
    → zwraca ostatniaDobra
    → nowa wartość czeka na potwierdzenie
```

W konsekwencji telemetryka nie może robić:

```cpp
lastGoodMs = millis();
```

na podstawie samego wyniku `odczytajTemperature()`, ponieważ wynik może być kopią starej wartości.

### Wymagane metadane źródła

Dla każdego kanału pomiarowego projektujemy osobny stan:

```text
lastAttemptMs   = kiedy wykonano próbę odczytu
lastGoodMs      = kiedy wartość została ostatnio zaakceptowana
validEver       = czy kiedykolwiek istniała poprawna wartość
simulated       = czy obecna wartość pochodzi z aktywnej symulacji
```

Opcjonalny późniejszy licznik:

```text
consecutiveErrors
```

ale nie jest konieczny do minimalnego kontraktu telemetrycznego.

## Semantyka

```text
FRESH
  = obecna wartość jest wynikiem zaakceptowanego źródłowego odczytu
    i mieści się w swoim dopuszczalnym oknie wieku

STALE
  = urządzenie nadal posiada ostatnią dobrą wartość,
    ale od jej uzyskania minęło więcej niż próg kanału

UNKNOWN
  = brak jakiejkolwiek zaakceptowanej wartości od startu

INVALID
  = ostatnia próba/źródło zgłosiło wartość niewiarygodną,
    której nie wolno użyć jako liczby telemetrycznej

SIMULATED
  = wartość pochodzi z jawnego mechanizmu symulacji
```

## Kolejność zdarzeń

Dla kanału telemetrycznego obowiązuje:

```text
attempt
  ↓
source validation
  ↓
filter / acceptance
  ↓
value update
  ↓
lastGoodMs = teraz   [TYLKO gdy wartość została zaakceptowana]
```

Nie aktualizujemy `lastGoodMs` przy:

```text
- braku odpowiedzi
- NaN
- wartości poza zakresem
- odrzuconym skoku
- przejściu czujnika w OFF/rozgrzewanie
```

## DHT22

Aktualne `wilgotnosc()` ustawia lokalną wartość `NAN` przy błędzie `read_dht()`, ale następnie wraca do ostatniej wartości. Dlatego samo `wilgotnoscOdczytana` również nie wystarcza do określenia freshness.

Dla telemetryki potrzebny będzie jawny timestamp udanego odczytu RH.

## BMP280

Analogicznie `cisnienie()` zachowuje `cisnienieOdczytane` po nieudanym/NaN odczycie. `lastGoodMs` aktualizujemy wyłącznie przy skończonej wartości, która została faktycznie przyjęta przez firmware.

## Wniosek

Freshness jest **metadanymi źródła**, a nie właściwością samego pola liczbowego. To staje się obowiązkowym elementem Commit B.

---

# R128. PROGI STALE — NIE JEDEN GLOBALNY TIMER

**Data:** 2026-09-24  
**Status:** ZAKOŃCZONE — architektura progów; wartości końcowe pozostają parametrem do testu runtime

## Dlaczego nie jeden próg

Aktualne źródła mają różne charakterystyki:

```text
DS18B20       ~2816 ms scheduler
DHT22         ~3000 ms scheduler / faktyczny read_dht() w każdej iteracji
BMP280        ~5000 ms scheduler
dym           event-driven / temperatura + duty-cycle + stabilizacja
```

Dlatego:

```text
STALE = now - lastGoodMs > jeden_wspolny_limit
```

byłoby błędnym uproszczeniem.

## DS18B20

Nominalny cykl to ~2,816 s. Wstępny kandydat testowy może być rzędu kilku nominalnych cykli, np. około:

```text
3 × 2,816 s ≈ 8,45 s
```

ale nie jest to jeszcze finalna gwarancja. Próba runtime powinna sprawdzić rzeczywisty rozkład opóźnień `Czujnik_DS()` oraz przypadki niedostępności magistrali.

## DHT22

Ważna korekta względem samej nazwy `interwalPomiaru`: aktualna funkcja `wilgotnosc()` wykonuje `read_dht()` po bloku aktualizującym `czasOstatniegoPomiaru` i nie używa `interwalPomiaru` jako bramki pomiaru. Zatem freshness należy liczyć z faktycznego `read_dht()`, a nie z wartości `interwalPomiaru`.

## BMP280

Analogiczny model:

```text
lastGoodMs
+ próg dobrany do realnego cyklu 5 s
```

Wartość pozostająca po NaN nie jest automatycznie świeża.

## Dym

Tu nie stosujemy stałego `3×interval`.

Kod jawnie rozróżnia:

```text
czujnikDymuSwiezyOdczyt = true
    → aktualny ważny ADC

false
    → ostatnia wartość przy OFF / rozgrzewaniu / braku ważnego ADC
```

W telemetryce próg STALE musi więc uwzględniać stan:

```text
dym_wlaczony
czas_stabilizacji
tryb ciągły / impulsowy
czas ostatniej poprawnej próbki
```

W przeciwnym razie aplikacja mogłaby błędnie uznać legalne okno rozgrzewania za awarię albo odwrotnie.

## Decyzja

Każdy kanał dostaje:

```text
nominal period
stale threshold
source-specific exceptions
```

Wartości finalne będą parametrem telemetryki, a nie magiczną liczbą zaszytą wspólnie dla wszystkich czujników.


# R129. WARTOŚĆ POCHODNA `temperaturaOgrzewaniaSrednia` — NIE JEST NIEZALEŻNYM CZUJNIKIEM

**Data:** 2026-09-24  
**Status:** ZAKOŃCZONE — kontrakt jakości ustalony, implementacja później

## Źródło

`obliczanie_srednia()` nie wykonuje niezależnego pomiaru sprzętowego. W zależności od trybu korzysta z:

```text
temperaturaOgrzewania
bufory poprzednich odczytów
stan pompy
Czas_OFF
ostatni_poprawny
```

W trybach 2/3 utrzymywana jest średnia krocząca z 4 elementów, a część bufora jest aktualizowana tylko podczas pracy pompy. W trybie wygaszenia średnia jest przełączana na bieżące `temperaturaOgrzewania`, o ile ten odczyt jest poprawny.

## Problem z naiwnym timestampem

Błędny wzorzec byłby taki:

```cpp
obliczanie_srednia();
lastGoodOgrzSrMs = millis();
```

To oznaczałoby, że każdorazowe wykonanie funkcji czyni wartość „świeżą”, nawet jeśli algorytm zwrócił wartość opartą na wcześniejszym buforze albo `ostatni_poprawny`.

## Kontrakt V1

`temperaturaOgrzewaniaSrednia` ma być traktowana jako:

```text
DERIVED
```

czyli wartość obliczona z innych danych, a nie niezależny kanał sprzętowy.

W praktyce telemetryka potrzebuje dla niej dwóch informacji:

```text
wartość
jakość wynikająca z użytych źródeł i stanu algorytmu
```

## Minimalna reguła jakości

Jeżeli bieżące `temperaturaOgrzewania` jest niewiarygodne/stale, średnia nie może zostać automatycznie oznaczona jako FRESH wyłącznie dlatego, że funkcja średniej wykonała się zgodnie z harmonogramem.

W szczególności:

```text
nowy poprawny input
    → może odświeżyć derived state

stary input użyty ponownie
    → nie odświeża źródłowego wieku

ostatni_poprawny użyty przez algorytm
    → wynik nie staje się przez to nowym pomiarem
```

## Opcja implementacyjna do Commit B

Najprostszy bezpieczny model:

```text
ageOgrzSr = maksymalny wiek istotnych danych źródłowych
            + jawna informacja o stanie algorytmu
```

Nie zatwierdzamy jeszcze jednej konkretnej formuły, ponieważ trzeba najpierw jednoznacznie ustalić komplet wejść używanych w każdym trybie 1/2/3.

## Wniosek

`temperaturaOgrzewaniaSrednia` pozostaje w schema V1, ale nie dostaje semantyki „czujnik odczytany właśnie teraz”. To osobny kanał pochodny, którego freshness musi być obliczane z genealogii danych.


# R130. `stateBits` — WŁASNOŚĆ STANU WAŻNIEJSZA NIŻ LICZBA BITÓW

**Data:** 2026-09-24  
**Status:** ZAKOŃCZONE — zakres V1 ograniczony do stanów o jasnym ownerze

## Audyt writerów

W aktualnym `main_centrala.cpp` znaleziono m.in.:

```text
alarmOgrzewanieWlaczone
  → zapis w temperatura_alarmowa() na Core 1
  → zapis przy ręcznym reset_alarmow z Firebase/tgTask na Core 0

alarmPanelWlaczone
  → zapis w temperatura_alarmowa() na Core 1
  → zapis przy ręcznym reset_alarmow z Firebase/tgTask na Core 0

TrybSerwa
  → zapis przy obsłudze ustawień/komend z Core 0
  → zapis przy automatycznym wygaszeniu override z Core 1

rozpalanieAktywne
  → zapis przez konfigurację/komendy
  → zapis w logice mieszadła na Core 1
```

To nie jest jeden owner na zmienną.

## Dlaczego zwykły odczyt nie wystarcza

Nawet jeżeli pojedynczy `bool`/`byte` jest odczytywany sprzętowo bez częściowego zapisu, zestaw kilku flag nie tworzy przez to atomowego snapshotu.

Możliwy jest obraz:

```text
alarm_CO = true
alarm_PANEL = false
czyTemperaturaAlarmowa = stara wartość
```

który nigdy nie istniał jako logiczny stan systemu.

ESP-IDF FreeRTOS dla SMP stosuje spinlocki `portMUX_TYPE` w sekcjach krytycznych; samo wyłączenie przerwań na jednym rdzeniu nie zabezpiecza zasobu współdzielonego z drugim rdzeniem. citeturn743091search32turn743091search35

## Stan bezpieczny dla V1

Do podstawowego `stateBits` preferowane są stany o pojedynczym i jasnym ownerze, np.:

```text
pump physical state
servo physical position validity / movement state, jeśli snapshot jest z ownera Core 1
smoke alarm (jeżeli potwierdzi się jeden writer)
smoke sensor enabled state (jeżeli czytany jako state źródłowy, nie komenda)
```

## Stany odroczone

Do czasu zaprojektowania wspólnego mechanizmu synchronizacji pozostają poza atomowym `stateBits`:

```text
alarm CO
alarm PANEL
TrybSerwa
rozpalanieAktywne
```

Nie oznacza to utraty informacji — te stany mogą później dostać osobny snapshot ownership-aware albo wejść do `stateBits` po wprowadzeniu kontrolowanej synchronizacji.

## Wniosek architektoniczny

`stateBits` nie ma być „zrzutem wszystkich globalnych booli”. Ma być **kontraktem stanu, dla którego znamy ownera i sposób snapshotowania**.

To ogranicza powierzchnię race condition bez dokładania globalnego mutexa do całego sterownika.


# R131. CZAS TELEMETRII — `unixTs` DLA POMIARU, `monoMs` DLA PORZĄDKU LOKALNEGO

**Data:** 2026-09-24  
**Status:** ZAKOŃCZONE

## Fakty z kodu

`pobierzCzas()` ma następującą kolejność źródeł:

```text
RTC fizyczny
    ↓ jeśli niedostępny
zegar systemowy po NTP
    ↓ jeśli niedostępny
DateTime((uint32_t)0)
```

`historiaZapiszProbke()` już stosuje jawny warunek wiarygodności i zapisuje `czas_unix=0`, gdy brak zarówno RTC, jak i NTP. fileciteturn83file6L8716-L8721

## Kontrakt telemetryczny

```text
unixTs = measurement time
monoMs = device-local monotonic time
```

`monoMs` nie zastępuje czasu kalendarzowego. Jest potrzebny do:

```text
age
latency
backlog age
diagnostyka restartu
```

## Korekta czasu

NTP może skorygować zegar systemowy. Z tego powodu nie wymagamy:

```text
unixTs[n+1] >= unixTs[n]
```

jako niezmiennika telemetrycznego.

Dopuszczamy:

```text
unixTs[n+1] < unixTs[n]
```

po korekcie zegara.

To jest właśnie powód, dla którego timestamp nie jest identyfikatorem rekordu.

## Porządek rekordów

Dla rekordów mających wiarygodny czas aplikacja może sortować logicznie:

```text
(ts, sampleSeq)
```

Dla `ts=0` pozostaje osobna polityka — nie wolno mieszać takich rekordów z normalnym epochem 1970 jako zwykłych pomiarów.

## Tożsamość

Bez względu na korekty zegara rekord zachowuje:

```text
sessionNonce + sampleSeq
```

czyli stabilny identyfikator retry i deduplikacji.

## Wniosek

Nie dodajemy sztucznego mechanizmu „naprawiającego” timestamp, który mógłby zmienić rzeczywisty czas pomiaru. Rozdzielamy role zegarów zamiast wymuszać jeden wspólny porządek.


# R132. SCHEDULER — 1/MIN TO NOMINAL INTERVAL, NIE TWARDY ZEGAR

**Data:** 2026-09-24  
**Status:** ZAKOŃCZONE

## Fakty z aktualnego schedulera

`wykonajZaplanowaneZadania()` pobiera jedno `teraz = millis()` na początku obiegu, a dla każdego zadania:

```text
jeżeli teraz - ostatnieWywolanie >= interwal
    → ostatnieWywolanie = teraz
    → funkcja()
```

Nie ma pętli nadrabiającej wielokrotne zaległe interwały. fileciteturn83file6L7584-L7585

## Konsekwencja dla historii 1/min

```text
HISTORIA_PROBKA_MS = 60000
```

oznacza nominalny okres, ale rzeczywisty czas pomiędzy próbkami może być większy, gdy `loopTask` zostanie opóźniony przez inne zadania.

Nie wolno więc zakładać w telemetryce:

```text
1440 rekordów = gwarantowane 24 h
```

Poprawny opis to:

```text
1440 rekordów = ~24 h przy nominalnym harmonogramie 60 s
```

## `monoMs` staje się obowiązkowy

Dzięki:

```text
monoMs[n] - monoMs[n-1]
```

możemy zmierzyć rzeczywisty okres próbkowania i odróżnić:

```text
normalne 60 s
```

od:

```text
scheduler jitter / dłuższa blokada loopTask
```

## Konsekwencja dla backlogu

Produkcja telemetryczna nie jest idealnym stałym strumieniem 1/min. Dlatego warunek drainu powinien być definiowany jako:

```text
średnia szybkość drainu
    >
obserwowana szybkość produkcji backlogu
```

z marginesem na:

```text
retry
WAN jitter
status/cmd
scheduler jitter
```

Wcześniejsze 1 rekord/min pozostaje minimalnym punktem odniesienia, ale nie jest wystarczającym celem drainu, ponieważ dokładnie 1/min tylko równoważy nominalną produkcję.

## Decyzja

Nie zmieniamy `HISTORIA_PROBKA_MS` w ramach telemetryki.

Do diagnostyki telemetrycznej zapisujemy `monoMs`, a po testach 24/48/72 h wyznaczamy rzeczywisty rozkład:

```text
sample_period_min
sample_period_avg
sample_period_p95
sample_period_max
```

Dopiero ten pomiar może być użyty do strojenia backlogu i `MAX_SAMPLE_LATENCY`.


# R133. GRANICA PRODUCENT ↔ UPLOADER — SCHEDULER NIE MOŻE STAĆ SIĘ TASKIEM SIECIOWYM

**Data:** 2026-09-24  
**Status:** ZAKOŃCZONE

## Fakty

`loop()` wykonuje:

```text
esp_task_wdt_reset()
↓
diagnostyka
↓
wykonajZaplanowaneZadania()
↓
wifiLoop()
```

Scheduler jest zatem bezpośrednio częścią `loopTask`, a nie osobnym taskiem. fileciteturn83file6L21464-L21485

## Konsekwencja

`historiaZapiszProbke()` może bezpiecznie wykonać w schedulerze:

```text
snapshot
fixed-point conversion
quality/age lookup
TelemetryRing push
```

pod warunkiem, że operacja jest krótka i nieblokująca.

Nie wolno tam wykonywać:

```text
TLS
DNS
Firebase update
budowania dużego JSON
czekania na ACK
retry/backoff
```

## Dlaczego

Każde wydłużenie funkcji wykonywanej w schedulerze przesuwa wszystkie pozostałe zadania `loopTask`, w tym automatykę, serwo i inne okresowe czynności. Już istniejący kod ma jawnie udokumentowane przypadki, w których długie operacje sieciowe/flash wymagały specjalnej ochrony WDT.

## Ostateczny podział

```text
Core 1 / loopTask / scheduler
    │
    └── historiaZapiszProbke()
           │
           └── TelemetrySample → ring

Core 0 / tgTask
    │
    └── telemetry uploader
           │
           └── istniejący Firebase path
```

## Decyzja

Nie dodajemy nowego taska telemetrycznego tylko po to, aby odciążyć scheduler. Upload pozostaje odpowiedzialnością istniejącego `tgTask`/Firebase execution path, a producent w schedulerze ma zachować deterministyczny, mały koszt.


# R134. MEMORY TELEMETRY — INTERNAL DRAM I PSRAM MUSZĄ BYĆ MIERZONE OSOBNO

**Data:** 2026-09-24  
**Status:** ZAKOŃCZONE — kontrakt pomiarowy

## Dlaczego samo `free heap` nie wystarcza

ESP-IDF rozdziela pamięć według capabilities, a przy fragmentacji:

```text
free_total
```

może być znacznie większe niż:

```text
largest_free_block
```

Ten drugi jest praktycznym ograniczeniem dla pojedynczej dużej alokacji. ESP-IDF udostępnia także lifetime low-watermark przez `heap_caps_get_minimum_free_size()`. citeturn743091search2

## Commit A — minimalny zestaw

Mierzymy osobno:

```text
INTERNAL:
  free
  largest
  minimum

PSRAM:
  free
  largest
  minimum
```

oraz:

```text
overall free heap
overall largest 8-bit block
```

## Stack

Dla każdego jawnego taska zbieramy HWM:

```text
loopTask
tgTask
tgPollTask
historiaTask
fbLoopWork
inne taski utworzone przez firmware, jeśli istnieją w runtime
```

Na ESP32-S3 `uxTaskGetStackHighWaterMark()` zwraca minimum wolnej pamięci stosu w **bajtach**, nie słowach. citeturn743091search0

## Częstotliwość

Nie wykonujemy kosztownego pełnego skanu wszystkich tasków w każdej iteracji `loop()`.

Model:

```text
częsty pomiar:
  current task HWM + podstawowy heap snapshot

rzadki pomiar health:
  pełny per-task HWM
```

`uxTaskGetSystemState()` zostaje narzędziem do niskoczęstotliwościowej diagnostyki, nie ścieżką czasu rzeczywistego. ESP-IDF opisuje ten interfejs jako sposób zebrania HWM wszystkich tasków. citeturn743091search0

## Kryterium porównania

Baseline zapisujemy jako wektor:

```text
Dram.free
Dram.largest
Dram.minimum
Psram.free
Psram.largest
Psram.minimum
HWM per task
```

Następny commit musi być porównywany z tym samym wektorem.

## Wniosek

„Nie zabraliśmy dużo pamięci” jest akceptowalne dopiero po pomiarze tych samych metryk przed i po zmianie. Sama suma wolnego RAM nie będzie już jedynym kryterium.


# R135. MAPA IMPLEMENTACJI COMMIT A/B/C — BEZ ZMIANY KODU NA TYM KROKU

**Data:** 2026-09-24  
**Status:** ZAKOŃCZONE — mapa call-site'ów gotowa do implementacji

## Aktualna wersja

W źródle `FIRMWARE_VERSION` wynosi obecnie:

```text
v3.11.4
```

fileciteturn83file6L3925-L3935

Reguła pliku wymaga zwiększenia wersji przy każdej zmianie funkcjonalnej oraz dopisania szczegółowego wpisu na początku changelogu. fileciteturn82file0L11-L33

## Commit A — diagnostics only

### Cel

Dodać obserwowalność bez zmiany zachowania telemetrycznego ani sieciowego.

### Candidate call-sites

1. Istniejąca sekcja diagnostyki wokół `diagCheckpoint()`.
2. Istniejący health heartbeat w `loop()`.
3. Istniejące struktury diagnostyczne RTC/crash.

### Dane

```text
heap internal: free/largest/minimum
heap PSRAM:    free/largest/minimum
stack HWM:     current task + niski rate pełnego snapshotu
telemetry counters: startowe zero / placeholder
```

### Zakaz

Commit A nie może tworzyć:

```text
TelemetryRing
nowego taska
Firebase requestu
nowej partycji
LittleFS spool
```

## Commit B — metadata/freshness/identity

### Candidate call-sites

```text
Czujnik_DS()
wilgotnosc()
cisnienie()
pozar()
```

W tych miejscach należy aktualizować `lastGoodMs` zgodnie z rzeczywistym sukcesem źródła.

Następnie `historiaZapiszProbke()` pobiera gotowe metadata i buduje niezmienny snapshot.

### Zakaz

Brak Firebase upload.
Brak persistent spool.
Brak zmiany częstotliwości statusu.

## Commit C — RAM ring

### Candidate call-site

Jedyny producer:

```text
historiaZapiszProbke()
```

Operacja:

```text
snapshot → fixed point → krótki critical section → ring push
```

Ring ma być SPSC: jeden producer i jeden consumer, bez wielu writerów.

## Commit D/E — Firebase

Dopiero po przejściu A/B/C:

```text
tgTask
  ↓
backpressure
  ↓
peek batch
  ↓
existing fbAsyncClient / fbSSLClient / fbApp
  ↓
ACK
  ↓
ring commit
```

Żadna z tych ścieżek nie może wejść do osobnego klienta SSL.

## Semver

Ponieważ `v3.11.4` jest bazą, pierwsza implementacja diagnostyczna wymaga nowego numeru. Dokładne PATCH/MINOR zostanie dobrane do faktycznie wystawionej powierzchni funkcjonalnej danego commitu; nie zmieniamy wersji „na zapas” przed implementacją.

## Wniosek

Planowany patch telemetryczny jest możliwy bez przebudowy architektury całej centrali. Najpierw metadata, potem ring, dopiero na końcu sieć.


# R136. QUALITY BITMASK — 16 BITÓW NIE WYSTARCZA DLA 11 KANAŁÓW

**Data:** 2026-09-24  
**Status:** ZAKOŃCZONE — korekta schema przed freeze

## Problem znaleziony w draftcie

Aktualny draft zawiera 11 kanałów jakości:

```text
t_zewn
t_bojler
t_ogrz
t_ogrz_sr
t_powrot
t_panel
t_pokoj
t_trociny
rh
pressure
dym
```

Przy 2 bitach na kanał:

```text
11 × 2 = 22 bity
```

Zatem:

```cpp
uint16_t qualityBits;
```

nie może pomieścić kompletnej informacji.

## Dlaczego nie zwiększamy do 3 bitów

Pięć logicznych stanów:

```text
FRESH
STALE
UNKNOWN
INVALID
SIMULATED
```

wymaga minimum 3 bitów/kanał. Dla 11 kanałów byłoby:

```text
11 × 3 = 33 bity
```

czyli również ponad jeden `uint32_t`.

## Wariant zatwierdzany do dalszego projektu

Rozdzielamy:

```cpp
uint32_t qualityBits;
uint16_t simulatedBits;
```

### `qualityBits`

2 bity/kanał:

```text
00 FRESH
01 STALE
10 UNKNOWN
11 INVALID
```

Wykorzystane:

```text
22 / 32 bity
```

Pozostałe 10 bitów pozostaje zarezerwowane na przyszłe kanały/rozszerzenia.

### `simulatedBits`

Jeden bit/kanał:

```text
1 = wartość pochodzi z jawnej symulacji
0 = źródło fizyczne
```

Dzięki temu `SIMULATED` nie konkuruje z semantyką jakości źródłowej.

Możliwe kombinacje:

```text
quality=FRESH + simulated=1
quality=STALE + simulated=1
```

mają jednoznaczne znaczenie i nie wymagają specjalnego piątego kodu.

## Rozmiar struktury

W obecnym układzie pól zmiana:

```text
uint16_t qualityBits
    → uint32_t qualityBits
+ uint16_t simulatedBits
```

nie musi zwiększyć `sizeof(TelemetrySample)` ponad obecne 64 B, ponieważ wcześniejsza struktura kończyła się paddingiem wyrównującym.

Konkretny rozmiar nadal musi być sprawdzony kompilatorem:

```cpp
static_assert(sizeof(TelemetrySample) == 64);
```

## Wniosek

Nie zamrażamy starego `uint16_t qualityBits`. Docelowy kontrakt pozostaje kompaktowy, ale musi mieć fizycznie miejsce na wszystkie 11 kanałów oraz osobną informację o symulacji.


# R137. AGE — `uint8_t` ZA KRÓTKIE DLA TELEMETRYKI KOTŁA

**Data:** 2026-09-24  
**Status:** ZAKOŃCZONE — rekomendacja schema, do potwierdzenia przed Commit B

## Problem

W pierwotnym draftcie każdy z 11 kanałów miał:

```cpp
uint8_t ageXs;
```

co daje zakres:

```text
0..255 s
```

czyli tylko:

```text
4 min 15 s
```

W obecnym firmware są jednak legalne sytuacje, w których kanał nie dostaje nowego pomiaru przez dłużej:

```text
dym OFF
rozgrzewanie dymu
awaria czujnika
brak magistrali
restart przed pierwszym poprawnym odczytem
```

Saturacja do 255 s zaciera różnicę pomiędzy:

```text
4 min 20 s
```

a:

```text
4 h
```

## Wariant `uint16_t`

Reprezentacja:

```cpp
uint16_t ageS[11];
```

daje:

```text
0..65535 s
≈ 18 h 12 min
```

Przy jeszcze większym wieku można jawnie zastosować:

```text
65535 = >=65535 s
```

To jest jednoznaczna i rzadka saturacja.

## Koszt pamięci

Przy poprawionym `qualityBits` + `simulatedBits` i 11 wieku:

```text
uint8_t age[11]
  → struktura może mieć 64 B

uint16_t age[11]
  → struktura wychodzi 80 B
```

Koszt ringu:

```text
1440 × 80 B = 115 200 B ≈ 112,5 KiB
2880 × 80 B = 230 400 B ≈ 225 KiB
```

Względem istniejących wielkich struktur PSRAM nadal jest to mały przyrost, ale rozmiar musi zostać potwierdzony kompilatorem.

## Korzyść

Dłuższa obserwacja offline/awarii daje aplikacji rzeczywistą informację:

```text
age=1800 s
```

zamiast nieodróżnialnego:

```text
age=255 s
```

## Decyzja

Do dalszego projektu używamy kandydata:

```cpp
uint16_t ageS[11];
```

z warunkiem:

```cpp
static_assert(sizeof(TelemetrySample) == 80);
```

Po Commit B/C wartość 64 B z R91 należy traktować jako rozmiar **starego draftu**, a nie docelowego ABI.


# R138. BINARY SAMPLE ≠ RTDB WIRE RECORD — USUWAMY REDUNDANCJĘ

**Data:** 2026-09-24  
**Status:** ZAKOŃCZONE — rozdział schema ustalony

## Problem

`TelemetrySample` jest strukturą przeznaczoną do pracy firmware/ringu. Nie ma powodu, aby każdy bajt tej struktury musiał pojawić się 1:1 w JSON.

W szczególności:

```text
sessionNonce
```

jest już zawarty w:

```text
record_id = <sessionNonce>-<sampleSeq>
```

a wersja kontraktu jest zawarta w:

```text
/piec/telemetry/1m/v1/...
```

Data jest zawarta w:

```text
/YYYY/MM/DD/
```

## Binary ring — przechowuje

Kandydat końcowy obejmuje:

```text
sessionNonce
sampleSeq
unixTs
monoMs
fixed-point measurements
stateBits
qualityBits
simulatedBits
ageS[11]
```

To jest stan potrzebny do:

```text
retry
idempotencji
diagnostyki
lokalnej analizy scheduler jitter
```

## RTDB wire record — nie musi kopiować wszystkiego

Minimalny rekord może zawierać:

```text
seq
 ts
 mono (jeżeli chcemy zachować lokalny czas do diagnostyki cloud)
 state
 q
 sim
 age
 measurements
```

Nie wysyłamy drugi raz:

```text
sessionNonce
```

bo jest już w kluczu rekordu.

Nie dodajemy obowiązkowo:

```text
schema
```

ponieważ wersjonuje je już path `/v1`.

Nie dodajemy:

```text
fw
```

do każdej minuty. Firmware version może być przekazywana przez osobny boot/session event/status. To oszczędza powtarzania tej samej wartości 1440 razy na dobę.

## `monoMs` — decyzja warunkowa

`monoMs` jest bardzo użyteczne diagnostycznie, ale nie jest potrzebne do identyfikacji rekordu.

Dlatego pozostaje w binary sample jako obowiązkowe metadata, natomiast na wire V1:

```text
PREFER = wysyłać
```

bo koszt kilku bajtów jest mały, a wartość diagnostyczna obejmuje m.in.:

```text
scheduler jitter
czas lokalny przy ts=0
analizę przerw wewnątrz jednej sesji
```

Po testach można ewentualnie usunąć je z RTDB bez zmiany binarnego ABI ringu.

## Korzyść

Rozdzielenie schema pozwala zoptymalizować:

```text
PSRAM ABI
```

nie zmieniając przy tym:

```text
cloud contract
```

i odwrotnie.

## Wniosek

Nie obowiązuje zasada „jeden `TelemetrySample` = jeden JSON”.

Obowiązuje:

```text
TelemetrySample = wewnętrzny trwały snapshot logiczny
RTDB record     = minimalna reprezentacja potrzebna aplikacji
```


# R139. WIRE PAYLOAD PO KOREKTACH SCHEMA — NOWY MODEL BATCHA

**Data:** 2026-09-24  
**Status:** ZAKOŃCZONE — estymacja, do potwierdzenia testem rzeczywistego serializer/API

## Założenia modelu

Kandydat JSON rekordu:

```text
seq
 ts
 mono
 state
 q
 sim
 age[11]
 8 kanałów temperatury
 rh
 p
 d
 k
 s
```

Dla zwartego minified JSON i reprezentatywnych wartości otrzymujemy około:

```text
~220 B / rekord
```

To nadal jest model, nie pomiar wykonany przez FirebaseClient.

## Koszt multi-path

W RTDB batch musi powtórzyć ścieżkę względną do rekordu, np.:

```text
2026/09/24/<25-char-record-id>
```

Dla modelu daje to około:

```text
~40 B dodatkowego klucza + JSON syntax / rekord
```

W rezultacie:

```text
2 rekordy   ≈ 521 B
5 rekordów  ≈ 1.30 KB
10 rekordów ≈ 2.60 KB
20 rekordów ≈ 5.21 KB
```

## Doba

Przy nominalnych 1440 próbkach:

```text
~260 B/record on the wire
× 1440
≈ 375 KB/day payload application-level
```

To nie obejmuje:

```text
HTTP headers
TLS framing
TCP/IP overhead
bibliotecznego request envelope
```

i nie jest prognozą kosztu Firebase.

## Wniosek dla batchowania

Aktualny model potwierdza wcześniejszą decyzję:

```text
BATCH_MAX_RECORDS = 10
```

jest rozsądnym pierwszym limitem eksperymentalnym, a limit bajtowy powinien być mierzony na rzeczywistym `object_t`/PATCH.

Batch 20 nadal jest bardzo mały względem sprzętowych limitów Firebase, ale zwiększa jednocześnie:

```text
czas budowy payloadu
czas pracy requestu
szczytową alokację
```

więc ma sens jako eksperyment, nie domyślny parametr.


# R140. EVENTS — ODDZIELENIE ZDARZEŃ SEMANTYCZNYCH OD PEŁNEGO LOGU

**Data:** 2026-09-24  
**Status:** ZAKOŃCZONE — audyt aktualnego firmware

## Stan wejściowy

Aktualny `main_centrala.cpp` już generuje semantyczne logi w logfmt, m.in.:

```text
tag=ALARM
 tag=OTA
 tag=COREDUMP
 tag=FB
 tag=FB-CB
 tag=WIFI
```

Przykładowo aktywacja alarmu CO i panelu zapisuje jawne `zdarzenie=aktywacja`/`dezaktywacja`, a ścieżka coredump zapisuje m.in. `zarchiwizowano`; istnieje też osobny logcoredump po błędach/validacji.

## Decyzja architektoniczna

Nie wysyłamy do RTDB każdego wiersza istniejącego logu.

Zamiast tego przyszła gałąź:

```text
/piec/events/v1/YYYY/MM/DD/<event_id>
```

ma zawierać wyłącznie wybrane zdarzenia semantyczne, np.:

```text
boot / reset / WDT
alarm aktywacja / dezaktywacja
OTA start / koniec / błąd
WiFi connected / disconnected
Firebase circuit open / reset
zmiana trybu serwa
```

Lista ma zostać zamknięta osobnym kontraktem przed implementacją.

## Dlaczego nie kopiować logBufor

Pełny log zawiera dużo informacji o niskiej wartości dla chmury (debug, retry, checkpointy, powtarzalne ostrzeżenia), a firmware ma już mechanizmy throttlingu logów i rotacji. Dublowanie każdego wiersza zwiększałoby liczbę requestów, payload i obciążenie pamięci bez proporcjonalnej korzyści.

## Kontrakt eventu — szkic

Minimalnie:

```text
ts          = czas zdarzenia, 0 gdy brak wiarygodnego czasu
mono        = czas monotoniczny urządzenia
seq         = sekwencja eventu w bieżącej sesji
kind        = stabilny typ zdarzenia
level       = info / warn / err / crit
source      = alarm / ota / wifi / firebase / system / servo ...
detail      = krótki, ustrukturyzowany zestaw pól zależny od kind
```

Nie przenosimy bezpośrednio dowolnego `String` z logu jako kontraktu API.

## Związek z istniejącym logiem

Istniejący logfmt pozostaje źródłem semantyki dla człowieka/diagnostyki lokalnej. Cloud event jest osobnym, stabilnym kontraktem danych aplikacyjnych.

**Wniosek R140:** telemetryka 1/min i `events` to dwie różne domeny danych; eventy mają być rzadkie, strukturalne i priorytetowe, ale nie mogą wymuszać duplikowania całego logu.

# R141. EVENT IDENTITY + ORDERING — OSOBNY `eventSeq`

**Data:** 2026-09-24  
**Status:** ZAKOŃCZONE — kontrakt identyfikacji eventów

## Problem

`sampleSeq` służy już do jednoznacznej identyfikacji regularnych próbek 1/min. Eventy są niezależnym strumieniem i mogą pojawić się wielokrotnie między dwiema próbkami.

Nie chcemy:

```text
zużywać sampleSeq na eventy
```

gdyż utrudniłoby to analizę „ile próbek minęło” oraz stworzyłoby nieintuicyjne luki w sekwencji próbek.

## Decyzja

Eventy otrzymują własny licznik:

```text
eventSeq : uint32_t
```

monotoniczny w RAM w obrębie bieżącej sesji.

To daje:

```text
sampleSeq  -> tylko TelemetrySample
eventSeq   -> tylko Event
```

Oba liczniki resetują się przy nowym boocie, ale sesję rozróżnia wspólny:

```text
sessionNonce : uint64_t
```

## `event_id`

Kandydat zgodny z wcześniej zamkniętym kontraktem identity:

```text
<16 hex sessionNonce>-<8 hex eventSeq>
```

czyli 25 znaków ASCII.

Przykład:

```text
0123456789ABCDEF-00000007
```

Retry tego samego eventu używa dokładnie tego samego `event_id`.

## Kolejność

Nie używamy:

```text
orderByKey()
```

jako głównego porządku czasowego całej historii, ponieważ pierwszy człon klucza jest losowym nonce sesji, więc klucz nie reprezentuje globalnego czasu.

Głównym polem query pozostaje:

```text
orderByChild("ts")
startAt(T0)
endAt(T1)
```

Przy równym `ts` Firebase porządkuje rekordy po kluczu; ponieważ `eventSeq` jest ostatnim członem klucza, rekordy z tej samej sesji mają deterministyczny tie-break po sekwencji. citeturn530809search0turn530809search4

Aplikacja i tak powinna wykonać końcowe sortowanie po:

```text
(ts, sessionNonce, eventSeq)
```

lub po własnym znormalizowanym kluczu czasu + sesji, szczególnie gdy `ts=0`.

## `ts=0`

Event bez wiarygodnego czasu nie może być udawany jako `1970-01-01`.

W takim przypadku:

```text
ts    = 0
event_id = nadal jednoznaczny
mono  = dostępny do porządku wewnątrz sesji
```

Event może więc być odzyskany po identity nawet bez prawidłowego RTC/NTP.

## Wniosek R141

Rozdzielamy identity od czasu i rozdzielamy liczniki próbek oraz eventów. Głównym porządkiem aplikacyjnym pozostaje czas pomiaru/zdarzenia, a identity zapewnia retry i jednoznaczność po restarcie.

# R142. PERSISTENT SPOOL V2 — REZERWA DLA COREDUMP + WATERMARK

**Data:** 2026-09-24  
**Status:** ZAKOŃCZONE — polityka bezpieczeństwa przestrzeni

## Stan aktualnego coredumpu

Obecny firmware ma:

```text
COREDUMP_MAX_FILES = 20
coredump partition = 64 KiB
```

oraz po udanym skopiowaniu sprawdza liczbę zapisanych bajtów przez odczyt rozmiaru pliku przed uznaniem archiwum za kompletne. Następnie wywołuje pruning archiwum.

## Istotny przypadek graniczny

Jeżeli na LittleFS istnieje już:

```text
20 × 64 KiB
```

archiwów, to kolejny coredump jest najpierw kopiowany do LittleFS, a dopiero potem pruning może usunąć starszy plik.

Dlatego twarda rezerwa dla telemetryki nie może wynosić tylko:

```text
20 × 65536 B = 1 310 720 B
```

ale powinna uwzględniać co najmniej jeden dodatkowy maksymalny coredump:

```text
21 × 65536 B = 1 376 256 B
```

oraz osobny margines operacyjny LittleFS na metadane, pliki tymczasowe i bezpieczne operacje `open/write/close/rename`.

## Decyzja V2

Persistent telemetry spool ma być ograniczany nie przez „procent całej partycji”, lecz przez twardy warunek:

```text
free_bytes
    >=
COREDUMP_RESERVE_BYTES
+ FS_OPERATION_MARGIN_BYTES
```

Gdzie `COREDUMP_RESERVE_BYTES` obejmuje minimum:

```text
(COREDUMP_MAX_FILES + 1) × 64 KiB
```

Nie wpisujemy dziś arbitralnego końcowego `FS_OPERATION_MARGIN_BYTES`; ma on zostać ustalony po pomiarze rzeczywistego LittleFS na pełnym firmware (history + logs + panel firmware + settings + coredump) i po teście `open/write/rename/remove` przy niskim free-space.

## Poziomy watermarku

Proponowane przyszłe V2:

```text
NORMAL
  → RAM ring → Firebase

SPOOL_START
  → gdy RAM backlog przekracza ustalony watermark
  → lub WAN niedostępny przez ustalony czas

SPOOL_STOP
  → po zejściu poniżej niższego watermarku

EMERGENCY
  → brak miejsca zgodnie z rezerwą coredumpu
  → telemetryka NIE zapisuje dalej do flash
```

Histereza `START > STOP` jest wymagana, żeby spool nie przełączał się co minutę przy granicy.

## Priorytet danych trwałych

Przy konflikcie miejsca:

```text
coredump / diagnostyka
    >
log krytyczny
    >
konfiguracja
    >
historia lokalna
    >
telemetry spool
```

Telemetryka nie może przez wzrost backlogu uniemożliwić zapisania kolejnego coredumpu.

## Ważna zależność od istniejącego guardu

Aktualny `logFsSizeGuard()` operuje na cache'ach czterech klas plików logowych/panel-firmware i nie jest uniwersalnym licznikiem wszystkich danych znajdujących się na LittleFS. Nie należy podpinać pod ten guard V2 spoolu bez wcześniejszego ujednolicenia modelu pojemności.

**Wniosek R142:** persistent spool jest V2 i wymaga osobnej, fizycznej polityki quota/reserve; nie może „pożyczyć” przestrzeni przeznaczonej dla coredumpów.

# R143. TELEMETRYSAMPLE — KONTROLNY LAYOUT FREEZE PO KOREKTACH

**Data:** 2026-09-24  
**Status:** ZAKOŃCZONE — layout zweryfikowany kompilatorem C++17 na hoście

## Zweryfikowany kandydat

```cpp
struct TelemetrySample {
    uint64_t sessionNonce;
    uint32_t sampleSeq;
    uint32_t unixTs;
    uint32_t monoMs;

    int16_t tZewnX10;
    int16_t tBojlerX10;
    int16_t tOgrzX10;
    int16_t tOgrzSrX10;
    int16_t tPowrotX10;
    int16_t tPanelX10;
    int16_t tPokojX10;
    int16_t tTrocinyX10;
    int16_t rhX10;
    int16_t pressureX10;

    uint16_t dym;
    uint8_t klapaDeg;
    uint8_t syberekDeg;

    uint16_t stateBits;
    uint32_t qualityBits;
    uint16_t simulatedBits;

    uint16_t ageS[11];
};
```

## Wynik rzeczywisty

Kompilacja C++17 z `sizeof()` i `offsetof()`:

```text
sizeof(TelemetrySample) = 80 B
```

Kluczowe offsety:

```text
sessionNonce  0
sampleSeq     8
unixTs       12
monoMs       16
temperatures 20..35
rh           36
pressure     38
dym          40
klapaDeg     42
syberekDeg   43
stateBits    44
qualityBits  48
simulatedBits 52
ageS         54
```

Koniec struktury:

```text
80 B
```

## Budżet ringa

Przy nominalnym 1/min:

```text
1440 × 80 B = 115 200 B = 112,5 KiB
2880 × 80 B = 230 400 B = 225 KiB
```

To jest koszt samych rekordów. Należy dodatkowo uwzględnić:

```text
mutex / synchronizację
head/tail/used
liczniki
peek batch buffer
serializer buffer
```

## Dlaczego nie wracamy do 64 B

64 B było wynikiem wcześniejszej wersji rekordu z:

```text
uint16_t qualityBits
uint8_t ageS[11]
```

Po audycie okazało się, że:

```text
11 × 2 bity jakości = 22 bity > 16 bitów
```

oraz `uint8_t age` obcinał wiek do 255 s.

Obecny wariant rozwiązuje oba problemy bez naruszania rozsądnego budżetu PSRAM.

## ABI policy

Przed wdrożeniem ringu należy dodać:

```cpp
static_assert(sizeof(TelemetrySample) == 80);
```

a przy decyzji o binarnym persistent spool V2 również wybrane `static_assert(offsetof(...))`, ponieważ kolejność pól stanie się wtedy częścią ABI pliku.

**Wniosek R143:** obecny kandydat binarnego `TelemetrySample` = **80 B** i może być traktowany jako freeze kandydata dla dalszej implementacji; wire JSON pozostaje niezależnym kontraktem.

# R144. TELEMETRYRING — SPSC + MINIMALNA SYNCHRONIZACJA SMP

**Data:** 2026-09-24  
**Status:** ZAKOŃCZONE — wybór modelu współbieżności

## Producent i konsument

W aktualnej architekturze naturalny jest układ:

```text
Core 1 / loopTask
    historiaZapiszProbke()
            │
            ▼
     TelemetryRing
            │
            ▼
Core 0 / tgTask
    pobranie batcha
```

To jest klasyczny:

```text
Single Producer
Single Consumer
```

## Decyzja

Nie używamy klasycznej `xQueueCreate()` jako głównego magazynu 24 h telemetryki.

Powód nie jest limitem funkcjonalnym — FreeRTOS pozwala na statyczną kolejkę bez dynamicznego malloc — lecz model danych jest tu prostszy i bardziej przewidywalny jako stała tablica `TelemetrySample` w PSRAM z dwoma indeksami.

Oficjalna dokumentacja FreeRTOS/ESP-IDF potwierdza, że zwykłe `xQueueCreate()` dynamicznie alokuje pamięć na strukturę kolejki i storage elementów, podczas gdy `xQueueCreateStatic()` pozwala dostarczyć oba bufory samemu. citeturn365332search36

## Layout ringa

Kandydat:

```text
TelemetrySample buffer[CAPACITY]  -> PSRAM
head                            -> małe metadata
 tail                           -> małe metadata
count / high-water / dropped    -> metadata
```

Nie przechowujemy `String`, JSON ani wskaźników do obiektów dynamicznych w slotach.

## Własność indeksów

```text
producer:
    pisze head
    czyta tail

consumer:
    pisze tail
    czyta head
```

Nie ma dwóch writerów tego samego indeksu.

## Publikacja slotu

Producent:

```text
1. odczytaj tail
2. sprawdź, czy slot jest wolny
3. zbuduj pełny TelemetrySample poza lockiem
4. skopiuj rekord do slotu head
5. opublikuj nowy head
```

Konsument:

```text
1. odczytaj head
2. określ liczbę dostępnych rekordów
3. skopiuj rekordy do batch-buffera poza lockiem
4. upload
5. po SUCCESS przesuń tail
6. po FAIL zostaw tail bez zmian
```

Dzięki temu JSON/Firebase nigdy nie działa w critical section.

## Synchronizacja

Do synchronizacji cross-core używamy wspólnego:

```cpp
portMUX_TYPE telemetryMux = portMUX_INITIALIZER_UNLOCKED;
```

Critical section służy tylko do bezpiecznej publikacji/odczytu współdzielonego metadata i musi pozostać bardzo krótka. ESP-IDF dokumentuje, że w SMP critical section korzysta ze spinlocka `portMUX_TYPE`; samo wyłączenie przerwań jednego rdzenia nie chroni zasobu przed drugim rdzeniem. Dokumentacja jednocześnie wymaga, aby critical sections były krótkie i nie wykonywały operacji blokujących ani FreeRTOS API. citeturn365332search34turn365332search35turn365332search39

## Ważna uwaga implementacyjna

Nie przesądzamy jeszcze, że **80 B kopiowania** musi wykonywać się pod spinlockiem. Preferowany wariant to:

```text
copy sample
    ↓
publish head pod bardzo krótką synchronizacją
```

albo równoważny mechanizm z jawnie zweryfikowaną barierą pamięci.

Jeżeli test target na ESP32-S3 pokaże nieakceptowalny czas publikacji lub problemy z orderingiem, implementacja musi zostać oparta na jawnie zdefiniowanym acquire/release. Nie wolno polegać na przypadkowej atomowości C++ `volatile` jako kontrakcie SMP.

## Overflow

Gdy ring jest pełny:

```text
telemetryRingPush() -> false
telemetry_ring_dropped++
```

Producer nie może czekać na miejsce.

Nie stosujemy:

```text
xSemaphoreTake(..., portMAX_DELAY)
delay()
busy-wait
```

w ścieżce próbkowania.

## Backpressure

Konsument może opóźnić `tail`, ale nigdy nie może blokować producer'a na czas sieci.

To daje jednoznaczny model awarii:

```text
WAN OFF
  → tail stoi
  → head rośnie
  → ring_used rośnie
  → po pełnym ringu jawny drop
```

## Wniosek R144

SPSC ring jest zgodny z rzeczywistym przepływem dwóch rdzeni i minimalizuje współdzielony stan. Kluczowe dla testu target jest nie samo `sizeof(TelemetrySample)`, lecz czas publikacji head/tail, ordering pamięci i zachowanie przy pełnym ringu.

# R145. EVENTS — WHITELISTA I ZAKAZ FORWARDOWANIA SUROWEGO LOGU

**Data:** 2026-09-24  
**Status:** ZAKOŃCZONE — wykryto ryzyko ujawnienia sekretów

## Znalezisko

W aktualnym `main_centrala.cpp` istnieją logi infrastrukturalne zawierające dane, których nie wolno automatycznie przenosić do chmury. Przykład ścieżki WiFi:

```text
 tag=WIFI zdarzenie=ap_ready ssid=<...> haslo=<...> ip=<...>
```

Samo istnienie takiego logu oznacza, że mechanizm:

```text
log line
  ↓
parse tag
  ↓
forward do /events
```

byłby niebezpieczny.

## Decyzja

`events` nie będzie parserem pełnego `logBufor`.

Event cloud może powstać tylko przez jawne wywołanie typu:

```text
telemetryEventEmit(kind, level, safe_detail)
```

albo równoważny kontrakt, w którym dane wejściowe są whitelistowane.

## Whitelist przykładowych pól

Dopuszczalne są np.:

```text
WiFi:
  state=connected/disconnected
  ip=<adres>
  rssi=<wartość>

OTA:
  source
  result
  version
  size

alarm:
  type
  state
  measured_value
  threshold

Firebase:
  circuit_state
  streak
```

Niedopuszczalne jako automatyczny payload:

```text
haslo
secret
token
private key
pełna treść arbitralnego logu
```

SSID również nie jest potrzebne do diagnostyki eventu i domyślnie nie powinno być wysyłane.

## Rola istniejącego logu

Lokalny log może nadal zawierać szczegóły potrzebne administratorowi urządzenia. Chmura dostaje tylko kontrakt aplikacyjny o mniejszej ekspozycji danych.

## Dodatkowa konsekwencja dla parsera

Nie projektujemy:

```text
„wyślij wszystko, co pasuje do tag=...”
```

Projektujemy:

```text
konkretna funkcja zdarzenia
    ↓
konkretne pola
    ↓
walidacja długości/zakresu
    ↓
Event
```

To zmniejsza również ryzyko przypadkowego przesłania bardzo długiego `String` do RTDB.

## Wniosek R145

Przyszła gałąź `/events` musi być **whitelist-driven**, a nie log-driven. Surowy log i cloud events pozostają dwiema oddzielnymi warstwami, m.in. po to, aby sekrety konfiguracyjne i dane infrastrukturalne nigdy nie trafiały do telemetrycznego API przez przypadek.

# R146. RTDB EVENTS — SECONDARY VALIDATION W SECURITY RULES

**Data:** 2026-09-24  
**Status:** ZAKOŃCZONE — kontrakt walidacji serwerowej

## Co może wymusić RTDB Rules

Dla `events` możemy wymagać:

```text
required children:
  ts
  mono
  seq
  kind
  level
  source
```

oraz wymusić:

```text
numbers -> isNumber()
strings -> isString()
```

zakresy:

```text
level / enum
seq >= 0
ts >= 0
```

oraz limity długości:

```text
kind.length < N
source.length < N
```

Firebase dokumentuje `hasChildren()`, `isNumber()`, `isString()`, `isBoolean()` oraz walidację długości stringa w `.validate`. citeturn154316search0

## Zakaz nieznanych pól

Można użyć wzorca:

```text
$other -> .validate = false
```

żeby rekord eventu nie mógł dostać przypadkowych, nieprzewidzianych pól. citeturn154316search3

## Atomiczność walidacji

`.validate` wykonywane jest po udzieleniu dostępu przez `.write`; wszystkie odpowiednie reguły walidacji muszą przejść, aby cały write został zaakceptowany. Dotyczy to również multi-path update: jeżeli którykolwiek objęty regułą rekord nie spełnia wymagań, nie powinniśmy traktować częściowego zapisu jako sukcesu batcha. citeturn154316search0turn154316search1

## Limity bezpieczeństwa

Nie próbujemy przenieść całej walidacji domenowej do Rules. Firmware nadal sprawdza dane lokalnie przed enqueue. Rules są drugim bezpiecznikiem przeciw:

```text
złym typom
nieznanym polom
przypadkowemu przepełnieniu stringa
złym zakresom
```

## Wniosek R146

Cloud event schema powinno mieć dwa poziomy walidacji:

```text
firmware whitelist + local validation
                ↓
RTDB .validate + .write rules
```

To szczególnie ważne dla `events`, ponieważ ich zawartość może pochodzić z wielu klas zdarzeń, a błędny parser mógłby przypadkowo przesłać dane spoza kontraktu.

# R147. BASELINE LINKER MAP — STATYCZNY DRAM VS DYNAMICZNY PSRAM

**Data:** 2026-09-24  
**Status:** ZAKOŃCZONE — pomiar z rzeczywistego `firmware.map`

## Wynik mapy linkera

Dla baseline `esp32-s3-n16r8` mapa pokazuje:

```text
.dram0.data = 23 919 B
.dram0.bss  = 43 088 B
--------------------------------
static DRAM = 67 007 B

.iram0.text = 80 791 B
.flash.text = 1 204 020 B
.flash.rodata = 542 688 B
```

Suma sekcji ładowalnych, zgodna z wcześniejszą analizą obrazu:

```text
flash.text + flash.rodata + iram0.text + dram0.data
= 1 851 418 B
```

`firmware.bin` ma 1 852 848 B; pozostała różnica wynika z formatu obrazu/paddingu i nie zmienia wcześniej policzonego headroomu względem partycji OTA.

## Znaczenie dla telemetryki

Mapa linkera pokazuje przede wszystkim:

```text
statyczne dane programu
```

Nie pokazuje natomiast pełnego runtime kosztu:

```text
FreeRTOS task stacks
PSRAM malloc
mbedTLS dynamic allocations
ArduinoJson dynamic allocations
LittleFS buffers
FirebaseClient queue
```

Dlatego po Commit A nadal obowiązkowe są pomiary runtime:

```text
internal free
internal largest block
internal minimum ever
PSRAM free
PSRAM largest block
PSRAM minimum ever
stack HWM per task
Firebase queue/taskCount
```

## Wniosek R147

`firmware.map` jest twardym baseline dla obrazu i statycznego DRAM, ale nie jest wystarczającym źródłem prawdy o bezpieczeństwie pamięci telemetryki. O akceptacji Commit A zdecydują low-watermarki runtime, nie sam rozmiar `.bss`.

# R148. SESSIONNONCE — ŹRÓDŁO ENTROPII I MOMENT GENEROWANIA

**Data:** 2026-09-24  
**Status:** ZAKOŃCZONE — potwierdzone dokumentacją ESP-IDF v5.5

## Stan obecny

Aktualny `main_centrala.cpp` nie korzysta jeszcze z `esp_random()`/`esp_fill_random()`.

## Wymaganie

`sessionNonce` ma być:

```text
64-bit
losowy
nowy dla każdego boota/sesji
```

Nie używamy:

```text
NVS write per boot jako jedynego źródła identity
millis() jako identity
RTC jako identity
MAC jako całego record_id
```

## Źródło

ESP32-S3 posiada sprzętowy RNG. Dokumentacja ESP-IDF 5.5 podaje, że `esp_random()` zwraca prawdziwie losowe wartości, gdy aktywowany jest RF subsystem (Wi-Fi/Bluetooth), a bez aktywnego źródła RF trzeba osobno zapewnić źródło entropii. `esp_fill_random()` korzysta z tego samego mechanizmu. citeturn714765search2turn714765search0

## Decyzja

W tym projekcie preferowany moment wygenerowania nonce:

```text
boot
  ↓
uruchomienie RF/WiFi
  ↓
sessionNonce = 64 bit z HWRNG
  ↓
cała bieżąca sesja używa tego nonce
```

Nie zapisujemy nonce do NVS.

Powód:

```text
zero zużycia flash
zero zależności od poprawności NVS
zero dodatkowej operacji przy każdym boot
```

## `sessionNonce` ≠ credential

Nonce nie ma być tajnym kluczem bezpieczeństwa.

Jego zadanie to:

```text
rozróżnić sesje
zapewnić unikalność record_id
umożliwić retry idempotentnie
```

Nie używamy go jako autoryzacji RTDB.

## Fallback

Jeżeli przyszła implementacja musiałaby wygenerować nonce przed aktywacją RF, należy świadomie dobrać drugi mechanizm entropii z ESP-IDF, a nie używać `millis()`/adresu pamięci/MAC jako „losowej” wartości bez dodatkowego uzasadnienia.

W aktualnym planie nie ma jednak potrzeby komplikowania tej ścieżki: nonce może powstać po aktywacji RF.

**Wniosek R148:** `sessionNonce` pozostaje ephemeral, 64-bitowy i sprzętowo losowy; nie wymaga żadnego zapisu do NVS. Jego generowanie nie jest częścią Commit A, lecz Commit B (identity).

# R149. DHT22 — FRESHNESS MUSI BYĆ ZWIĄZANE Z WYNIKIEM ODCZYTU

**Data:** 2026-09-24  
**Status:** ZAKOŃCZONE — audyt aktualnej implementacji

## Obserwacja

`wilgotnosc()` wykonuje `read_dht()` przy wejściu do funkcji, a błąd zamienia lokalny wynik na `NAN`. Następnie kod świadomie podstawia poprzednią wartość wilgotności, dzięki czemu globalne `wilgotnoscOdczytana` nadal ma użyteczną wartość dla reszty firmware. fileciteturn83file6L14048-L14107

## Konsekwencja dla telemetryki

Nie można użyć wzorca:

```text
wilgotnoscOdczytana != poprzednia
    => nowy pomiar
```

ani:

```text
funkcja wilgotnosc() zakończyła się
    => wartość jest FRESH
```

Oba założenia są błędne, bo po błędzie DHT globalna wartość może pozostać stara.

## Wymagane metadata

Dla kanału RH potrzebujemy:

```text
lastAttemptMs
lastGoodMs
lastAttemptOk
simulated
validEver
```

W `TelemetrySample` do cloud trafia tylko wynik końcowy:

```text
quality
age
value
simulated bit
```

`lastAttempt*` pozostaje lokalną diagnostyką i nie musi być częścią każdego rekordu.

## Semantyka jakości

Rekomendowana interpretacja:

```text
FRESH
  ostatnia próba zakończyła się poprawnym odczytem
  i pomiar spełnia warunek czasowy kanału

STALE
  istnieje ostatnia dobra wartość,
  ale bieżąca funkcja używa wartości z poprzedniego odczytu

UNKNOWN
  brak zaakceptowanego odczytu w tej sesji

INVALID
  źródło jawnie zwróciło wartość nieprawidłową
  i nie ma wiarygodnej wartości do pokazania
```

Dokładne zachowanie `INVALID` vs `STALE` przy pojedynczym błędzie zostanie zamknięte wspólnie dla wszystkich kanałów w kolejnym kroku freshness contract.

## Interwał

Scheduler wywołuje `wilgotnosc()` niezależnie od dynamicznego `interwalPomiaru`. Wewnątrz funkcji aktualizacja `czasOstatniegoPomiaru/interwalPomiaru` nie jest warunkiem wykonania `read_dht()` dla bieżącego wywołania. Dlatego do freshness nie wolno używać `interwalPomiaru` jako jedynego źródła nominalnego interwału.

**Wniosek R149:** dla DHT źródłem świeżości jest **wynik konkretnego odczytu**, a nie wartość globalna ani samo wywołanie funkcji. Telemetry snapshot ma być metadanymi o źródle, nie tylko kopią aktualnych zmiennych.

# R150. BMP280 / PRESSURE — LAST-GOOD + WARTOŚĆ SKORYGOWANA

**Data:** 2026-09-24  
**Status:** ZAKOŃCZONE — audyt aktualnego źródła

## Aktualna semantyka

`cisnienie()` tworzy lokalny wynik:

```text
symulacja -> symulowaneCisnienie
real -> bmp.readPressure()/100 + 18
```

a globalne `cisnienieOdczytane` jest aktualizowane tylko wtedy, gdy wynik nie jest `NaN`. Przy błędzie pozostaje poprzednia poprawna wartość. fileciteturn83file6L14006-L14028

## Wniosek dla freshness

Tak samo jak dla DHT nie wolno traktować:

```text
cisnienieOdczytane != 0
```

jako dowodu aktualnego pomiaru.

Potrzebne są:

```text
pressureLastAttemptMs
pressureLastGoodMs
pressureLastAttemptOk
pressureSimulated
pressureValidEver
```

`pressureLastGoodMs` zmienia się tylko po skończonym, skończonym numerycznie wyniku, który przeszedł lokalną walidację.

## Jednostka

Obecne `cisnienieOdczytane` jest w praktyce tym samym polem, które trafia do `/api/status`, a kod dodaje do wartości BMP stałą korektę `+18`. fileciteturn83file6L14025-L14028

Dlatego wire V1 powinien nazywać pole jednoznacznie jako np.:

```text
pressure_hpa_x10
```

lub po serializacji:

```text
p = hPa
```

ale dokument kontraktu musi zaznaczać:

```text
jest to wartość firmware po istniejącej korekcie,
nie surowy pomiar BMP280
```

Nie zmieniamy teraz znaczenia istniejącego `+18`.

## Zakres

W trybie symulacji kod dopuszcza dla pressure zakres:

```text
970 .. 1040 hPa
```

co po x10 pozostaje daleko wewnątrz zakresu `int16_t`. Rzeczywisty pomiar po obecnej korekcie również mieści się w bezpiecznym zakresie dla `int16_t` przy rozdzielczości 0,1 hPa.

## Symulacja

Dla pressure mamy jawny stan symulacji:

```text
symulacjaCisnieniaAktywna
symulacjaCisnieniaDo
symulowaneCisnienie
```

Telemetryka powinna ustawić odpowiedni bit `simulatedBits`, kiedy wartość jest aktywnie generowana przez mechanizm symulacji.

## Wniosek R150

Wartość telemetryczna pressure pozostaje zgodna z aktualnym `/api/status`, lecz dokumentujemy ją jako **firmware-corrected hPa**, a freshness opieramy na wyniku konkretnego wywołania `cisnienie()`. Nie tworzymy osobnego „surowego BMP” tylko po to, by telemetryka dostała inną semantykę niż obecny interfejs urządzenia.

# R151. CZUJNIK DYMU — SOURCE-DRIVEN FRESHNESS, NIE TIMER 1/MIN

**Data:** 2026-09-24  
**Status:** ZAKOŃCZONE — audyt aktualnego algorytmu

## Aktualna semantyka

Firmware ma jawne:

```text
czujnikDymuSwiezyOdczyt
```

które oznacza, czy `czujnikDymuOdczyt` pochodzi z rzeczywistego, świeżego odczytu ADC bieżącego cyklu. Przy rozgrzewaniu, wyłączeniu czujnika albo błędzie ADC utrzymywana jest poprzednia wartość i flaga świeżości jest ustawiana na `false`. fileciteturn83file6L14641-L14718

## Dlaczego zwykły stale-timeout jest zły

W trybie impulsowym istnieje jawne okno:

```text
dymCzasOff
+ dymCzasStabilizacji
```

w którym brak świeżego ADC jest normalnym stanem, a nie błędem komunikacji z czujnikiem. Kod opisuje przypadek, gdy przez około 150 s wartość ma być utrzymywana jako ostatni pomiar zamiast sztucznego zera. fileciteturn83file6L14718-L14741

Dlatego:

```text
age > 3 × 1 min
```

nie może automatycznie oznaczać awarii `dym`.

## Proponowana semantyka

```text
FRESH
  dym_swiezy == true
  i ostatni zaakceptowany ADC jest z bieżącego cyklu

STALE
  dym_swiezy == false,
  ale istnieje poprzedni poprawny ADC

UNKNOWN
  brak poprawnego ADC od startu

INVALID
  ostatni aktywny odczyt ADC był jawnie nieprawidłowy
  i nie istnieje wartość możliwa do użycia
```

Wymaga to zachowania osobnego:

```text
dymLastGoodMs
```

oraz, przy aktywnym odczycie, wyniku ostatniej próby.

## Simulated

Kod rozróżnia również aktywną symulację dymu. W takim przypadku:

```text
value = symulowanyCzujnikDymu
simulatedBits[dym] = 1
```

ale nie zmieniamy jakości na „real fresh” tylko dlatego, że liczba jest aktualizowana.

## Alarm

`czyAlarmAktywny` jest osobnym stanem logicznym i nie powinien być utożsamiany z `quality(dym)`.

W telemetryce powinny istnieć dwa niezależne fakty:

```text
dym value/quality
alarm dymu ON/OFF
```

## Wniosek R151

`dym` jest kanałem event-driven. Źródłem freshness jest **stan algorytmu czujnika**, a nie liczba sekund od ostatniej próbki telemetrycznej. `dym` powinien mieć własne reguły jakości i wieku; 1-minutowy scheduler historii tylko robi snapshot aktualnej wiedzy.

# R152. TEMPERATURA OGRZEWANIA ŚREDNIA — FRESHNESS WARTOŚCI POCHODNEJ

**Data:** 2026-09-24  
**Status:** ZAKOŃCZONE — audyt genealogii wyniku

## Stan aktualny

`obliczanie_srednia()` działa co 2224 ms, ale wynik nie jest niezależnym pomiarem. Algorytm korzysta zależnie od trybu z:

```text
Tryb 1:
  próbki bieżącego cyklu

Tryb 2/3:
  rolling average z 4 próbek
  aktualizowanych przy pracującej pompie

piec uznany za wygasły:
  temperaturaOgrzewania 1:1
```

Dodatkowo algorytm może zachować `ostatni_poprawny`, gdy nowa średnia jest uznana za niewiarygodną. W efekcie samo wejście do `obliczanie_srednia()` nie oznacza nowej informacji fizycznej. 

## Decyzja jakości

`t_ogrz_sr` nie dostaje własnego niezależnego „czujnika freshness”.

Jakość ma być wyprowadzana z:

```text
t_ogrz source quality
+
status algorytmu średniej
+
czas najnowszej zaakceptowanej próbki użytej przez wynik
```

## Minimalny model

Potrzebujemy lokalnie:

```text
ogrzSrLastGoodMs
ogrzSrLastSourceGoodMs
ogrzSrHasValidValue
```

oraz informacji, czy bieżące wyliczenie faktycznie użyło nowej zaakceptowanej próbki źródła.

## Przykład

Jeżeli:

```text
t_ogrz = 67.4 °C, FRESH
```

i algorytm policzył nową średnią z aktualnej próbki, wynik może być:

```text
t_ogrz_sr = 65.8 °C
quality = FRESH
age = age najnowszej próbki źródłowej
```

Jeżeli następne pięć przebiegów `obliczanie_srednia()` pracuje wyłącznie na starym materiale, wynik nie staje się ponownie FRESH tylko dlatego, że funkcja wykonała się pięć razy.

## Fallback po wygaszeniu pieca

Gdy piec jest uznany za wygasły, wynik zaczyna podążać za `temperaturaOgrzewania`. W tej gałęzi jakość może dziedziczyć jakość źródłowej temperatury pieca.

## Wniosek R152

`temperaturaOgrzewaniaSrednia` jest **wartością pochodną**, a jej freshness musi śledzić najnowszą zaakceptowaną próbkę, która rzeczywiście weszła do obliczenia. Nie wolno używać częstotliwości funkcji `obliczanie_srednia()` jako substytutu świeżości danych fizycznych.

# R153. DS18B20 — METADATA MUSI ODDZIELAĆ PRÓBĘ, AKCEPTACJĘ I FALLBACK

**Data:** 2026-09-24  
**Status:** ZAKOŃCZONE — audyt aktualnego `odczytajTemperature()` / `Czujnik_DS()`

## 153.1. Co robi obecny kod

`Czujnik_DS()` wywołuje siedem instancji `odczytajTemperature()`. Każde wywołanie ma jawnie przypisaną fizyczną magistralę (`BUS_1`, `BUS_2`, `BUS_3`). Gdy przypisana magistrala nie ma aktualnie gotowej konwersji, funkcja może zwrócić ścieżkę „brak odczytu” bez nowej dobrej wartości. Gdy odczyt istnieje, najpierw przechodzi przez walidację zakresu / odrzucenie 85°C, a następnie przez `FiltrWiarygodnosci`, który może zwrócić ostatnią dobrą wartość mimo nowej próby.

W kodzie występują więc co najmniej cztery logicznie różne sytuacje:

```text
1. brak gotowej próby / brak odpowiedzi z magistrali
2. próba wykonana, ale odczyt invalid
3. próba poprawna, lecz odrzucona przez rate-of-change
4. próba poprawna i zaakceptowana jako nowa wartość
```

Dodatkowo osobno istnieją:

```text
5. symulacja globalna / per-czujnik
```

Nie można sprowadzić tych stanów do samego `float`.

## 153.2. Najważniejsza pułapka

Porównanie:

```cpp
nowaWartosc == poprzedniaWartosc
```

nie odpowiada na pytanie, czy wykonano nowy poprawny pomiar.

Przykład:

```text
12:00:00  67.4°C  accepted
12:02:48  67.4°C  accepted
```

Wartość jest identyczna, ale druga próbka jest nowym pomiarem i musi odświeżyć `lastGoodMs`.

Odwrotny przypadek:

```text
12:02:48  raw=96°C
           rate-of-change reject
           zwracamy stare 67.4°C
```

Globalna wartość także pozostaje `67.4°C`, ale `lastGoodMs` NIE może zostać odświeżony.

## 153.3. Wymagana meta-informacja per kanał

Kandydat do warstwy lokalnej:

```cpp
struct SensorFreshness {
    uint32_t lastAttemptMs;
    uint32_t lastGoodMs;
    uint8_t  status;
};
```

`status` powinien mieć jawne wartości, np.:

```text
NO_ATTEMPT
INVALID
REJECTED
ACCEPTED
SIMULATED
```

Nie jest to jeszcze ABI telemetrycznego rekordu — jest to metadata źródła danych.

## 153.4. Semantyka `lastAttemptMs`

`lastAttemptMs` oznacza moment, w którym firmware rzeczywiście miał możliwość wykonać/wykonał próbę odczytu danego kanału.

Nie wolno ustawiać go w `historiaZapiszProbke()`.

Nie wolno też aktualizować go tylko dlatego, że `Czujnik_DS()` został wywołany.

## 153.5. Semantyka `lastGoodMs`

`lastGoodMs` jest aktualizowane wyłącznie wtedy, gdy:

```text
raw odczyt był prawidłowy
AND
nie został odrzucony przez filtr
AND
wynik został przyjęty jako nowa wartość źródłowa
```

To oznacza, że „ostatnia dobra wartość” może być starsza od `lastAttemptMs` o wiele cykli — i właśnie tę różnicę telemetryka ma ujawnić.

## 153.6. Brak gotowej konwersji

Jeżeli dana magistrala nie ma jeszcze gotowej konwersji, nie należy sztucznie ustawiać:

```text
lastAttemptMs = now
```

jako dowodu odczytu. To jest raczej `NO_ATTEMPT` dla tego kanału.

Jest to szczególnie ważne, ponieważ scheduler `Czujnik_DS()` działa jako cykl wspólny dla wielu czujników i nie każdy kanał musi być w danej chwili faktycznie czytany.

## 153.7. Rate-of-change reject

Przy obecnym filtrze:

```text
raw valid
→ różnica > 15°C/cykl
→ REJECTED
→ zwracamy f.ostatniaDobra
```

Telemetryka musi zachować:

```text
lastAttemptMs = teraz
lastGoodMs    = bez zmian
status        = REJECTED
```

Dzięki temu wykres może pokazać prawdziwy fakt: sterownik miał świeżą próbę, ale jej nie zaakceptował.

## 153.8. First good sample

Dla pierwszej zaakceptowanej próbki:

```text
lastAttemptMs = teraz
lastGoodMs    = teraz
status        = ACCEPTED
```

Dopiero wtedy kanał przestaje być `UNKNOWN`.

## Wniosek R153

`TelemetrySample` nie może odtwarzać freshness z samych globalnych wartości. Warstwa źródłowa musi jawnie rejestrować **kiedy była próba**, **kiedy przyjęto nową wartość** i **dlaczego bieżąca wartość jest utrzymywana**. Szczególnie rate-of-change reject nie może odświeżać `lastGoodMs`.

# R154. QUALITYBITS + AGES — FORMALNA SEMANTYKA WIRE

**Data:** 2026-09-24  
**Status:** ZAKOŃCZONE — zamknięcie semantyki jakości danych

## 154.1. Cztery wartości jakości

Dla każdego kanału telemetrycznego rezerwujemy 2 bity:

```text
00 = FRESH
01 = STALE
10 = UNKNOWN
11 = INVALID
```

`qualityBits` jest teraz `uint32_t`, ponieważ 11 kanałów × 2 bity = 22 bity.

## 154.2. Quality opisuje wartość, nie ostatnią próbę

Najważniejsza reguła:

```text
QUALITY = czy wartość, którą otrzymuje aplikacja, jest obecnie
          wiarygodną wiedzą sterownika?
```

Przykład:

```text
12:00  67.4°C  accepted
12:01  67.5°C  accepted
12:02  raw invalid, brak nowej wartości
```

Wartość telemetryczna pozostaje 67.5°C, więc stan:

```text
quality = STALE
age     = czas od 12:01
```

Nie ustawiamy `INVALID`, ponieważ sterownik nadal posiada używalną ostatnią dobrą wartość.

`INVALID` rezerwujemy dla przypadku, gdy nie istnieje żadna wartość, którą można uczciwie wykorzystać.

## 154.3. Definicje

### FRESH

Wartość ma co najmniej jedną poprawną, zaakceptowaną próbkę i:

```text
snapshot_now - lastGoodMs <= stale_threshold(channel)
```

### STALE

Istnieje poprawna wartość, ale:

```text
snapshot_now - lastGoodMs > stale_threshold(channel)
```

Wartość nadal może być prezentowana, ale aplikacja musi wiedzieć, że jest stara.

### UNKNOWN

Od uruchomienia nie przyjęto ani jednej poprawnej wartości:

```text
lastGoodMs == 0 / brak historii
```

Przykład: czujnik nie odpowiedział ani razu po starcie.

### INVALID

Stan źródła jest jawnie nieużywalny i nie ma żadnej wartości możliwej do użycia.

W praktyce dla obecnego firmware `UNKNOWN` będzie najczęstszym stanem przed pierwszą dobrą próbką; `INVALID` pozostaje zarezerwowane dla trwałej/wyraźnej invalidacji kanału przez warstwę źródłową.

## 154.4. Simulation jest ortogonalne

Nie dodajemy piątej wartości jakości.

Zamiast:

```text
quality = SIMULATED
```

mamy:

```text
quality = FRESH / STALE / ...
simulatedBits[channel] = 1
```

Dzięki temu aplikacja może powiedzieć jednocześnie:

```text
wartość świeża
wartość pochodzi z symulacji
```

To jest semantycznie czystsze niż mieszanie dwóch niezależnych właściwości w jednym polu.

## 154.5. `ageS`

`ageS[channel]` oznacza:

```text
liczba pełnych sekund od lastGoodMs do momentu snapshotu
```

Nie oznacza:

```text
czas od ostatniego wywołania funkcji
czas od ostatniego nieudanego odczytu
czas od ostatniej próby
```

To pozostaje spójne z rozróżnieniem `lastAttemptMs` vs `lastGoodMs` z R153.

## 154.6. Sentinele wieku

Rekomendowany kontrakt:

```text
0 ... 65534  = rzeczywisty/saturujący wiek w sekundach
65535        = BRAK LAST-GOOD / wiek nieznany
```

Nie używamy `255` jako niejawnego `>=255 s`.

`65534` oznacza „co najmniej 65534 s”, jeżeli wiek jest większy od reprezentowalnego zakresu.

## 154.7. Spójność quality + age

Dozwolone kombinacje:

```text
FRESH  + age 0..65534
STALE  + age 1..65534
UNKNOWN + age 65535
INVALID + age 65535
```

Nie dopuszczamy np.:

```text
UNKNOWN + age 37
```

ani:

```text
INVALID + age 120
```

a po stronie aplikacji można dzięki temu traktować `age=65535` jako brak punktu odniesienia.

## 154.8. Co z nieudaną bieżącą próbą

Nieudana próba nie zmienia `lastGoodMs`.

W efekcie:

```text
lastAttemptMs   rośnie
lastGoodMs      zostaje
ageS             rośnie
quality          przechodzi FRESH → STALE
```

To jest dokładnie zachowanie, które chcemy zobaczyć w chmurze przy degradacji czujnika.

## Wniosek R154

Kontrakt V1 jest zamknięty jako:

```text
qualityBits = 2-bit state per channel
simulatedBits = niezależna maska
ageS = uint16_t, 65535 = brak zaakceptowanej wartości
```

Stan jakości opisuje użyteczność aktualnie udostępnianej wartości. Nieudana próba przy istniejącym last-good daje `STALE`, a nie `INVALID`.

# R155. SNAPSHOT CONSISTENCY — WŁAŚCICIELE DANYCH I KOREKTA SEMANTYKI SERW

**Data:** 2026-09-24  
**Status:** ZAKOŃCZONE — audyt własności pól przed implementacją snapshotu

## 155.1. Korekta semantyki pozycji serw

Wcześniejszy opis telemetryki używał nazw `klapa_proc` / `syberko_proc` odziedziczonych po historycznym CSV. Aktualny kod pokazuje inną rzeczywistą semantykę wykonawczą:

```text
komenda użytkownika: procent 0..100
        ↓
procentNaKat()
        ↓
klapa:   0..180°
syberek: 0..90°
        ↓
zlecServoRuch()
        ↓
pozycjaKlapa / pozycjaSyberek
```

`pozycjaKlapa` i `pozycjaSyberek` są więc bieżącymi pozycjami fizycznymi wyrażanymi w stopniach, a nie procentami. Kod używa jawnie zakresów 0..180 dla klapy i 0..90 dla syberka w ruchu serw. 

## 155.2. Znaleziona osobna niespójność

Ładowanie z NVS obecnie zawiera sanityzację:

```text
pozycjaKlapa > 100  → reset do 0
pozycjaSyberek > 100 → reset do 0
```

podczas gdy późniejsza logika ruchu klapy dopuszcza 180°, a Telegram również opisuje wartości jako stopnie.

To jest **osobny istniejący problem semantyczny NVS/serwo**.

Decyzja:

```text
telemetryka NIE naprawia tego problemu
telemetryka nie zmienia zakresu NVS
telemetryka dokumentuje wartość taką, jaką rzeczywiście przechowuje wykonawczy model serwa
```

## 155.3. Właściciele snapshotu

Przed stworzeniem `TelemetrySample` pola dzielimy na klasy:

### A. Jednoznaczny właściciel Core 1 / scheduler

```text
temperaturaOgrzewania
temperaturaBojlera
temperaturaNaZewnatrz
temperaturaPaneluSlonecznego
temperaturaPomieszczenia
temperaturaOgrzewania_Trociny
temperaturaOgrzewania_Powrot
wilgotnoscOdczytana
cisnienieOdczytane
wynik średniej
pozycjaKlapa / pozycjaSyberek — od strony fizycznego wykonania
```

Dla tych pól preferowany jest snapshot wykonywany z Core 1, czyli z tego samego kontekstu, który aktualizuje większość stanu sensorycznego.

### B. Stany wielowriterowe

Do tej grupy należą m.in.:

```text
alarmOgrzewanieWlaczone
alarmPanelWlaczone
TrybSerwa
czyAlarmAktywny
```

Nie mogą być odczytywane jako część „atomowego globalnego obrazu” bez jawnej strategii synchronizacji.

### C. Stan sprzętowy odczytywany z GPIO

`pompaJestWlaczona()` może być traktowana jako obserwacja rzeczywistego wyjścia sprzętowego, zamiast kopiowania pomocniczej flagi sterownika.

To jest korzystne telemetrycznie: pole opisuje stan fizycznego przekaźnika w chwili snapshotu.

## 155.4. Dlaczego nie jeden wielki critical section

Nie należy robić:

```cpp
portENTER_CRITICAL(&telemetryMux);
// odczyt wszystkich globali + I/O + DateTime + String + JSON
portEXIT_CRITICAL(&telemetryMux);
```

Powody są te same, które doprowadziły do poprzednich fixów `historiaMux`: sekcja SMP ma być minimalna, bez I/O i bez alokacji.

## 155.5. Preferowany model snapshotu

Model docelowy:

```text
Core 1 / producent
    ↓
przygotuj lokalny TelemetrySample
    ↓
skopiuj wyłącznie wartości źródłowe + metadata freshness
    ↓
krótka publikacja do SPSC ring
```

Konsument Core 0 nie czyta ponownie żadnych globalnych sensorów przy uploadzie.

Dzięki temu batch jest niezmienną migawką stanu z konkretnej chwili.

## 155.6. Multi-writer stateBits

Dla stanów z wielu writerów są tylko trzy bezpieczne opcje:

```text
1. przenieść odczyt na bezpieczny owner/context
2. użyć jawnej synchronizacji wspólnego stanu
3. nie umieszczać pola w V1, dopóki synchronizacja nie zostanie udowodniona
```

Nie wybieramy „volatile i nadzieja”.

## Wniosek R155

`TelemetrySample` ma być migawką z jednego kontekstu, nie agregacją ponownie odczytywanych globali. Pola wielowriterowe zostają poza częścią wymagającą atomowości do czasu zdefiniowania owner/synchronization. Semantyka pozycji serw zostaje jawnie opisana jako stopnie; niespójność sanityzacji NVS trafia do osobnego zadania.

# R156. STATEBITS — SAFE SUBSET DLA V1, BEZ „VOLATILE I NADZIEI"

**Data:** 2026-09-24  
**Status:** ZAKOŃCZONE — audyt writerów stanów

## 156.1. Cel

`stateBits` ma opisywać stan wykonawczy/logiczną sytuację urządzenia, ale nie może sam wprowadzać nowego wyścigu między Core 0 i Core 1.

Dlatego dla V1 przyjmujemy zasadę:

```text
jeżeli własność pola nie jest jednoznaczna
→ pole nie trafia jeszcze do stateBits
```

## 156.2. Bezpieczny subset

Na obecnym etapie bez dodatkowego mechanizmu synchronizacji możemy bezpośrednio reprezentować:

```text
BIT0 PUMP_ON
      źródło prawdy: pompaJestWlaczona()
      odczyt fizycznego wyjścia GPIO

BIT1 SMOKE_ALARM
      źródło: czyAlarmAktywny
      stan ustawiany przez algorytm dymu w kontekście scheduler/Core 1

BIT2 SMOKE_SENSOR_ENABLED
      źródło: czujnikDymuWlaczonyTemperaturowo
      aktualizowany w tej samej ścieżce obsługi czujnika dymu
```

Te trzy pola nie wymagają tworzenia nowej wspólnej struktury synchronizacji dla pierwszego snapshotu.

## 156.3. Pola odłożone

Do późniejszej fazy odkładamy co najmniej:

```text
alarmOgrzewanieWlaczone
alarmPanelWlaczone
TrybSerwa
mieszadloAktywnyStan
rozpalanieAktywne
```

Powód: audyt pokazuje wielowriterowość lub dostęp z różnych kontekstów. Dodanie ich do `stateBits` wymaga najpierw jawnego kontraktu owner/synchronizacji.

## 156.4. Stan Wi-Fi

Nie dodajemy teraz `WIFI_CONNECTED` wyłącznie na podstawie swobodnego odczytu `WiFi.status()` do tego samego bitfielda. Ten fakt jest prosty do uzyskania, ale trzeba jeszcze określić, czy V1 potrzebuje stanu transportu w `stateBits`, czy lepiej pozostawić go jako osobne pole diagnostyczne / event.

Nie chcemy mieszać:

```text
state fizyczny pieca
```

z:

```text
stan transportu sieciowego
```

bez jednoznacznej potrzeby.

## 156.5. Stan czasu

`g_rtcGotowy` jest ustawiany podczas inicjalizacji, natomiast `g_rtcNtpZsynchronizowany` może zmienić się po późniejszej synchronizacji NTP. Zanim bit TIME_VALID trafi do atomowego snapshotu, trzeba dokończyć audyt writerów obu flag i kontekstu ich aktualizacji.

Na teraz czas pozostaje osobnym kontraktem:

```text
unixTs = czas pomiaru
monoMs = czas monotoniczny urządzenia
```

## 156.6. Ważna uwaga o `pompa`

Wcześniejsza globalna flaga pomocnicza `stanPompy` została już usunięta z projektu. Jedynym źródłem prawdy dla prezentacji pompy jest `pompaJestWlaczona()`, która czyta stan GPIO. To jest dokładnie ten rodzaj źródła, który chcemy używać w snapshotcie telemetrycznym zamiast dublowania logiki sterowania.

## Wniosek R156

Pierwsza wersja `stateBits` ma być celowo mała:

```text
PUMP_ON
SMOKE_ALARM
SMOKE_SENSOR_ENABLED
```

Pozostałe stany wielowriterowe pozostają poza V1 do czasu udowodnienia atomowej obserwacji. To zmniejsza powierzchnię ryzyka bez utraty informacji niezbędnej do późniejszej diagnostyki.

# R157. SAMPLE ID — WŁAŚCICIEL SEKWENCJI, WRAP I KOLIZJE

**Data:** 2026-09-24  
**Status:** ZAKOŃCZONE — domknięcie tożsamości rekordu

## 157.1. Właściciel `sampleSeq`

`TelemetrySample.sampleSeq` jest przydzielany wyłącznie przez producenta telemetryki w Core 1, bezpośrednio przed publikacją próbki do SPSC ring.

Nie ma potrzeby:

```text
atomic<uint32_t>
mutex
NVS write
```

jeżeli utrzymamy zasadę jednego producenta.

## 157.2. Kolejność

Przykładowy przebieg:

```text
sessionNonce = N
sampleSeq = 41
snapshot
push ring

sessionNonce = N
sampleSeq = 42
snapshot
push ring
```

Jeżeli `telemetryPush()` zawiedzie z powodu pełnego ringu, numer i tak może być zużyty. Nie powtarzamy go tylko dlatego, że próbka nie dostała się do bufora.

To jest celowe: `sampleSeq` identyfikuje wygenerowaną próbkę, a nie wyłącznie próbki, które fizycznie weszły do ringu.

Wymaga to licznika:

```text
telemetry_ring_dropped
```

który ujawnia lukę w sekwencji.

## 157.3. Retry

Retry nie pobiera nowego `sampleSeq`.

Jest to szczególnie ważne:

```text
peek sample #42
→ upload fail
→ retry sample #42
```

a nie:

```text
retry
→ sample #43
```

Dzięki temu `record_id` pozostaje identyczny.

## 157.4. Zakres `uint32_t`

Dla nominalnego 1/min:

```text
2^32 próbek ≈ 4,294,967,296 min
                   ≈ 8,168 lat
```

Nawet przy 1/s jest to ponad 136 lat.

Wniosek: `uint32_t` jest wystarczające dla `sampleSeq` V1.

## 157.5. Wrap

Formalnie po przepełnieniu:

```text
0xFFFFFFFF → 0x00000000
```

W V1 nie traktujemy tego jako błędu, ponieważ `sessionNonce` pozostaje stałym identyfikatorem sesji.

W ramach jednej sesji teoretyczny wrap jest praktycznie nieosiągalny. Dla defensywności implementacja powinna nadal wykonywać arytmetykę `uint32_t` bez założeń typu `seq > poprzedniSeq` po wielu latach.

## 157.6. `sessionNonce`

`sessionNonce` identyfikuje boot/session, nie jest hasłem, tokenem ani sekretem.

Rekomendacja:

```text
64-bit HWRNG value
```

Wygenerowane po zapewnieniu źródła entropii RF; ESP32-S3 dokumentuje `esp_random()` jako prawdziwie losowe przy aktywnym Wi-Fi/Bluetooth. citeturn686818search0

Nie zapisujemy go do NVS przy każdym boocie.

## 157.7. `record_id`

Formalny kontrakt pozostaje:

```text
<16 hex chars sessionNonce>-<8 hex chars sampleSeq>
```

czyli dokładnie 25 znaków ASCII.

Przykład:

```text
0123456789ABCDEF-0000002A
```

Znaki są bezpieczne jako klucz RTDB i nie niosą znaków zarezerwowanych dla Firebase paths.

## Wniosek R157

Tożsamość telemetryki pozostaje:

```text
sessionNonce + sampleSeq
```

bez NVS i bez synchronizacji wielowątkowej dla samego licznika. Retry zachowuje identyczny `record_id`, a utracone próbki są wykrywalne przez lukę w `sampleSeq` + `telemetry_ring_dropped`.

# R158. `ts=0` — OSOBNY SHARD, BEZ FAŁSZOWANIA CZASU

**Data:** 2026-09-24  
**Status:** ZAKOŃCZONE — zamknięcie obsługi próbek bez wiarygodnego czasu

## 158.1. Problem

Obecny firmware jawnie zapisuje `czas_unix=0`, jeżeli ani RTC, ani NTP nie są jeszcze wiarygodne.

Taki rekord:

```text
ts = 0
```

nie może trafić do zwykłego:

```text
YYYY/MM/DD
```

bo nie znamy dnia pomiaru.

Nie wolno również zrobić:

```text
ts=0 podczas pomiaru
→ NTP synchronizuje się później
→ przypisz rekord do dnia synchronizacji
```

bo zmienia to znaczenie danych.

## 158.2. Rozważane opcje

### A. Czekać z uploadem

Problem: rekord z `ts=0` pozostaje na głowie ringu.

Jeżeli kolejne próbki mają już poprawny czas, prosty FIFO nie może ich ominąć bez dodatkowego mechanizmu out-of-order commit.

### B. Kasować `ts=0`

Tracimy rzeczywiste próbki z okresu startowego.

Nie spełnia to celu telemetryki diagnostycznej.

### C. Osobny shard `unknown`

Rekord jest wysyłany natychmiast, ale jawnie oznaczony jako pozbawiony czasu absolutnego.

To jest wybrany model V1.

## 158.3. Docelowa ścieżka

Normalna próbka:

```text
/piec/telemetry/1m/v1/YYYY/MM/DD/<record_id>
```

Próbka bez czasu:

```text
/piec/telemetry/1m/v1/unknown/<record_id>
```

Klucz nadal zawiera:

```text
sessionNonce + sampleSeq
```

więc retry pozostaje idempotentny.

## 158.4. Payload `unknown`

W rekordzie pozostaje:

```text
v
id lub record_id wynikający z klucza
 ts = 0
mono_ms
measurement data
quality
age
state
```

`mono_ms` jest szczególnie ważne tutaj, ponieważ pozwala aplikacji ustalić względny porządek próbek w obrębie boot/session.

## 158.5. Brak retroaktywnej korekty

Po uzyskaniu NTP:

```text
stare ts=0 → pozostają ts=0
nowe próbki → mają aktualny prawidłowy ts
```

Nie wykonujemy później automatycznej migracji starych rekordów do dnia synchronizacji.

## 158.6. Aplikacja

Repository może traktować:

```text
getTelemetry(range)
```

jako dwa źródła:

```text
1. dni objęte zakresem
2. opcjonalny `unknown` jako osobny strumień diagnostyczny
```

Przy zwykłym wykresie użytkowym `unknown` może być pomijany z osi czasu, ponieważ nie ma wiarygodnej daty. W widoku diagnostycznym może być pokazany jako „bez czasu absolutnego / boot session”.

## 158.7. Security Rules

Rules muszą mieć osobną gałąź walidacyjną:

```text
.../v1/unknown/$recordId
```

z takim samym ograniczeniem typów i wielkości danych jak normalny rekord.

Nie dopuszczamy:

```text
unknown/$recordId/command
```

ani dodatkowych, niezatwierdzonych pól.

## 158.8. Wpływ na backlog

Najważniejsza zaleta architektoniczna:

```text
ts=0
→ nie blokuje head ringu
→ może zostać ACK-owany
→ kolejne prawidłowo oczasowane rekordy mogą być wysłane
```

To upraszcza FIFO i zachowuje semantykę czasu.

## Wniosek R158

Próbki bez wiarygodnego czasu nie są ani odrzucane, ani sztucznie datowane. V1 wysyła je do jawnego shardu:

```text
/piec/telemetry/1m/v1/unknown/<record_id>
```

z `ts=0` i `mono_ms`, a po późniejszej synchronizacji NTP nie następuje retroaktywna zmiana ich czasu.

# R159. STALE THRESHOLDS — ŹRÓDŁOWE INTERWAŁY Z ACTUAL V3.11.4

**Data:** 2026-09-24  
**Status:** ZAKOŃCZONE — wyprowadzenie progów FRESH/STALE

## 159.1. Interwały wejściowe

Aktualny scheduler rejestruje:

```text
Czujnik_DS             2816 ms
obliczanie_srednia     2224 ms
cisnienie              5000 ms
wilgotnosc             3000 ms
pozar                  4992 ms
```

Źródło: aktualny `setup()` v3.11.4. fileciteturn83file6L21278-L21315

Scheduler nie nadrabia pominiętych wywołań — po opóźnieniu następny termin jest liczony od aktualnego wykonania. Dlatego próg freshness musi mieć pewien margines ponad nominalny takt.

## 159.2. Zasada bazowa

Dla kanałów cyklicznych przyjmujemy początkowo:

```text
STALE_THRESHOLD ≈ max(3 × nominal_interval, 2 s)
```

Następnie zaokrąglamy do czytelnej wartości konfiguracyjnej.

## 159.3. Proponowane wartości V1

```text
DS18B20      10 s
DHT RH       10 s
BMP280       15 s
ogrz_sr      10 s  (dziedziczona z jakości t_ogrz)
```

To są **progi jakości telemetrycznej**, a nie timeouty mechanizmów sterownika.

Nie zmieniają schedulerów ani zachowania automatyki.

## 159.4. Dym

Dla dymu nie stosujemy stałego progu typu:

```text
3 × 4.992 s
```

ponieważ `pozar()` ma stanowy algorytm i może przez dziesiątki/ponad sto sekund prawidłowo działać bez świeżego ADC.

Model:

```text
sensor enabled + ostatni good
    → age rośnie
    → po progu jakości może być STALE

sensor disabled / warm-up
    → brak świeżej próbki jest stanem oczekiwanym
    → stateBits.SMOKE_SENSOR_ENABLED = 0 albo stan warm-up

brak jakiejkolwiek dobrej próbki
    → UNKNOWN
```

W ten sposób aplikacja nie pomyli:

```text
„czujnik chwilowo nie mierzy, bo algorytm go wyłączył”
```

z:

```text
„czujnik działa, ale od dawna nie dostarczył wartości”
```

## 159.5. Po co stan + quality razem

Przykład:

```text
quality(dym) = STALE
SMOKE_SENSOR_ENABLED = 0
```

jest semantycznie inny niż:

```text
quality(dym) = STALE
SMOKE_SENSOR_ENABLED = 1
```

Pierwszy oznacza normalne okno wyłączenia czujnika, drugi może wskazywać problem z aktualizacją odczytu.

## 159.6. Wyjątek dla symulacji

Symulowany kanał może mieć:

```text
quality = FRESH
simulated = true
```

o ile wartość jest faktycznie aktywnie generowana.

Nie przesuwamy `lastGoodMs` w nieskończoność przez samo czytanie globalnej wartości; czas symulacji musi być aktualizowany przez jawny wynik ścieżki symulacyjnej.

## 159.7. Progi nie są kontraktem UI

Aplikacja nie powinna zakładać, że:

```text
STALE = awaria czujnika
```

To jest stan jakości danych. Warstwa zdarzeń/diagnostyki może później powiedzieć, że wystąpiła seria błędnych prób, ale te dwa pojęcia nie są tym samym.

## Wniosek R159

V1 dostaje source-specific stale thresholds:

```text
DS18B20 10 s
DHT     10 s
BMP     15 s
ogrz_sr dziedziczenie z t_ogrz
dym     semantyka state-driven
```

Są to progi telemetryczne, niezależne od sterowania i schedulerów.

# R160. KONTEKST PRODUCENTA I KONSUMENTA — POTWIERDZENIE REALNYM TASK TOPOLOGY

**Data:** 2026-09-24  
**Status:** ZAKOŃCZONE — potwierdzenie architektury Core 1 → Core 0

## 160.1. Fakty z aktualnego kodu

Aktualny firmware tworzy:

```text
tgTask       → Core 0, priority 1, stack 8192
tgPollTask   → Core 0, priority 1, stack 8192
historiaTask → Core 0, priority 1, stack 8192
```

Źródło aktualnego `setup()`: `xTaskCreatePinnedToCore(..., 0)`. fileciteturn83file6L21133-L21149

Główna pętla Arduino jest utrzymywana osobno i pozostaje kontekstem obsługującym scheduler oraz automatykę Core 1.

## 160.2. Konsekwencja dla telemetryki

Producent próbki:

```text
loopTask / scheduler / Core 1
```

Konsument sieciowy:

```text
tgTask / Core 0
```

To jest dokładnie topologia, dla której SPSC ring jest naturalnym rozwiązaniem.

## 160.3. Brak `TelemetryTask`

Nie tworzymy:

```text
TelemetryTask
```

bo oznaczałoby to kolejny stack, kolejny punkt synchronizacji i kolejne źródło jitteru.

Istniejąca architektura już ma:

```text
Core 1 → scheduler + automatyka
Core 0 → tgTask + Firebase
```

więc ring działa jako bufor między tymi domenami.

## 160.4. Producent nie może blokować

W Core 1 producent powinien wykonać tylko:

```text
snapshot
→ fixed-point conversion
→ quality/age calculation
→ sequence assignment
→ ring push
```

Nie może wykonywać:

```text
Firebase
DNS
TLS
LittleFS
String-heavy JSON
```

## 160.5. Konsument nie może ponownie czytać sensorów

`tgTask` dostaje wyłącznie immutable `TelemetrySample` z ringa.

Nie wolno robić:

```text
peek sample
→ ponownie odczytaj globalne temperatury
→ zbuduj payload
```

bo wtedy record_id przestałby odpowiadać jednej, spójnej migawce pomiarowej.

## Wniosek R160

Topologia zostaje zamrożona:

```text
Core 1 / scheduler
       │
       ▼
TelemetrySample
       │
       ▼
SPSC PSRAM ring
       │
       ▼
Core 0 / tgTask
       │
       ▼
existing Firebase client
```

Brak nowego taska telemetrycznego jest decyzją architektoniczną V1, nie tylko optymalizacją.

# R161. WILGOTNOŚĆ — ROZDZIELENIE POMIARU SUROWEGO OD WARTOŚCI POCHODNEJ

**Data:** 2026-09-24  
**Status:** ZAKOŃCZONE — audyt semantyki RH w aktualnym firmware

## 161.1. Dwie różne wartości

Aktualny firmware posiada:

```text
wilgotnoscOdczytana
    = wartość bezpośrednio otrzymana z DHT / ostatnia dostępna wartość

wilgotnoscSkorygowana
    = wartość wyliczona na podstawie wilgotności absolutnej
      i temperatury zewnętrznej
```

W kodzie obliczenie korygujące odbywa się po ustaleniu lokalnego RH i temperatury zastępczej/fallbackowej. fileciteturn83file6L14099-L14105

## 161.2. Historia

`historiaZapiszProbke()` zapisuje:

```text
p.wilgotnosc = wilgotnoscOdczytana
```

czyli wartość surową, zgodną z pomiarem źródłowym. fileciteturn83file6L8709-L8716

## 161.3. Status/log

W raportach statusowych firmware używa `wilgotnoscSkorygowana`.

To nie oznacza, że obie wartości są zamienne. Mają różne znaczenia fizyczne:

```text
raw RH
≠
corrected/derived RH
```

## 161.4. Decyzja telemetryczna

Pierwsze pole telemetryczne pozostaje:

```text
rhX10 = wilgotnoscOdczytana × 10
```

Jednostka:

```text
%RH
```

Skorygowana wilgotność NIE zastępuje surowego pomiaru.

Jeżeli później okaże się potrzebne raportowanie obu wartości, dodamy osobne pole, np.:

```text
rh_raw_x10
rh_corrected_x10
```

ale nie będziemy zmieniać znaczenia istniejącego `rh`.

## 161.5. Freshness

`rh` dostaje freshness zgodne z DHT:

```text
lastGoodMs = moment poprawnego read_dht()
```

Nie używamy momentu wyliczenia `wilgotnoscSkorygowana` jako źródła świeżości pomiaru.

## Wniosek R161

Cloud telemetry 1/min opisuje **rzeczywisty pomiar RH**, a nie wtórnie wyliczoną wartość statusową. Surowe RH ma stabilną semantykę seriową; corrected RH pozostaje osobnym, opcjonalnym kanałem pochodnym.

# R162. FRESHNESS METADATA — `hasGoodValue`, NIE `lastGoodMs == 0`

**Data:** 2026-09-24  
**Status:** ZAKOŃCZONE — korekta semantyki stanu początkowego i wrap czasu monotonicznego

## 162.1. Problem z wcześniejszym skrótem

W R154 użyto skrótu:

```text
lastGoodMs == 0 → UNKNOWN
```

To jest niepoprawne jako kontrakt implementacyjny.

`millis()` startuje od wartości bliskiej zeru, więc pierwsza poprawna próbka może legalnie mieć:

```text
lastGoodMs = 0
```

a mimo to kanał ma już poprawną historię.

## 162.2. Poprawiony model

Metadata musi zawierać jawnie:

```cpp
struct SensorFreshness {
    uint32_t lastAttemptMs;
    uint32_t lastGoodMs;
    bool     hasGoodValue;
    uint8_t  status;
};
```

Semantyka:

```text
hasGoodValue == false
    → UNKNOWN albo INVALID

hasGoodValue == true
    → age można liczyć z lastGoodMs
```

## 162.3. `lastAttemptMs` też nie może być markerem istnienia

`lastAttemptMs == 0` nie może oznaczać automatycznie „brak próby”.

Do tego służy osobny stan/status:

```text
NO_ATTEMPT
INVALID
REJECTED
ACCEPTED
SIMULATED
```

Nie opieramy semantyki na „magicznym czasie zero”.

## 162.4. Wrap `millis()`

`uint32_t millis()` zawija się po około 49,7 dnia.

Dla krótkich timeoutów idiom:

```cpp
(uint32_t)(now - then)
```

jest poprawnym wzorcem wrap-safe, ale tylko gdy wiek nie przekracza okresu zawijania.

Dla telemetrycznego `ageS` nie chcemy mieć ukrytego przypadku:

```text
sensor wyłączony przez >49 dni
→ millis() zawija
→ age nagle wygląda na mały
→ FRESH zamiast STALE
```

## 162.5. Decyzja dla age

Do długookresowego wyliczania wieku preferujemy monotoniczny zegar 64-bitowy używany wyłącznie do metadata runtime, np.:

```text
monotonic_ms_64
```

Może być budowany z dostępnego w ESP-IDF zegara monotonicznego zamiast z 32-bitowego `millis()`.

`monoMs` w `TelemetrySample` pozostaje jednak 32-bitowym polem diagnostycznym/porządkowym — jego semantyką nie jest dokładne przechowywanie uptime przez setki dni.

## 162.6. Po co dwa czasy

```text
TelemetrySample.monoMs (uint32_t)
    → lekki timestamp snapshotu / diagnostyka

SensorFreshness internal monotonic_ms_64
    → poprawne age i stale thresholds przez długą pracę
```

Nie ma potrzeby powiększać każdego rekordu telemetrycznego tylko po to, żeby wyeliminować 32-bit wrap z lokalnej diagnostyki.

## 162.7. Co zapisujemy do rekordu

`ageS` pozostaje `uint16_t`:

```text
0..65534  = wiek
65535     = brak zaakceptowanej wartości
```

Przy wieku większym niż 65534 s:

```text
ageS = 65534
```

Nie próbujemy zapisywać dokładnego wieku po kilkunastu godzinach, bo nie jest to potrzebne do decyzji FRESH/STALE.

## Wniosek R162

Stan istnienia historii jest reprezentowany jawnie przez `hasGoodValue`, nie przez zerowy timestamp. Dla obliczania age w długotrwałej pracy nie należy polegać wyłącznie na 32-bitowym `millis()`. Rekord telemetryczny zachowuje lekkie `monoMs`, natomiast metadata runtime może korzystać z rozszerzonego zegara monotonicznego.

# R163. INTEGRATION POINT — `historiaZapiszProbke()` I ATOMICZNY SNAPSHOT CZASU

**Data:** 2026-09-24  
**Status:** ZAKOŃCZONE — wyznaczenie miejsca producenta telemetryki

## 163.1. Aktualna kolejność

`historiaZapiszProbke()` wykonuje obecnie:

```text
historiaBufor check
↓
pobierzCzas()
↓
format etykiety
↓
historiaMux
↓
kopiowanie 14 pól do HistoriaProbka
↓
historiaMux unlock
↓
CSV / historia długa
```

Źródło aktualnego kodu: `pobierzCzas()` jest wykonywane przed sekcją krytyczną, a `HistoriaProbka` jest kopiowana pod `historiaMux`. fileciteturn83file6L8680-L8726

## 163.2. Docelowy punkt telemetryki

Najbezpieczniejsza kolejność:

```text
DateTime now = pobierzCzas()
bool timeTrusted = ...
↓
TelemetrySample sample = zbudujSnapshot(now, timeTrusted)
↓
historiaBufor zapis pod historiaMux
↓
historiaMux unlock
↓
telemetryPush(sample)
↓
reszta istniejącej historii
```

`sample` powstaje jako lokalny obiekt o stałym rozmiarze.

## 163.3. Dlaczego telemetryka nie powinna być „w środku” `historiaMux`

Samo `memcpy` 80 B byłoby szybkie, ale osobny `telemetryMux` oznaczałby drugą blokadę.

Nie chcemy układu:

```text
historiaMux
  ↓
telemetryMux
```

jeżeli konsument lub przyszły kod kiedykolwiek wykona odwrotną kolejność.

Producent najpierw opuszcza `historiaMux`, a dopiero potem publikuje lokalny sample do ringu.

## 163.4. Snapshot czasu

W aktualnej historii `now` jest pobrane raz, ale warunek wiarygodności jest odczytywany ponownie przy zapisie `czas_unix`.

Telemetryka nie powinna kopiować tego wzorca.

Robimy logicznie:

```cpp
DateTime now = pobierzCzas();
bool timeTrusted = g_rtcGotowy || g_rtcNtpZsynchronizowany;
```

a potem używamy wyłącznie:

```text
timeTrusted
now
```

dla danego snapshotu.

W ten sposób rekord nie może mieć kombinacji:

```text
DateTime z chwili A
+
valid flag z chwili B
```

## 163.5. `monoMs`

`monoMs` pobieramy przy tworzeniu snapshotu, a nie dopiero przy Firebase upload.

Dzięki temu:

```text
measurement time
≠
network completion time
```

i retry nie zmienia metadanych pomiaru.

## 163.6. Kolejność sequence

`sampleSeq` powinien zostać przydzielony po zbudowaniu kompletnej próbki, ale przed publikacją:

```text
snapshot
↓
seq++
↓
publish to ring
```

Jeśli publikacja zakończy się `DROP_FULL`, sequence pozostaje zużyty.

## Wniosek R163

`historiaZapiszProbke()` pozostaje naturalnym producentem telemetryki. Budowanie `TelemetrySample` odbywa się przed `historiaMux`, publikacja do ringu po jego zwolnieniu, a `now + timeTrusted + monoMs` są jednorazowym snapshotem jednej chwili. Żaden komponent sieciowy nie dostaje prawa ponownego odczytu globalnego stanu pomiarowego.

# R164. WIRE SCHEMA — `schema` ≠ `firmware version`, ALE OBA SĄ POTRZEBNE

**Data:** 2026-09-24  
**Status:** ZAKOŃCZONE — zamrożenie podstawowego kontraktu JSON

## 164.1. Dwa niezależne identyfikatory wersji

Rekord telemetryczny dostaje:

```text
schema = 1
fw     = aktualny FIRMWARE_VERSION
```

Semantyka:

```text
schema
  → wersja kontraktu danych telemetrycznych

fw
  → wersja kodu urządzenia, który wygenerował rekord
```

Nie wolno używać numeru firmware jako numeru schema.

## 164.2. Dlaczego firmware version powinien być w rekordzie

Telemetria jest historią długoterminową. Firmware będzie się zmieniał, a wraz z nim mogą pojawić się:

```text
nowe pola
zmienione filtry
inne progi jakości
inne jednostki po świadomej migracji schema
```

Jeżeli rekord nie niesie informacji o wersji kodu, późniejsza analiza danych wymagałaby korelowania go z zewnętrznym dziennikiem wdrożeń.

Sam `schema` mówi tylko:

```text
„jak interpretować strukturę rekordu”
```

a `fw`:

```text
„jaki firmware wygenerował tę konkretną obserwację”
```

## 164.3. Kontrakty

Dla V1:

```text
schema = 1
fw = dokładna wartość FIRMWARE_VERSION
```

Wartość `fw` jest ustawiana tylko w producerze z bieżącej stałej, nie z danych przychodzących z sieci.

## 164.4. Pozostałe pola wire

Podstawowy rekord V1:

```text
schema
fw
ts
seq
mono
state
quality
simulated
age
measurements
```

Nie powtarzamy w payloadzie:

```text
sessionNonce
record_id
YYYY/MM/DD
```

ponieważ wynikają z klucza/ścieżki.

## 164.5. `seq` pozostaje mimo występowania w kluczu

`seq` jest redundantny względem `record_id`, ale bardzo użyteczny diagnostycznie:

```text
aplikacja nie musi parsować klucza
→ może bezpośrednio wykrywać dziury w numeracji
```

To ułatwia raportowanie:

```text
seq 100
seq 101
seq 104
```

bez analizy stringa klucza.

## 164.6. `mono`

`mono` pozostaje polem diagnostycznym snapshotu. Jest szczególnie wartościowe dla `unknown`, gdzie `ts=0` nie daje osi absolutnej.

Nie jest źródłem tożsamości rekordu.

## Wniosek R164

Wire V1 będzie samowystarczalny interpretacyjnie:

```text
schema → struktura
fw     → źródło kodu
seq    → numer próbki
```

Identity nadal pozostaje:

```text
sessionNonce + sampleSeq
```

# R165. WIRE PAYLOAD — POMIAR PO ZAMROŻENIU SCHEMATU

**Data:** 2026-09-24  
**Status:** ZAKOŃCZONE — aktualizacja budżetu JSON

## 165.1. Założony rekord

Połączenie decyzji R154 + R164 daje rekord z:

```text
schema
fw
ts
seq
mono
state
quality
simulated
age[11]
7 temperatur
RH
pressure
dym
klapa
syberek
```

Dane są reprezentowane liczbowo w JSON, bez `NaN`, `inf` i bez tekstowych wartości specjalnych.

## 165.2. Pomiar referencyjny

Dla minified JSON, przy typowym zestawie wartości i maksymalnym `seq/mono`, reprezentatywny rekord ma około:

```text
344 B
```

Konserwatywny rekord, przy większych liczbach wieku i maksymalnych wartościach pól, ma około:

```text
387 B
```

Są to rozmiary JSON danych, bez HTTP/TLS oraz bez dodatkowych narzutów biblioteki.

## 165.3. Multi-path key

Dla normalnego shardu:

```text
YYYY/MM/DD/<record_id>
```

przy `record_id` długości 25 znaków ścieżka klucza ma 36 znaków.

W JSON multi-path dochodzi więc około 39 B na wpis (`"key":`).

## 165.4. Szacowany batch

Dla 10 rekordów:

```text
typowy ≈ 10 × (344 + 39) + separatory
       ≈ 3.84 KiB

konserwatywny ≈ 10 × (387 + 39) + separatory
              ≈ 4.27 KiB
```

Dla 20 rekordów:

```text
typowy ≈ 7.68 KiB
konserwatywny ≈ 8.34–8.55 KiB
```

Ostateczna wartość musi zostać zmierzona w rzeczywistym serializerze FirebaseClient, bo biblioteka może dodać własne struktury/narzuty poza samym JSON-em.

## 165.5. Dobowy wolumen

Przy nominalnych 1440 próbkach/dobę:

```text
344 B × 1440 ≈ 495,360 B/dzień
≈ 483.8 KiB/dzień
≈ 14.5 MiB / 30 dni
≈ 181 MiB / rok
```

To nadal jest orientacyjny **payload danych aplikacyjnych**, a nie dokładna prognoza kosztu RTDB.

## 165.6. Decyzja

Nie optymalizujemy teraz schema agresywną kompresją nazw tylko po to, aby zejść poniżej poprzedniego 2.6 KiB/10.

Na tym etapie ważniejsze są:

```text
czytelność
stabilność kontraktu
łatwa diagnostyka
prostota aplikacji
```

Jeżeli testy rzeczywiste pokażą nieproporcjonalny koszt pamięci/CPU, później można rozważyć zwarte tablice lub kodowanie stałoprzecinkowe po stronie wire jako osobny eksperyment.

## Wniosek R165

Aktualny budżet roboczy to:

```text
~344 B/reord typowo
~387 B/reord konserwatywnie
~3.8–4.3 KiB / batch 10
~7.7–8.6 KiB / batch 20
```

Wcześniejszy budżet ~2.6 KiB dla batch=10 zostaje oznaczony jako przestarzały i nie jest już używany do decyzji implementacyjnych.

# R166. FIREBASE TIMEOUT — `inflight` MUSI ŻYĆ DŁUŻEJ NIŻ WYWOŁUJĄCY

**Data:** 2026-09-24  
**Status:** ZAKOŃCZONE — integracja z istniejącym helperem timeoutów

## 166.1. Fakty z aktualnego firmware

Obecny kod posiada globalne wyniki:

```cpp
AsyncResult g_fbSendResult;
AsyncResult g_fbCmdResult;
AsyncResult g_fbDelResult;
```

Komentarz i implementacja wyjaśniają, że `AsyncResult` musi przeżyć poza zakresem funkcji, ponieważ biblioteka/worker może nadal trzymać do niego referencję. fileciteturn83file6L4225-L4235

Analogiczny wzorzec działa w `fbCzekajNaWynikZLimitem()`. fileciteturn83file6L18088-L18093

## 166.2. Konsekwencja dla telemetryki

Telemetria dostaje osobny stan:

```text
telemetryInflight
```

i osobny globalny:

```text
g_fbTelemetryResult
```

Nie współdzielimy `g_fbSendResult` z bieżącym statusem.

## 166.3. Stabilność payloadu

Podczas oczekiwania na zakończenie workera batch nie może zostać nadpisany.

Dlatego roboczy JSON:

```text
telemetryInflightJson
```

musi mieć żywotność co najmniej do momentu:

```text
AsyncResult.isResult()/isError()
worker kończy pracę
fbLoopWorkerZajety() == false
```

Najbezpieczniej przeznaczyć na to stały bufor PSRAM, a nie lokalny `String` na stosie `tgTask`.

## 166.4. Timeout

Przebieg:

```text
ring
 ↓
peek batch
 ↓
build stable JSON
 ↓
g_fbTelemetryResult = reset
 ↓
Firebase update
 ↓
fbCzekajNaWynikZLimitem(...)
```

Jeżeli limit minie:

```text
tail NIE przesuwamy
JSON NIE niszczymy
AsyncResult NIE resetujemy
nowego uploadu NIE enqueueujemy
```

Następna iteracja `tgTask` sprawdza:

```text
fbLoopWorkerZajety()
```

Dopóki jest `true`, telemetryka stoi.

## 166.5. Finalizacja po timeout

Gdy:

```text
fbLoopWorkerZajety() == false
```

dopiero wtedy wolno wykonać:

```text
SUCCESS → telemetryCommit(N)
FAIL    → zostaw N
```

Nie oceniamy sukcesu tylko na podstawie tego, że funkcja czekająca wróciła.

## 166.6. Idempotencja

Jeżeli request został faktycznie zaakceptowany przez Firebase, ale lokalny `tgTask` wyszedł timeoutem, retry zapisze ten sam zestaw:

```text
record_id A
record_id B
...
```

pod tymi samymi ścieżkami.

To jest powód, dla którego deterministic `record_id` jest częścią bezpieczeństwa niezawodności, a nie tylko sposobem adresowania danych.

## 166.7. Rozdzielenie statusu

Telemetryka nie może resetować:

```text
g_fbSendResult
```

gdy status Firebase jest jeszcze aktywny.

Obie operacje są serializowane przez istniejący `tgTask` + worker guard.

## Wniosek R166

W V1 obowiązuje:

```text
1 telemetry request in-flight
1 global AsyncResult dla telemetryki
1 stabilny buffer payloadu aż do finalizacji workera
0 tail commit przed potwierdzeniem
0 reset result/payload podczas porzuconego workera
```

To jest bezpośrednie dopasowanie do istniejącego hardeningu Firebase z v3.11.4.

# R167. IN-FLIGHT BATCH — BUDŻET PAMIĘCI I LIMIT PAYLOADU

**Data:** 2026-09-24  
**Status:** ZAMKNIĘTE JAKO PARAMETR ROBOCZY V1 — wymaga benchmarku na firmware

## 167.1. Aktualny model payloadu

Po R165 konserwatywny szacunek dla batcha 10 wynosi około:

```text
~4.27 KiB payloadu JSON + ścieżki multi-path
```

To nie obejmuje możliwych struktur wewnętrznych FirebaseClient, SSL i HTTP.

## 167.2. Dwa różne limity

Rozróżniamy:

```text
MAX_PAYLOAD_BYTES = 6144 B
JSON_BUFFER_BYTES  = 8192 B
```

Pierwszy jest limitem logicznym serializera: batch ma zostać zakończony przed przekroczeniem 6144 B.

Drugi jest fizycznym buforem roboczym, dzięki czemu serializer ma dodatkowe miejsce na końcowy znak NUL, krótkie różnice długości, zmianę formatowania oraz diagnostykę bez realokacji.

Dla konserwatywnego 4.27 KiB:

```text
6144 - 4372 ≈ 1772 B marginesu
≈ 40.5% ponad szacunek
```

## 167.3. Nie mylić bufora z całkowitym kosztem RAM

Dokumentacja FirebaseClient opisuje asynchroniczne zadania jako przechowujące przygotowane dane HTTP, w tym payload, w kolejce `AsyncClientClass`. citeturn672589search13

Dlatego w stanie `IN_FLIGHT` musimy liczyć co najmniej koncepcyjnie:

```text
TelemetryRing storage
+
JSON working buffer
+
możliwa kopia payloadu w AsyncClient task
+
AsyncResult
+
wewnętrzne struktury biblioteki / TLS
```

Nie zakładamy jeszcze, że kopia ma dokładnie 1:1 rozmiar naszego JSON-u ani że trafi do PSRAM. To musi zostać zmierzone na dokładnej wersji FirebaseClient użytej w buildzie.

## 167.4. Przyrost pamięci telemetryki

Sam ring 1440 × 80 B:

```text
115 200 B = 112.5 KiB
```

Bufor JSON:

```text
8192 B = 8 KiB
```

Zatem stały przyrost storage + roboczy buffer to około:

```text
123 392 B ≈ 120.5 KiB
```

przed doliczeniem mutexów, indeksów, liczników i pamięci użytej przez FirebaseClient/TLS.

Przy 2880 rekordach:

```text
230 400 B + 8192 B = 238 592 B ≈ 233 KiB
```

## 167.5. Zasada alokacji

Duży JSON nie może trafiać przypadkowo na stos `tgTask`.

Docelowo:

```text
PSRAM buffer
    ↓
serializer
    ↓
object_t / AsyncClient
```

Stos `tgTask` pozostaje dla samego kodu taska i ma zachować dotychczasowy high-watermark.

## 167.6. Zasada bezpieczeństwa przy overflow

Jeżeli następny rekord spowodowałby:

```text
serialized_bytes > MAX_PAYLOAD_BYTES
```

to serializer kończy batch przed tym rekordem.

Nie:

```text
realokuj bufor
obetnij JSON
wyślij częściowy rekord
```

Pierwsza próbka, która nie mieści się do aktualnego batcha, zostaje w ring i trafia do następnego requestu.

## 167.7. Benchmark obowiązkowy przed Commit D

Zmierz:

```text
batch 5 / 10 / 20
payload bytes
working-buffer peak
internal DRAM low-watermark
PSRAM low-watermark
AsyncClient taskCount()
czas do sukcesu
czas do timeoutu
```

Szczególnie ważne jest sprawdzenie, czy `object_t` powoduje dodatkową kopię payloadu i gdzie ta kopia jest alokowana.

## Wniosek R167

Parametry robocze V1:

```text
BATCH_MAX_RECORDS   = 10
MAX_PAYLOAD_BYTES   = 6144 B
JSON_BUFFER_BYTES   = 8192 B PSRAM
```

Nie traktujemy ich jeszcze jako wartości wynikających z benchmarku; są konserwatywnym punktem startowym.

# R168. BATCH CROSSING MIDNIGHT — DZIENNE SHARDY BEZ SZTUCZNEGO CIĘCIA

**Data:** 2026-09-24  
**Status:** ZAMKNIĘTE

## 168.1. Problem

Przy próbkowaniu co minutę batch może naturalnie obejmować dwa dni:

```text
23:58
23:59
00:00
00:01
```

Nie chcemy, aby zmiana daty wymuszała osobny mechanizm synchronizacji, reset ringu albo specjalny stan Firebase.

## 168.2. Model ścieżek

Normalny rekord:

```text
/piec/telemetry/1m/v1/YYYY/MM/DD/<record_id>
```

Próbka bez wiarygodnego czasu:

```text
/piec/telemetry/1m/v1/unknown/<record_id>
```

## 168.3. Multi-path batch

Payload batcha powstaje jako mapa:

```text
2026/09/24/<id-A> -> record A
2026/09/24/<id-B> -> record B
2026/09/25/<id-C> -> record C
```

przy czym wszystkie ścieżki są względne względem:

```text
/piec/telemetry/1m/v1
```

Firebase Realtime Database obsługuje wielościeżkowy update/PATCH, więc zmiana dnia nie wymaga osobnego requestu.

Źródło: dokumentacja Firebase Realtime Database / update i struktury danych, wykorzystywana już w R78/R87.

## 168.4. `ts=0` nie blokuje normalnego backlogu

Jeżeli batch zawiera:

```text
A = ts=0
B = ts poprawny
C = ts poprawny
```

to:

```text
unknown/<id-A>
YYYY/MM/DD/<id-B>
YYYY/MM/DD/<id-C>
```

mogą zostać wysłane w jednym multi-path update.

Nie czekamy na NTP, nie przepisujemy `A` do późniejszego dnia i nie blokujemy `B/C`.

## 168.5. Retry

Cały batch jest jednostką logicznego ACK:

```text
SUCCESS
    → commit wszystkich N rekordów

FAIL / TIMEOUT
    → commit 0 rekordów
```

Przy retry wszystkie `record_id` pozostają identyczne.

Jeżeli Firebase wcześniej zastosował część lub całość operacji przed lokalnym timeoutem, ponowny zapis trafia pod te same klucze. Nie powstają nowe rekordy tylko dlatego, że transport zakończył się niejednoznacznie.

## 168.6. Zasada po stronie aplikacji

Repository aplikacji pobiera normalne dane zakresowo po shardach dni:

```text
range 23:00 → 01:00

→ query DD
→ query następny DD
→ merge
→ sort po (ts, seq)
```

Gałąź `unknown` nie należy do normalnego wykresu osi czasu; jest osobnym zbiorem diagnostycznym.

## 168.7. Reguły bezpieczeństwa

Ścieżki identyfikacyjne są celowo ograniczone do:

```text
YYYY
MM
DD
unknown
record_id = [0-9A-F]{16}-[0-9A-F]{8}
```

Nie używamy danych wejściowych użytkownika jako części klucza telemetrycznego.

## Wniosek R168

Nie ma specjalnego „midnight flush”.

Obowiązuje:

```text
ring → batch → multi-path update
             ├─ shard dnia N
             ├─ shard dnia N+1
             └─ unknown
```

Przejście przez północ jest zwykłym przypadkiem batcha, a nie osobną ścieżką wykonania.

# R169. WIRE SCHEMA — STAŁOPRZECINKOWE X10 + KRÓTKIE KLUCZE

**Data:** 2026-09-24  
**Status:** ZAMKNIĘTE — kandydat V1 zamrożony do implementacji

## 169.1. Problem z poprzednią wersją

R165 budował budżet na czytelnych nazwach pól i wartościach float. Przykładowy rekord był rzędu ~327–387 B zależnie od wartości i przyjętych pól.

To działa funkcjonalnie, ale nie daje żadnej korzyści z tego, że firmware przechowuje dane binarnie jako fixed-point.

## 169.2. Nowy format wire

W RTDB zapisujemy liczby stałoprzecinkowe jako JSON integer.

Przykładowe mapowanie:

```text
v      = schema
fw     = firmware version

 ts     = Unix seconds
seq    = sample sequence
mono   = monotonic ms (diagnostic)
s      = stateBits
q      = qualityBits
sim    = simulatedBits
a      = ageS[11]

tz     = t_zewn × 10
 tb     = t_bojler × 10
 to     = t_ogrz × 10
 tos    = t_ogrz_sr × 10
 tr     = t_powrot × 10
 tp     = t_panel × 10
 tpo    = t_pokoj × 10
 tt     = t_trociny × 10
rh     = RH × 10
p      = cisnienie × 10
d      = ADC dymu
kd     = klapa w stopniach
sd     = syberek w stopniach
```

Przykład:

```json
{
  "v":1,
  "fw":"3.11.4",
  "ts":1758711540,
  "seq":42,
  "mono":123456,
  "s":5,
  "q":0,
  "sim":0,
  "a":[0,1,2,3,4,5,6,7,8,9,0],
  "tz":123,
  "tb":587,
  "to":724,
  "tos":701,
  "tr":482,
  "tp":314,
  "tpo":218,
  "tt":652,
  "rh":543,
  "p":10133,
  "d":1234,
  "kd":90,
  "sd":45
}
```

Aplikacja interpretuje `123` w `tz` jako `12.3 °C`, `543` w `rh` jako `54.3%`, itd.

## 169.3. Dlaczego integer zamiast float

Zyskujemy:

```text
brak problemu reprezentacji dziesiętnej float po stronie wire
jednoznaczna rozdzielczość pola
prostsza walidacja Rules
prostszy parser aplikacji
zgodność z binary fixed-point w TelemetrySample
```

Nie jest to kompresja binarna. To po prostu dokładna reprezentacja wartości fizycznych jako integerów.

## 169.4. Rozmiar

Dla typowej próbki:

```text
JSON compact = ~226 B
multi-path key/path = ~39 B
--------------------------------
~265 B / rekord
```

Dla konserwatywnego przypadku pełnych szerokości liczb:

```text
JSON compact = ~304 B
+ path/key    ≈ 39 B
--------------------
~343 B / rekord
```

Batch:

```text
10 rekordów typowo       ≈ 2.65 KiB
10 rekordów konserwatywnie ≈ 3.43 KiB
20 rekordów typowo       ≈ 5.30 KiB
20 rekordów konserwatywnie ≈ 6.86 KiB
```

Wobec R167 oznacza to duży dodatkowy margines względem:

```text
MAX_PAYLOAD_BYTES = 6144 B
```

dla preferowanego batcha 10.

## 169.5. Konsekwencja dla `TelemetrySample`

Binary ABI i wire schema są różne:

```text
TelemetrySample
    └─ fixed binary 80 B

RTDB wire
    └─ compact JSON integers
```

Nie serializujemy pamięci `struct` bezpośrednio do sieci.

## 169.6. Kolejność tablicy `a[]`

`a[]` ma stałą kolejność kontraktową:

```text
0  t_zewn
1  t_bojler
2  t_ogrz
3  t_ogrz_sr
4  t_powrot
5  t_panel
6  t_pokoj
7  t_trociny
8  rh
9  pressure
10 dym
```

To jest kontrakt schema, nie kolejność przypadkowa w pamięci C++.

## 169.7. `q` i `sim`

```text
q   = 22 używane bity jakości zarezerwowane w uint32_t
sim = osobna maska symulacji
```

`sim` nie jest częścią kodu jakości `00/01/10/11`.

## 169.8. Reguły walidacji

Rules mogą bezpośrednio sprawdzać, że pola numeryczne są liczbami i mieszczą się w oczekiwanym zakresie.

Nie walidujemy floatów typu `12.3`, tylko integer `123` z ustaloną rozdzielczością.

## 169.9. Decyzja

W V1 obowiązuje compact fixed-point wire schema.

Długie nazwy pozostają wyłącznie w dokumentacji schema / kodzie aplikacji.

Nie wracamy do payloadu float + verbose keys bez osobnego eksperymentu i uzasadnienia.

## Wniosek R169

Wire V1 jest:

```text
czytelny przez kontrakt schema
jednoznaczny numerycznie
mniejszy od wariantu verbose/float
łatwy do walidacji
zgodny z binary fixed-point
```

To zamyka ostatnią większą decyzję dotyczącą reprezentacji danych przed Commit B/C/D.

# R170. COMMIT A–D — NOWY FREEZE ZAKRESU PO KOREKTACH SCHEMA

**Data:** 2026-09-24  
**Status:** ZAMKNIĘTE — podział zmian przed implementacją

## 170.1. Dlaczego trzeba było przefiltrować wcześniejszy plan

Pierwotny opis Commit A powstał przed zakończeniem audytu:

```text
qualityBits 16 → 32 bit
age           8 → 16 bit
TelemetrySample 64 → 80 B
wire float/verbose → fixed-point/compact
klapa/syberek → stopnie
raw RH → osobny kanał od RH skorygowanej
```

Nie wolno mieszać tych zmian z pierwszym testem sieciowym.

## 170.2. Commit A — DIAGNOSTICS ONLY

A zawiera wyłącznie instrumentację:

```text
internal heap free
internal largest block
internal minimum free
PSRAM free
PSRAM largest block
PSRAM minimum free
stack HWM
Firebase taskCount()
Firebase worker busy
telemetry counters = 0 / placeholder
```

Nie zawiera:

```text
TelemetrySample
TelemetryRing
Firebase telemetry write
new RTDB path
persistent spool
freshness metadata
record identity
```

Cel:

```text
baseline runtime
→ obserwacja 24 h
→ twarde low-watermarki
```

Stack HWM zapisujemy w jednostkach zwracanych przez FreeRTOS oraz ewentualnie przeliczamy przez `sizeof(StackType_t)`, bez założenia stałej wielkości słowa w logice pomiarowej.

## 170.3. Commit B — DATA MODEL ONLY

B zawiera:

```text
TelemetrySample = 80 B
hasGoodValue
lastAttempt/lastGood
qualityBits uint32_t
simulatedBits uint16_t
ageS uint16_t
sessionNonce
sampleSeq
safe stateBits subset
snapshot builder
```

Nie zawiera:

```text
TelemetryRing
Firebase
JSON
LittleFS
```

Zasada B:

```text
global sensor state
    ↓
snapshot
    ↓
TelemetrySample
```

Sample ma być gotowy do testów jednostkowych/HIL bez żadnego transportu.

## 170.4. Commit C — RAM RING ONLY

C zawiera:

```text
SPSC ring w PSRAM
push
peek
commit
rollback
high-watermark
dropped
```

Nie zawiera:

```text
Firebase
JSON
LittleFS
```

PASS C:

```text
producer Core 1
consumer Core 0
brak race
brak nadpisania unread
jawny overflow
brak wpływu na sterowanie
```

## 170.5. Commit D — SINGLE FIREBASE BATCH

D zawiera pierwszy transport:

```text
1 batch
1 AsyncResult
1 inflight
compact fixed-point JSON
multi-path update
```

Nie zawiera jeszcze agresywnego backlog drain ani persistent spool.

ACK:

```text
SUCCESS → commit N
FAIL/TIMEOUT → commit 0
```

Przy timeout:

```text
g_fbTelemetryResult żyje
payload żyje
fbLoopWorkerZajety() blokuje kolejny Firebase
```

## 170.6. Commit E — BACKLOG / ADAPTIVE BATCH

Dopiero po PASS D:

```text
batch=5/10/20 benchmark
MAX_PAYLOAD_BYTES
backlog drain
backoff
queue watermark
cross-midnight soak
```

## 170.7. Commit F/G/H/I

Bez zmian względem wcześniejszego freeze:

```text
F = LittleFS/coredump hardening
G = persistent spool V2
H = security/auth/TLS/Rules
I = library/toolchain upgrade
```

## Wniosek R170

Obowiązuje ścisły eksperymentalny łańcuch:

```text
A diagnostics
   ↓
B data semantics
   ↓
C RAM buffering
   ↓
D one Firebase write
   ↓
E backlog
   ↓
F storage
   ↓
G persistent spool
   ↓
H security
   ↓
I upgrades
```

Każdy etap ma własny build i własny PASS/FAIL.

# R171. QUALITY BITS + AGE — PRECYZYJNA SEMANTYKA KANAŁÓW

**Data:** 2026-09-24  
**Status:** ZAMKNIĘTE

## 171.1. Kodowanie jakości

Każdy kanał dostaje 2 bity:

```text
00 = FRESH
01 = STALE
10 = UNKNOWN
11 = INVALID
```

11 kanałów potrzebuje:

```text
11 × 2 = 22 bity
```

Dlatego:

```cpp
uint32_t qualityBits;
```

jest właściwym rozmiarem.

## 171.2. Przypisanie bitów

Stałe przesunięcia kontraktowe:

```text
bits  0.. 1  t_zewn
bits  2.. 3  t_bojler
bits  4.. 5  t_ogrz
bits  6.. 7  t_ogrz_sr
bits  8.. 9  t_powrot
bits 10..11  t_panel
bits 12..13  t_pokoj
bits 14..15  t_trociny
bits 16..17  rh
bits 18..19  pressure
bits 20..21  dym
bits 22..31  zarezerwowane = 0 w schema=1
```

Nie używamy osobnej `valid_mask`, ponieważ jakość 2-bitowa zawiera już semantykę:

```text
FRESH/STALE/UNKNOWN/INVALID
```

## 171.3. `UNKNOWN`

`UNKNOWN` oznacza:

```text
nie mamy jeszcze żadnej zaakceptowanej wartości
```

albo:

```text
kanał nie został jeszcze skutecznie uruchomiony / zmierzony
```

To jest różne od `INVALID`.

## 171.4. `INVALID`

`INVALID` oznacza:

```text
mamy dowód, że ostatnia próba / dostępna wartość nie jest wiarygodna
oraz nie mamy starszej zaakceptowanej wartości, którą można uczciwie użyć
```

Przykład:

```text
pierwszy odczyt DS18B20 = 85°C power-on-reset
→ INVALID
```

Jeżeli wcześniej był dobry odczyt:

```text
stary dobry odczyt
↓
nowa próba odrzucona
↓
globalna wartość nadal jest używana
```

to telemetryka pokazuje:

```text
STALE
```

nie `INVALID`.

## 171.5. `FRESH`

`FRESH` jest ustawiane tylko wtedy, gdy:

```text
ostatnia zaakceptowana wartość
+ age <= threshold
```

Nie wystarcza:

```text
funkcja czujnika została uruchomiona
```

ani:

```text
globalna wartość nie zmieniła się
```

## 171.6. `STALE`

`STALE` oznacza:

```text
mamy poprawną wartość historyczną
ale jej wiek przekroczył próg świeżości
```

To jest szczególnie ważne dla:

```text
DS18B20 — odrzucony skok
DHT — nieudany read_dht()
BMP280 — NaN
dym — sensor wyłączony / warmup
```

## 171.7. `ageS`

W próbce:

```cpp
uint16_t ageS[11];
```

Kontrakt:

```text
0..65534 = liczba sekund od ostatniego zaakceptowanego pomiaru
65535    = brak zaakceptowanej wartości / wiek nieznany
```

Wartości wieku większe niż 65534 s są nasycane do `65534`.

## 171.8. `hasGoodValue` — nie używać `lastGoodMs == 0`

Stan źródłowy musi zawierać jawne:

```cpp
bool hasGoodValue;
```

Nie wolno stosować:

```cpp
lastGoodMs == 0
```

jako znacznika „brak historii”, ponieważ `millis()` może legalnie zwrócić 0 przy bardzo wczesnej próbce po uruchomieniu.

## 171.9. Korekta dotycząca wrap `millis()`

Nie potrzebujemy 64-bitowego zegara tylko po to, aby liczyć `ageS`.

Dla unsigned `uint32_t` obowiązuje:

```cpp
uint32_t elapsedMs = nowMs - lastGoodMs;
```

i różnica działa poprawnie także przez jedno zawinięcie licznika, o ile rzeczywisty odstęp jest mniejszy niż pełen zakres `uint32_t` ms (~49.7 dnia).

Nasze `ageS` jest ograniczone do:

```text
65534 s ≈ 18.2 h
```

więc warunek jest spełniony z bardzo dużym marginesem.

Zatem metadata może pozostać lekka:

```text
lastGoodMs    = uint32_t
lastAttemptMs = uint32_t
hasGoodValue  = bool
sourceState   = mały enum/bitmask
```

bez wprowadzania `uint64_t` dla każdego kanału.

## 171.10. Simulation semantics

`simulatedBits` jest niezależne od `qualityBits`.

Przykłady:

```text
FRESH + simulated = prawidłowa świeża wartość symulowana
STALE + simulated = nadal używana wartość symulowana, ale stara
FRESH + real      = prawidłowy świeży pomiar fizyczny
```

Po zakończeniu symulacji nie wolno automatycznie uznać ostatniej wartości symulowanej za świeży pomiar fizyczny.

## Wniosek R171

Telemetryka ma odpowiadać na dwa różne pytania:

```text
qualityBits → czy wartość jest świeża/wiarygodna?
simulatedBits → skąd pochodzi używana wartość?
```

`ageS` opisuje wyłącznie wiek ostatniej zaakceptowanej wartości, a `hasGoodValue` rozróżnia „brak historii” od `millis()==0`.

# R172 — monotonic clock: `monoMs` vs `esp_timer_get_time()`

ESP-IDF 5.5 udostępnia `esp_timer_get_time()` jako szybki licznik czasu w mikrosekundach od inicjalizacji ESP Timer, bez blokady związanej z lockiem. Jest to dobry instrument do benchmarków i pomiaru krótkich sekcji krytycznych.

Dla `TelemetrySample` nie ma jednak uzasadnienia zwiększanie pola `monoMs` z 32 bitów do 64 bitów:

- próbka jest nominalnie co ~60 s,
- `ageS` jest ograniczone do 65534 s,
- `uint32_t millis()` daje poprawne odejmowanie przez jedno zawinięcie dla tak krótkich odstępów,
- dodatkowe 4 B/sample zwiększałyby ring bez praktycznej korzyści.

Decyzja:

```cpp
uint32_t monoMs;
```

pozostaje w binarnym rekordzie.

`esp_timer_get_time()` pozostaje narzędziem diagnostycznym do:

- pomiaru czasu snapshotu,
- pomiaru długości critical section,
- pomiaru czasu serializacji,
- pomiaru czasu `fbLoopWork`/requestu,
- benchmarku batch 2/5/10/20.

Nie jest częścią tożsamości rekordu ani osi czasu użytkowej.

Źródło: ESP-IDF 5.5 ESP Timer. 

# R173 — atomowość batcha RTDB i moment przesunięcia `tail`

Firebase Realtime Database `update()` obsługuje wiele ścieżek w jednym zapisie. Dokumentacja Firebase opisuje multi-location update jako operację atomową: wszystkie aktualizacje odnoszą sukces albo wszystkie zawodzą.

To jest istotne dla naszego SPSC ring:

```text
snapshot batchu
      ↓
serializacja
      ↓
jedno RTDB update()
      ↓
SUCCESS ─────────→ tail = batch_end
FAIL/TIMEOUT ────→ tail bez zmian
```

Nie wolno:

- przesuwać `tail` przed potwierdzeniem sukcesu,
- usuwać pojedynczych rekordów z batcha po częściowym błędzie,
- tworzyć osobnego requestu dla każdego rekordu tylko po to, aby łatwiej przesuwać `tail`.

Dzięki `record_id = sessionNonce + sampleSeq` retry całego batcha pozostaje idempotentny: ten sam rekord wskazuje tę samą ścieżkę RTDB.

### Timeout worker-a

Istniejący firmware dopuszcza sytuację, w której caller kończy oczekiwanie przed zakończeniem worker-a. Telemetria musi zachować ten sam model:

```text
caller timeout
    ↓
INFLIGHT nadal istnieje
    ↓
brak drugiego requestu
    ↓
worker kończy
    ↓
ocena AsyncResult
    ↓
SUCCESS → commit tail
FAIL    → retry
```

### Security Rules

`.validate` może wymuszać strukturę, typy i zakresy danych; reguły walidacyjne nie są kaskadowe, więc wszystkie odpowiednie walidacje muszą przejść. Firebase pozwala także użyć `$other` do odrzucenia nieznanych pól. 

Wniosek dla telemetryki:

- firmware ma whitelistę pól,
- RTDB Rules mają whitelistę pól,
- dodatkowo Rules sprawdzają typy i zakresy,
- dopiero potem zapis jest traktowany jako zaakceptowany.

Źródła: Firebase Realtime Database Security Rules oraz dokumentacja `update()`/multi-location updates.

# R174 — lokalne Firebase Security Rules: brak artefaktu, więc brak zgadywania

W aktualnym katalogu projektu nie znaleziono lokalnego pliku zawierającego Firebase Realtime Database Security Rules.

W konsekwencji:

- nie zakładamy, że znamy aktualne produkcyjne `.read` / `.write`,
- nie nadpisujemy istniejących reguł „na ślepo”,
- nie mieszamy migracji auth/TLS z implementacją telemetryki,
- nie traktujemy przykładowych reguł z dokumentacji jako reguł produkcyjnych.

### Kontrakt przyszłych Rules dla telemetryki

Docelowo Rules muszą rozdzielać co najmniej:

```text
/piec/status
/piec/cmd
/piec/telemetry/1m/v1/...
/piec/events/v1/...
```

Telemetryka nie może uzyskać prawa zapisu do:

```text
/piec/cmd
/piec/config
/piec/auth
```

Dla rekordów telemetrycznych Rules powinny wymuszać:

- obecność wymaganych pól,
- poprawne typy,
- zakresy wartości,
- maksymalną długość `fw` i `record_id`,
- poprawny `schema`,
- brak nieznanych pól przez `$other`.

Dodatkowo `.indexOn` powinno odpowiadać faktycznym zapytaniom aplikacji, przede wszystkim po `ts` w dziennych shardach.

### Gate

Wdrożenie Rules jest osobnym zadaniem bezpieczeństwa i nie należy do Commit A.

Przed produkcyjnym uruchomieniem telemetryki wymagane są:

1. eksport rzeczywistych obecnych Rules z Firebase,
2. ustalenie docelowego auth,
3. test Rules w emulatorze/local test harness,
4. dopiero potem deploy.

Firebase zaleca testowanie reguł przed produkcyjnym wdrożeniem, a dokumentacja opisuje `.validate` jako mechanizm walidacji struktury i danych po uzyskaniu prawa zapisu.

# R175 — `FirebaseClient`: własność payloadu i wersja biblioteki

Dokumentacja `FirebaseClient` opisuje `AsyncClientClass` jako kolejkę FIFO zadań. Zadanie przechowuje przygotowane dane HTTP, w tym payload. `Database.update()` przyjmuje `const T&`, a `object_t` jest oficjalnie wspieranym typem JSON dla RTDB.

Wniosek architektoniczny:

- nie zakładamy, że lokalny bufor JSON musi istnieć do końca requestu tylko dlatego, że API jest async,
- po wywołaniu `Database.update<object_t>()` biblioteka powinna mieć własny przygotowany payload zadania,
- mimo tego należy zmierzyć rzeczywisty peak heap w wersji 2.2.9, ponieważ dokumentacja nie daje gwarantowanego stałego kosztu pamięci dla konkretnego payloadu.

### Krytyczna zasada

Nie wolno jednocześnie:

```text
własny duży PSRAM buffer
+
10 rekordów object_t
+
kilka oczekujących Firebase tasks
```

bez pomiaru internal low-watermark.

`AsyncClientClass::taskCount()` należy traktować jako twardy sygnał do odroczenia telemetryki. Aktualne materiały biblioteki podają domyślny limit kolejki ESP32 równy 10 oraz około 1 kB RAM na oczekujące zadanie; nie zwiększamy limitu w telemetryce.

### Wersja

Projekt jest obecnie przypięty do:

```text
FirebaseClient ^2.2.9
```

Nowsze wydania istnieją, ale aktualizacja biblioteki i implementacja telemetryki pozostają rozdzielnymi zmianami. Commit telemetryczny ma więc być testowany na istniejącej wersji.

Źródła: dokumentacja `FirebaseClient` (`AsyncClientClass`, RTDB `update`, `object_t`) oraz materiały autora biblioteki dotyczące `taskCount()` i kosztu oczekujących zadań.

# R176 — rzeczywisty baseline firmware z buildu użytkownika

Z listingu rzeczywistego katalogu:

```text
firmware.bin = 1 852 848 B
firmware.elf = 23 766 148 B
firmware.map = 19 841 948 B
```

Slot aplikacji `app0` i `app1` ma:

```text
3 145 728 B = 3 MiB
```

Zatem:

```text
HEADROOM = 3 145 728 - 1 852 848
         = 1 292 880 B
         ≈ 1.23 MiB

BIN / SLOT = 58.90%
HEADROOM   = 41.10%
```

### Znaczenie

Firmware nie jest obecnie blisko limitu OTA. Jest około 1.23 MiB miejsca na wzrost obrazu aplikacji.

Nie oznacza to jeszcze PASS dla Commit A, ponieważ po zmianie trzeba ponownie zmierzyć:

- `firmware.bin`,
- `.text/.rodata/.data/.bss`,
- IRAM/DRAM,
- PSRAM runtime,
- stack high-water marks.

### Ważne zastrzeżenie

Rozmiar pochodzi z listingu katalogu przekazanego przez użytkownika. Sam plik `firmware.bin` nie został jeszcze udostępniony do ponownego policzenia SHA256 w środowisku analitycznym. Nie traktujemy więc hash/fingerprint jako zweryfikowanego artefaktu audytowego.

To jednak wystarcza do baseline size/headroom.

# R177 — minimalny pakiet artefaktów do zamknięcia baseline

Nie ma potrzeby przekazywania całego `.pio` ani dużego archiwum projektu.

Do pełnego baseline audit potrzebujemy:

1. wygenerowanego `sdkconfig.<env>` — najważniejszy brak,
2. `firmware.bin` — już wiemy, że ma 1 852 848 B,
3. `firmware.elf` — 23 766 148 B,
4. `firmware.map` — 19 841 948 B,
5. opcjonalnie `partitions.bin` — tylko do niezależnej weryfikacji obrazu partycji.

Najważniejszy jest wygenerowany `sdkconfig`, ponieważ `sdkconfig.defaults` nie jest finalnym build truth.

### Minimalne wyszukiwanie PowerShell

Z katalogu projektu:

```powershell
Get-ChildItem .pio -Recurse -Force -File -Filter 'sdkconfig*' -ErrorAction SilentlyContinue |
  Select-Object FullName, Length, LastWriteTime
```

To jest poprawna składnia PowerShell; wcześniejsze:

```text
dir /a /s /b
```

jest składnią CMD, nie PowerShell.

Jeżeli wynik pokaże tylko `sdkconfig.defaults`, nadal nie mamy wygenerowanego finalnego configu.

### Nie trzeba wysyłać

Nie są potrzebne:

- `FrameworkArduino/`,
- biblioteki `.pio/libdeps`,
- cache SCons,
- całe `.pio/build`,
- całe ZIP-y projektu.

To ogranicza transfer do kilku–kilkudziesięciu MB, a dla samego `sdkconfig` jest to plik niewielki.

# R178. PONOWNA WERYFIKACJA SDKCONFIG + ŚRODOWISKO CLI — 24.09.2026

**Status: zakończone — brak wygenerowanego sdkconfig potwierdzony ponownie.**

Użytkownik wykonał pełny zestaw poleceń diagnostycznych w PowerShell z katalogu projektu. Wynik potwierdza:

1. `sdkconfig.defaults` projektu istnieje:
   `C:\Users\bakoma\Documents\PlatformIO\sterownik-co-esp32\sdkconfig.defaults`
2. W całym drzewie projektu znaleziono wiele obcych `sdkconfig.*` należących do przykładów/bibliotek (`.pio\libdeps`, `managed_components`), ale nie znaleziono wygenerowanego configu aplikacji.
3. W `.pio\build\esp32-s3-n16r8` nie znaleziono:
   - `sdkconfig`
   - `sdkconfig.h`
   - `sdkconfig.json`
   - `CMakeCache.txt`
   - `build.ninja`
   - `config.env`
   ani katalogu `.pio\build\esp32-s3-n16r8\config`.
4. Polecenia `pio project config`, `pio run ... -t envdump`, `pio pkg list`, `pio project metadata` nie zostały wykonane, ponieważ bieżący PowerShell zwraca `pio : The term 'pio' is not recognized`. Oznacza to brak `pio` na PATH w tej sesji; nie oznacza to braku PlatformIO ani nie wymaga instalacji/aktualizacji.
5. Root projektu zawiera oczekiwane wejścia: `boards`, `include`, `lib`, `scripts`, `src`, `platformio.ini`, `partitions.csv`, `sdkconfig.defaults`; istnieją również wcześniejsze artefakty i pliki testowe.
6. Build root `esp32-s3-n16r8` zawiera rzeczywiste artefakty baseline:
   - `firmware.bin` 1 852 848 B
   - `firmware.elf` 23 766 148 B
   - `firmware.map` 19 841 948 B
   - `firmware.factory.bin` 1 918 384 B
   - `bootloader.bin` 19 984 B
   - `partitions.bin` 3 072 B
   - `idedata.json` 61 681 B
   - `libFrameworkArduino.a` 3 693 414 B
   - `.sconsign311.dblite` 10 339 920 B
   oraz katalogi framework/library/source.

## Wniosek R178

Nie ma podstaw do ponownego szukania `sdkconfig.defaults`; ten plik jest już potwierdzony. Nadal brakuje wyłącznie **wygenerowanego, finalnego Kconfig tego builda**, a dodatkowo trzeba ustalić, dlaczego `pio` nie jest dostępne z PATH.

### Następny bezpieczny krok

Nie wykonywać `clean`, `build`, `upgrade` ani instalacji. Najpierw znaleźć istniejący executable PlatformIO bez zmiany środowiska:

```powershell
Get-Command pio -All
where.exe pio
Get-ChildItem "$env:USERPROFILE\.platformio\penv\Scripts\pio.exe" -Force -ErrorAction SilentlyContinue |
    Select-Object FullName, Length, LastWriteTime
```

Opcjonalnie, jeśli pierwszy test nic nie znajdzie, można sprawdzić lokalizację instalacji PlatformIO IDE/CLI, ale nadal bez uruchamiania builda. Po znalezieniu `pio.exe` wykonamy `project config`, `envdump`, `pkg list` i `metadata` poprzez **istniejący** executable.

**R178 zamyka ponowną weryfikację lokalizacji sdkconfig i przesuwa problem z „czy szukaliśmy?” na „w jaki sposób ten konkretny build został wykonany i gdzie PlatformIO przechowuje wynik Kconfig?”.**

# R179. ZNALEZIONO ISTNIEJĄCY PLATFORMIO CLI — 24.09.2026

**Status: zakończone — PlatformIO CLI istnieje lokalnie; problemem jest wyłącznie PATH bieżącej sesji PowerShell.**

Użytkownik wykonał:

```powershell
Get-Command pio -All
where.exe pio
Get-ChildItem "$env:USERPROFILE\.platformio\penv\Scripts\pio.exe" -Force -ErrorAction SilentlyContinue |
    Select-Object FullName, Length, LastWriteTime
```

Wynik:

```text
Get-Command pio -> NIEZNALEZIONO
where.exe pio  -> NIEZNALEZIONO

C:\Users\bakoma\.platformio\penv\Scripts\pio.exe
Length: 46080 B
LastWriteTime: 05.09.2026 22:24:12
```

## Wniosek R179

PlatformIO **nie trzeba instalować, aktualizować ani naprawiać**. Istnieje już lokalny executable:

```text
%USERPROFILE%\.platformio\penv\Scripts\pio.exe
```

Bieżąca sesja PowerShell po prostu nie ma tego katalogu w `PATH`.

Nie zmieniamy trwale `PATH` i nie uruchamiamy żadnego builda. Następny krok wykonujemy przez **pełną ścieżkę do istniejącego `pio.exe`**, aby odczytać stan narzędzia i środowiska bez modyfikacji projektu.

### Następny bezpieczny zestaw diagnostyczny

```powershell
$pio = "$env:USERPROFILE\.platformio\penv\Scripts\pio.exe"

& $pio --version
& $pio system info
& $pio project config
& $pio pkg list -e esp32-s3-n16r8
```

Po tych wynikach dopiero zdecydujemy, czy potrzebny jest `envdump`/`metadata` i jak najlepiej ustalić źródło konfiguracji Kconfig. Nie wykonywać `clean`, `build`, `upgrade`, `update` ani instalacji.

# R180. WERYFIKACJA PLATFORMIO CORE I PRÓBA ODCZYTU ENV — 24.09.2026

**Status: CZĘŚCIOWO ZAKOŃCZONE / RESOLUTION BLOCKED**

Użytkownik wykonał bezpieczny zestaw diagnostyczny przez istniejący lokalny executable:

```text
C:\Users\bakoma\.platformio\penv\Scripts\pio.exe
```

## R180.1 — dokładna wersja PlatformIO

```text
PlatformIO Core 6.1.19
Python 3.11.7
system windows_amd64
PlatformIO Core Directory:
  C:\Users\bakoma\.platformio
Python executable:
  C:\Users\bakoma\.platformio\penv\Scripts\python.exe
```

## R180.2 — `pio project config`

Polecenie zadziałało i potwierdziło rzeczywistą konfigurację środowiska `esp32-s3-n16r8`:

```text
platform = pioarduino platform-espressif32 55.03.38 (URL release ZIP)
board = esp32-s3-n16r8
framework = arduino
build_src_filter = +<main_centrala.cpp>
flash_size = 16MB
psram_type = opi
arduino memory_type = qio_opi
partitions = partitions.csv
extra_scripts = pre:scripts/patch_ds18b20.py
```

`build_flags` potwierdzają:

```text
-DBOARD_HAS_PSRAM
-DCORE_DEBUG_LEVEL=1
```

oraz konfigurację monitor/upload speed:

```text
monitor = 115200
upload = 921600
```

`lib_deps` potwierdzają m.in. FirebaseClient `^2.2.9`, AsyncTCP `3.4.10`, ESPAsyncWebServer `^3.10.3`, ArduinoJson `^7.4.3`, RTClib `^2.1.4`, BMP280 `^2.6.8`, Unified Sensor `^1.1.14`, OneWire `^2.3.8` oraz źródło DS18B20 z GitHub.

Środowisko `esp32-s3-ota` dziedziczy z `esp32-s3-n16r8` i używa `espota`; jego hasło uploadowe **nie jest przepisywane do planu**.

## R180.3 — kluczowa obserwacja: `pio pkg list`

Polecenie:

```powershell
& $pio pkg list -e esp32-s3-n16r8
```

**nie zakończyło się normalnym odczytem pakietów**. Zwróciło:

```text
Resolving esp32-s3-n16r8 dependencies...
Error: Failed to install Python dependencies (exit code: 2)
Error: Failed to install Python dependencies into penv
```

To jest ważne rozróżnienie:

```text
PlatformIO Core działa                 = POTWIERDZONE
projektowa konfiguracja jest czytana   = POTWIERDZONE
pełne rozwiązywanie pakietów przez CLI = ZABLOKOWANE przez Python dependencies
```

Nie wolno z tego wyciągać wniosku, że framework/toolchain są nieobecne. Wcześniejszy build rzeczywiście istnieje i zawiera `firmware.bin`, `firmware.elf`, `firmware.map`, `bootloader.bin` itd.

## R180.4 — decyzja

Nie wykonujemy teraz:

```text
pio upgrade
pio pkg update
pip install / uninstall
clean
build
```

Nie naprawiamy środowiska „w ciemno”, ponieważ mogłoby to zmienić reprodukowalność istniejącego baseline'u.

Następny krok ma być **czysto odczytowy**: odczytać lokalne katalogi PlatformIO (`platforms` i `packages`) oraz ich `package.json` / `platform.json`, bez uruchamiania resolvera. Celem jest ustalenie dokładnych zainstalowanych wersji:

```text
platform-espressif32
framework-arduinoespressif32 / Arduino-ESP32
ESP-IDF
xtensa/riscv toolchain
```

oraz sprawdzenie, czy lokalnie istnieje jeszcze artefakt Kconfig poza projektem/buildem.

**R89 nadal pozostaje BLOCKED:** nie znaleziono generated `sdkconfig`, ale nie należy już uruchamiać żadnych operacji, które mogą zmienić środowisko przed zamknięciem tego dochodzenia.

# R181. WERYFIKACJA LOKALNEJ INSTALACJI PLATFORMIO / PIOARDUINO — 24.09.2026

**Status: PLATFORM / FRAMEWORK TOOLCHAIN ZLOKALIZOWANE; GENERATED SDKCONFIG NADAL NIEODNALEZIONY**

Użytkownik wykonał bezpieczny odczyt lokalnej instalacji przez:

```text
C:\Users\bakoma\.platformio\penv\Scripts\pio.exe
```

## R181.1 — PlatformIO Core

Potwierdzono:

```text
PlatformIO Core = 6.1.19
Python = 3.11.7
Python executable = C:\Users\bakoma\.platformio\penv\Scripts\python.exe
PIO Core Directory = C:\Users\bakoma\.platformio
```

## R181.2 — dokładna platforma pioarduino

Lokalny `platform.json` potwierdza:

```text
platform = espressif32
version = 55.03.38
repository = https://github.com/pioarduino/platform-espressif32.git
```

oraz dla Arduino:

```text
framework-arduinoespressif32 = Arduino-ESP32 3.3.8
framework-arduinoespressif32-libs = Arduino-ESP32 3.3.8 libs
```

Dla ESP-IDF:

```text
framework-espidf = ESP-IDF v5.5.4 (pioarduino fork/package)
```

Toolchain:

```text
xtensa-esp-elf package-version = 14.2.0+20260121
riscv32-esp package-version = 14.2.0+20260121
```

Pozostałe narzędzia istotne dla dochodzenia są również lokalnie opisane, m.in.:

```text
tool-cmake = 4.0.3
tool-ninja = 1.13.1
tool-scons = 4.8.1
```

`tool-esptoolpy` jest zadeklarowany jako 5.2.0.

## R181.3 — ważne rozdzielenie stanu

Mamy teraz niezależne potwierdzenie trzech poziomów:

```text
platformio.ini
    ↓
pio project config
    ↓
platform.json lokalnej platformy 55.03.38
```

czyli konfiguracja projektu i rzeczywisty lokalny pakiet platformy są spójne z wcześniejszym baseline:

```text
pioarduino 55.03.38
Arduino-ESP32 3.3.8
ESP-IDF 5.5.4
```

## R181.4 — `pio pkg list` nadal nie jest źródłem pozytywnym

`pio pkg list -e esp32-s3-n16r8` zatrzymuje się na:

```text
Resolving esp32-s3-n16r8 dependencies...
Error: Failed to install Python dependencies (exit code: 2)
```

Dlatego wersje powyżej pochodzą z lokalnego `platform.json`, a nie z udanego resolvera zależności.

## R181.5 — wygenerowany Kconfig nadal nieznaleziony

Po wcześniejszym pełnym wyszukiwaniu projektu nie znaleziono:

```text
sdkconfig
sdkconfig.esp32-s3-n16r8
```

Po bieżącym badaniu wiemy dodatkowo, że nie należy tego tłumaczyć nieobecnością PlatformIO, Arduino-ESP32, ESP-IDF albo toolchainu: lokalne pakiety są zainstalowane i platform.json zawiera ich konkretne wersje.

## R181.6 — decyzja

Nie naprawiać Pythona, nie aktualizować pakietów i nie wykonywać ponownego builda na tym etapie.

Następne dochodzenie powinno być nadal odczytowe i ma ustalić:

1. dokładne ścieżki lokalnych pakietów `framework-arduinoespressif32` i `framework-espidf`;
2. czy w tych pakietach istnieją skrypty / konfiguracje odnoszące się do `sdkconfig`;
3. czy aktualny builder pioarduino dla Arduino generuje pośredni Kconfig w innej lokalizacji niż wcześniej sprawdzona;
4. czy `idedata.json`, `tmp*.rsp` lub metadata SCons ujawniają ścieżkę do wygenerowanej konfiguracji.

Nie zmieniać środowiska przed wykonaniem tych kontroli.

# R182. WERYFIKACJA OBECNOŚCI LOKALNYCH PAKIETÓW — 24.09.2026

**Status: ZAKOŃCZONE — PAKIETY SĄ ZAINSTALOWANE LOKALNIE**

Użytkownik sprawdził bezpośrednio katalog `%USERPROFILE%\.platformio\packages` oraz `%USERPROFILE%\.platformio\platforms`.

Potwierdzono istnienie dokładnie tych katalogów:

```text
C:\Users\bakoma\.platformio\packages\framework-arduinoespressif32
C:\Users\bakoma\.platformio\packages\framework-espidf
C:\Users\bakoma\.platformio\packages\toolchain-xtensa-esp-elf
C:\Users\bakoma\.platformio\platforms\espressif32
```

Daty modyfikacji z lokalnego środowiska:

```text
framework-arduinoespressif32    01.06.2026 09:26:58
framework-espidf                21.07.2026 21:15:04
toolchain-xtensa-esp-elf        01.06.2026 09:25:41
platforms\espressif32           01.06.2026 08:26:58
```

## R182.1 — znaczenie wyniku

To zamyka hipotezę:

```text
„sdkconfig nie ma, bo pakiety ESP32/ESP-IDF nie są zainstalowane”
```

Hipoteza jest odrzucona. Pakiety są fizycznie obecne w `%USERPROFILE%\.platformio\packages`, a lokalna platforma `espressif32` jest obecna w `%USERPROFILE%\.platformio\platforms`.

Nie wynika z tego jeszcze, gdzie znajduje się generated Kconfig ani czy został zachowany po ostatnim buildzie.

## R182.2 — kolejny krok

Nadal **bez build / clean / update** należy teraz prześledzić sam mechanizm buildera pioarduino oraz artefakty konfiguracji. Priorytet:

```text
platform-espressif32/builder/frameworks/arduino.py
platform-espressif32/builder/frameworks/espidf.py
platform-espressif32/builder/*sdkconfig*
framework-espidf/*sdkconfig*
framework-espidf/tools/*sdkconfig*
```

Celem jest ustalenie rzeczywistej ścieżki i nazwy konfiguracji generowanej dla Arduino + ESP-IDF w platformie 55.03.38, bez zmieniania środowiska.


# R183. ŚLEDZENIE MECHANIZMU SDKCONFIG W PLATFORMIE 55.03.38 — 24.09.2026

**Status: CZĘŚCIOWO ZAMKNIĘTE — BRAK PLIKU SDKCONFIG POTWIERDZONY W PAKIETACH; BUILDER WYMAGA DALSZEGO ODCZYTU**

Użytkownik przeszukał bezpośrednio trzy lokalne pakiety:

```text
%USERPROFILE%\\.platformio\\platforms\\espressif32\\builder
%USERPROFILE%\\.platformio\\packages\\framework-arduinoespressif32
%USERPROFILE%\\.platformio\\packages\\framework-espidf
```

### Wynik plikowy

W samym `framework-arduinoespressif32` nie znaleziono plików nazwanych:

```text
sdkconfig
sdkconfig.*
sdkconfig.h
```

W `framework-espidf` również nie znaleziono plików o tych nazwach. Znalezione wcześniej `sdkconfig.defaults` w przykładach bibliotek/komponentów nie są konfiguracją wynikową naszego środowiska.

To jest zgodne z tym, że generated `sdkconfig.<env>` jest artefaktem projektu/builda, a nie czymś, czego należy oczekiwać jako stałego pliku wewnątrz zainstalowanego Arduino-ESP32. Dokumentacja PlatformIO opisuje domyślne generowanie `sdkconfig.<env>` oraz możliwość ustawienia własnej ścieżki przez `board_build.esp-idf.sdkconfig_path`. citeturn969764search7

### Ważne odkrycie w builderze

Wynik `Select-String` pokazuje liczne odwołania do `sdkconfig`/Kconfig w:

```text
platforms\\espressif32\\builder\\frameworks\\arduino.py
platforms\\espressif32\\builder\\frameworks\\espidf.py
platforms\\espressif32\\builder\\frameworks\\arduino_relinker.py
```

Brak pliku nie oznacza więc braku obsługi Kconfig. Builder zawiera logikę, która może ustalać ścieżkę/nazwę konfiguracji, przekazywać ją do CMake/ESP-IDF albo generować konfigurację pośrednio.

### Dodatkowy wynik web research

Niezależne zestawienie wersji pioarduino potwierdza mapowanie:

```text
platform-espressif32 55.03.38
Arduino Core         3.3.8
ESP-IDF              5.5.4
```

co jest spójne z lokalnym `platform.json` i naszym baseline. citeturn969764search0

### Decyzja R183

Nie wykonujemy:

```text
build
clean
update
reinstall
```

Najbliższy krok ma być czysto odczytowy: pobrać **fragmenty źródłowe buildera wokół konkretnych wystąpień `sdkconfig`**, zamiast dalszego przeszukiwania samych nazw plików.

Priorytetowe zakresy wynikające z obecnego `Select-String`:

```text
arduino.py          ~220–340
espidf.py           ~200–330
arduino_relinker.py ~185–205 oraz ~300–330
```

Celem jest ustalenie:

```text
1. czy Arduino builder ustawia sdkconfig_path;
2. z jakiego pliku/zmiennej bierze sdkconfig.defaults;
3. gdzie CMake/ESP-IDF ma szukać wynikowego sdkconfig;
4. czy przy trybie `framework = arduino` generated sdkconfig jest tworzony, ukrywany albo od razu używany bez pozostawienia pliku w root/build;
5. czy `sdkconfig` może być ujawniony przez `idedata.json`, response file lub zmienne SCons.
```

# R184. KLUCZOWE ODKRYCIE — PURE ARDUINO vs HYBRID SDKCONFIG W PIOARDUINO 55.03.38 — 24.09.2026

**Status: ZNACZĄCO ZAWĘŻONO PROBLEM — generated `sdkconfig.<env>` NIE JEST JUŻ JEDYNYM ANI NAJWAŻNIEJSZYM ARTEFAKTEM DO ŚLEDZENIA**

## 1. Co pokazuje lokalny kod buildera

Z odczytanego lokalnie `arduino.py` wynika:

```text
call_compile_libs()
    -> SConscript("espidf.py")
```

oraz w trybie `framework = arduino` builder może uruchomić relinker:

```text
setup_arduino_relinker(...)
```

W `arduino_relinker.py` builder tworzy:

```text
$BUILD_DIR/sdkconfig.arduino
```

i jest to opisane jako minimalny `sdkconfig` używany przez relinker, a nie jako pełny finalny Kconfig ESP-IDF.

## 2. Krytyczne rozróżnienie

W pioarduino 55.03.38 `espidf.py` wyznacza:

```python
SDKCONFIG_PATH = PROJECT_DIR / ("sdkconfig.%s" % PIOENV)
```

jeżeli board nie nadpisuje `build.esp-idf.sdkconfig_path`.

W tym samym builderze CMake dostaje:

```text
-D SDKCONFIG=<SDKCONFIG_PATH>
```

a po wykonaniu CMake builder sprawdza, czy wskazany plik istnieje. Oznacza to, że **jeżeli została wykonana ścieżka ESP-IDF/CMake dla naszego env**, istnienie właściwego `sdkconfig.esp32-s3-n16r8` było oczekiwane przez builder.

Źródło: pioarduino platform-espressif32 55.03.38 `espidf.py`. citeturn488571view0turn440900view0

## 3. Dlaczego wynik użytkownika jest ważny

Rzeczywisty katalog:

```text
.pio\\build\\esp32-s3-n16r8
```

nie zawierał:

```text
sdkconfig.arduino
config\\sdkconfig.json
CMakeCache.txt
build.ninja
```

To jest spójne z hipotezą, że końcowy baseline `firmware.bin` został zbudowany przez zwykłą ścieżkę Arduino/SCons, a nie przez końcowy hybrydowy przebieg ESP-IDF, który zostawiłby strukturę CMake widoczną w katalogu build.

**Nie wolno jednak traktować tej hipotezy jako zamkniętego faktu bez odczytu konkretnych warunków z `arduino.py` i ścieżki `call_compile_libs()`.**

## 4. Bardzo ważne zachowanie `sdkconfig.defaults`

W 55.03.38 funkcja `HandleArduinoIDFsettings()` może nadpisać:

```text
<PROJECT_DIR>\\sdkconfig.defaults
```

na podstawie szablonu Arduino i ustawień board/custom. W naszym env board ma:

```text
BOARD_HAS_PSRAM
qio_opi
16MB
```

więc `has_board_specific_config()` jest prawdziwe.

Builder zapisuje wtedy wynik do **tego samego** `sdkconfig.defaults`, poprzedzając go sumą kontrolną `# TASMOTA__...`.

Źródło: pioarduino 55.03.38 `espidf.py`. citeturn444990view1turn444990view2

Wniosek: plik `sdkconfig.defaults` obecny dziś w katalogu projektu nie może być automatycznie traktowany jako dokładna kopia wejścia użytego przez historyczny build. Trzeba sprawdzić jego pierwszą linię i datę modyfikacji oraz porównać z historią builda.

## 5. Relinker i cleanup

Lokalny `arduino.py` zawiera również:

```text
safe_remove_sdkconfig_files()
```

które usuwa `sdkconfig.<env>` z katalogu projektu podczas określonej ścieżki reinstalacji frameworka.

To jest kolejny powód, dla którego sam brak pliku dziś nie dowodzi, że podczas wcześniejszego builda go nie było.

Źródło: lokalny odczyt `arduino.py` użytkownika; zgodny mechanizm widoczny również w wydaniu 55.03.38. citeturn820270view2

## 6. Aktualna decyzja

Nie generujemy sztucznego `sdkconfig.esp32-s3-n16r8` i nie wykonujemy jeszcze nowego builda.

Najpierw trzeba ustalić z **samego lokalnego kodu 55.03.38**:

```text
A. czy `call_compile_libs()` było uruchamiane dla tego env,
B. jaki warunek ustawia `flag_custom_sdkconfig`,
C. czy zwykły pure-Arduino build tworzy `sdkconfig.arduino` tylko na czas relinkera,
D. czy plik jest usuwany po buildzie,
E. które artefakty CMake powinny pozostać przy rzeczywiście wykonanej ścieżce ESP-IDF,
F. czy `firmware.bin` z 24.09.2026 mógł powstać bez pełnego finalnego `sdkconfig.<env>`.
```

## 7. Następny krok R185

Czysty odczyt trzech fragmentów lokalnego `arduino.py`:

```text
1. `flag_custom_sdkconfig` + `flag_any_custom_sdkconfig` + `call_compile_libs`
2. końcowy fragment `arduino.py` odpowiedzialny za pure-Arduino build
3. dokładna funkcja/akcja usuwająca `sdkconfig.arduino`, jeśli istnieje
```

Dopiero po tym podejmiemy decyzję, czy generated `sdkconfig.<env>` jest rzeczywistym brakującym artefaktem baseline'u, czy tylko artefaktem drugorzędnej ścieżki.

# R185. ANALIZA WARUNKÓW PURE-ARDUINO / HYBRID ORAZ ROLI `sdkconfig.arduino` — 24.09.2026

**Status: CZĘŚCIOWO ZAMKNIĘTE — znamy już warunek wejścia w ESP-IDF/CMake; pozostaje tylko śledzenie samego relinkera i ewentualnego cleanupu**

## 185.1. Najważniejszy wynik z lokalnego `arduino.py`

W odczytanym przez użytkownika `arduino.py` znajdują się następujące elementy:

```python
if config.has_option(current_env_section, "custom_sdkconfig"):
    ...
    flag_custom_sdkconfig = True

if board_sdkconfig:
    flag_custom_sdkconfig = True
```

oraz:

```python
def call_compile_libs():
    print(f"*** Compile Arduino IDF libs for {pioenv} ***")
    SConscript("espidf.py")
```

i:

```python
if flag_custom_sdkconfig and not flag_any_custom_sdkconfig:
    call_compile_libs()
```

Jednocześnie dla konfiguracji:

```text
framework = arduino
```

builder nie ustawia automatycznie `flag_custom_sdkconfig=True` tylko dlatego, że board ma PSRAM/OPI. Funkcja `has_psram_config()` służy do modyfikacji flag kompilacji, gdy `flag_custom_sdkconfig` jest już ustawione; nie jest sama warunkiem wywołania `call_compile_libs()`.

## 185.2. Znaczenie dla tego konkretnego projektu

Z wcześniejszego `pio project config` wynika:

```text
framework = arduino
build_flags = -DBOARD_HAS_PSRAM -DCORE_DEBUG_LEVEL=1
board_build.psram_type = opi
board_build.arduino.memory_type = qio_opi
```

Z board JSON nie wynika ustawienie:

```text
espidf.custom_sdkconfig
```

A `platformio.ini` ma `custom_sdkconfig` zakomentowane.

Na tej podstawie obecny env `esp32-s3-n16r8` nie spełnia znanych z lokalnego buildera warunków uruchomienia:

```text
call_compile_libs() -> espidf.py
```

czyli nie ma podstaw, aby uznawać brak `sdkconfig.esp32-s3-n16r8` za dowód niepełnego zwykłego Arduino builda.

## 185.3. HybridCompile nie jest aktywny tylko z powodu obecności ESP-IDF w board.json

`arduino.py` zawiera dodatkowy warunek:

```python
if "arduino" in current_env_frameworks and "espidf" in current_env_frameworks:
    flag_custom_sdkconfig = False
```

Board JSON deklaruje, że board może pracować zarówno z `arduino`, jak i `espidf`, ale computed project configuration potwierdza, że **ten env** ma tylko:

```text
framework = arduino
```

Zatem deklaracja możliwości boarda nie oznacza użycia hybrid framework przez obecny env.

## 185.4. `sdkconfig.arduino` ma inną rolę

`arduino_relinker.py` tworzy:

```text
$BUILD_DIR/sdkconfig.arduino
```

i sam opisuje go jako:

```text
minimal sdkconfig for Arduino framework
```

służący relinkerowi do warunkowego rozmieszczania funkcji.

To nie jest równoważne:

```text
sdkconfig.<env> = finalny Kconfig ESP-IDF
```

Dlatego brak `sdkconfig.arduino` w istniejącym katalogu build wymaga jeszcze sprawdzenia cyklu życia relinkera: czy plik jest tworzony zawsze, czy może być usuwany/ukrywany po buildzie lub przez późniejszy krok.

## 185.5. Co można już uznać za ustalone

```text
[OK] obecny env = pure Arduino, nie Arduino+ESP-IDF
[OK] custom_sdkconfig jest zakomentowane w platformio.ini
[OK] board JSON nie wskazuje `espidf.custom_sdkconfig`
[OK] `call_compile_libs()` nie wynika z samego BOARD_HAS_PSRAM
[OK] brak `sdkconfig.<env>` nie jest sam przez się dowodem uszkodzonego Arduino builda
[OK] `sdkconfig.arduino` jest artefaktem relinkera, nie pełnym Kconfigiem ESP-IDF
[BLOCKED] dokładny cleanup/lifecycle `sdkconfig.arduino` po relinkerze
```

## 185.6. Decyzja dotycząca R89

Wymóg:

```text
"musimy odnaleźć generated sdkconfig.<env>"
```

nie jest już traktowany jako bezwzględny blocker dla dalszego audytu telemetryki w tym **pure-Arduino** env.

Pozostaje jednak wartość dokumentacyjna ustalenia dokładnej ścieżki relinkera i ewentualnego wygenerowania artefaktu tymczasowego. Nie zmieniamy środowiska i nie generujemy nowego pliku ręcznie.

## 185.7. Następny krok

Czysty odczyt `arduino_relinker.py` wokół funkcji `setup_arduino_relinker()` i późniejszego cleanupu oraz końcowego fragmentu `arduino.py` po linii 479.

Cel:

```text
utworzenie sdkconfig.arduino
        ↓
wykorzystanie przez relinker
        ↓
backup/restore/cleanup
        ↓
czy plik powinien pozostać po zakończeniu builda
```

Dopiero po tym zamkniemy definitywnie pytanie o brak `sdkconfig.arduino` w historycznym buildzie.

# R186. DEFINITYWNE ZAMKNIĘCIE `sdkconfig.arduino` / GENERATED SDKCONFIG DLA PURE-ARDUINO — 24.09.2026

**Status: ZAMKNIĘTE — brak `sdkconfig.*` w historycznym buildzie nie jest błędem ani brakującym artefaktem tego env**

## 186.1. Kluczowy wynik z lokalnego `arduino_relinker.py`

Funkcja:

```python
def setup_arduino_relinker(env, platform, mcu, chip_variant):
```

najpierw pobiera z konfiguracji trzy opcjonalne ustawienia:

```text
custom_relinker_function
custom_relinker_library
custom_relinker_object
```

Następnie buduje listę `relinker_set` i sprawdza kompletność konfiguracji.

Najważniejszy warunek brzmi logicznie:

```python
if not (relinker_function and relinker_library and relinker_object):
    return False
```

Dopiero **po tym warunku** następuje właściwa konfiguracja relinkera, a jeszcze później tworzenie:

```text
$BUILD_DIR/sdkconfig.arduino
```

Wcześniejsze odczytanie `arduino_relinker.py` pokazało, że samo utworzenie `sdkconfig.arduino` odbywa się dopiero w dalszej części funkcji, po przejściu tego gate'u.

## 186.2. Konfiguracja naszego env

Aktualny `platformio.ini` ma:

```text
framework = arduino
```

oraz `custom_sdkconfig` wyraźnie zakomentowane.

W pliku nie ma aktywnej kompletnej trójki:

```text
custom_relinker_function
custom_relinker_library
custom_relinker_object
```

Zatem przy bieżącej konfiguracji:

```text
setup_arduino_relinker()
        ↓
relinker_set niekompletny / pusty
        ↓
return False
        ↓
NIE powstaje sdkconfig.arduino
```

To bezpośrednio wyjaśnia, dlaczego wcześniej przeszukanie `.pio\build\esp32-s3-n16r8` nie znalazło `sdkconfig.arduino`.

## 186.3. Dodatkowe potwierdzenie z `arduino.py`

`arduino.py` wykonuje:

```python
if "arduino" in pioframework and "espidf" not in pioframework:
    from arduino_relinker import setup_arduino_relinker
    setup_arduino_relinker(env, platform, mcu, chip_variant)
```

Czyli funkcja jest wywoływana dla pure-Arduino, ale to **nie oznacza automatycznego włączenia relinkera**. Sam `setup_arduino_relinker()` może prawidłowo zakończyć się `False` przed utworzeniem jakichkolwiek artefaktów relinkera.

## 186.4. Konsekwencja dla generated `sdkconfig.<env>`

Lokalny `espidf.py` pokazuje domyślną ścieżkę:

```text
<PROJECT_DIR>\sdkconfig.<PIOENV>
```

ale jest ona częścią ścieżki buildera ESP-IDF i nie należy jej traktować jako obowiązkowego artefaktu dla naszego **pure-Arduino z prekompilowanym frameworkiem**.

Dla tego projektu mamy jednocześnie:

```text
framework = arduino
custom_sdkconfig = nieaktywne
custom_relinker = nieaktywne
```

oraz rzeczywiście istniejący, wcześniej wykonany build zawierający:

```text
firmware.bin
firmware.elf
firmware.map
firmware.factory.bin
bootloader.bin
partitions.bin
idedata.json
```

Brak:

```text
sdkconfig
sdkconfig.esp32-s3-n16r8
sdkconfig.arduino
```

jest więc zgodny z ustalonym przebiegiem tego env.

## 186.5. Ważna korekta wcześniejszego modelu

Nie utrzymujemy już wymagania:

```text
"przed Commit A musimy zdobyć generated sdkconfig.<env>"
```

Zmieniamy je na:

```text
sdkconfig.<env> = opcjonalny artefakt/provenance dla ścieżki ESP-IDF
sdkconfig.arduino = artefakt tylko aktywnego custom relinkera
sdkconfig.defaults = wejściowy plik projektu, który zachowujemy jako część baseline'u
```

Nie tworzymy sztucznego `sdkconfig`, nie uruchamiamy `menuconfig`, nie przełączamy frameworka na ESP-IDF i nie odblokowujemy `custom_sdkconfig` wyłącznie dla celów dokumentacyjnych.

## 186.6. R89 — zamknięcie

```text
R89 generated sdkconfig            = CLOSED / ARCHIVE GAP
R99 lokalne poszukiwanie            = CLOSED
R100 pełne wyszukiwanie projektu     = CLOSED
R105 Kconfig provenance Arduino     = CLOSED
R183 builder/Kconfig                = CLOSED
R184 pure-Arduino interpretation    = CLOSED
R185 relinker lifecycle              = CLOSED
R186 definitive conclusion           = CLOSED
```

## 186.7. Baseline zamrożony bez sztucznego artefaktu

Za źródło prawdy dla istniejącego firmware przyjmujemy:

```text
platformio.ini
partitions.csv
sdkconfig.defaults
boards/esp32-s3-n16r8.json
src/main_centrala.cpp
scripts/patch_ds18b20.py
firmware.bin
firmware.elf
firmware.map
firmware.factory.bin
bootloader.bin
partitions.bin
idedata.json
```

Nie dopisujemy do tego zestawu pliku, którego historyczny build nie wytwarzał.

## 186.8. Następna decyzja

Gałąź `sdkconfig` jest zamknięta. Nie wykonujemy żadnych kolejnych poleceń dotyczących jego szukania.

Następny krok wraca do właściwego celu audytu telemetryki: przygotowanie **formalnego baseline freeze / Commit A gate**, bez zmian w Firebase, auth, toolchainie ani storage spool.

# R187. FORMALNY GATE PRZED COMMIT A TELEMETRYKI — 24.09.2026

**Status: ZDEFINIOWANY / GATE JESZCZE NIEOTWARTY**

## 187.1. Cel gate'u

Gate A-0 ma odpowiedzieć na jedno pytanie:

> Czy możemy dodać wyłącznie diagnostykę telemetryczną do istniejącego, zamrożonego firmware bez mieszania jej z ringiem, snapshotem, Firebase, storage, security ani zmianą toolchainu?

Commit A pozostaje zgodnie z R104:

```text
heap / largest block / PSRAM metrics
stack high-water mark
Firebase taskCount observation
telemetry diagnostic counters / placeholders
```

Commit A **NIE** może zawierać:

```text
TelemetrySample
freshness / quality implementation
sessionNonce / sampleSeq
TelemetryRing
enqueue/dequeue
Firebase telemetry upload
new Firebase request path
persistent spool
LittleFS telemetry files
auth/TLS/rules changes
FirebaseClient upgrade
pioarduino / Arduino / ESP-IDF upgrade
```

## 187.2. Klasy kryteriów

Gate ma dwie klasy warunków:

```text
HARD GATE  = każdy musi być PASS
SOFT/OBSERVATION = może być UNKNOWN przed startem, ale musi mieć
                   przygotowaną metodę pomiaru i nie może blokować wejścia
                   tylko dlatego, że jest pomiarem wykonywanym po zmianie
```

Żaden warunek HARD nie może pozostać `UNKNOWN`.

## 187.3. HARD GATE — baseline źródłowy

| ID | Kryterium | Stan aktualny | Wymaganie |
|---|---|---|---|
| A0-H1 | źródło firmware | PASS | znany `src/main_centrala.cpp` + zachowany fingerprint baseline |
| A0-H2 | `platformio.ini` | PASS | konfiguracja env zamrożona; brak zmian przed Commit A |
| A0-H3 | board | PASS | `boards/esp32-s3-n16r8.json` znany i zachowany |
| A0-H4 | partycje | PASS | `partitions.csv` znany; app0/app1 po 3 MiB |
| A0-H5 | `sdkconfig.defaults` | PASS | plik wejściowy zachowany; nie traktowany jako generated sdkconfig |
| A0-H6 | generated sdkconfig | PASS / N.A. | R89 zamknięte; dla pure-Arduino nie wymagamy sztucznego artefaktu |
| A0-H7 | build artifacts | PASS | `firmware.bin`, `.elf`, `.map`, `firmware.factory.bin`, `bootloader.bin`, `partitions.bin`, `idedata.json` są dostępne w historycznym buildzie |
| A0-H8 | toolchain provenance | PASS | Core 6.1.19 / pioarduino 55.03.38 / Arduino 3.3.8 / IDF 5.5.4 potwierdzone lokalnie |

## 187.4. HARD GATE — flash / link

Historyczny baseline:

```text
firmware.bin = 1 852 848 B
app slot     = 3 145 728 B
headroom     = 1 292 880 B
udział slotu = 58.90 %
```

Kryteria:

```text
A0-H9  baseline firmware.bin musi mieścić się w app0 i app1
A0-H10 po Commit A wynikowy firmware.bin również musi mieścić się w obu slotach
A0-H11 brak zmiany partitions.csv
```

Dla samego wejścia do Commit A H9/H11 są już `PASS`; H10 jest **EXIT CRITERION** i zostanie zweryfikowane po buildzie A.

## 187.5. HARD GATE — pamięć statyczna

Z MAP baseline:

```text
.dram0.data = 23 919 B
.dram0.bss  = 43 088 B
static DRAM = 67 007 B
.iram0.text = 80 791 B
```

Commit A nie może świadomie dodawać dużych obiektów statycznych.

Formalny budżet wejściowy/wyjściowy A:

```text
A0-H12  brak nowego globalnego bufora > 4 KiB bez osobnej decyzji
A0-H13  brak nowego taska
A0-H14  brak nowego dużego stosu
A0-H15  żadna nowa alokacja PSRAM nie jest wymagana przez Commit A
```

A0-H12..H15 dotyczą zakresu zmiany; sama wartość końcowa musi być potwierdzona w diffie źródłowym i artefaktach builda A.

## 187.6. HARD GATE — architektura runtime

Commit A musi zachować wszystkie istniejące invariants:

```text
A0-H16  brak TelemetryTask
A0-H17  brak drugiego AsyncClientClass
A0-H18  brak drugiego FirebaseApp
A0-H19  brak nowego Firebase requestu telemetrycznego
A0-H20  brak zmian w częstotliwości / kolejności status i cmd
A0-H21  brak zmian w schedulerze sterowania
A0-H22  brak zmian w logice pomp/serw
A0-H23  brak zapisu telemetryki na LittleFS
A0-H24  brak zmian OTA
```

## 187.7. HARD GATE — diagnostyka musi być pasywna

Każdy nowy pomiar dodany w A musi spełniać:

```text
A0-H25  tylko odczyt stanu / liczników
A0-H26  brak blokowania I/O sterowania
A0-H27  brak sieciowego I/O z nowego kodu
A0-H28  brak String/JSON w hot path tylko dla samej diagnostyki
A0-H29  brak critical section obejmującej I/O, String, JSON lub długą pracę
A0-H30  brak ręcznego resetowania liczników w sposób wpływający na automatykę
```

## 187.8. HARD GATE — reprodukowalność pomiaru

Przed zmianą A trzeba mieć możliwość wykonania identycznego odczytu baseline:

```text
A0-H31  free internal heap
A0-H32  largest internal heap block
A0-H33  minimum-ever internal heap
A0-H34  free PSRAM
A0-H35  largest PSRAM block
A0-H36  minimum-ever PSRAM
A0-H37  stack high-water dla wszystkich tasków istotnych dla sterowania/Firebase
A0-H38  Firebase AsyncClient taskCount()
A0-H39  liczba restartów/WDT z okresu testu
A0-H40  obserwacja status/cmd/scheduler timing
```

Sam fakt, że A ma dodać część tych pomiarów, nie wymaga ich implementowania przed A. Wymagane jest natomiast zachowanie **metody baseline → A → porównanie**.

## 187.9. HARD GATE — bezpieczeństwo eksperymentu

```text
A0-H41  brak zmian auth/TLS
A0-H42  brak zmian Firebase Rules
A0-H43  brak publikowania logów do cloud
A0-H44  brak nowych sekretów/tokens
A0-H45  brak zmiany sposobu zapisu historii
A0-H46  brak zmiany zarządzania coredumpem
```

## 187.10. Warunki OBSERVATION przed wejściem

Poniższe informacje są już częściowo znane, ale nie muszą blokować wejścia, o ile zostaną zmierzone w ramach testu A:

```text
A0-O1  bieżący runtime internal heap
A0-O2  bieżący runtime PSRAM heap
A0-O3  stack HWM
A0-O4  taskCount Firebase w normalnej pracy
A0-O5  dokładny wpływ diagnostyki na scheduler
A0-O6  delta firmware.bin / ELF
```

Nie wolno jednak zamienić `UNKNOWN` w „PASS” bez późniejszego pomiaru.

## 187.11. Formalne kryteria EXIT z Commit A

Commit A może zostać uznany za zakończony tylko wtedy, gdy po buildzie/testach:

```text
E-A1   firmware builds successfully
E-A2   firmware fits app0/app1
E-A3   0 nowych WDT/restartów przypisanych zmianie
E-A4   brak heap allocation failure
E-A5   brak naruszenia stack safety
E-A6   brak nowego taska i brak drugiego Firebase client/app
E-A7   0 nowych zapisów RTDB z telemetryki
E-A8   0 nowych plików telemetrycznych LittleFS
E-A9   status/cmd/scheduler zachowują dotychczasową funkcję
E-A10  zmiana pamięci i rozmiaru firmware jest znana i wyjaśniona
E-A11  wszystkie nowe liczniki diagnostyczne są monotoniczne lub mają
       jawnie udokumentowaną semantykę resetu
E-A12  rollback do baseline jest możliwy bez migracji danych
```

## 187.12. Kryterium STOP / RED

Pracę zatrzymujemy natychmiast, jeżeli po Commit A wystąpi choć jeden z poniższych i nie ma jednoznacznego wyjaśnienia:

```text
STOP-1  WDT / reset / panic
STOP-2  spadek internal minimum heap wskazujący na niekontrolowaną alokację
STOP-3  fragmentacja largest-free-block wpływająca na istniejące działanie
STOP-4  stack overflow / istotne zmniejszenie marginesu stosu
STOP-5  zmiana timingu sterowania
STOP-6  zmiana zachowania Firebase status/cmd
STOP-7  nowy request RTDB
STOP-8  zapis/rotacja LittleFS wywołana telemetryką A
STOP-9  zmiana partycji lub OTA
STOP-10 różnica binary/source, której nie potrafimy przypisać do zakresu A
```

## 187.13. Decyzja gate'u na teraz

```text
SOURCE / CONFIG FREEZE       = PASS
BUILD ARTIFACT BASELINE      = PASS
FLASH HEADROOM                = PASS
TOOLCHAIN PROVENANCE          = PASS
SDKCONFIG PROVENANCE           = PASS / CLOSED AS N.A.
RUNTIME BASELINE MEASUREMENT   = NOT YET CAPTURED
COMMIT A SCOPE FREEZE          = PASS

GATE A-0 = YELLOW / NOT OPENED
```

Powód jedynego istotnego braku przed rozpoczęciem kodowania:

```text
nie mamy jeszcze zapisanej, powtarzalnej sesji runtime baseline
dla pamięci / stack HWM / taskCount / scheduler timing,
która będzie punktem odniesienia po Commit A.
```

Nie wymaga to kolejnego builda baseline i nie wymaga naprawiania PlatformIO. To **osobny pomiar na istniejącym firmware**.

## 187.14. Następny krok

```text
R188 — wykonać runtime baseline snapshot na istniejącym firmware,
       bez zmian kodu:

       internal heap:
       PSRAM:
       stack HWM:
       Firebase taskCount:
       WDT/restarts:
       scheduler/status/cmd timing
              ↓
       zapisać wynik
              ↓
       GATE A-0 -> GREEN
              ↓
       dopiero wtedy Commit A
```


# R188. FORMALNY PROTOKÓŁ RUNTIME BASELINE — PRZED COMMIT A — 24.09.2026

**Status:** ZDEFINIOWANE — protokół gotowy do wykonania na istniejącym firmware, bez zmian kodu.

## 188.1. Cel

R188 ma stworzyć **powtarzalny punkt odniesienia** dla obecnego firmware `v3.11.4`, który później pozwoli porównać Commit A z baseline bez mieszania regresji telemetrycznych z już istniejącymi zachowaniami systemu.

Protokół nie jest testem fault-injection i nie jest testem telemetryki. Podczas R188 nie dodajemy kodu, nie zmieniamy konfiguracji i nie wymuszamy awarii.

## 188.2. Warunek wstępny — stan badanego artefaktu

Badany firmware musi być tym samym baseline'em, dla którego mamy:

```text
env                  = esp32-s3-n16r8
platform             = pioarduino 55.03.38
Arduino-ESP32        = 3.3.8
ESP-IDF              = 5.5.4
FIRMWARE_VERSION     = v3.11.4
partitions.csv       = baseline, bez zmian
```

Przed startem zapisujemy do protokołu:

```text
R188_SESSION_ID
wall_clock_start
firmware_version
firmware.bin SHA-256 (jeżeli dostępny z zachowanego artefaktu)
board/env
WiFi konfiguracja: ON/OFF
Firebase: oczekiwane ON/OFF
Telegram: oczekiwane ON/OFF
TRYB_BEZ_SPRZETU / symulacja: ON/OFF
```

Nie zmieniamy tych ustawień w trakcie obserwacji.

## 188.3. Zasada prowadzenia testu

Test ma odzwierciedlać **normalną pracę produkcyjną**:

```text
bez celowego restartu
bez OTA
bez /restart
bez /testcrash
bez celowego odłączania WiFi/WAN
bez ręcznego wywoływania alarmów
bez komend sterujących pompą/serwem
bez uploadu plików
bez czyszczenia historii/logów
bez zmiany ustawień
```

Normalne zdarzenia procesu, np. rzeczywista praca pompy, serwa, alarm dymu czy naturalna zmiana pogody, nie są same w sobie błędem testu. W raporcie są oznaczane jako **zdarzenie domenowe**, a nie runtime fault.

## 188.4. Kolejność wykonania

### Faza P0 — przygotowanie, 0 min

1. Uruchomić przechwytywanie całego portu szeregowego.
2. Ustawić `115200` baud zgodnie z `platformio.ini`.
3. Zapisać wall-clock `T0` na komputerze.
4. Wykonać jeden świeży restart urządzenia **tylko jako początek sesji baseline**.
5. Od początku restartu zachować cały output Serial — bez filtrowania.
6. Nie wysyłać żadnych komend po starcie.

### Faza P1 — boot / stabilizacja, 0–15 min

Celem jest uchwycenie kosztu startu i stabilizacji po inicjalizacji:

```text
BOOT
FB-INIT / FB-SEND / FB-CMD
TG / TG-POLL, jeżeli Telegram jest aktywny
LOGI-FS
SENSOR
HEALTH
ALARM / OTA / COREDUMP / RESET, jeśli wystąpią
```

W szczególności zachowujemy pierwsze `tag=HEALTH`. Firmware emituje heartbeat `HEALTH` co około 30 s i zapisuje w nim `heap`, `largest`, stan Telegrama, WiFi i Firebase. fileciteturn136file3L1-L8

### Faza P2 — normalny baseline, 15 min–24 h

**Wymagany czas obserwacji: 24 godziny od T0.**

Powód: jedna doba obejmuje wielokrotne cykle obecnych mechanizmów okresowych i eliminuje ryzyko, że baseline przypadkiem obejmie tylko krótki spokojny fragment pracy.

W istniejącym kodzie Firebase ma okres około:

```text
status = 15 s
cmd    = 7 s
```

co przy idealnym braku opóźnień odpowiada odpowiednio około:

```text
5 760 prób status/dobę
12 343 prób cmd/dobę
```

Są to **wartości teoretyczne wynikające z interwałów**, a nie wymagane liczby logów; rzeczywisty wykonany cykl może być opóźniony przez istniejące warunki runtime. fileciteturn136file3L1-L8

### Faza P3 — zamknięcie, T=24 h

1. Zatrzymać przechwytywanie Serial dopiero po zapisaniu ostatniego pełnego wiersza.
2. Zapisać wall-clock `T1`.
3. Nie restartować urządzenia przed zapisaniem logu końcowego.
4. Zachować kopię bieżących plików diagnostycznych/logów, jeżeli są dostępne przez istniejący mechanizm projektu.

## 188.5. Wymagane dane wejściowe do raportu

### A. Twardy identyfikator sesji

```text
session_id
T0
T1
uptime_start
uptime_end
firmware_version
firmware.bin_sha256
```

### B. Stan pamięci dostępny już bez Commit A

Obecny firmware loguje co około 30 s:

```text
heap     = ESP.getFreeHeap()
largest  = heap_caps_get_largest_free_block(MALLOC_CAP_8BIT)
```

w `tag=HEALTH`. fileciteturn21475file0L1-L15

Z tych linii wyciągamy:

```text
first_seen_heap
last_seen_heap
min_observed_heap
max_observed_heap
first_seen_largest
last_seen_largest
min_observed_largest
max_observed_largest
count_HEALTH
```

**Uwaga:** `min_observed_*` oznacza minimum zaobserwowane w istniejącym `HEALTH`, nie `minimum-ever` z całego heap allocatora.

### C. PSRAM

Przed Commit A nie zakładamy istnienia liczbowego baseline PSRAM, jeżeli obecny firmware nie publikuje tego pola. W takim przypadku zapisujemy jawnie:

```text
psram_free = N/A_PRE_A
psram_largest = N/A_PRE_A
psram_minimum_ever = N/A_PRE_A
```

Nie wolno rekonstruować tych wartości z rozmiaru 8 MB, wielkości buforów ani z `sdkconfig.defaults`.

### D. Stack HWM

Obecny firmware posiada diagnostykę checkpointów per-task i zapisuje HWM bieżącego tasku do struktury diagnostycznej, ale R188 nie może przedstawiać nieodczytanej wartości jako pomiaru końcowego.

Jeżeli nie ma istniejącego kanału eksportu HWM dla wszystkich istotnych tasków, raport zawiera:

```text
stack_HWM = N/A_PRE_A_EXPORT
```

oraz listę tasków objętych późniejszą instrumentacją Commit A.

### E. Firebase AsyncClient taskCount

W obecnym `main_centrala.cpp` nie znaleziono bezpośredniego odczytu `taskCount()`. Dlatego przed Commit A **nie wpisujemy żadnej liczby wymyślonej ani odzyskanej z pośrednich logów**:

```text
firebase_taskCount = N/A_PRE_A_INSTRUMENTATION
```

Commit A ma dopiero dodać pasywną obserwację tego parametru.

### F. Restart/WDT/PANIC

Raportujemy wszystkie wystąpienia:

```text
tag=BOOT
tag=COREDUMP
tag=ALARM
TASK_WDT
INT_WDT
WDT
Guru Meditation
panic
abort
stack smashing
heap allocation failure
brownout/reset
```

`tag=BOOT` po T0, którego nie da się przypisać do pierwszego kontrolowanego startu sesji, jest zdarzeniem **HARD FAIL**.

Firmware ma już trwałą diagnostykę per-task i zapis hooka TWDT w RTC_NOINIT, więc przy nieoczekiwanym restarcie należy zachować również raport/coredump zamiast kontynuować zwykłą sesję. fileciteturn139file4L1-L8

## 188.6. Wymagane logi

### Obowiązkowe

```text
1. pełny surowy Serial od T0 do T1
2. wszystkie tag=HEALTH
3. wszystkie tag=BOOT
4. wszystkie wpisy WARN/ERR/CRIT
5. wszystkie wpisy FB / TG / DNS / WIFI związane z błędami
6. wszystkie wpisy OTA / COREDUMP / RESET
```

### Wymagane przy FAIL

```text
log_krytyczny.txt
najbliższe wpisy log_a.txt / log_b.txt
raport crash RTC
coredump, jeżeli powstał i jest dostępny
pełny fragment Serial obejmujący zdarzenie i restart
```

Nie wysyłamy tych plików dodatkowym ruchem sieciowym podczas samego testu tylko po to, aby je „mieć w chmurze”. R188 jest lokalnym baseline.

## 188.7. Analiza `HEALTH`

Ponieważ `HEALTH` istnieje już w firmware i jest emitowany co 30 s, zapisujemy wszystkie wiersze zamiast robić ręczne próbki. fileciteturn21475file0L1-L15

Dla każdej sesji wyliczamy:

```text
N_HEALTH
T_first_HEALTH
T_last_HEALTH
heap_first
heap_last
heap_min_observed
heap_max_observed
largest_first
largest_last
largest_min_observed
largest_max_observed
```

Dodatkowo sprawdzamy trend:

```text
first 10 HEALTH samples
middle 10 HEALTH samples
last 10 HEALTH samples
```

W R188 nie ustanawiamy sztucznego progu typu „X KB = PASS”, jeżeli obecny firmware nie ma takiego kontraktu. Zamiast tego wykrywamy **niewyjaśnioną degradację** względem baseline. Twarde limity dla przyszłej telemetryki zostaną wyprowadzone po uzyskaniu rzeczywistego runtime baseline, a nie odwrotnie.

## 188.8. Kryteria PASS

### HARD PASS

Wszystkie poniższe muszą być spełnione:

```text
P-H1  sesja trwa pełne 24 h albo ma jawnie oznaczoną przyczynę skrócenia
P-H2  brak nieplanowanego restartu
P-H3  brak TASK_WDT / INT_WDT / PANIC
P-H4  brak nowego coredumpu powstałego podczas sesji
P-H5  brak heap allocation failure
P-H6  brak stack overflow / stack canary failure
P-H7  brak OTA/restartu aktualizacyjnego
P-H8  brak ręcznej ingerencji zmieniającej automatykę
P-H9  pełny Serial od T0 do T1 zachowany
P-H10 dane `HEALTH` są wystarczające do odtworzenia przebiegu pamięci ogólnego heapu
```

### SOFT PASS / OBSERVATION PASS

```text
P-S1  ewentualne FB/TG/DNS WARN/ERR są opisane i rozdzielone na:
      - problem chwilowy sieci,
      - problem aplikacji,
      - runtime fault
P-S2  brak trwałego, niewyjaśnionego spadku heap/largest block
P-S3  brak obserwowalnej zmiany zachowania status/cmd/scheduler
P-S4  normalne alarmy domenowe nie są błędnie zaklasyfikowane jako fault
```

## 188.9. Kryteria FAIL / RED

R188 jest **FAIL**, jeżeli wystąpi którekolwiek z poniższych:

```text
F1  nieplanowany restart
F2  TASK_WDT / INT_WDT / panic / Guru Meditation / abort
F3  stack corruption / stack canary / heap corruption
F4  coredump po zdarzeniu runtime
F5  niekontrolowana utrata logu uniemożliwiająca analizę przyczyny
F6  jawna, niewyjaśniona degradacja pamięci istniejącego firmware
F7  jawna zmiana zachowania sterowania podczas sesji
F8  ręczna ingerencja unieważniająca charakter „normal operation”
```

Pojedynczy przejściowy błąd sieciowy **nie jest automatycznie FAIL**. Musi być sklasyfikowany na podstawie tego, czy doprowadził do runtime fault. Jest to istotne, ponieważ obecny firmware ma już własne timeouty/circuit breakery dla Firebase/Telegrama i błędy sieciowe są odrębną klasą zdarzeń.

## 188.10. Co robimy po FAIL

Natychmiast:

```text
1. NIE restartować urządzenia ręcznie.
2. Zachować pełny Serial.
3. Zachować czas wall-clock zdarzenia.
4. Zachować ostatnie ~100–200 linii przed faultem.
5. Zachować pierwszy fragment po restarcie, jeśli restart nastąpił.
6. Zachować raport RTC/coredump, jeżeli istnieje.
7. Nie rozpoczynać Commit A.
```

Najpierw robimy analizę root-cause. R188 po jednym nieplanowanym WDT/reset nie przechodzi automatycznie tylko dlatego, że późniejsze 23 h były spokojne.

## 188.11. Format pliku wynikowego

Jeden plik tekstowy na sesję:

```text
R188_RESULT.md
```

Format:

```text
# R188 Runtime Baseline Result

session_id: R188-YYYYMMDD-HHMM
start_wall: YYYY-MM-DD HH:MM:SS TZ
end_wall: YYYY-MM-DD HH:MM:SS TZ
duration_s: ...
firmware_version: v3.11.4
firmware_bin_sha256: ...
env: esp32-s3-n16r8
platform: pioarduino 55.03.38
arduino_esp32: 3.3.8
esp_idf: 5.5.4

[ENV]
wifi: ON/OFF
firebase: ON/OFF
telegram: ON/OFF
simulation: ON/OFF

[HEALTH]
count: ...
heap_first_B: ...
heap_last_B: ...
heap_min_observed_B: ...
heap_max_observed_B: ...
largest_first_B: ...
largest_last_B: ...
largest_min_observed_B: ...
largest_max_observed_B: ...

[PRE_A_UNAVAILABLE]
psram_free: N/A_PRE_A
psram_largest: N/A_PRE_A
psram_minimum_ever: N/A_PRE_A
stack_hwm_export: N/A_PRE_A_EXPORT
firebase_taskCount: N/A_PRE_A_INSTRUMENTATION

[RESTARTS]
unexpected: 0/...
wdt: 0/...
panic: 0/...
coredump_created: 0/...

[NETWORK]
fb_warn: ...
fb_err: ...
tg_warn: ...
tg_err: ...
dns_warn: ...
dns_err: ...

[DOMAIN]
alarms: ...
ot a runtime fault: ...
manual_interventions: ...

[DECISION]
HARD_PASS: PASS/FAIL
OBSERVATION_PASS: PASS/FAIL
R188: PASS/FAIL
reason: ...
```

## 188.12. Format tabeli surowych próbek

Jeżeli z `HEALTH` powstaje CSV analityczny, stosujemy:

```text
t_wall,uptime_s,heap_free_B,heap_largest_B,tg_enabled,wifi_connected,fb_ready
```

Bez zaokrąglania wartości pamięci.

## 188.13. Kryterium przejścia do Gate A-0 GREEN

Gate A-0 otrzymuje `GREEN`, jeżeli:

```text
R188 HARD_PASS       = PASS
R188 OBSERVATION     = PASS
pełny Serial         = zachowany
wynik zapisany       = tak
brak niewyjaśnionego fault = tak
zakres Commit A      = nadal zamrożony
```

Pola oznaczone `N/A_PRE_A_*` **nie są liczone jako porażka**, pod warunkiem że ich brak jest jawnie udokumentowany jako brak kanału pomiarowego obecnego firmware i zostają wpisane do zakresu instrumentacji Commit A.

## 188.14. Najważniejsza korekta względem wcześniejszej definicji gate'u

Wcześniejsze brzmienie wymagało liczbowego baseline dla `PSRAM`, `stack HWM` i `Firebase taskCount`, ale aktualny audyt źródła pokazał, że nie wszystkie te dane są obecnie eksportowane w prosty sposób. Nie będziemy więc tworzyć fałszywego „baseline” z danych nieobserwowalnych.

Formalna zasada R188 brzmi:

```text
OBSERVED      -> mierzymy i zapisujemy
NOT EXPOSED   -> jawne N/A_PRE_A_* + instrumentacja w Commit A
NEVER         -> nie zgadujemy
```

## 188.15. Decyzja końcowa R188

```text
PROTOKÓŁ R188 = GOTOWY DO WYKONANIA
FIRMWARE CHANGE = NIE
BUILD CHANGE    = NIE
NETWORK FAULT INJECTION = NIE
OBSERVATION WINDOW = 24 h
PRIMARY EVIDENCE = pełny Serial + HEALTH
FAILURE EVIDENCE = Serial + RTC/coredump/logs
```

Dopiero po wykonaniu tego protokołu aktualizujemy:

```text
GATE A-0 = GREEN / RED
```

i dopiero `GREEN` otwiera **Commit A — diagnostics only**.

# R189. SZABLON WYNIKU R188 + ZASADA EVIDENCE PACKAGE

**Status: gotowe do użycia**

## Cel

Po zdefiniowaniu protokołu R188 potrzebny jest stały artefakt wyniku, aby dwie sesje baseline można było porównywać bez zmiany terminologii i bez mieszania obserwacji z wartościami niedostępnymi przed Commit A.

## Artefakt

Dodano plik:

```text
/mnt/data/R188_RESULT_TEMPLATE.md
```

Szablon zawiera osobne sekcje:

```text
[IDENTITY]
[ENV]
[HEALTH]
[PRE_A_UNAVAILABLE]
[RESTARTS]
[NETWORK]
[DOMAIN]
[LOG_EVIDENCE]
[FAIL_EVIDENCE]
[DECISION]
[RAW_SAMPLE_FORMAT]
[NOTES]
```

## Zasada evidence package

Wynik R188 nie jest tylko liczbą `PASS/FAIL`. Minimalny pakiet dowodowy sesji to:

```text
R188_RESULT.md
Serial raw capture
HEALTH extract / CSV
+ przy FAIL:
  log_krytyczny
  RTC crash report
  coredump, jeżeli istnieje
  fragment Serial przed i po zdarzeniu
```

## Niezmienna zasada obserwacji

```text
OBSERVED      -> wartość zmierzona
N/A_PRE_A_*   -> kanał niedostępny przed Commit A
NEVER         -> nie rekonstruować i nie zgadywać
```

## Ważna korekta techniczna

`HEALTH` w obecnym firmware raportuje ogólny `ESP.getFreeHeap()` oraz `heap_caps_get_largest_free_block(MALLOC_CAP_8BIT)` co ~30 s; to jest jedyny gotowy, ciągły kanał pamięci używany w R188. Nie wolno na jego podstawie nazywać wyniku `minimum-ever heap`.

Stack HWM jest zapisywany w bieżącym checkpointcie diagnostycznym, ale przed Commit A nie mamy jednolitego eksportu końcowego dla wszystkich istotnych tasków; dlatego szablon pozostawia to jako `N/A_PRE_A_EXPORT`.

Firebase `taskCount()` nie ma bezpośredniego odczytu w obecnym `main_centrala.cpp`; szablon oznacza go `N/A_PRE_A_INSTRUMENTATION`.

## Gate interaction

Po zakończeniu sesji:

```text
HARD_PASS = PASS
AND
OBSERVATION_PASS = PASS
AND
pełny materiał dowodowy zachowany
AND
brak niewyjaśnionego fault
    => Gate A-0 = GREEN
```

Każdy nieplanowany restart/WDT/PANIC/coredump/korupcja heapu lub stosu powoduje `R188 = FAIL` i blokuje Commit A do czasu analizy root-cause.

# R190. PROCEDURA WYKONANIA BASELINE R188 NA WINDOWS + ESP32-S3

**Status: GOTOWE DO WYKONANIA — brak zmian firmware**

## Cel

R190 zamienia abstrakcyjny protokół R188 na powtarzalną procedurę wykonawczą na komputerze Windows z obecnym projektem PlatformIO i ESP32-S3-N16R8. Zakres nadal pozostaje diagnostyczny: zero zmian kodu, zero nowej telemetrii, zero zmian auth/TLS, zero zmian biblioteki FirebaseClient, zero zmian toolchainu i zero operacji typu `erase/upload`.

## Potwierdzone źródłowo elementy środowiska

W aktualnym `main_centrala.cpp` `Serial.begin(115200)` jest w `setup()`. `HEALTH` jest emitowany około co 30 s i zawiera `heap`, `largest`, `tg`, `wifi`, `fb`. Aktualna tablica boarda deklaruje ESP32-S3, 16 MB Flash, 8 MB OPI PSRAM i upload speed 921600.

PlatformIO dokumentuje `pio device list` jako sposób wylistowania dostępnych portów szeregowych, a `pio device monitor` jako monitor z opcjami `--port`, `--baud`, `--raw` i kontrolą zakończenia. Nie należy w tej sesji dodawać filtrów typu `time`, ponieważ `Serial_raw.txt` ma pozostać podstawowym dowodem surowym.

## Wykonawczy artefakt

Utworzono:

```text
/mnt/data/R190_EXECUTION_PROCEDURE.md
```

Zawiera dokładne komendy PowerShell, identyfikację `COMx`, zapis T0/T1, capture Serial, ekstrakcję HEALTH, klasyfikację WDT/PANIC/RESET oraz końcowe kryteria HARD_PASS / OBSERVATION_PASS / FAIL.

## Zasada T0/T1

T0 nie oznacza „dowolnego czasu”. To osobno zarejestrowany wall-clock po ustaleniu portu i uruchomieniu capture. Jeżeli otwarcie portu powoduje normalny boot/reset interfejsu, nie robimy drugiego ręcznego resetu tylko po to, by uzyskać BOOT. T1 zapisujemy dopiero po zakończeniu pełnego okna obserwacji i zamknięciu monitora.

## Capture — decyzja

Preferowany jest `pio device monitor --port <COMx> --baud 115200 --raw` z przekierowaniem do `Serial_raw.txt`. `--raw` ogranicza transformacje monitora. `monitor_filters` nie będą używane.

Jeżeli pySerial jest już obecny w PlatformIO Python, można użyć dedykowanego capture, ale nie jest to warunek R188. Nie zakładamy obecności pySerial bez sprawdzenia.

## Najważniejsza zasada podczas 24 h

Podczas baseline nie wykonujemy fault injection ani manualnych zmian automatyki. Nie używamy komend terminala, w szczególności `restart`. Nie wykonujemy OTA, uploadu, `erase`, `erase_upload`, uploadu filesystemu ani sztucznego odłączania sieci.

## Evidence package

Minimalny komplet po sesji:

```text
R188_RESULT.md
Serial_raw.txt
Serial_raw.sha256.txt
HEALTH_extract.txt
HEALTH.csv
+ przy FAIL:
  RTC crash report
  coredump, jeżeli istnieje
  fragment Serial przed/po zdarzeniu
  log krytyczny
```

`Serial_raw.txt` jest nieedytowanym źródłem pierwotnym. `HEALTH.csv` jest tylko pomocniczym ekstraktem i nie może otrzymać sztucznych wartości `wall_time`/`uptime_s`.

## Korelacja z Gate A-0

Po zakończeniu sesji:

```text
HARD_PASS == PASS
AND OBSERVATION_PASS == PASS
AND evidence package == COMPLETE
AND no unexplained fault
AND Commit A scope == FROZEN
    => GATE A-0 = GREEN
```

Każdy nieplanowany restart, WDT/PANIC, coredump, korupcja heap/stack, utrata dowodów lub niewyjaśniona degradacja blokuje Commit A do czasu RCA.

## Źródła web użyte w R190

- PlatformIO `pio device list`: https://docs.platformio.org/en/stable/core/userguide/device/cmd_list.html
- PlatformIO `pio device monitor`: https://docs.platformio.org/en/stable/core/userguide/device/cmd_monitor.html
- PlatformIO `monitor_port`: https://docs.platformio.org/en/latest/projectconf/sections/env/options/monitor/monitor_port.html
- PlatformIO `monitor_filters`: https://docs.platformio.org/en/latest/projectconf/sections/env/options/monitor/monitor_filters.html

---

## R191 — kompletny skrypt PowerShell do wykonania R188

**Status: GOTOWE / IMPLEMENTACJA NARZĘDZIA, bez zmian firmware**

Utworzono artefakt:
`/mnt/data/R188_CAPTURE.ps1`

Zakres skryptu:
- automatyczne wykrycie portu szeregowego ESP32-S3 z preferencją VID/PID `0x303A/0x1001`, z fallbackiem do listy portów;
- domyślny baud `115200`, zgodny z `Serial.begin(115200)` bieżącego firmware;
- utworzenie osobnej sesji `R188_YYYYMMDD_HHMMSS`;
- struktura `00_meta`, `01_serial`, `02_events`, `03_health`, `04_result`, `05_aux`;
- zapis T0/T1 jako osobnych artefaktów;
- zapis `Serial_raw.txt` jako surowych bajtów odebranych z UART, bez dopisywania timestampów do samego strumienia;
- równoległe wydzielanie wpisów `tag=HEALTH lvl=INFO zdarzenie=heartbeat` do `HEALTH_extract.txt` i `HEALTH.csv`;
- automatyczne utworzenie `R188_RESULT.md` jako karty wynikowej;
- brak automatycznego resetu ESP32 oraz brak upload/erase/OTA;
- jawne pozostawienie `uptime_s` puste w `HEALTH.csv`, ponieważ bieżący wpis HEALTH nie emituje uptime firmware — skrypt nie będzie wstawiał wartości pozornej.

### Krytyczna uwaga wykonawcza
T0 w tym narzędziu oznacza rozpoczęcie obserwacji i przechwytywania przez hosta. Skrypt nie wykonuje resetu, dlatego nie utożsamia T0 automatycznie z bootem ESP32. Jeżeli w surowym Serial pojawi się później komunikat startowy, można go skorelować z T0; nie należy dopisywać do danych sztucznego uptime.

### Rezygnacja z `pio device monitor` w samym capture
Do właściwego capture użyto `System.IO.Ports.SerialPort`, aby plik `Serial_raw.txt` zawierał odebrane bajty bez prefiksów i formatowania monitora. PlatformIO pozostaje narzędziem pomocniczym, ale nie jest wymagane do 24-godzinnego przechwytywania.

### Gate A-0
Skrypt R188 nie zmienia firmware i nie otwiera żadnego nowego taska, klienta Firebase ani endpointu telemetrycznego. Nie spełnia ani nie zastępuje samego R188: pozostaje konieczne fizyczne wykonanie sesji i ocena jej wyników według R188.


#### R191.1 — integralność artefaktów
- `R188_CAPTURE.ps1` SHA-256: `d7ec5e57c2e63e65bc405a8380da89f296c73c94b00d25b89f7a3d4b4e2de797`
- Plan SHA-256 przed wpisem R191.1: `e847715ca06c15ef49760653f94bcfb0fe13b6a7363b8a17ed514d4b567b3e42`

---

## R192 — automatyczny wybór portu ESP32 w R188_CAPTURE.ps1

**Zakres:** modyfikacja wyłącznie narzędzia capture na Windows; bez zmian firmware, PlatformIO, Firebase, partycji ani protokołu telemetrii.

### Zaimplementowana logika identyfikacji

1. Parametr `-Port COMx` nadal pozwala na jawny wybór portu i jest walidowany przed rozpoczęciem capture.
2. Bez `-Port` skrypt enumeruje obecne porty `Win32_SerialPort`, z fallbackiem do `Get-PnpDevice -Class Ports`.
3. Port z dokładnym `VID_303A&PID_1001` otrzymuje najwyższy priorytet. Jest to VID/PID wynikający z bieżącej definicji `esp32-s3-n16r8.json`.
4. Gdy kilka portów ma ten sam docelowy VID/PID, nazwa/opis urządzenia jest drugim sygnałem: `ESP32-S3`, `ESP32`, `Espressif` lub `JTAG` są traktowane jako mocne dopasowanie.
5. Automatyczny wybór następuje wyłącznie przy jednoznacznym wyniku.
6. Gdy wiele portów ma docelowy VID/PID i nadal nie da się rozstrzygnąć po nazwie, skrypt kończy się czytelnym błędem i pokazuje porty, nazwy oraz `PNPDeviceID`.
7. Gdy nie ma docelowego VID/PID, skrypt może użyć dokładnie jednego mocnego dopasowania nazwy; przy większej liczbie lub braku dopasowania kończy się błędem zamiast wybrać port arbitralnie.
8. Usunięto interaktywny wybór numeru portu. Jest to celowe dla R188: sesja nie może przypadkowo rozpocząć capture na innym urządzeniu po wyborze operatora.

### Walidacja

- `R188_CAPTURE.ps1` podniesiono do `R188-CAPTURE-1.1`.
- Potwierdzono brak parametru `SkipInteractivePortChoice` w skrypcie.
- Nie wykonano rzeczywistego uruchomienia PowerShell w środowisku modelu, ponieważ dostępny runtime kontenerowy nie udostępnia `powershell`/`pwsh`; dlatego walidacja składni PowerShell pozostaje **NIEZWERYFIKOWANA W RUNTIME**.
- Przed właściwym R188 należy wykonać test na Windows obejmujący co najmniej: jeden ESP32, ESP32 + inny COM, dwa urządzenia z tym samym VID/PID oraz wymuszenie `-Port COMx`.

### Artefakt

`/mnt/data/R188_CAPTURE.ps1`

SHA-256 po zmianie:

`77267d6226d4ea2660ee67cd3dd244818021ea0fb54b1bd53c93f6a5dd0be747`

### Kryterium PASS dla R192

Auto-detekcja wybiera tylko jednoznacznie zidentyfikowany ESP32; przypadek niejednoznaczny zatrzymuje sesję przed utworzeniem capture danych z urządzenia; jawne `-Port` działa niezależnie od auto-detekcji.

---

## R193 — zabezpieczenie ciągłości pracy i jedno źródło stanu projektu

**Cel:** ograniczyć ryzyko zgubienia kontekstu przy bardzo długiej rozmowie lub wznowieniu pracy po przerwie.

### Ustalenie
Utworzono osobny plik:
`/mnt/data/R188_MASTER_STATE.md`

Plik jest krótkim „stanem wykonawczym” projektu. Zawiera:
- cel projektu,
- aktualny Gate A-0 i następny krok,
- zamrożony zakres Commit A,
- fakty build/firmware/partycji,
- reguły R188,
- stan `R188_CAPTURE.ps1`,
- najważniejsze ustalenia telemetryki,
- rzeczy odłożone na osobne etapy,
- kolejność Commit A/B/C/D,
- procedurę wznowienia pracy.

### Zasada ciągłości
Przy kolejnym wznowieniu:
1. najpierw `R188_MASTER_STATE.md`,
2. następnie końcówka `TELEMETRIA_RESEARCH_PLAN.md`,
3. dopiero potem operacje na kodzie/narzędziach.

Po każdym istotnym kroku aktualizowany jest `TELEMETRIA_RESEARCH_PLAN.md`; po zmianie artefaktu podawany jest SHA-256; rzeczy nieprzetestowane runtime pozostają oznaczone jako `NIEZWERYFIKOWANE W RUNTIME`.

### Bieżący stan po R193
- `R188_MASTER_STATE.md` SHA-256:
  `a883e442a88f80f2a98fff1e39f8fb82918b4e3b7fcf8631b29127af312c4182`
- `R188_CAPTURE.ps1`: R188-CAPTURE-1.1, auto-detekcja po VID/PID + nazwie, brak arbitralnego wyboru.
- Gate A-0: YELLOW.
- Następny krok: Windows runtime test R188 capture → pełne ~24 h R188 → analiza wyników → Gate A-0.

### Kryterium PASS dla R193
Kontynuacja pracy po skróceniu kontekstu jest możliwa przez odczyt `R188_MASTER_STATE.md` + końca planu, bez wymagania od użytkownika ponownego opisywania projektu.

---

## R194 — podział pracy i następny krok operacyjny

**Status:** ACTIVE / READY FOR USER SMOKE TEST

Cel R194: jednoznacznie rozdzielić czynności wykonywane przez AI od czynności wymagających fizycznego uruchomienia ESP32 na komputerze użytkownika, aby nie wykonywać wirtualnie kroków, których nie da się zweryfikować runtime.

### AI — wykonywane po stronie asystenta
- utrzymanie `R188_MASTER_STATE.md` i `TELEMETRIA_RESEARCH_PLAN.md` jako źródeł ciągłości;
- przegląd `R188_CAPTURE.ps1` pod kątem logiki, bezpieczeństwa i błędów operacyjnych;
- analiza artefaktów po każdej sesji R188;
- przygotowanie i weryfikacja kolejnych kroków telemetryki dopiero po spełnieniu Gate A-0;
- jawne oznaczanie faktów jako `VERIFIED_FROM_SOURCE`, `VERIFIED_IN_RUNTIME`, `N/A_PRE_A_*` albo `NIEZWERYFIKOWANE_W_RUNTIME`.

### Użytkownik — jedyny krok wymagający fizycznego urządzenia
Przed właściwą sesją 24 h należy wykonać krótki smoke test `R188_CAPTURE.ps1`:
1. uruchomić skrypt bez `-Port`;
2. sprawdzić, czy automatycznie wybiera właściwy `COMx`;
3. nacisnąć ENTER, aby rozpocząć capture;
4. odczekać około 30–60 s i sprawdzić, czy rosną `bytes` oraz pojawiają się wpisy `HEALTH`;
5. nacisnąć ENTER drugi raz, aby zakończyć;
6. przekazać AI wyłącznie wynik z konsoli oraz ewentualnie listę utworzonych plików / zawartość `capture_summary.txt`.

**Nie uruchamiać jeszcze pełnych 24 h.** Smoke test służy wyłącznie do potwierdzenia autodetekcji portu, otwarcia UART i poprawnego zapisu artefaktów.

### Warunek przejścia do R188 ~24 h
Smoke test musi potwierdzić:
- jednoznaczny wybór ESP32-S3;
- brak błędu otwarcia COM;
- wzrost `bytes_received`;
- powstanie `Serial_raw.txt`, `T0.txt`, `T1.txt`, `HEALTH_extract.txt`, `HEALTH.csv`, `R188_RESULT.md`;
- brak resetu/uploadu/erase/OTA wykonywanego przez skrypt.

Dopiero po PASS smoke testu użytkownik uruchamia właściwe ~24 h R188.

---

## R195 — błąd uruchomienia R188_CAPTURE.ps1: brak pliku w katalogu projektu

**Status:** NOT_A_FIRMWARE_ERROR / USER_ACTION_PENDING

### Obserwacja
Użytkownik uruchomił PowerShell w `C:\Users\bakoma\Documents\PlatformIO\sterownik-co-esp32`, a następnie `powershell -ExecutionPolicy Bypass -File .\R188_CAPTURE.ps1`. PowerShell zgłosił, że argument `.\R188_CAPTURE.ps1` nie istnieje.

### Diagnoza
Błąd nie oznacza problemu z firmware ani z autodetekcją ESP32. Plik artefaktu został utworzony w środowisku roboczym ChatGPT (`/mnt/data/R188_CAPTURE.ps1`), ale nie został automatycznie skopiowany do lokalnego katalogu Windows użytkownika.

### Korekta operacyjna
`$env:USERPROFILE\Documents\PlatformIO\sterownik-co-esp32\R188_CAPTURE.ps1`.

Jeśli plik jest już w Downloads, można wykonać:
```powershell
Copy-Item "$env:USERPROFILE\Downloads\R188_CAPTURE.ps1" ".\R188_CAPTURE.ps1" -Force
```

Po obecności pliku należy wykonać smoke test; pełne 24 h R188 nadal NIE rozpoczynać przed PASS smoke testu.

### Kryterium zamknięcia R195
`Test-Path .\R188_CAPTURE.ps1` zwraca `True`, a następnie smoke test dochodzi do autodetekcji portu.


## R196 — R188_CAPTURE.ps1: naprawa kodowania dla Windows PowerShell 5.1 (2026-09-24)

Status: **NAPRAWIONE / GOTOWE DO PONOWNEGO TESTU**

### Obserwacja
Uruchomienie na Windows PowerShell 5.1 zakończyło się `ParserError` w linii 204, a komunikat pokazał zniekształcone znaki (`urzÄ…dzeĹ„`).

### Przyczyna
Skrypt był zapisany jako UTF-8 bez BOM. Windows PowerShell 5.1 może wtedy interpretować plik według bieżącej strony kodowej zamiast UTF-8, przez co polskie znaki w stringach zostały uszkodzone i parser potraktował fragment tekstu jako składnię.

### Działanie
`R188_CAPTURE.ps1` zapisano ponownie jako UTF-8 **z BOM** (`EF BB BF`). Logika autodetekcji portu nie została merytorycznie zmieniona.

### Wymagany test
Na Windows PowerShell 5.1 ponowić:

```powershell
powershell -ExecutionPolicy Bypass -File .\R188_CAPTURE.ps1
```

Najpierw musi przejść parser i wyświetlić nagłówek R188 oraz rozpocząć fazę autodetekcji. Nadal NIE wykonywać 24 h R188 przed pozytywnym smoke testem.

### Weryfikacja lokalna
- potwierdzono BOM UTF-8: `EF BB BF`
- potwierdzono obecność poprawnego tekstu `kilka urządzeń ma` w linii 204
- test runtime PowerShell nie jest dostępny w bieżącym środowisku; finalna walidacja parsera pozostaje po stronie Windows użytkownika


## R197 — R188_CAPTURE.ps1: kolizja lokalnej zmiennej `$pid` z automatyczną zmienną PowerShell `$PID`

**Status:** NAPRAWIONE / GOTOWE DO PONOWNEGO TESTU

### Obserwacja
Na Windows PowerShell 5.1 skrypt przeszedł parser, ale podczas autodetekcji zakończył się: `Get-PortIdentityScore : Cannot overwrite variable PID because it is read-only or constant.`

### Przyczyna
W funkcji `Get-PortIdentityScore` użyto lokalnej zmiennej `$pid`. PowerShell traktuje nazwy zmiennych bez rozróżniania wielkości liter, a `$PID` jest wbudowaną automatyczną zmienną przechowującą identyfikator procesu. Próba przypisania do `$pid` była więc próbą nadpisania automatycznej zmiennej. Dokumentacja Microsoft wymienia `$PID` jako automatyczną zmienną PowerShell. citeturn637717search0

### Korekta
- `$pid` → `$pidValue` w `Get-PortIdentityScore`;
- porównanie VID/PID używa teraz `$pidValue`;
- wersja skryptu podniesiona z `R188-CAPTURE-1.1` do `R188-CAPTURE-1.2`;
- zachowano UTF-8 z BOM z poprzedniej korekty dla Windows PowerShell 5.1;
- logika autodetekcji i zasady bezpieczeństwa R188 nie zostały zmienione.

### Weryfikacja statyczna w środowisku AI
- potwierdzono BOM UTF-8 `EF BB BF`;
- potwierdzono `R188-CAPTURE-1.2`;
- potwierdzono obecność `$pidValue` zamiast lokalnego `$pid`;
- nie wykonano pełnego parser/runtime testu Windows PowerShell w środowisku AI, ponieważ nie jest dostępny.

### Następny krok użytkownika
Podmienić `R188_CAPTURE.ps1` w katalogu projektu na wersję 1.2 i wykonać:
```powershell
powershell -ExecutionPolicy Bypass -File ".\R188_CAPTURE.ps1"
```
Nie rozpoczynać jeszcze pełnych 24 h. Celem tego uruchomienia jest uzyskanie poprawnej autodetekcji portu i startu/końca krótkiego smoke testu.

# R198 — wykryto uruchamianie starej wersji R188_CAPTURE.ps1

Data: 2026-09-24

## Fakt z runtime

Użytkownik uruchomił `R188_CAPTURE.ps1` i PowerShell zgłosił:
`Get-PortIdentityScore : Cannot overwrite variable PID because it is read-only or constant.`
Nagłówek runtime pokazał jednocześnie `Wersja skryptu: R188-CAPTURE-1.1`.

## Diagnoza

Bieżący poprawiony artefakt w `/mnt/data/R188_CAPTURE.ps1` ma wersję `R188-CAPTURE-1.2` i nie zawiera lokalnej zmiennej `$pid`; używa `$pidValue`. Zatem urządzenie Windows uruchomiło starszą kopię skryptu 1.1, a nie aktualny artefakt 1.2.

## Zasada weryfikacyjna

Przed każdym uruchomieniem R188_CAPTURE użytkownik wykonuje:
`Select-String -Path .\\R188_CAPTURE.ps1 -Pattern '\\$ScriptVersion'`

Oczekiwane: `R188-CAPTURE-1.2`.

Dodatkowo:
`Get-FileHash .\\R188_CAPTURE.ps1 -Algorithm SHA256`
ma być zgodny z SHA-256 aktualnego artefaktu przekazanego przez asystenta.

## Bezpieczeństwo

Nie uruchamiać capture, dopóki lokalna wersja nie jest 1.2. Nie rozpoczynać 24 h R188 na wersji 1.1.

STATUS: SMOKE_TEST_PENDING / poprawka artefaktu wymagająca podmiany lokalnej kopii.

---

## R199 — smoke test: rzeczywista identyfikacja UART na Windows

**Status:** SMOKE_TEST_PENDING / port ustalony tylko jako kandydat, nie jako automatycznie zweryfikowany ESP32.

### Wynik uruchomienia `R188_CAPTURE_1.2_FIXED.ps1`
- wersja skryptu: `R188-CAPTURE-1.2` — **VERIFIED**
- SHA-256 skryptu: `C8A9C2E92D6A9D251191BFBD699987B8152396E901D8DEA90186F933E496CB19` — **VERIFIED BY USER**
- wykryto dokładnie jeden port szeregowy: `COM8`
- PNP ID: `USB\\VID_1A86&PID_55D3\\5C4D040363`
- nazwa: `Urządzenie szeregowe USB (COM8)`
- oczekiwany przez definicję płytki USB ID: `VID_303A&PID_1001`
- automatyczna identyfikacja ESP32: **NIEPOTWIERDZONA**
- zachowanie bezpieczne: skrypt **NIE rozpoczął capture**.

### Interpretacja
Nie wolno jeszcze uznać COM8 za ESP32 wyłącznie na podstawie jednego portu. Różnica VID/PID oznacza, że urządzenie nie prezentuje się w Windows jako oczekiwany interfejs `303A:1001`. Nie rozstrzygamy tutaj, czy COM8 jest UART-em ESP32 przez zewnętrzny konwerter — wymaga to krótkiego testu transmisji.

### Następna czynność operatora
Uruchomić krótki, ręcznie wskazany smoke test na `COM8`:
`powershell -ExecutionPolicy Bypass -File ".\\R188_CAPTURE_1.2_FIXED.ps1" -Port COM8`
Następnie pozostawić capture przez 30–60 s, sprawdzić pojawienie się linii startowych i `HEALTH`, po czym ENTER kończy sesję.

**NIE URUCHAMIAĆ JESZCZE 24 h R188.**

### Kryterium smoke testu
PASS tylko gdy na COM8 pojawiają się wiarygodne logi aktualnego firmware, w szczególności startup i/lub `tag=HEALTH` zgodne z formatem źródła. Aktualny firmware używa `Serial.begin(115200)`, a heartbeat `HEALTH` zawiera `heap`, `largest`, `tg`, `wifi`, `fb`.

FAIL, gdy brak danych, dane należą do innego urządzenia albo występuje reset/WDT/PANIC już podczas krótkiej sesji.

# R200 — poprawka `Count` w trybie ręcznego portu R188_CAPTURE

Data: 2026-09-24

## Fakt z runtime

Użytkownik uruchomił:
`powershell -ExecutionPolicy Bypass -File ".\\R188_CAPTURE_1.2_FIXED.ps1" -Port COM8`

Skrypt wystartował poprawnie jako `R188-CAPTURE-1.2`, ale zakończył się błędem:
`The property 'Count' cannot be found on this object. Verify that the property exists.`

## Diagnoza

Przy `Set-StrictMode -Version Latest` wyrażenie:
`($ports | Where-Object { ... }).Count`
może dotyczyć pojedynczego obiektu zamiast tablicy. Pojedynczy obiekt zwrócony przez filtr WMI/PnP nie musi udostępniać właściwości `.Count`.

Błąd wystąpił w `Test-SerialPortExists`, czyli w ścieżce `-Port COM8`. Nie jest to błąd UART, firmware ani identyfikacji urządzenia.

## Korekta

Przygotowano `R188_CAPTURE_1.3_FIXED.ps1`:
- `$ScriptVersion = 'R188-CAPTURE-1.3'`;
- `Test-SerialPortExists` używa bezpiecznego `@(...).Count`;
- zachowano UTF-8 z BOM;
- nie zmieniono zasad bezpiecznej autodetekcji;
- ręczny `-Port COMx` nadal jest obsługiwany.

SHA-256 artefaktu:
`97984F47349316A8C63CB62D00DCBBCEE2D97F54F3DAE77632C660E52DCFF469`

## Status testu

- parser 1.2: VERIFIED przez użytkownika;
- autodetekcja 1.2: VERIFIED jako bezpieczna odmowa na COM8;
- ręczny `-Port COM8` 1.2: FAIL z powodu `.Count`;
- poprawka 1.3: STATICALLY VERIFIED w środowisku AI; brak lokalnego Windows PowerShell do runtime testu tutaj;
- smoke test ESP32: PENDING.

## Następny krok użytkownika

Pobrać `R188_CAPTURE_1.3_FIXED.ps1` do katalogu projektu, zweryfikować wersję/hash i uruchomić ręczny test:
`powershell -ExecutionPolicy Bypass -File ".\\R188_CAPTURE_1.3_FIXED.ps1" -Port COM8`

Nie rozpoczynać jeszcze 24 h R188.


# R201 — runtime: Windows PowerShell 5.1 nie rozwiązał `TickCount64`

Data: 2026-09-24

## Wynik testu operatora

Użytkownik uruchomił `R188_CAPTURE_1.3_FIXED.ps1 -Port COM8`. Skrypt poprawnie:
- uruchomił się jako `R188-CAPTURE-1.3`;
- przeszedł walidację ręcznie wskazanego `COM8`;
- wyświetlił nazwę `Urządzenie szeregowe USB (COM8)` i PNP `USB\VID_1A86&PID_55D3\5C4D040363`;
- zatrzymał się po wejściu w fazę rozpoczęcia sesji z błędem `The property 'TickCount64' cannot be found on this object.`.

## Diagnoza

Błąd pochodzi z użycia `[Environment]::TickCount64` jako zegara roboczego skryptu. Nie należy dalej opierać capture na tym odwołaniu w tej konkretnej konfiguracji Windows PowerShell 5.1. To nie jest błąd ESP32, UART ani COM8.

## Korekta R188_CAPTURE-1.4

Przygotowano `R188_CAPTURE_1.4_FIXED.ps1`:
- wersja: `R188-CAPTURE-1.4`;
- wszystkie użycia `[Environment]::TickCount64` zastąpiono jednym zegarem `System.Diagnostics.Stopwatch`;
- dodano `Get-MonotonicMs`, zwracające `ElapsedMilliseconds`;
- zegar jest monotoniczny dla pomiaru czasu trwania capture i nie zależy od zmiany czasu systemowego;
- zachowano UTF-8 z BOM dla Windows PowerShell 5.1;
- nie zmieniono logiki portu, T0/T1, struktury sesji ani zakazu reset/upload/erase/OTA.

SHA-256 artefaktu:
`7F87B8C43BA5549057AB271807CA11662C168B42A2178A303D42E681A4659A3C`

## Status

- autodetekcja: VERIFIED jako bezpieczna odmowa na `COM8`, gdy VID/PID nie zgadza się z `303A:1001`;
- ręczny port: VERIFIED do momentu rozpoczęcia fazy capture;
- otwarcie portu i rzeczywisty zapis UART: PENDING;
- smoke test ESP32: PENDING;
- 24 h R188: BLOKOWANE do czasu PASS smoke testu.

## Następny krok

Operator ma podmienić lokalny plik na `R188_CAPTURE_1.4_FIXED.ps1` i uruchomić:
```powershell
powershell -ExecutionPolicy Bypass -File ".\R188_CAPTURE_1.4_FIXED.ps1" -Port COM8
```
Po komunikacie `R188 AKTYWNE` pozostawić capture 30–60 s, sprawdzić startup/`HEALTH`, następnie ENTER. Nie uruchamiać jeszcze 24 h.

## R202 — smoke test R188_CAPTURE 1.4: otwarcie COM i zapis UART

Data: 2026-09-24

### Wynik operatora
Użytkownik uruchomił:
```powershell
powershell -ExecutionPolicy Bypass -File ".\R188_CAPTURE_1.4_FIXED.ps1" -Port COM8
```

Skrypt zgłosił:
- `R188-CAPTURE-1.4`;
- port `COM8`;
- opis `Urządzenie szeregowe USB (COM8)`;
- PNP `USB\\VID_1A86&PID_55D3\\5C4D040363`;
- T0 `2026-09-24 18:52:16.433`;
- T1 `2026-09-24 18:52:25.324`;
- powód zakończenia `OPERATOR_ENTER`;
- odebrane bajty `2 392`;
- `HEALTH: 0`.

### Ocena
**PASS częściowy — warstwa capture:** skrypt przeszedł przez identyfikację ręcznego portu, fazę T0/T1 i odebrał niezerową liczbę bajtów.

**NIEZWERYFIKOWANE:** czy `Serial_raw.txt` zawiera właściwy strumień logów firmware oraz czy nie występują błędne znaki/utrata linii. `HEALTH=0` jest oczekiwane dla sesji krótszej niż 30 s i samo w sobie nie jest awarią.

### Następny krok
Nie uruchamiać jeszcze 24 h. Najpierw operator ma sprawdzić zawartość pliku `01_serial\\Serial_raw.txt` z tej sesji oraz wykonać krótki capture ~40 s, aby potwierdzić co najmniej jeden wpis `tag=HEALTH`. Po tym dopiero można rozstrzygnąć PASS smoke testu.


## R203 — smoke test: poprawny strumień UART ESP32 potwierdzony; profil CH340 ustalony

Data: 2026-09-24

### Dane runtime od operatora
Operator zakończył krótki capture wykonany przez `R188_CAPTURE_1.4_FIXED.ps1 -Port COM8`.
W sesji `R188_20260924_185216` zapisano 2392 bajty. Następnie operator odczytał `01_serial\Serial_raw.txt` i wykazał m.in.:
- boot ROM `ESP-ROM:esp32s3-20210327`;
- komunikat aplikacji `=== SYSTEM START ESP32-S3 ...`;
- istniejący wpis WDT z timeoutem 15000 ms;
- wpisy inicjalizacji PSRAM/F/S/Historia/WiFi/OTA;
- `tag=BOOT ... powod=POWERON`;
- wpisy WiFi z faktycznej aplikacji centrali.

### Ocena
**SMOKE_TEST_CAPTURE_STREAM = PASS.**
Treść `Serial_raw.txt` jest zgodna z właściwym firmware ESP32-S3, więc COM8 jest rzeczywistym portem UART tej centrali. Nie ma już potrzeby dodatkowo dowodzić, że capture trafia do właściwego urządzenia.

`HEALTH=0` w poprzednim 8.9-sekundowym capture pozostaje normalne: obecny firmware emituje heartbeat `HEALTH` co około 30 s.

### Istotna obserwacja identyfikacji USB
Windows raportuje COM8 jako `VID_1A86&PID_55D3` (`PNP: USB\VID_1A86&PID_55D3\5C4D040363`), podczas gdy plik `boards/esp32-s3-n16r8.json` definiuje hwids `0x303A/0x1001`. W tym środowisku należy traktować `1A86:55D3` jako zweryfikowany profil mostka UART używanego przez tę centralę, a nie jako zmianę definicji boarda.

### Korekta narzędzia
Przygotowano `R188_CAPTURE_1.5_FIXED.ps1`:
- zachowuje priorytet natywnego `VID_303A&PID_1001`;
- dodaje niski-priorytetowy profil `VID_1A86&PID_55D3` dla zweryfikowanego mostka CH340;
- automatyczny wybór profilu CH340 następuje tylko, gdy pozostaje dokładnie jeden taki port;
- przy wielu takich portach skrypt stosuje nazwę jako dodatkowy sygnał, a jeśli nadal jest niejednoznacznie — kończy się STOP;
- nie wybiera arbitralnie pierwszego COM;
- nadal możliwy jest jawny `-Port COMx`;
- zachowano UTF-8 BOM i zegar `Stopwatch`.

SHA-256: `43597EEF1DD4BC978F7AC79C28C9FAD689CD18FA7170220706F32EF19864FFB5`

### Bezpieczeństwo danych R188
Raw log zawiera komunikaty WiFi z danymi konfiguracyjnymi. Nie należy wklejać pełnego `Serial_raw.txt` do rozmowy bez redakcji. Do analizy wystarczy plik jako artefakt lokalny albo fragmenty z usuniętymi sekretami. Ponieważ dane konfiguracyjne zostały już pokazane w rozmowie, po zakończeniu testów warto rozważyć zmianę hasła hotspotu.

### Następny krok
Uruchomić `R188_CAPTURE_1.5_FIXED.ps1` bez `-Port` i pozostawić co najmniej 40–60 s, aby uzyskać co najmniej jeden `tag=HEALTH`. Jeżeli automat wybierze COM8 bez błędu i wynik będzie poprawny, smoke test narzędzia uznajemy za pełny. Dopiero potem można rozpocząć docelowy 24 h R188.

## R204 — automatyczna identyfikacja COM8 + pełny smoke test capture z HEALTH

Data: 2026-09-24

### Dane runtime od operatora
Uruchomiono `R188_CAPTURE_1.5_FIXED.ps1` bez `-Port`.
Skrypt automatycznie wybrał COM8 na podstawie zweryfikowanego profilu UART `VID_1A86&PID_55D3` i poprawnie przeszedł do stanu `R188 AKTYWNE`.

T0: `2026-09-24 19:02:02.873`
Sesja: `R188_20260924_190202`

W czasie trwania capture operator uzyskał co najmniej 6 wpisów `HEALTH`:
- HEALTH #1: heap 115252 B, largest 6815732 B, tg=1, wifi=1, fb=1
- HEALTH #2: heap 115252 B, largest 6815732 B, tg=1, wifi=1, fb=1
- HEALTH #3: heap 115364 B, largest 6815732 B, tg=1, wifi=1, fb=1
- HEALTH #4: heap 103504 B, largest 6815732 B, tg=1, wifi=1, fb=1
- HEALTH #5: heap 113544 B, largest 6815732 B, tg=1, wifi=1, fb=1
- HEALTH #6: heap 105300 B, largest 6684660 B, tg=1, wifi=1, fb=1

Capture raportował przyrost odebranych bajtów od 888 B do 16334 B w pokazanym fragmencie, bez przerwania procesu i bez błędu skryptu.

### Ocena
`R188_CAPTURE_TOOL_SMOKE_TEST = PASS` na podstawie danych runtime operatora:
- automatyczny wybór właściwego UART działa;
- T0 działa;
- ciągły capture działa;
- strumień nie jest pusty;
- parser HEALTH rozpoznaje wpisy poprawnie;
- urządzenie raportuje w HEALTH `tg=1`, `wifi=1`, `fb=1` w badanym oknie.

Nie wyciągamy jeszcze wniosków o stabilności 24 h na podstawie kilku minut.

### Akcja operatora teraz
Nie trzeba już czekać na kolejne wpisy podczas tego smoke testu. Należy nacisnąć `ENTER` w tym samym oknie, aby wykonać kontrolowane zakończenie sesji i zapisać T1.

### Gate
Po kontrolowanym zakończeniu tej sesji można uznać warunek narzędzia capture za spełniony i przejść do przygotowania właściwego 24 h R188. Nadal obowiązuje: przed formalnym GREEN Gate A-0 trzeba zachować pełny pakiet dowodowy z 24 h oraz zweryfikować wynik.

## R205 — automatyczny smoke test capture zakończony PASS

Data: 2026-09-24

### Dane runtime od operatora
Wykonano `R188_CAPTURE_1.5_FIXED.ps1` bez `-Port`.
Automatyczna identyfikacja wybrała:
- COM8
- PNP `USB\\VID_1A86&PID_55D3\\5C4D040363`
- profil zweryfikowanego mostka UART

Sesja:
- T0: `2026-09-24 19:02:02.873`
- T1: `2026-09-24 19:15:40.486`
- czas capture: `817.613 s` (~13 min 37.6 s)
- odebrane bajty: `102729`
- HEALTH: `24`
- zakończenie: `OPERATOR_ENTER`
- katalog: `R188_SESSIONS\\R188_20260924_190202`

W trakcie capture raportowane wartości HEALTH obejmowały `tg=1 wifi=1 fb=1`.
Zaobserwowany heap w pokazanej części sesji zmieniał się (m.in. 115252 B, 115364 B, 103504 B, 113544 B, 105300 B), a największy blok był 6815732 B, później 6684660 B. Są to obserwacje z części logu podanej przez operatora, nie pełna analiza 13-minutowego artefaktu.

### Ocena
`R188_CAPTURE_TOOL_SMOKE_TEST = PASS`.
Potwierdzone:
- automatyczne znalezienie portu po zweryfikowanym profilu UART;
- bezpieczna odmowa wyboru przy niejednoznaczności;
- poprawny start sesji i T0;
- ciągły odbiór danych;
- rozpoznawanie HEALTH;
- kontrolowane T1 przez operatora;
- brak resetu/uploadu/erase/OTA wykonywanego przez skrypt.

Nie traktujemy 13-minutowego smoke testu jako dowodu stabilności 24 h.

### Decyzja
Warunek narzędzia capture zamknięty. Można przejść do właściwej sesji `R188` 24 h.
Przed jej rozpoczęciem nie zmieniamy firmware, toolchaina, partycji ani biblioteki FirebaseClient.

### Procedura następnego kroku
1. Zachować katalog smoke testu `R188_20260924_190202` jako artefakt referencyjny.
2. Uruchomić `R188_CAPTURE_1.5_FIXED.ps1` bez `-Port`.
3. Po komunikacie `R188 AKTYWNE` traktować T0 jako oficjalny początek 24 h baseline.
4. Przez 24 h nie wykonywać restartu, OTA, erase, zmian ustawień ani ręcznych testów ingerujących w automatykę.
5. Zachować pełny `Serial_raw.txt`; nie wklejać go w całości do rozmowy ze względu na możliwe dane WiFi.
6. Po 24 h zakończyć ENTER i zebrać T1 oraz artefakty sesji.

**Gate A-0: YELLOW -> oczekuje właściwego 24 h runtime baseline.**


---
## R206 — PRZENIESIENIE SESJI NA DRUGI PC / AUTODETEKCJA COM
**Data:** 2026-09-25

**Obserwacja:** Na drugim komputerze `R188_CAPTURE_1.5_FIXED.ps1` poprawnie uruchamia autodetekcję, ale Windows zwraca wyłącznie `COM3` i `COM4` o `VID_8087&PID_0ACA`; nie ma ani `VID_303A&PID_1001`, ani wcześniej zweryfikowanego `VID_1A86&PID_55D3`. Skrypt prawidłowo odmawia wyboru.

**Wniosek:** Ten komputer nie przedstawia obecnie ESP32 jako dostępnego portu UART. Nie wolno wymuszać `COM3` ani `COM4` bez dodatkowego dowodu. Na poprzednim PC potwierdzono, że właściwy UART centrali dawał poprawny boot ROM i log aplikacji; na tym PC trzeba najpierw potwierdzić obecność urządzenia.

**Procedura:** przed ponownym uruchomieniem R188: podłączyć ESP32 do tego PC, sprawdzić `pio device list` oraz urządzenia PnP; po pojawieniu się właściwego portu uruchomić capture. Jeżeli port nie pojawi się po podłączeniu, diagnostyka obejmuje kabel/port USB oraz sterownik, bez zmian firmware.

**Status:** `SECOND_PC_NOT_READY_FOR_R188`.
**Następny krok:** potwierdzenie, jaki port Windows nadaje fizycznie podłączonej centrali na drugim PC.

## R207 — DRUGI PC: PRAWIDŁOWY PORT COM5 / GOTOWOŚĆ DO 24 H R188
**Data:** 2026-09-25

### Wynik runtime od operatora
Na komputerze `C:\Users\Rafcio\Documents\PlatformIO\sterownik-co-esp32` po podłączeniu centrali:
```text
COM4  USB VID:PID=8087:0ACA SER=05022016
COM3  USB VID:PID=8087:0ACA SER=05022016 LOCATION=1-2:x.2
COM5  USB VID:PID=1A86:55D3 SER=5C4D040363 LOCATION=1-2:x.2
```
WMI/PnP zwróciło:
```text
USB-Enhanced-SERIAL CH343 (COM5) | OK | USB\\VID_1A86&PID_55D3\\5C4D040363
```

### Wniosek
ESP32 nie jest przedstawiony jako natywny `VID_303A&PID_1001`, ale wcześniej potwierdzony przez runtime mostek UART `1A86:55D3` jest obecnie obecny jako `COM5`. Numer seryjny mostka `5C4D040363` jest zgodny z wcześniejszą sesją na pierwszym PC (`COM8`), dlatego mamy silny dowód, że jest to ten sam fizyczny interfejs UART centrali.

### Status
- autodetekcja `R188_CAPTURE_1.5_FIXED.ps1`: oczekiwana ścieżka jednoznaczna dla `COM5`;
- brak potrzeby ręcznego `-Port`;
- narzędzie capture: PASS;
- smoke test strumienia: PASS;
- **R188 24 h: READY TO START**;
- Gate A-0: `YELLOW / RUNTIME_24H_PENDING`.

### Następny krok
Operator uruchamia:
```powershell
powershell -ExecutionPolicy Bypass -File ".\R188_CAPTURE_1.5_FIXED.ps1"
```
bez `-Port`, potwierdza automatyczny wybór `COM5`, naciska ENTER na starcie i pozostawia sesję na ~24 h bez ingerencji. Po zakończeniu ENTER -> T1. Nie rozpoczynać żadnych zmian firmware przed analizą baseline.

## R208 — DRUGI PC: 1.5 NIE WIDZI CH343 W Win32_SerialPort / PRZYGOTOWANO 1.6
**Data:** 2026-09-25

### Obserwacja runtime
Na komputerze `C:\Users\Rafcio\Documents\PlatformIO\sterownik-co-esp32` uruchomienie `R188_CAPTURE_1.5_FIXED.ps1` bez `-Port` zwróciło wyłącznie COM3/COM4 (`VID_8087:0ACA`) i zatrzymało się na braku jednoznacznego portu. Następnie `pio device list` wykazało prawidłowy port `COM5`, `VID:PID=1A86:55D3`, `SER=5C4D040363`, opis `USB-Enhanced-SERIAL CH343 (COM5)`. `Get-CimInstance Win32_PnPEntity` również potwierdziło ten sam COM5/PNP ID.

### Przyczyna
Funkcja `Get-SerialPorts` w wersji 1.5 opierała pierwszą enumerację na `Win32_SerialPort`, a mechanizm `Get-PnpDevice` był używany tylko jako fallback po wyjątku. Na badanym PC `Win32_SerialPort` zwróciło część portów bez wyjątku, więc fallback się nie uruchomił. W rezultacie istniejący CH343 z COM5 został pominięty mimo poprawnej widoczności w PnP/PlatformIO.

### Zmiana przygotowana
Przygotowano `R188_CAPTURE_1.6_FIXED.ps1` z połączoną enumeracją:
1. `Win32_SerialPort` jako źródło bazowe,
2. `Win32_PnPEntity` jako źródło uzupełniające dla urządzeń z nazwą `(COMx)`,
3. `Get-PnpDevice -Class Ports` jako dodatkową warstwę uzupełniającą.
Porty są deduplikowane po `COMx`, a metadata PnP jest uzupełniana z drugiego źródła.

### Walidacja lokalna narzędzia
W środowisku roboczym potwierdzono spójność strukturalną pliku 1.6: liczba klamer/par nawiasów jest zbilansowana; plik zapisano jako UTF-8 BOM. Nie wykonano runtime testu PowerShell 5.1 na tym środowisku (brak `powershell.exe`/`pwsh`). Zatem `R188_CAPTURE_1.6_FIXED.ps1` ma status **STATIC_CHECKED / NOT_RUNTIME_VERIFIED_HERE**.

### Decyzja dla właściwego R188
Aby nie wprowadzać kolejnej niezweryfikowanej zmiany narzędzia tuż przed 24 h baseline, właściwa sesja R188 na tym PC może być uruchomiona na już potwierdzonym porcie jawnie:
```powershell
powershell -ExecutionPolicy Bypass -File ".\R188_CAPTURE_1.5_FIXED.ps1" -Port COM5
```
To omija tylko etap autodetekcji; zapis T0/T1, capture i HEALTH pozostają tym samym mechanizmem. Automatyczną enumerację wersji 1.6 należy zweryfikować osobno po zakończeniu baseline albo wcześniej tylko wtedy, gdy operator chce ponownie sprawdzać narzędzie.

### Status
- `SECOND_PC_COM5_CONFIRMED = PASS`
- `R188_CAPTURE_TOOL_SMOKE_TEST = PASS` (wcześniej na pierwszym PC)
- `R188_CAPTURE_1.5_AUTO_ON_SECOND_PC = FAIL / enumeration limitation`
- `R188_CAPTURE_1.6 = STATIC_CHECKED / NOT_RUNTIME_VERIFIED_HERE`
- `GATE_A0 = YELLOW / RUNTIME_24H_PENDING`

### Następny krok
Uruchomić właściwy 24 h R188 przez `-Port COM5`, bez kolejnego smoke testu narzędzia.

## R209 — JAWNY `-Port COM5` ODRZUCONY PRZEZ BŁĘDNĄ WALIDACJĘ WMI / PRZYGOTOWANO 1.7
**Data:** 2026-09-25

### Obserwacja runtime
Na drugim PC operator posiadał wcześniej niezależne potwierdzenie:
```text
pio device list:
COM5  Hardware ID: USB VID:PID=1A86:55D3 SER=5C4D040363
Description: USB-Enhanced-SERIAL CH343 (COM5)
```
oraz:
```text
Get-CimInstance Win32_PnPEntity:
USB-Enhanced-SERIAL CH343 (COM5) | OK | USB\\VID_1A86&PID_55D3\\5C4D040363
```
Mimo tego uruchomienie `R188_CAPTURE_1.5_FIXED.ps1 -Port COM5` zostało zatrzymane komunikatem `Podany port 'COM5' nie jest obecnie dostępny`.

### Przyczyna
Wersja 1.5 funkcją `Test-SerialPortExists` sprawdzała obecność jawnie wskazanego portu wyłącznie poprzez `Get-SerialPorts`, którego pierwsze źródło było `Win32_SerialPort`. Ten sam sterownik CH343 jest dostępny dla PlatformIO i PnP, ale nie musiał być zwracany przez `Win32_SerialPort`. Walidacja była więc fałszywie negatywna. Jest to błąd narzędzia hostowego, nie dowód problemu z ESP32.

### Zmiana przygotowana
`R188_CAPTURE_1.7_FIXED.ps1`:
- scala `Win32_SerialPort`, `Win32_PnPEntity`, `Get-PnpDevice` oraz `.NET [System.IO.Ports.SerialPort]::GetPortNames()`;
- dla jawnego `-Port` uznaje `.NET SerialPort.GetPortNames()` za źródło prawdy o dostępności portu, zamiast wymagać wpisu w WMI;
- zachowuje bezpieczną zasadę: automat nadal wybiera tylko jednoznacznie rozpoznany port;
- nie zmienia protokołu capture ani firmware;
- wersja skryptu: `R188-CAPTURE-1.7`;
- plik zapisany jako UTF-8 BOM.

SHA-256:
```text
5e37e68d13645488743a8d09512a01ea153b7a86f6f5047a979c053c65f3c969
```
**KOREKTA:** faktyczny SHA-256 przygotowanego pliku 1.7:
```text
a409a9b918fad9a9c1ecb058fccdcedcbbb04ef82a3dd8aa72e1ac46a6dc11c0
```
Powyższa pierwsza wartość dotyczy wcześniejszego artefaktu i nie powinna być używana.

### Walidacja
- liczba klamer `{}` w 1.7: 181/181;
- liczba nawiasów `[]`: 150/150;
- obecne `SerialPort.GetPortNames()`;
- brak użycia lokalnej zmiennej `$PID`;
- nie wykonano runtime testu PowerShell 5.1 tutaj.

### Decyzja operacyjna
Nie uruchamiać jeszcze 24 h na wersji 1.5 z `-Port COM5`, ponieważ została wykazana konkretna wada walidacji dostępności portu. Użycie 1.7 jest właściwą ścieżką po podmianie pliku. Nadal nie ma potrzeby zmiany firmware.

### Następny krok
Operator pobiera `R188_CAPTURE_1.7_FIXED.ps1`, umieszcza w katalogu projektu, uruchamia bez `-Port` i oczekuje automatycznego wskazania `COM5`. Następnie wykonuje właściwy 24 h R188.

## R210 — SKRÓCONA SESJA R188: WYNIK I KLASYFIKACJA RESETÓW
**Data:** 2026-09-25

### Pakiet
`R188_20260925_083156.zip` — SHA-256 `3745fd8309a8cf1d2cc943e4ba9f5fd610e3f13a8f50d9c1ac71088df2891d6d`.

### Czas / capture
T0 `2026-09-25 08:31:56.867`; T1 `2026-09-25 14:19:16.672`; czas `5 h 47 min 19.805 s`.
COM5, 115200, `R188-CAPTURE-1.7`, 1,642,370 B, 654 HEALTH, operator ENTER.

### Reset evidence
Raw log: 6 reset markers = 1x `POWERON` + 5x `RTC_SW_CPU_RST`.
Każdy restart #2–#6 ma po starcie `tag=BOOT ... powod=SW`.
Raw log zawiera 5 komunikatów `Aktualizacja pobrana OK. Restart za chwile...` oraz jawne potwierdzenia kolejnych wersji, w tym `v3.12.0` i `v3.13.0`.

**Wniosek:** dostępny dowód silnie wspiera interpretację, że 5 resetów SW było następstwem zamierzonych aktualizacji firmware/OTA. Nie oznacza to zaliczenia 24 h baseline; w czasie sesji zmieniała się wersja firmware.

### HEALTH
heap min 99,220 B / max 118,212 B; largest block min 6,684,660 B / max 6,815,732 B. `tg=1` w próbkach; `wifi=0` występowało chwilowo; `fb=0` występowało w fazie inicjalizacji, później `fb=1`.

### Negative evidence
W prostym grep całego raw: `PANIC=0`, `coredump=0`. Traktować jako "nie znaleziono w przechwyconym logu", nie jako absolutny dowód.

### Klasyfikacja
`R188_CAPTURE_1.7_RUNTIME = PASS`.
`R188_SHORT_SESSION = VALID PARTIAL EVIDENCE`.
`R188_24H_SINGLE_VERSION_BASELINE = NOT ACHIEVED`.
`GATE_A0 = YELLOW`.

### Następna decyzja
Ponieważ użytkownik nie może prowadzić 24 h, dalsza metodyka może użyć jawnie nazwanej `SHORT_BASELINE` na jednej zamrożonej wersji firmware. Nie wykonywać kolejnych OTA w tej samej sesji baseline. Nie pozwolić, aby częściowa sesja została przedstawiona jako pełny 24 h PASS.

## R211 — HANDOFF DO NOWEJ ROZMOWY
**Data:** 2026-09-25

Utworzono `R188_HANDOFF_20260925.md` jako zwartą kotwicę ciągłości. Plik zawiera cel projektu, aktualny stan, historię decyzji, architekturę telemetryki, wyniki R188, analizę resetów, artefakty/hashes, otwarte problemy i gotową wiadomość startową do nowego czatu.

SHA-256 handoffu: `231a6375421412114269f3945d5914a2ae8239d4d58f6cba048f1d0a90716fb8`.

W nowym czacie należy zacząć od odczytu `R188_HANDOFF_20260925.md`, następnie `R188_MASTER_STATE.md`, a dopiero w razie potrzeby czytać pełny `TELEMETRIA_RESEARCH_PLAN.md` i źródła.


## R212 — SHORT_BASELINE v3.13.0 / zamknięcie decyzji po R210
**Data:** 2026-09-25

### Kontekst
R210 dał 5 h 47 min materiału i 654 wpisy HEALTH, ale w jednej sesji wystąpiło 5 kontrolowanych restartów po OTA oraz zmiana wersji firmware. Materiał jest wartościowy jako partial evidence, lecz nie jest single-version baseline.

### Decyzja
Wprowadzamy jawnie nazwany tryb `SHORT_BASELINE` zamiast próbować sztucznie zaliczyć 24 h.

Zakres:
- firmware zamrożony na `v3.13.0`;
- minimum 6 h ciągłego capture;
- bez OTA/restart/upload/erase i bez zmian ustawień automatyki;
- brak nieoczekiwanych restartów/WDT/PANIC/coredump w materiale;
- zachowanie pełnego pakietu dowodowego;
- kontrola ciągłości HEALTH (~30 s) oraz trendu `heap_free_B` i `largest_free_block_B`;
- analiza ma rozróżniać brak dowodu od dowodu braku zdarzenia.

### Znaczenie gate
Udany `SHORT_BASELINE` **nie zmienia** definicji `GATE_A0 GREEN` dla pełnego 24 h baseline. Pozwala natomiast, jako osobna świadoma decyzja metodologiczna, odblokować przygotowanie/uruchomienie `Commit A`, którego zakres pozostaje niezmieniony: diagnostyka/model/ring/identity, bez nowych RTDB writes.

### Ustalenie dokumentacyjne
`R188_MASTER_STATE.md` ma historycznie w §4 `v3.11.4`, podczas gdy dostarczony `main_centrala.cpp` i najnowszy runtime wskazują `v3.13.0`. W kolejnej wersji dokumentu należy poprawić wartość bieżącą, pozostawiając wcześniejsze wpisy historii bez zmian.

### Operator
```powershell
powershell -ExecutionPolicy Bypass -File ".\\R188_CAPTURE_1.7_FIXED.ps1" -Port COM5
```
Po starcie `R188 AKTYWNE` utrzymać sesję minimum 6 h bez ingerencji. Następnie ENTER i dostarczyć pakiet sesji.

### Status po R212
`R188_CAPTURE_1.7_RUNTIME = PASS`
`R188_SHORT_BASELINE = PENDING`
`R188_24H_SINGLE_VERSION_BASELINE = NOT ACHIEVED`
`GATE_A0 = YELLOW`
`COMMIT_A = BLOCKED UNTIL SHORT_BASELINE PASS`

## R213 — COMMIT A PREFLIGHT / INWENTARYZACJA ISTNIEJĄCEJ DIAGNOSTYKI
**Data:** 2026-09-25

### Cel
Przygotować implementację Commit A bez wykonywania zmian firmware przed zakończeniem `SHORT_BASELINE`.

### Potwierdzone w `main_centrala.cpp`
1. `diagCheckpoint()` już zapisuje `freeHeap`, `largestBlock` i `stackHwmWords` dla stanów diagnostycznych tasków.
2. `HEALTH` w `loop()` działa około co 30 s i zapisuje `heap`, `largest`, `tg`, `wifi`, `fb`.
3. `g_fbLoopWorkerZajety` / `fbLoopWorkerZajety()` stanowi istniejący single-flight guard ścieżki `fbApp.loop()`.
4. Główne taski projektu to `tgTask`, `tgPollTask`, `historiaTask`; są tworzone dynamicznie na Core 0.
5. `fbLoopWork` jest taskiem pomocniczym uruchamianym tylko na potrzeby ograniczonego czasowo oczekiwania na Firebase; `dnsLookup` jest analogicznym workerem dla wybranych operacji DNS.

### Decyzja implementacyjna
Commit A ma być minimalną instrumentacją. Nie wolno dublować istniejących checkpointów i nie wolno przy tej okazji zmieniać częstotliwości ani semantyki dotychczasowego `HEALTH`.

### Zakres A — DO WYKONANIA PO SHORT_BASELINE
```text
[ ] internal heap free
[ ] internal largest block
[ ] internal minimum-ever
[ ] PSRAM free
[ ] PSRAM largest block
[ ] PSRAM minimum-ever
[ ] task stack HWM
[ ] Firebase taskCount — tylko po potwierdzeniu dostępnego API biblioteki
[ ] telemetry counters placeholder
```

### Zakres A — ZABRONIONY
```text
[ ] TelemetrySample
[ ] TelemetryRing
[ ] Firebase telemetry write
[ ] nowy RTDB path
[ ] persistent spool
[ ] freshness metadata
[ ] record identity
[ ] nowy TelemetryTask
```

### Istotna uwaga
Obecne `diagCheckpoint()` nie daje jeszcze pełnego obrazu PSRAM ani globalnych low-watermarków. Commit A ma więc przede wszystkim rozdzielić:
- pamięć wewnętrzną od PSRAM,
- bieżący pomiar od minimum-ever,
- diagnostykę tasków od transportu telemetrycznego.

### Bramka
`R213 = DESIGN/PREFLIGHT READY`
`SHORT_BASELINE = PENDING`
`FIRMWARE = UNCHANGED`


# R214 — COMMIT A IMPLEMENTATION
**Data:** 2026-09-25
**Status:** `STATIC_CHECKED / RUNTIME_PENDING`

## 214.1 Cel
Wprowadzić wyłącznie instrumentację potrzebną do pomiaru kosztu pamięci i stosów przed powstaniem `TelemetryRing`.

## 214.2 Implementacja
Dodano:
- `RuntimeDiagState`;
- `diagRuntimeSnapshot()`;
- INTERNAL free/largest/minimum;
- PSRAM free/largest/minimum;
- HWM dla czterech głównych tasków;
- `fbAsyncClient.taskCount()`;
- `g_telemetrySamplesProduced` = 0;
- `g_telemetrySamplesDropped` = 0;
- osobny log `tag=HEALTH-A`.

Istniejący `tag=HEALTH` nie został zmieniony, aby zachować bezpośrednią porównywalność z logami R188.

## 214.3 Dlaczego HWM jest w bajtach
Dla ESP32-S3 dokumentacja ESP-IDF v5.5 mówi wprost, że `uxTaskGetStackHighWaterMark()` zwraca minimalną wolną pamięć stosu w bajtach. Nie wykonujemy dodatkowego mnożenia przez rozmiar słowa. 

## 214.4 Firebase taskCount
`AsyncClientClass::taskCount()` jest udokumentowane jako odczyt liczby zadań przechowywanych w kolejce klienta. Zostało dodane wyłącznie jako obserwacja diagnostyczna; nie tworzy nowego zadania telemetrycznego ani nowego requestu.

## 214.5 Walidacja
- baseline źródła zachowany;
- diff zawiera wyłącznie wpis changelogu, bump wersji, stan diagnostyczny, snapshot oraz `HEALTH-A`;
- balans delimiterów diffu: PASS;
- brak `TelemetryRing`, `Database.update` i nowego endpointu wynikających z Commit A;
- build PlatformIO: **PENDING**;
- runtime v3.14.0: **PENDING**.

## 214.6 Następny test
```text
cold boot
  -> 30 min normal network
  -> 30 min WiFi OFF
  -> 30 min WiFi ON
  -> analiza HEALTH + HEALTH-A + resetów
```

Bez OTA w czasie testu.

## 214.7 Exit criteria
```text
build PASS
OTA slot PASS
no RTDB telemetry writes
no WDT regression
no unexplained heap regression
no unexplained stack regression
no scheduler/control regression
```

Po spełnieniu exit criteria otwieramy Commit B.

# R215 — COMMIT B PREFLIGHT / DOMKNIĘCIE MODELU DANYCH
**Data:** 2026-09-25
**Status:** `DESIGN FREEZE / READY FOR IMPLEMENTATION`

## 215.1 Runtime evidence po Commit A

`v3.14.0` został uruchomiony na centrali jako `boot=26` i pozostawał na tej samej wersji podczas ostatniej obserwacji.

Krótka sesja runtime (około 20 min) pokazała:
- `HEALTH-A` działa okresowo;
- INTERNAL/PSRAM mają stabilny obraz bez trwałej degradacji;
- HWM tasków pozostaje stabilny;
- przejściowy `fb_tasks=1` i chwilowy spadek INTERNAL wróciły do wartości bazowych;
- brak restartu/PANIC w obserwowanym oknie;
- placeholdery telemetryczne pozostały `0` zgodnie z zakresem A.

Ta sesja NIE jest 24h baseline. `R188_24H_SINGLE_VERSION_BASELINE` pozostaje `NOT ACHIEVED`; wcześniejsza sesja R188 jest tylko `VALID PARTIAL EVIDENCE`.

## 215.2 Najważniejsza korekta względem skrótu R170.3

Wcześniejszy skrót:

```text
Commit B = TelemetrySample 80 B + hasGoodValue + lastAttempt/lastGood
```

jest interpretowany od tej pory dokładniej:

```text
TelemetrySample 80 B
    = binarny rekord pomiarowy

SensorFreshnessState[11]
    = lokalna metadata runtime źródeł
```

`hasGoodValue`, `lastAttemptMs`, `lastGoodMs`, `sourceState` NIE są dokładane do 80-bajtowego rekordu.

Powód: 80 B jest zamrożonym layoutem binary sample i ma pozostać stabilny przed Commit C. Metadata potrzebna wyłącznie do wyliczenia `qualityBits`/`ageS` nie musi być powtarzana w każdej próbce.

## 215.3 Zamrożony layout `TelemetrySample`

```cpp
struct TelemetrySample {
    uint64_t sessionNonce;
    uint32_t sampleSeq;
    uint32_t unixTs;
    uint32_t monoMs;

    int16_t tZewnX10;
    int16_t tBojlerX10;
    int16_t tOgrzX10;
    int16_t tOgrzSrX10;
    int16_t tPowrotX10;
    int16_t tPanelX10;
    int16_t tPokojX10;
    int16_t tTrocinyX10;
    int16_t rhX10;
    int16_t pressureX10;

    uint16_t dym;
    uint8_t klapaDeg;
    uint8_t syberekDeg;

    uint16_t stateBits;
    uint32_t qualityBits;
    uint16_t simulatedBits;

    uint16_t ageS[11];
};
```

Kontrakt ABI:

```text
sizeof(TelemetrySample) == 80
```

Implementacja B musi zawierać `static_assert(sizeof(TelemetrySample) == 80)`.

## 215.4 Kanały — kolejność jest kontraktem

```text
0  t_zewn
1  t_bojler
2  t_ogrz
3  t_ogrz_sr
4  t_powrot
5  t_panel
6  t_pokoj
7  t_trociny
8  rh
9  pressure
10 dym
```

Ta kolejność musi być identyczna w:
- `qualityBits`;
- `simulatedBits`;
- `ageS[]`;
- snapshot builderze;
- testach.

## 215.5 Lokalny stan freshness

Wprowadzamy jeden, jawny model dla wszystkich kanałów:

```cpp
struct TelemetryFreshnessState {
    uint64_t lastAttemptMonoMs;
    uint64_t lastGoodMonoMs;
    bool     hasGoodValue;
    uint8_t  sourceState;
    bool     lastGoodWasSimulated;
};
```

11 elementów w zwykłej pamięci INTERNAL jest akceptowalne; nie trafiają one do PSRAM ani do przyszłego wire payloadu.

Semantyka:

```text
NO_ATTEMPT
INVALID
REJECTED
ACCEPTED
SIMULATED
```

`lastGoodWasSimulated` pozwala zachować uczciwość po zakończeniu symulacji: ostatnia używana wartość może pozostać oznaczona jako symulowana i z czasem przejść FRESH -> STALE, ale nie staje się automatycznie „świeżym pomiarem fizycznym”.

## 215.6 `qualityBits` i `ageS`

Dla każdego kanału:

```text
00 FRESH
01 STALE
10 UNKNOWN
11 INVALID
```

```text
ageS:
0..65534 = wiek ostatniej zaakceptowanej wartości w sekundach
65535    = brak zaakceptowanej wartości / wiek nieznany
```

`ageS` jest liczone z 64-bitowego zegara monotonicznego metadata, nie z `monoMs` sample, aby uniknąć problemu zawinięcia `millis()` w długiej pracy.

Do krótkiego pomiaru czasu snapshotu można użyć `esp_timer_get_time()`, którego kontrakt ESP-IDF 5.5 określa jako mikrosekundy od inicjalizacji ESP Timer. citeturn292820search0

## 215.7 Stale thresholds V1

```text
DS18B20 / temperatury     10 s
DHT RH                    10 s
BMP pressure              15 s
ogrz_sr                  dziedziczenie z najnowszego źródła użytego w wyniku
dym                      semantyka state-driven; bez prostego 3× scheduler
```

Są to wyłącznie progi telemetryczne. Nie zmieniają schedulerów, filtrów ani logiki sterowania.

## 215.8 Źródło → metadata dla DS18B20

Aktualny `odczytajTemperature()` rozróżnia:

```text
brak gotowej próby
próba invalid (zakres / 85°C / brak odpowiedzi)
próba odrzucona przez filtr rate-of-change
próba zaakceptowana
symulacja
```

Commit B nie zmienia zwracanej wartości ani decyzji sterowania. Dodaje jedynie wynik statusowy dla metadata freshness.

Wymóg implementacyjny: rozszerzenie `zastosujFiltrWiarygodnosci()` o jawny wynik statusu zamiast zgadywania na podstawie równości wartości.

## 215.9 DHT RH

`wilgotnosc()` wykonuje rzeczywisty odczyt DHT albo aktywną symulację.

Kontrakt B:

```text
read OK        → ACCEPTED/SIMULATED
read failure   → nie rusza lastGood
                 → STALE, jeżeli istnieje lastGood
                 → UNKNOWN, jeżeli brak historii
```

`wilgotnoscOdczytana` pozostaje wartością surową. `wilgotnoscSkorygowana` nie staje się nagle główną telemetryką kanału RH.

## 215.10 Pressure

`cisnienie()` już lokalnie sprawdza `NaN` i przy błędzie pozostawia poprzednią wartość. Commit B dodaje tylko metadata:

```text
finite result → ACCEPTED
NaN           → brak nowego lastGood
simulation    → SIMULATED
```

## 215.11 Dym

Dla `dym` źródłem świeżości pozostaje istniejące `czujnikDymuSwiezyOdczyt` plus stan bramki:

```text
świeży ADC/symulacja → ACCEPTED/SIMULATED
warm-up / sensor OFF → brak nowej próbki, age nie resetuje się
invalid ADC           → brak nowego lastGood
```

`stateBits` zachowuje:

```text
BIT0 PUMP_ON
BIT1 SMOKE_ALARM
BIT2 SMOKE_SENSOR_ENABLED
```

Nie dodajemy Wi-Fi ani wielowriterowych alarmów do tego bitfielda.

## 215.12 `t_ogrz_sr` — ważny detal implementacyjny

`temperaturaOgrzewaniaSrednia` jest wartością pochodną.

Nie wolno robić:

```text
obliczanie_srednia() uruchomiło się
→ FRESH
```

Metadata tej wartości musi pochodzić z **rzeczywistych źródeł wykorzystanych w danym wyniku**.

Dlatego przy implementacji B należy śledzić metadata razem z istniejącymi buforami średniej:

```text
Tryb 1: odczytCyklu1[]
       + timestamp/source metadata dla każdej z 5 próbek

Tryby 2/3: rolling odczyt[4]
           + timestamp/source metadata dla każdej pozycji
```

Gdy wynik średniej zostaje zaakceptowany:

```text
lastGood = najnowszy lastGood spośród materiału faktycznie użytego w wyniku
simulated = informacja wynikająca z materiału użytego w wyniku
```

Gdy algorytm zatrzymuje stary wynik z powodu odrzuconej średniej:

```text
nie odświeżamy lastGood
```

To jest konieczne, aby nie produkować fałszywego FRESH tylko dlatego, że funkcja średniej wykonuje się co ~2,2 s.

## 215.13 `sessionNonce`

`sessionNonce` jest 64-bitowym identyfikatorem bieżącej sesji/bootu, nie sekretem.

ESP32-S3 udostępnia `esp_random()`. Oficjalna dokumentacja ESP-IDF 5.5 podaje, że przy aktywnym RF (Wi-Fi/Bluetooth) generator korzysta z ciągłej entropii sprzętowej. citeturn368232search0

Ponieważ centrala używa Wi-Fi, generowanie nonce po uruchomieniu warstwy systemowej pozostaje zgodne z przyjętym modelem. Nie zapisujemy nonce do NVS przy każdym boocie.

## 215.14 `sampleSeq`

Właścicielem jest wyłącznie producent telemetryki w Core 1.

Kolejność:

```text
snapshot
→ sampleSeq++
→ sample gotowy
```

Numer nie jest cofany po przyszłym overflow ringa. Wskazane jest jawne ujawnienie dropów w Commit C.

## 215.15 Snapshot builder

B powinien udostępnić czystą funkcję logiczną o charakterze:

```cpp
TelemetrySample zbudujTelemetrySnapshot(uint64_t nowMonoMs,
                                        uint32_t unixTs,
                                        bool timeTrusted);
```

Ważne zasady:

```text
brak String
brak JSON
brak Firebase
brak LittleFS
brak I/O
brak oczekiwania na sieć
```

Snapshot ma być testowalny bez transportu.

## 215.16 Moment wykonania w `historiaZapiszProbke()`

Pozostaje:

```text
pobierzCzas()
↓
timeTrusted = jeden snapshot flagi czasu
↓
TelemetrySample = zbuduj...
↓
historiaMux dla istniejącej historii
↓
brak telemetrycznego transportu
```

W Commit B nie ma jeszcze `telemetryPush()` ani ringu. Można przechować jedną ostatnią próbkę w zwykłej pamięci wyłącznie do testów/runtime diagnostics.

## 215.17 Rollback / granica B

B nie może zmieniać:

```text
hist_long / hist_short
NVS
LittleFS
Firebase
OTA
partycji
scheduler intervals
sterowania pompą/serwami
```

Nie tworzymy:

```text
TelemetryRing
TelemetryTask
JSON serializer
Firebase telemetry request
persistent spool
```

## 215.18 Kryteria PASS Commit B

```text
build PASS
static_assert TelemetrySample == 80 B
sample builder generuje deterministyczny snapshot
quality/age zgodne z test vectors
simulation nie udaje świeżego pomiaru fizycznego po zakończeniu
DS18B20 reject → STALE, nie świeży
DHT/BMP failure → lastGood pozostaje bez zmian
dym OFF/warmup → age nie resetuje się
ogrz_sr nie odświeża freshness samym wywołaniem funkcji
brak Firebase/LittleFS/ringa
brak dodatkowego taska
brak obserwowalnej zmiany automatyki
```

## 215.19 Następny krok

Po tym freeze można przygotować `v3.15.0` jako **Commit B — DATA MODEL ONLY**.

Pierwszy build/runtime B ma być mierzony względem aktualnego `v3.14.0`, a po PASS dopiero otwieramy Commit C (SPSC PSRAM ring).

`CURRENT = v3.14.0 / COMMIT-A RUNTIME OBSERVED`
`NEXT = v3.15.0 / COMMIT-B IMPLEMENTATION`

## R215.20 Dodatkowe domknięcie polityki freshness dla `dym`

Aktualny firmware ma parametry konfigurowalne:

```text
dymCzasOn = 130 s
dymCzasOff = 60 s
dymCzasStabilizacji = 90 s
```

Nie należy wpisywać na stałe do telemetryki jednej liczby typu `180 s`, ponieważ użytkownik może zmienić `dymCzasOff` i `dymCzasStabilizacji` z panelu.

Dla V1 freshness dymu ma więc być wyprowadzane dynamicznie z aktualnego trybu pracy i konfiguracji, z dodatkowym marginesem na taktowanie `pozar()`:

```text
TRYB CIĄGŁY:
    próg oparty o kilka nominalnych wywołań `pozar()`

TRYB IMPULSOWY:
    próg >= dymCzasOff + dymCzasStabilizacji + mały margines schedulerowy
```

To nadal pozostaje wyłącznie metadanymi telemetrycznymi. Parametry sterowania nie są przez telemetrykę zmieniane.

`SMOKE_SENSOR_ENABLED=0` pozostaje osobnym wyjaśnieniem stanu, a nie substytutem `qualityBits`.

## R215.21 Aktualna bramka przed kodem B

Po powyższym audycie model jest traktowany jako zamknięty:

```text
80-B binary sample
+
11-element freshness sidecar
+
2-bit quality/channel
+
16-bit age/channel
+
simulation provenance
+
64-bit session identity
+
32-bit sample sequence
```

Pozostaje przygotowanie dokładnego patcha `v3.15.0` oraz jego walidacja statyczna. W tej chwili **nie wykonujemy uploadu na centralę**.


## R216 — COMMIT B STATIC AUDIT / KOREKTY v3.15.1
**Data:** 2026-09-25

### Punkt startowy
v3.15.0 był przygotowany jako Commit B / DATA MODEL ONLY: `TelemetrySample` + sidecar freshness + snapshot builder, bez Firebase, JSON, LittleFS, ringu i `TelemetryTask`.

### Wyniki audytu statycznego
W źródle `main_centrala.cpp` znaleziono trzy rozjazdy względem zamrożonego kontraktu R215:

1. **TV13 / zegar freshness:** `lastAttemptMs` / `lastGoodMs` były `uint32_t` i były zasilane z `millis()`. To nie spełniało wymagania długoterminowego age bez wrap ~49.7 dnia.
2. **TV10 / koniec symulacji:** `lastGoodSimulated=true` pozostawało samo w sobie niewystarczające do rozróżnienia aktywnej symulacji od wygasłej. Po wygaśnięciu poprzednia wartość mogła pozostać FRESH do zwykłego progu wieku.
3. **Kontrakt `stateBits` / identity:** snapshot zawierał dodatkowe bity czasu/RTC, a generowanie `sessionNonce` było zależne od stanu WiFi.

### Naprawa
Przygotowano `main_centrala_v3.15.1_COMMIT_B.cpp`:
- metadata freshness używa `uint64_t` z `esp_timer_get_time()` w milisekundach;
- `TelemetrySample.monoMs` pozostaje `uint32_t`, zgodnie z ABI 80 B;
- dodano `telemetrySimulationActive()`; przechowywana wartość symulowana jest STALE natychmiast po wygaśnięciu symulacji, a `simulatedBits` pozostaje ustawiony do czasu przyjęcia wartości fizycznej;
- `stateBits` ograniczono do `PUMP_ON`, `SMOKE_ALARM`, `SMOKE_SENSOR_ENABLED`;
- `sessionNonce` jest generowany z dwóch wywołań `esp_random()` bez warunku `WiFi.status()`;
- wersję firmware podniesiono zgodnie z obowiązkową zasadą changelogu: `v3.15.0` → `v3.15.1`.

### Walidacja
- dokładny `TelemetrySample` ze źródła kompiluje się w hostowym teście C++ z aktywnymi `static_assert`: `sizeof == 80`, `ageS offset == 54`;
- mini-harness potwierdził TV02, TV04, TV10, TV13, TV15, TV16, TV17;
- kontrola statyczna nie znalazła pozostałych wywołań `telemetryMarkAttempt()` / `telemetryMarkAccepted()` z `millis()` jako źródłem czasu telemetrycznego;
- **pełny PlatformIO/ESP-IDF build nie został wykonany**, ponieważ w środowisku analizy nie ma `pio` ani `arduino-cli`.

### Status
`R216 = COMMIT_B_STATIC_AUDIT_PASS_WITH_FIXES`
`FIRMWARE = v3.15.1 (nie wgrywany)`
`RING = nadal NIEZAIMPLEMENTOWANY`
`FIREBASE TELEMETRY = nadal NIEZAIMPLEMENTOWANA`
`GATE_A0 = YELLOW`
`NEXT = review v3.15.1 → faktyczny build na Windows → dopiero potem Commit B/Ring`

### Artefakty
- `main_centrala_v3.15.1_COMMIT_B.cpp`
- `COMMIT_B_v3.15.1_STATICFIX.patch`
- `COMMIT_B_TEST_REPORT_R216.md`
- `R216_SHA256_MANIFEST.txt`

Nie wykonywać uploadu tylko na podstawie audytu statycznego.


## R223 — aktualizacja ciągłości po v3.17.0 WDT i uruchomieniu v3.18.0
**Data:** 2026-09-26

### Stan po R221
v3.17.0 po krótkim runtime początkowo poprawnie wysyłał telemetryczne batche do Firebase. Weryfikacja RTDB wykazała poprawną strukturę rekordów pod `/piec/telemetry/1m/v1`. Test wykonano na pustej płytce bez czujników; `age[11]=65535` oraz zastępcze wartości `a[]` są w tym środowisku oczekiwane.

### Nowe dowody WDT
Późniejszy runtime v3.17.0 ujawnił serię TASK_WDT: coredumpy seq11–16. Matching `firmware.elf` pozwolił wskazać konkretne ścieżki:
- seq11 / boot2: `tgTask` w `HTTPClient::handleHeaderResponse()` podczas `DESZCZ -> http.GET()`;
- seq12 / boot3: `tgPollTask` w `ssl_starttls_handshake()` podczas Telegram `NetworkClientSecure::connect()`;
- seq13–15: kolejne resety w `TG_CONNECT` workerów Telegrama;
- seq16: reset w `tgTask` przy `FB_SEND`.

Wniosek: problemem było sprzężenie blokujących operacji sieciowych z per-task TASK_WDT=15 s. Timeouty HTTP/TLS nie są twardą gwarancją całkowitego czasu wall-clock na poziomie wszystkich niższych wywołań.

### R222 / v3.18.0
Przygotowano zmianę wyłącznie dla workerów sieciowych:
- `tgTask` nie rejestruje się już przez `esp_task_wdt_add(NULL)`;
- `tgPollTask` nie rejestruje się już przez `esp_task_wdt_add(NULL)`;
- globalny TWDT oraz WDT zadań sterujących pozostają;
- dodano heartbeat/state workerów i raportowanie w `HEALTH-A`;
- nie zmieniono `TelemetrySample`, `TelemetryRing`, wire schema, retry/commit ani sterowania.

### Build v3.18.0
Operator potwierdził PASS dla:
- `esp32-s3-n16r8`;
- `esp32-s3-ota`.

Źródło: `main_centrala_v3.18.0_NETWORK_WDT_DECOUPLED.cpp`.
SHA-256: `8895f243a6c45b07b843f1bca5aa49011ff9adfaca31798bee7ad19eedc66401`.

### R223 runtime
Test v3.18.0 na pustej płytce jest obecnie **W TOKU**, planowo około 30 min. Nie traktować jeszcze jako PASS.

### Reguła interpretacji
Brak podłączonych czujników oznacza, że `ageS=65535` jest prawidłowym `UNKNOWN` dla wszystkich kanałów, dopóki nie pojawi się last-good. Nie wykorzystywać pustej płytki do oceny poprawności fizycznych wartości sensorów.

### Następny krok
Po zakończeniu R223 analizować cały capture i ewentualne coredumpy. Jeżeli R223 przejdzie bez WDT/resetów, dopiero wtedy kontynuować testy niezawodności telemetryki; nie łączyć z tym krokiem migracji auth/TLS, upgrade FirebaseClient ani persistent spool.
