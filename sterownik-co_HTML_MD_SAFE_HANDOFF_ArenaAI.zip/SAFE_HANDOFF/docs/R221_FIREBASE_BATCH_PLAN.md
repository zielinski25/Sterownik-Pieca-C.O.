# R221 — pierwszy transport telemetryki Firebase
Data: 2026-09-26

## Stan wejściowy
- v3.16.0 / PSRAM TelemetryRing: runtime PASS obserwacyjny (~29 min).
- telemetry_produced=28, telemetry_dropped=0.
- 0 TASK_WDT, 0 PANIC, 0 resetów, 0 coredumpów.
- Gate A-0: YELLOW.

## Zakres v3.17.0
Pierwszy transport cloud, bez persistent spool i bez agresywnego backlog drain.

### Kontrakt
- jeden `AsyncResult` telemetryczny;
- jeden in-flight request telemetryczny;
- istniejący `fbAsyncClient` / `fbApp`;
- istniejący globalny guard `fbLoopWorkerZajety()`;
- `RealtimeDatabase.update<object_t>()` na bazie `/piec/telemetry/1m/v1`;
- batch maks. 10 rekordów;
- logiczny limit payloadu 6144 B;
- roboczy bufor JSON 8192 B w PSRAM;
- compact fixed-point JSON;
- `ts=0` → shard `unknown`;
- retry zachowuje rekordy w ring;
- `tail` przesuwany wyłącznie po pełnym SUCCESS.

## Wire V1
Rekord:
`seq`, `ts`, `mono`, `a[11]`, `k`, `s`, `state`, `q`, `sim`, `age[11]`.

`sessionNonce` nie jest powtarzany w payloadzie; występuje w `record_id`.

## Bezpieczne zachowanie
Timeout/error nie usuwa próbek. Najstarszy batch pozostaje na początku ringu i może zostać wysłany ponownie.

## Nie obejmuje
- Firebase Rules produkcyjnych;
- auth/TLS migration;
- persistent spool;
- adaptive batch 5/10/20;
- cross-midnight soak;
- benchmarków finalnej pamięci FirebaseClient;
- upgrade FirebaseClient/toolchain.

## Następny krok operatora
Build only:
`pio run -e esp32-s3-n16r8`

Nie uploadować przed przeglądem wyniku builda.
