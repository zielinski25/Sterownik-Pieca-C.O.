# ESP32 CENTRALA — HANDOFF R220
Data: 2026-09-26

## Current state
- Runtime fix v3.15.2: observation PASS for 30 min 12 s, no WDT/PANIC/reset in capture.
- Gate A-0: YELLOW.
- Commit B model: implemented and statically validated.
- Next implementation: v3.16.0 PSRAM SPSC TelemetryRing.

## v3.16.0
- 1440 x 80 B = 115200 B PSRAM.
- SPSC, no mutex, head/tail atomics acquire/release.
- Producer attached to `historiaZapiszProbke()` after snapshot build.
- `sampleSeq` allocated before push and never reused after drop.
- Full ring => increment `g_telemetrySamplesDropped`; successful enqueue => `g_telemetrySamplesProduced`.
- No Firebase/JSON/LittleFS/TLS/DNS/task creation in push path.
- Future consumer must use `peek()` then successful batch handling and only then `commitPop()`.

## Next operator action
Build only:
`pio run -e esp32-s3-n16r8`

Do not upload yet. Review build output before hardware test.
