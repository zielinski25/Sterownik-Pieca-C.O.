# R252 — Telemetria -> Persistent Spool V2 mirror (LOCAL ONLY)

## Cel
Potwierdzic, ze rzeczywisty `TelemetrySample` utworzony w normalnym producencie `historiaZapiszProbke()` moze zostac zapisany do zamrozonego formatu Spool V2, bez zmiany zachowania ring/Firebase gdy mirror jest nieuzbrojony.

## Zakres
- firmware lokalny: v3.21.2
- tylko pusta/testowa plytka ESP32-S3
- produkcyjny sterownik pozostaje v3.19.2
- plik testowy: `/telemetry_spool/r252_telemetry_mirror.bin`
- 3 kolejne rozne `sampleSeq`
- page: 64 B header + 3 x 84 B record + 64 B footer = 380 B
- CRC rekordu, CRC payloadu strony, footer commit
- przed uzbrojeniem brak zapisu spool
- hard quota sprawdzane przed rozpoczeciem testu

## Test
1. Wgrac v3.21.2 przez USB na pusta plytke.
2. Wpisac `/spool252 TAK`.
3. Poczekac na 3 kolejne normalne probki telemetryczne z `historiaZapiszProbke()`.
4. Wpisac `/spool252verify`.

## Oczekiwany PASS
`R252 telemetry mirror verify: PASS`
`size=380 records=3 realTelemetry=YES headerCRC=OK recordCRC=OK pageCRC=OK footerCommit=OK seq=<first>..<last>`

## Kryteria
PASS tylko gdy:
- `records=3`
- `realTelemetry=YES`
- seq sa rosnace i rozne
- `headerCRC=OK`
- `recordCRC=OK`
- `pageCRC=OK`
- `footerCommit=OK`
- rozmiar 380 B

FAIL gdy mirror zapisze mniej niz 3 rekordy, powtorzy ten sam `sampleSeq`, naruszy CRC albo quota admission zawiedzie.
