# ESP32 CENTRALA — HANDOFF R219
Data: 2026-09-26

## START HERE
Do not start the project from the beginning.
The current operational issue is a network/WDT stabilization defect discovered in R218.

## CURRENT
- Running central remains on **v3.15.1** unless operator has already changed it.
- v3.15.1 build: PASS.
- v3.15.1 runtime: FAIL, 3× TASK_WDT on `tgTask`.
- Commit B / TelemetryRing: blocked.

## KEY FINDING
The timeout helper introduced a real deadlock hazard:
- DNS timeout path could wait forever on the worker mutex.
- Firebase timeout path could wait forever on the worker mutex.
- Firebase success path had a context lifetime race.

Therefore the next change is not a telemetry change. It is v3.15.2 network/WDT hardening.

## ARTEFACT
`main_centrala_v3.15.2_NETWORK_WDT.cpp`
SHA-256: `6c3ae650146e52391582ac6680fe1aafc86fb3d4bfc77a10dcad1703dad48403`

`COMMIT_NETWORK_WDT_v3.15.2.patch`
SHA-256: `986de68365fd07935a8d70bbbd261268c355e4cd135fc1e4620cab5ac53ca30d`

## IMPORTANT
Do not raise the TWDT timeout as the fix.
Do not implement TelemetryRing yet.
Do not add Firebase telemetry.
Do not change TelemetrySample.

## OPERATOR STEPS
1. Put `main_centrala_v3.15.2_NETWORK_WDT.cpp` into the project as the source to build.
2. Run the normal PlatformIO build for `esp32-s3-n16r8`.
3. If build is SUCCESS, upload once over USB.
4. Run a 30–60 min controlled capture.
5. Return the build result + runtime report + any coredumps.
