# R252 HANDOFF

Stan poprzedni: R251 PASS/ZAMKNIETY.
Produkcja: v3.19.2, bez OTA.

## Nowy build lokalny
- v3.21.2
- artefakt: `main_centrala_v3.21.2_LOCAL_R252_TELEMETRY_SPOOL_MIRROR.cpp`
- patch: `COMMIT_v3.21.2_LOCAL_R252_TELEMETRY_SPOOL_MIRROR.patch`

## Nowa sciezka
`historiaZapiszProbke()` po poprawnym `TelemetryRing.push()` wywoluje test-only `spoolR252MirrorOnTelemetrySample()`.
Adapter jest aktywny tylko po `/spool252 TAK`.

## Komendy Telegram
- `/spool252`
- `/spool252 TAK`
- `/spool252verify`

## Test
Po `/spool252 TAK` czekac na 3 kolejne probki harmonogramu (HISTORIA_PROBKA_MS).
Nastepnie `/spool252verify`.

## Nie wykonywac
- nie OTA na piec
- nie uzywac produkcyjnego pliku spool
- nie wlaczac mirroru na produkcji
