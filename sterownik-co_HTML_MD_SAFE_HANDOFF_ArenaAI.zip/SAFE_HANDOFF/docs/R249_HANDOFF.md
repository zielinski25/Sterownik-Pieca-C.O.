# R249 HANDOFF

Build lokalny: v3.20.9

Komenda:
`/spool249 TAK`

Oczekiwany PASS:
`R249 full page: PASS`
`full page OK: size=64640 records=768 headerCRC=OK recordCRC=OK pageCRC=OK footerCommit=OK`

Test wyłącznie na pustej płytce.
Nie OTA na prawdziwy sterownik.
