# ESP32 CENTRALA — HANDOFF R222
Data: 2026-09-26

## Current state
- v3.17.0 Firebase batch worked for ~46 min on an otherwise empty board, but later runtime produced repeated TASK_WDT resets.
- Coredumps 11–16 plus matching `firmware.elf` identify network-worker blocking as the immediate cause.
- `TelemetryRing` remains implemented and runtime-tested.
- Firebase batch remains implemented and short-runtime tested.
- Do not continue with further telemetry features until v3.18.0 network/WDT runtime is validated.

## Next artifact
`main_centrala_v3.18.0_NETWORK_WDT_DECOUPLED.cpp`
SHA-256: 8895f243a6c45b07b843f1bca5aa49011ff9adfaca31798bee7ad19eedc66401

## Operator action
Build only first:
`pio run -e esp32-s3-n16r8`
`pio run -e esp32-s3-ota`

Do not upload until both builds are PASS.
