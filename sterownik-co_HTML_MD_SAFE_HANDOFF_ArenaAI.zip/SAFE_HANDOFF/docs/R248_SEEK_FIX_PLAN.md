# R248 FIX — v3.20.8

R248 poprzednio zatrzymal sie na blednym sprawdzeniu `File::seek()` przy ponownym otwarciu pliku R247.
W Arduino FS `File::seek()` zwraca bool (sukces/blad), wiec warunek porownujacy wynik z 64 byl niepoprawny.

Test po poprawce pozostaje identyczny: wejscie 272 B, 2 pelne rekordy + 40 B ogona, odrzucenie 40 B, zapis nowego rekordu #3, flush/close/reopen i pelna walidacja CRC.

## Kryterium PASS
`/spool248repair TAK` powinno zakonczyc sie `R248 recovery continue: PASS`, z `input=272B`, `validPrefix=232B`, `discardedTail=40B`, `output=316B`, `records=3`, `headerCRC=OK`, `recordCRC=OK`, `footer=ABSENT`.

Tylko lokalna pusta plytka. Produkcja pozostaje v3.19.2.
