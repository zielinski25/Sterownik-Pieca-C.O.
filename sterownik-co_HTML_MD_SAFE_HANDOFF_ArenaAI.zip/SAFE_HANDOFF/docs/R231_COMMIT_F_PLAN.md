# R231 — Commit F1: LittleFS / coredump hardening

Data: 2026-09-26

## Punkt startowy

- Produkcyjna centrala: v3.19.2, telemetryka V1 zamknieta i stabilna.
- R230: PASS.
- Nie zmieniamy telemetryki, Firebase, auth/TLS, automatyki ani partycji.
- Realny sterownik pozostaje bez OTA do czasu przejscia lokalnego gate'u F1.

## Cel F1

Naprawic dwa P0 wskazane w planie:

1. normalny boot nie moze automatycznie formatowac LittleFS po bledzie mount;
2. archiwizacja coredumpu ma miec bezpieczna granice:
   integrity check -> kopia `.part` -> sprawdzenie kazdego write -> pelny size -> rename -> dopiero erase zrodla.

## Zakres kodu

### F1.1 LittleFS safe mount

Usunieto automatyczne `LittleFS.begin(true)`.

Po bledzie `LittleFS.begin(false)`:
- `littlefsReady=false`;
- dane na partycji pozostaja nietkniete;
- normalny boot nie formatuje produkcyjnej partycji.

### F1.2 Coredump safe archive

`archiwizujCoredumpJesliCrash()`:

```text
bylCrash()
  -> esp_core_dump_image_check()
  -> esp_core_dump_image_get()
  -> /coredumps/dump_....bin.part
  -> sprawdzenie kazdego File::write()
  -> sprawdzenie lacznego rozmiaru
  -> close + ponowne otwarcie + size()
  -> rename(.part -> final)
  -> esp_core_dump_image_erase()
```

Jesli dowolny krok kopiowania/rename zawiedzie, zrodlo coredumpu pozostaje w partycji `coredump`.

Stary `.part` jest usuwany dopiero wtedy, gdy zaczynamy od nowa kopiowac ten sam zrzut z zachowanego zrodla.

## Zmieniona wersja

`FIRMWARE_VERSION = v3.19.3`.

Klasyfikacja: PATCH — brak zmiany zewnetrznego kontraktu telemetryki, RTDB, NVS i partycji.

## Artefakty

- `main_centrala_v3.19.3_COMMIT_F_FS_COREDUMP.cpp`
- `COMMIT_v3.19.3_COMMIT_F_FS_COREDUMP.patch`
- `R231_COMMIT_F_SHA256_MANIFEST.txt`

## Walidacja statyczna wykonana

PASS:
- brak wykonywalnego `LittleFS.begin(true)`;
- `esp_core_dump_image_check()` znajduje sie przed `esp_core_dump_image_get()`;
- zapis idzie do `.part`;
- kazdy `File::write()` jest sprawdzany;
- laczny zapis musi byc rowny rozmiarowi obrazu;
- size pliku `.part` jest sprawdzany po zamknieciu;
- `rename(.part -> final)` wystepuje przed `esp_core_dump_image_erase()`;
- przy bledzie archiwum finalne nie jest tworzone i zrodlo pozostaje zachowane;
- diff ogranicza sie do changelogu, wersji, funkcji archiwizacji coredumpu i mount LittleFS.

Build ESP32 nie zostal tutaj wykonany: w tym srodowisku brak kompletnego projektu PlatformIO / wykonywalnego `pio`.

## Gate lokalny

1. Backup obecnego `src/main.cpp`.
2. Wstaw `main_centrala_v3.19.3_COMMIT_F_FS_COREDUMP.cpp` jako `src/main.cpp`.
3. Build `esp32-s3-n16r8`.
4. Build `esp32-s3-ota`.
5. Dopiero po obu PASS: USB upload tylko na pustej plytce.
6. Normalny runtime lokalny: HEALTH + diagnostyka telemetryki.
7. Test `/testcrash TAK` dopiero po rozdzieleniu bota Telegram dla plytki testowej od prawdziwego pieca. Przy wspolnym bocie NIE wykonywac tej komendy.
8. Po bezpiecznym teście coredumpu sprawdzic `/coredumplist`, pobrac plik i zweryfikowac go narzedziem `esp-coredump` na PC.

## Gate produkcyjny

Dopiero po lokalnym PASS F1:

- przygotowac OTA v3.19.3;
- OTA na prawdziwy sterownik wylacznie przez istniejaca sciezke zdalna;
- po OTA obserwowac Telegram/logi;
- nie wykonywac `/testcrash TAK` na prawdziwym sterowniku.

## Cel nadrzedny po F1

Po zamknieciu F1 otwieramy F2: ujednolicone accounting LittleFS (`total/used/free`, historia, settings, panel firmware, coredumpy i pozostale pliki) przed projektowaniem persistent spool V2.
