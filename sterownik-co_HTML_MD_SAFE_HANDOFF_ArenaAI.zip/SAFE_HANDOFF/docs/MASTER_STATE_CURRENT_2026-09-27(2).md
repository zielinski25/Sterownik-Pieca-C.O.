# PIECO / Piec_CO — MASTER STATE — 2026-09-27

## 0. STATUS / HANDOFF

Stan zebrany ponownie od początku bieżącej serii prac Persistent Spool V2.
Ostatni potwierdzony runtime: **R313–R324 = PASS**.
Następny krok: **Commit G / R325–R334** na płytce testowej.

## 1. PRODUKCJA / SAFETY

- Produkcyjny sterownik / prawdziwy piec: **v3.19.2**.
- Produkcja: **OTA only**.
- Nigdy USB na prawdziwym sterowniku.
- Wszystkie v3.20.x+ / spool V2 / fault batch / Commit G są **LOCAL TEST ONLY** do czasu osobnego release gate.
- Nie wolno mieszać eksperymentów spool z produkcyjną automatyką.

## 2. ŁAŃCUCH COMMITÓW

```text
A = diagnostics
B = TelemetrySample / metadata
C = PSRAM SPSC ring
D = single Firebase batch
E = backlog / adaptive batch
F = LittleFS + coredump hardening
G = persistent spool V2
H = security / auth / TLS / Rules
I = library / toolchain upgrade
```

Commit G wchodzi dopiero po przejściu storage fault tests. H i I są osobnymi etapami i nie powinny być mieszane z G.

## 3. TELEMETRY V1 / DATA MODEL

- `TelemetrySample` ABI: **80 B**.
- `qualityBits`: `uint32_t`, 11 kanałów × 2 bity.
- `simulatedBits`: 16 bit.
- `ageS`: 16 bit.
- `sessionNonce` + `sampleSeq` są częścią stabilnej tożsamości próbki.
- `TelemetryRing`: SPSC, PSRAM, **1440 rekordów = 115200 B**.
- Producent: `historiaZapiszProbke()` / Core 1.
- Consumer Firebase: osobny drain / single-flight.
- `sampleSeq` jest przydzielany przed `push()` i nie jest cofany po dropie.
- Normalny producer nie wykonuje LittleFS/Firebase podczas `push()`.

## 4. FROZEN PERSISTENT SPOOL V2 ABI

```text
page:                 64 KiB
safe records:         768
record:               84 B
sample payload:       80 B
record CRC32:          4 B
header:               64 B
footer:               64 B
used at 768 records: 64640 B
slack at safe cap:    896 B
coverage @ 1/min:     12 h 48 min
```

Header kontraktowo zawiera m.in. magic, formatVersion, pageSeq, firstSampleSeq, recordBytes, capacity, timestamps i headerCRC.

Record = pełny `TelemetrySample` + CRC32 rekordu.

Footer zawiera m.in. pageSeq, first/last sample sequence, recordCount, payload/page CRC, commit marker i footerCRC.

Zasady:
- footer = commit marker;
- brak footeru = strona otwarta, ale odzyskiwalna do poprawnego prefiksu;
- niepełny/CRC-invalid rekord kończy valid prefix;
- uszkodzony header/footer/page CRC => reject;
- duplicate sequence => reject;
- `.part` musi być zweryfikowany przed rename;
- zły `.part` nie może nadpisać poprawnego final;
- FIFO po `page_sequence`;
- fizyczne `LittleFS.usedBytes()` jest źródłem quota; accounting logiczny jest diagnostyczny;
- spool nigdy nie odzyskuje miejsca przez kasowanie coredump/log/settings/history/panel firmware.

## 5. WRITE POLICY / REPLAY POLICY

Online:
```text
PSRAM ring -> Firebase
```

Offline/backpressure:
```text
PSRAM ring -> closed spool pages only when watermark requires
```

Nie mirrorować każdej próbki co minutę do flash.

Replay:
```text
oldest page
 -> batches max 10 records
 -> one Firebase request in flight
 -> full ACK
 -> advance replay cursor
 -> delete page only after full page ACK
```

Expected property: **at-least-once replay + deterministic record identity**, bez cichego przyjęcia uszkodzonego rekordu.

## 6. ZAMKNIĘTE TESTY R242–R252

### R242/R243
- benchmark strony 32/48/64 KiB;
- 64 KiB wybrano jako wariant bezpieczny dla 768 rekordów;
- geometry/ABI przeprowadzone do freeze.

### R244 — PASS
Frozen V2 application ABI: header 64 B / record 84 B / footer 64 B, 768 safe records.

### R245 — PASS
Pierwszy kontrolowany zapis + reopen/verify kompletnej strony testowej.

### R246 — PASS
Open page bez footeru; recovery poprawnego prefiksu.

### R247 — PASS
Rzeczywisty power-loss/restart:
```text
size=272 validRecords=2 tail=40B headerCRC=OK recordCRC=OK footer=ABSENT open=RECOVERABLE
```

### R248 — PASS
Recovery + continuation:
```text
input=272B validPrefix=232B discardedTail=40B output=316B records=3 headerCRC=OK recordCRC=OK footer=ABSENT continuedSeq=0xF2470003
```

### R249 — PASS
```text
size=64640 records=768 headerCRC=OK recordCRC=OK pageCRC=OK footerCommit=OK
```

### R250 — PASS
Corrupt record #2:
```text
validPrefix=1 badRecord=2 record2CRC=FAIL recovery=REJECT_BAD_RECORD
```

### R251 — PASS
Hard quota boundary:
```text
free=8667136 protected=5132099 quota=3535037 exact=ADMIT over1=REJECT
```

### R252 — PASS
Real telemetry mirror, po odczekaniu na 3 kolejne próbki:
```text
size=380 records=3 realTelemetry=YES headerCRC=OK recordCRC=OK pageCRC=OK footerCommit=OK seq=4..6
```

R252 potwierdza bezpieczne przeniesienie prawdziwego snapshotu telemetryki do formatu spool bez zmiany normalnego producenta/ringu/Firebase.

## 7. R253–R262 — PASS

```text
R253 PASS OK
R254 PASS size=262 records=2 tail=30
R255 PASS pageSeq=2551,2552,2553
R256 PASS badRecord=2 validPrefix=1
R257 PASS headerCRC=FAIL rejected
R258 PASS footerCommit=FAIL rejected
R259 PASS recordCRC=OK pageCRC=FAIL
R260 PASS page1=768 page2=1 seq-contiguous
R261 PASS .part verified -> rename -> final verified
R262 PASS usedDelta=4096 min=2816 protected=5131947
```

## 8. R263–R272 — PASS

```text
R263 PASS first=0xF2630001 last=0xF2630004 count=4
R264 PASS duplicateSeq=0xF2640001 badRecord=2 validPrefix=1
R265 PASS footerRecordCount=5 expected=4 rejected
R266 PASS footerPageSeq=9999 headerPageSeq=266 rejected
R267 PASS footer first/last mismatch rejected
R268 PASS size=297 trailing=1 rejected
R269 PASS bad .part rejected; final pageSeq=2690 preserved
R270 PASS sampleABI=80B byteExact=YES recordCRC=OK
R271 PASS qualityBits=0xA5A55A5A simulatedBits=0x0555 ageS=100..110 preserved
R272 PASS records=768 first=0xF2720001 last=0xF2720300 size=64640 footer=OK
```

## 9. R273–R282 — PASS

```text
R273 PASS sampleSeq=1 sessionNonce=<stable> byteExact=YES
R274 PASS seq=1,2,3 sessionNonce=STABLE
R275 PASS records=3 realBuilder=YES size=380 records=3 realTelemetry=YES headerCRC=OK recordCRC=OK pageCRC=OK footerCommit=OK seq=1..3
R276 PASS duplicate=IGNORED records=3
R277 PASS qualityBits=0xA5A55A5A simulatedBits=0x0555 ageS=100..110 byteExact=YES
R278 PASS produced=1 dropped=0 sent=1 transportErrors=0 unchanged=YES
R279 PASS sizes=148/232/380 footerAt3=YES
R280 PASS page=380B free=8654848 protected=5131184 quota=3523664 admit=YES
R281 PASS reopen+verify size=380 records=3 recovery=OK
R282 PASS records=768 coverage=12h48m bytes=64640
```

## 10. R283–R300 — PASS

```text
R283 PASS footer first mismatch rejected
R284 PASS footer pageSeq mismatch rejected
R285 PASS recordBytes mismatch rejected
R286 PASS capacity mismatch rejected
R287 PASS header magic rejected
R288 PASS formatVersion mismatch rejected
R289 PASS footer magic rejected
R290 PASS footer format rejected
R291 PASS footerCRC=FAIL rejected
R292 PASS size=297 trailing=1 rejected
R293 PASS records=1 tail=83 open=RECOVERABLE
R294 PASS records=0 tail=0 footer=ABSENT recoverable=YES
R295 PASS pageSeq=2951,2952,2953
R296 PASS first=4069916673 last=4069916676 next=4069916677
R297 PASS page1=768 page2=1 seq-contiguous
R298 PASS bad .part rejected; final pageSeq=2980 preserved
R299 PASS exact=ADMIT over1=REJECT quota=3362549
R300 PASS usedDelta=12288 min=800 physical=YES
```

Additional already confirmed in the same mega batch:
```text
R273 PASS byteExact=YES recordCRC=OK
R274 PASS deterministic=YES crc=1967420827
R275 PASS magic=OK format=1 bytes=64 record=84 capacity=768
R276 PASS footer fields validated by full-page scanner
R277 PASS records=1 pageSeq=2770
R278 PASS records=768 pageSeq=2780
R279 PASS records=2 pageSeq=2790
R280 PASS pageCRC=OK records=5
```

## 11. R301–R312 — PASS / REPLAY

```text
R301 PASS oldest=301 newest=302 oldest-first=YES
R302 PASS records=23 batches=10,10,3 max=10
R303 PASS acked=7/10 cursorAdvanced=NO pageRetained=YES
R304 PASS acked=10/10 pageDeleted=YES
R305 PASS restart=SIM pageRetained=YES replayAgain=YES stableRecordId=YES atLeastOnce=YES
R306 PASS records=2 uniqueIds=YES retryIdentityStable=YES
R307 PASS oldest=3071 retained -> next=3072 blocked; after full ACK next admitted=YES
R308 PASS middleRecordCRC=FAIL replay=REJECT pageDeleted=NO
R309 PASS footerCRC=FAIL replay=REJECT pageRetained=YES
R310 PASS records=11 requests=2 batches=10+1 noRequest>10=YES
R311 PASS reopen=OK cursorSourceStable=YES recordIdStable=YES
R312 PASS pages=2 records=12 oldest-first=YES uniqueIds=YES fullACK=YES deleted=YES missing=0
```

To zamyka semantykę replay/ACK/delete.

## 12. R313–R324 — PASS / STORAGE FAULT MATRIX

```text
R313 PASS records=2 tail=40 footer=ABSENT recoverable=YES
R314 PASS records=3 footer=ABSENT validPrefix=3
R315 PASS records=768 size=64576 footer=ABSENT validPrefix=768
R316 PASS records=4 footer=COMMITTED pageCRC=OK recovery=OK
R317 PASS footerCRC=FAIL replay=REJECT pageRetained=YES
R318 PASS firstRecordCRC=FAIL validPrefix=0 replay=REJECT
R319 PASS lastRecordCRC=FAIL validPrefix=2 replay=REJECT pageRetained=YES
R320 PASS recordCRC=OK pageCRC=FAIL footer=REJECT records=5
R321 PASS pageSeq=3211,3213 gap=1 noInventedPage=YES oldest-first=YES
R322 PASS old=VALID new=REJECTED oldestReady=YES newPageDeleted=NO
R323 PASS oldest=3231 committed; newest=3232 open tail=20; newestCannotBypass=YES
R324 PASS twoPages=129280 twoPagesAdmission=ADMIT free=8503296 protected=5128277 quota=3375019 exactQuota=ADMIT overQuota=REJECT snapshotStable=YES protectedPreserved=YES
```

R324 initially had an invalid test expectation (`129281 B` expected reject while quota was ~3.4 MB). It was corrected to test `exactQuota` vs `quota+1`, using one consistent `FsQuotaHard` snapshot. Final runtime is PASS.

## 13. CURRENT BUILD — COMMIT G v3.27.0

File:
`main_centrala_v3.27.0_LOCAL_SPOOL_COMMIT_G.cpp`

Purpose:
```text
R325–R334
real TelemetryRing -> .part -> flush/close/reopen -> CRC verification
-> rename to final -> only then ring tail commit
```

The build has a dedicated Telegram batch command:
```text
/spoolg TAK
```

Current status: **prepared, not yet runtime-verified in this handoff**.

Important invariant:
- R325/R... must not prematurely dequeue the ring record;
- tail must advance only after durable page verification;
- tests must not corrupt/consume the live ring state in a way that invalidates later cases.

## 14. PLATFORMIO / TOOLCHAIN NOTE

During preparation of v3.26.2, PlatformIO hit a broken/incomplete Arduino-ESP32 package installation:
```text
framework-arduinoespressif32\cores\esp32\Arduino.h not found
WiFiGeneric.h -> Network.h not found
WinError 32/145/183
```

The fix was to terminate `platformio.exe`, remove the broken framework package and `.pio`, then reinstall dependencies. A subsequent build/runtime path succeeded sufficiently to produce the final R313–R324 PASS.

This toolchain incident is considered environmental, not a firmware fault.

## 15. PRODUCTION GATE — CURRENT

Before any production OTA of Persistent Spool V2:

```text
[PASS] R242–R244 format/geometry/freeze
[PASS] R245–R252 write/recovery/power-loss/real telemetry/quota
[PASS] R253–R262 storage batch
[PASS] R263–R272 semantics/invariants
[PASS] R273–R282 telemetry integration
[PASS] R283–R300 mega batch / corruption / quota
[PASS] R301–R312 replay/ACK/delete
[PASS] R313–R324 storage fault matrix
[OPEN] R325–R334 Commit G real ring -> durable spool integration
[OPEN] final integration/soak on local test board
[OPEN] production release candidate + rollback verification
```

The earlier project research plan also specifies broader telemetry acceptance scenarios such as normal online operation, transient Firebase loss, Wi-Fi-off buffering, backlog recovery without duplicates, timeout/retry, restart, 24 h stability, 7 day memory-growth check, full RTDB checks and security testing. These belong to the final release gate rather than being silently assumed to be covered by storage unit/fault batches.

## 16. FILE / SOURCE INVENTORY RELEVANT TO CONTINUATION

- `R242_PERSISTENT_SPOOL_V2_ARCHITECTURE.md` — frozen architecture candidate / contract.
- `R245_PERSISTENT_SPOOL_FIRST_WRITE_PLAN.md` — first-write harness plan.
- `R263_R272_BATCH2_PLAN.md` — batch 2 semantics.
- `main_centrala_v3.24.3_LOCAL_SPOOL_BATCH3_SAFE_SIZEFIX.cpp` — R273–R282.
- `main_centrala_v3.25.2_LOCAL_SPOOL_REPLAY_BATCH_FIX.cpp` — R301–R312 final replay harness lineage.
- `main_centrala_v3.26.1_LOCAL_SPOOL_FAULT_BATCH_FIX.cpp` — R313–R324 before final quota correction.
- `main_centrala_v3.26.2_LOCAL_SPOOL_FAULT_BATCH_QUOTA_FIX.cpp` — final R313–R324 PASS build used for runtime.
- `main_centrala_v3.27.0_LOCAL_SPOOL_COMMIT_G.cpp` — current next build, R325–R334.

## 17. CONTINUATION RULE

When the user provides the next Telegram dump:
1. Parse the complete batch exactly as reported.
2. Mark only actually proven tests PASS/FAIL.
3. Do not infer missing runtime evidence.
4. Keep production at v3.19.2.
5. If Commit G fails, fix the narrow failing invariant and rerun the batch rather than changing unrelated telemetry/Firebase code.
6. Prefer one large batch over many tiny builds.
