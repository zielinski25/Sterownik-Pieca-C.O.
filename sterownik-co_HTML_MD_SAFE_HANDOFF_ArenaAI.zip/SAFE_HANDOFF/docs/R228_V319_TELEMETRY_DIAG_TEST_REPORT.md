# R228 — v3.19.0 TELEMETRY DIAGNOSTICS — TEST REPORT

Data: 2026-09-26

## Candidate

Source: `main_centrala_v3.19.0_TELEMETRY_DIAG.cpp`
SHA-256: `ab14a45ba386f0da34205f941a062737cdc10238c581ff926193886d38b11b91`

Patch: `COMMIT_v3.19.0_TELEMETRY_DIAG.patch`
SHA-256: `5e86e25a6f9dc248166340af008fa1845ba38b4f47e46c4af68bd5b21ac5c724`

## Static checks

PASS:
- v3.19.0 changelog entry added before v3.18.1
- `TG_TELEMETRY_DIAG` added to Telegram deferred-command enum
- `telemetry_diag` callback added to diagnostics menu
- callback mapping added
- handler case added in `tgTaskFn()`
- `buildTelegramTelemetryDiagReport()` added
- no second Firebase client added
- no new telemetry task added
- TelemetryRing capacity unchanged
- batch max records unchanged
- send interval unchanged
- Firebase request timeout unchanged
- TG iteration budget unchanged
- TWDT/network code outside the feature is unchanged by the patch
- empty ring is reported as no sample, rather than falsely as fresh sample `seq=0`

## Build status

NOT RUN IN THIS ARTIFACT WORKSPACE.

Reason: the current `/mnt/data` workspace contains source and patch artifacts but does not contain the project's `platformio.ini`/full PlatformIO build environment and `pio` executable is not available here.

Therefore the candidate status is:

`STATIC_CHECKED / BUILD_PENDING / RUNTIME_PENDING`

## Runtime test to perform locally

1. Build `esp32-s3-n16r8`.
2. Upload to the local empty/test ESP32-S3 via USB.
3. Confirm boot/HEALTH and no new WDT/task-not-found messages.
4. Open Telegram -> Diagnostyka -> Telemetria.
5. Confirm the report contains ring status, pending, produced, sent, dropped, failures, last attempt and last sample.
6. Disable Wi-Fi for a few minutes without powering down ESP32.
7. Query the report again; pending should rise and dropped should remain zero while ring is not full.
8. Restore Wi-Fi; pending should drain and sent should increase.
9. Repeat the report during/after recovery.
10. No production OTA in this test.

## Acceptance

PASS requires:
- build PASS for both PlatformIO environments
- local runtime PASS
- no regression in Telegram menu/navigation
- no regression in status/history/controls
- no TASK_WDT/PANIC/RESET/COREDUMP
- no `task not found`
- report is observation-only at the builder level

## Production rule

Only after local PASS may this candidate be considered for a new release and eventual OTA to the remote controller.

`v3.18.1` remains the rollback/master baseline.
