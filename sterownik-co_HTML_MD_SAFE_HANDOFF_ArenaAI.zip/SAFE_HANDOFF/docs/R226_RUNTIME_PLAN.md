# R226 — Runtime v3.18.1 on real CO controller

## Cel
Sprawdzić v3.18.1 na właściwej centrali z podłączonymi czujnikami po zaliczeniu testów na pustej płytce.

## Aktualny stan
- v3.18.1: build PASS dla esp32-s3-n16r8 i esp32-s3-ota
- R224: 15 min 39 s, 0 WDT/reset/PANIC/coredump, telemetry 15, batch_ok 15
- R225: offline buffering + backlog drain PASS, telemetry_dropped=0, bez resetów
- FAIL -> RETRY -> ACK -> COMMIT TAIL: nieudowodnione bezpośrednio

## Test
1. USB upload v3.18.1 na prawdziwą centralę.
2. Nie używać OTA.
3. Uruchomić R188 na COM właściwej centrali.
4. Obserwować 30 min bez restartów/OTA/zmian automatyki.
5. Sprawdzić: TASK_WDT=0, PANIC=0, reset=0, coredump=0, telemetry_dropped=0.
6. Sprawdzić co najmniej kilka rekordów telemetryki: realne temperatury/RH/pressure/smoke, ageS, qualityBits, simulatedBits.
7. Po 30 min zakończyć capture i zarchiwizować ZIP.

## Zakres
Bez zmian Firebase auth/TLS, rules, toolchain, biblioteki, LittleFS persistent spool.
