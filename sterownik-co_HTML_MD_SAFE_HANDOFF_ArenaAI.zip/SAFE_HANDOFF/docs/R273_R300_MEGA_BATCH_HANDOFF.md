R273-R300 HANDOFF

1. Na pustej plytce testowej wgrac v3.23.0.
2. Nie OTA na prawdziwy piec.
3. Telegram: /spoolmega TAK
4. Oczekiwane: jedna odpowiedz "R273-R300 spool mega batch: PASS" oraz 28 linii PASS.
5. Jezeli Telegram znowu nie odpowiada, NIE powtarzac komendy w ciemno. Zresetowac lokalna plytke i sprawdzic Telegram/status.

Wazne: v3.23.0 jest oparty o v3.22.1, ktory juz zaliczyl R253-R262. To celowe, aby nie przenosic potencjalnego bledu R279.
