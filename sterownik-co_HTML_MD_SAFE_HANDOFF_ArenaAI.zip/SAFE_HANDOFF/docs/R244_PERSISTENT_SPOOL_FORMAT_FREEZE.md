# R244 — Persistent Spool V2: frozen page format

Data: 2026-09-27
Status: READY do lokalnego builda/testu — bez zapisu spool do LittleFS.

## Geometry

- page: 64 KiB = 65 536 B
- header: 64 B
- record: 84 B = TelemetrySample 80 B + CRC32 4 B
- footer: 64 B
- safe records: 768
- used by safe page: 64 640 B
- slack: 896 B
- coverage: 768 min = 12 h 48 min
- theoretical max: 778 records, slack 56 B

## Exact binary ABI

### Header — 64 B

| Offset | Size | Field |
|---:|---:|---|
| 0 | 4 | magic `0x53504C31` |
| 4 | 2 | formatVersion = 1 |
| 6 | 2 | headerBytes = 64 |
| 8 | 8 | pageSeq |
| 16 | 8 | firstSampleSeq |
| 24 | 2 | recordBytes = 84 |
| 26 | 2 | capacity = 768 |
| 28 | 4 | flags/reserved |
| 32 | 4 | firstUnixTs |
| 36 | 4 | firstMonoMs |
| 40 | 20 | reserved = 0 |
| 60 | 4 | headerCrc32 |

Header CRC covers bytes 0..59.

### Record — 84 B

```text
TelemetrySample 80 B
CRC32 4 B
```

Record CRC covers exactly the 80 bytes of `TelemetrySample`.

No `record_len` is stored because record size is fixed by the frozen ABI.

### Footer — 64 B

| Offset | Size | Field |
|---:|---:|---|
| 0 | 4 | magic |
| 4 | 2 | formatVersion |
| 6 | 2 | footerBytes = 64 |
| 8 | 8 | pageSeq |
| 16 | 8 | firstSampleSeq |
| 24 | 8 | lastSampleSeq |
| 32 | 4 | recordCount |
| 36 | 4 | payloadCrc32 |
| 40 | 4 | commitMarker `0x434F4D4D` |
| 44 | 16 | reserved = 0 |
| 60 | 4 | footerCrc32 |

Footer CRC covers bytes 0..59.

`payloadCrc32` covers the complete written record area, i.e. `recordCount × 84 B` including record CRCs.

## Close / commit

```text
create page
→ write header
→ append fixed-size records
→ verify each record write
→ write footer last
→ verify footer write + CRC/readback
→ page committed
```

A page without a valid footer is **OPEN**, not automatically discarded.

## Recovery after power loss

```text
scan page files
→ validate filename/header
→ validate header CRC
→ scan fixed-size records
→ stop at first incomplete/CRC-invalid record
→ valid prefix is recoverable
→ if valid footer exists: CLOSED
→ if footer missing/invalid: OPEN_RECOVERED
→ replay valid records FIFO
→ never append new records to recovered old page; start a new page
```

Page ordering comes from `pageSeq` in the header; filename is only an index/hint.

Candidate filename:

```text
/telemetry_spool/page_%016llX.bin
```

The source of truth for ordering remains the header `pageSeq`.

## Deliberately not included in R244

- no LittleFS writes
- no telemetry spool directory creation
- no replay
- no truncation/delete after recovery
- no power-loss test code
- no production OTA

Production controller remains on v3.19.2.
