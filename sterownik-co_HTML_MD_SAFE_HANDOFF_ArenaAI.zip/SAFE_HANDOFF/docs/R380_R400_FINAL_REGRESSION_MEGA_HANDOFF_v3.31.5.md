# R380-R400 — FINAL REGRESSION MEGA v3.31.5

Status: local/test firmware only. Production remains v3.19.2.

## Cel
Jedna komenda uruchamia pelny regresyjny lancuch krytycznych gateow:

- R253-R262 — Spool V2 core
- R263-R272 — Spool V2 semantics/invariants
- R273-R282 — producer telemetry -> Spool adapter
- R301-R312 — replay/ACK/delete
- R313-R324 — recovery/fault/quota
- R325-R334 — Commit G real ring -> durable spool
- R335-R344 — Security H1 TLS/secret baseline
- R345-R356 — Security H2 UserAuth + Rules shadow
- R367-R379 — RTDB integration mega batch, w tym cross-midnight range z `.indexOn: ["ts"]`

Po gateach sa wykonywane dodatkowe sentinele runtime:

- LittleFS READY
- TelemetryRing READY
- Telegram poll idle przed startem
- Firebase worker idle
- telemetry request idle
- WiFi connected
- Firebase UserAuth READY
- Firebase circuit CLOSED
- Firebase worker idle po batchu
- telemetry request idle po batchu
- latest coredump archive present
- overall FINAL-MEGA PASS/FAIL

## Bezpieczenstwo wykonania

`/finalmega TAK` uruchamia osobny worker na Core 0.
Na czas testu:
- Telegram long-poll jest blokowany przez `g_finalMegaActive`;
- tgTask pomija normalne operacje Firebase/telemetryczne;
- nowe uruchomienie przy zajetym Firebase workerze, aktywnym G2, H2 albo aktywnym requestcie telemetrycznym jest odrzucane;
- produkcyjna telemetria V1 nie jest przelaczana na nowy namespace.

Na PASS komunikat zawiera tylko summary poszczegolnych gateow. Gdy gate FAIL, dolaczany jest jego szczegolowy wynik.

## Run

1. Flash tylko lokalna/testowa plytka.
2. `/version` -> v3.31.5
3. `/finalmega TAK`
4. Odeslij caly komunikat `R380-R400 final regression mega batch`.

## Uwaga

Nie wykonano builda PlatformIO w tym srodowisku: lokalny runtime nie ma zainstalowanego `pio` ani kompletnego toolchainu. Wykonano kontrolę strukturalną źródła: nowe bloki są zbilansowane składniowo, deklaracja/definicja/dispatcher/komenda są spójne, a worker ma własny stos. Build/flash musi być wykonany w dotychczasowym lokalnym środowisku używanym do testów.
