# PIECO — MASTER STATE CURRENT — 2026-09-28 — v3.31.16

## 1. GRANICA PRODUKCYJNA
- Produkcyjny sterownik / prawdziwy piec: **v3.19.2**.
- Produkcja: **OTA only**.
- Nigdy USB na prawdziwym sterowniku.
- v3.31.16 i wszystkie wcześniejsze v3.20.x+ pozostają **LOCAL TEST ONLY**.
- Wyniki lokalne nie są automatyczną zgodą na produkcję.

## 2. AKTUALNY TESTOWY FIRMWARE
- Wersja uruchomiona na płytce testowej: **v3.31.16**.
- Source: `02_CURRENT/main_centrala_v3.31.16_FIREBASE_LOOP_SAME_TASK.cpp`
- Source SHA256: `1dcca68e69661767e71a5b51aec047ece4a3403879a336273d1f2aadab8f9c75`
- Patch SHA256: `b5e372ca3c9991868639df460bd40c99d9b2016903ee4ac0ce850b9e8edac7c9`
- Zmiana v3.31.16: usunięcie detached `fbLoopWork`; `fbApp.loop()` jest wykonywane w istniejącym `tgTask`; inicjalizacja Firebase startuje asynchronicznie w setup.

## 3. WAŻNY INCYDENT v3.31.14 — ZAMKNIĘTY DIAGNOSTYCZNIE
- coredump seq87, boot2, 35556 B.
- Exact ELF SHA256: `98ae230ecd55b7819a19415378cfe2c306bb7de4731e3a8e4a8703a831a1cea1`.
- Panic: `assert failed: sys_untimeout /IDF/components/lwip/lwip/src/core/timeouts.c:334 (Required to lock TCPIP core functionality!)`.
- Wniosek: detached Firebase worker wchodził w lwIP bez właściwego kontekstu/core lock.
- v3.31.15 próbował lokalnego `LOCK_TCPIP_CORE()`, ale live boot pokazał nowy problem: worker mógł pozostać zablokowany pod lockiem.
- Dlatego v3.31.16 zmienił architekturę: brak detached Firebase worker.

## 4. R380-R470 — AKTUALNE WYNIKI RUNTIME
### R380-R400 — PASS na v3.31.16
Wszystkie R380-R400 PASS.

### R401-R430 — PASS na v3.31.16
Wszystkie R401-R430 PASS, w tym:
- R405 firebaseWorker=IDLE
- R422 rtdbRound3=PASS
- R423 postRoundHealth=OK
- R427 firebaseCircuit=CLOSED
- R429 workersAndRequests=IDLE
- R430 overall=PASS

### R431-R470 — PASS na v3.31.16
Wszystkie R431-R470 PASS, w tym:
- R451 runtimeHealth=IDLE
- R453 firebaseWorker=IDLE
- R455 tgPoll=IDLE
- R456 firebaseCircuit=CLOSED
- R461 producerRegression=PASS
- R462 replayRegression=PASS
- R463 faultRegression=PASS
- R464 commitGRegression=PASS
- R465 securityH1Regression=PASS
- R466 securityH2Regression=PASS
- R467 rtdbRegression=PASS
- R468/R469 postRegression worker/request=IDLE
- R470 overall=PASS

## 5. KONTROLOWANY COREDUMP v3.31.16
Wykonano na płytce testowej:
- `/testcrash` — uzbrojenie 60 s.
- `/testcrash TAK` — dokładnie jeden kontrolowany PANIC.
- raport po restarcie: `boot=2 reset=PANIC streak=1`.
- `coredump_seq=98`, `dump_seq0000000098_boot2.bin`, 30788 B.
- po restarcie ponowne `/testcrash TAK` zostało odrzucone: `Test nie jest uzbrojony`.
- `/version` po restarcie: `v3.31.16`.
- `/coredumplist`: 13 bootów dostępnych.
- `/coredumpy`: seq98 został wysłany przez Telegram.

Uwaga: surowy plik seq98 nie jest obecnie zapisany jako osobny artefakt w tej paczce; poniżej zachowano dokładny wynik Telegrama.

## 6. POST-CRASH RECOVERY
Po seq98 wykonano:
- `/version` — PASS, v3.31.16.
- `/status` — PASS.
- `/coredumplist` — PASS, 13 bootów.
- `/coredumpy` — PASS, seq98 wysłany.
- `/recoverymega TAK` — **R431-R470 PASS**.
- kolejny `/status` — PASS.

## 7. TESTOWE OGRANICZENIA SPRZĘTOWE
Na płytce testowej nadal występują brakujące czujniki / brak karty SD / awaria RTC podczas części startowej. Nie są one podstawą do oznaczania R380-R470 jako FAIL, ponieważ właściwe gate'y zakończyły się PASS. WiFi było słabe podczas sesji (około -84 do -93 dBm), ale Telegram działał.

## 8. ZAMKNIĘTE GATE'Y
R247-R470: wszystkie udokumentowane gate'y PASS.
W szczególności zamknięte:
- Persistent Spool V2
- real telemetry producer
- replay/ACK/delete
- fault/quota
- Commit G
- Security H1
- Security H2/UserAuth/Rules
- G2 runtime
- RTDB R367-R379
- Final R380-R400
- Stability R401-R430
- Recovery/OTA/FS/Boot R431-R470
- controlled testcrash/coredump one-shot

## 9. NASTĘPNY ETAP — NIE ZGADYWAĆ NUMERÓW R
Pliki projektu, które przejrzano, nie zawierają wiarygodnie zdefiniowanego zestawu R471+.
Źródła opisują natomiast osobny gate: **final integration / soak / release candidate / rollback**.
Nie należy wymyślać numerów R471+ ani wykonywać OTA produkcyjnego bez osobnego, jawnego planu tego gate'u.

Przed produkcją pozostają do formalnego zamknięcia co najmniej:
1. final integration / soak na jednej zamrożonej wersji,
2. release candidate z jednoznacznym artefaktem builda,
3. weryfikacja OTA + rollback na płytce testowej,
4. dopiero po tym osobna decyzja o produkcyjnym OTA.

## 10. ZASADA KONTYNUACJI
- Nie dotykać v3.19.2 na produkcji.
- Nie wykonywać teraz produkcyjnego OTA.
- Nie tworzyć nowych testów tylko dla numeracji.
- Następny plan ma być oparty na istniejących artefaktach OTA/release/rollback z projektu.
- Każdy wynik runtime zapisywać dokładnie, bez dopisywania PASS do testów, których nie wykonano.
