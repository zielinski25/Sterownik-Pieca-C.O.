# R222 — NETWORK WORKER / TWDT DECOUPLING
Data: 2026-09-26

## Status
R218-R221 established a repeated TASK_WDT pattern in network workers. R222 prepares v3.18.0 as an isolated network/WDT change before any further telemetry expansion.

## Evidence
Coredumps 11–16 from v3.17.0 show repeated TASK_WDT events in `tgTask` / `tgPollTask` during blocking Telegram/Firebase/Open-Meteo work. The exact v3.17.0 ELF analysis identified:
- coredump 11: `HTTPClient::handleHeaderResponse()` during DESZCZ `http.GET()`;
- coredump 12: `ssl_starttls_handshake()` from Telegram `NetworkClientSecure::connect()`;
- coredumps 13–15: Telegram `TG_CONNECT` path;
- coredump 16: `FB_SEND` path.

## v3.18.0 change scope
1. Do not subscribe `tgTask` or `tgPollTask` to per-task TWDT.
2. Keep the global TWDT configuration and the existing loop/control-task subscription unchanged.
3. Add 32-bit heartbeat + coarse state for both network workers.
4. Report worker state/heartbeat age from `HEALTH-A` on the control-side `loop()`.
5. Do not change `TelemetrySample`, `TelemetryRing`, Firebase wire schema, record identity, retry/commit semantics, or controller outputs.

## Rationale
`tgPollTask` intentionally performs a Telegram long-poll up to 30 s. A 15 s per-task watchdog therefore conflicts with the task's documented purpose. The coredumps also show that shorter network-client timeouts are not a hard wall-clock bound for every lower-level TLS/HTTP operation.

The change does not raise the watchdog timeout and does not remove the watchdog from the control loop. A stuck network worker becomes observable through heartbeat age instead of resetting the controller because it is inside a blocking network primitive.

## Required validation
1. Build `v3.18.0` for `esp32-s3-n16r8`.
2. Build `v3.18.0` for `esp32-s3-ota`.
3. Only after both builds PASS, upload once by USB.
4. Run a controlled runtime capture; no OTA/restart/erase/manual automation changes.
5. Collect HEALTH-A and any reset/coredump evidence.

## Success criteria
- No unexpected TASK_WDT caused by `tgTask`/`tgPollTask`.
- No PANIC/reset/coredump during the observation window.
- Control loop continues normally.
- `HEALTH-A` exposes `tg_state`, `tg_hb_age_ms`, `tg_poll_state`, `tg_poll_hb_age_ms`.
