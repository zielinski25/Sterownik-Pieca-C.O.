# R367-R379 — RTDB Integration Index Fix v3.31.4

Status: local/test firmware only. Production remains v3.19.2.

## Observed result on v3.31.3
R367 PASS
R368 PASS
R369 PASS
R370 FAIL error=HTTP_STATUS_400
R371 FAIL (cascaded from R370)
R372-R379 PASS

## Diagnosis
Firebase Realtime Database REST returns HTTP 400 for query requests when the required index is not defined in Security Rules. R370 is the only test using a REST range query ordered by child `ts`.

The query target is:
`/piec/devices/<uid>/telemetry/_rtdb_test/<run>/cross_midnight`

The index therefore belongs on the `cross_midnight`-level dataset node, represented by:
`_rtdb_test/$run/$dataset/.indexOn = ["ts"]`

No change is made to read/write authorization. The existing H2 device shadow permissions remain intact.

## v3.31.4 firmware changes
- preserves the v3.31.3 INT_WDT hardening;
- preserves isolated REST range worker on Core 0;
- preserves explicit CA/TLS and Firebase UserAuth token use;
- preserves test namespace and V1 path isolation;
- includes bounded HTTP error-body reporting for future 4xx/5xx diagnosis;
- adds checkpoint 3703 immediately before the range query.

## Rules patch
Apply the following fragment into the existing deployed Rules under `piec.devices.$uid.telemetry`:
`_rtdb_test.$run.$dataset: { ".indexOn": ["ts"] }`

This is an index-only change; no `.read` or `.write` rule is added.

## Run
1. Apply the index patch together with the existing H2 Rules.
2. Flash only the local/test board with v3.31.4.
3. `/version` -> v3.31.4
4. `/rtdbmega`
5. Return the complete R367-R379 result.
