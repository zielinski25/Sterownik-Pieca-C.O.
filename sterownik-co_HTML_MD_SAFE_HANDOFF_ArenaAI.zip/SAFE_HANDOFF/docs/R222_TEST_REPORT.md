# R222 — STATIC TEST REPORT

## Source
`main_centrala_v3.18.0_NETWORK_WDT_DECOUPLED.cpp`

## Checks
- `FIRMWARE_VERSION` = `v3.18.0`.
- `tgTaskFn()` contains no `esp_task_wdt_add(NULL)`.
- `tgPollTaskFn()` contains no `esp_task_wdt_add(NULL)`.
- Existing global `loop()` WDT registration remains unchanged.
- Existing `historiaTaskFn()` WDT registration remains unchanged.
- `TelemetrySample` / `TelemetryRing` code is carried forward without semantic changes.
- New worker heartbeat/state fields are 32-bit/8-bit and read with acquire semantics from `loop()`.
- No new network, filesystem, scheduler, or control operation was introduced by the heartbeat itself.

## Runtime status
Not yet tested. Build must be performed in the real PlatformIO environment before upload.
