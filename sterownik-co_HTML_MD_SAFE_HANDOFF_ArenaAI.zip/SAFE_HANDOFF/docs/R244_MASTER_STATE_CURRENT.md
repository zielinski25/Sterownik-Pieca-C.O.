# MASTER STATE — R244

Updated: 2026-09-27

## Production

- Remote controller: v3.19.2
- No production OTA in R244

## Storage

LittleFS total: 10 354 688 B
Current observed physical use: 1 363 968 B
Current observed physical free: 8 990 720 B

Fixed panel firmware contract: 2 MiB
Coredump archive cap: 20 files / 64 KiB class

## Persistent Spool V2

R242/R243 benchmark PASS.
Frozen candidate format in R244:

```text
page = 64 KiB
header = 64 B
record = 84 B
footer = 64 B
safe records = 768
safe used = 64 640 B
slack = 896 B
coverage = 12 h 48 min
```

Recovery model:
- validate header CRC
- scan fixed records until first invalid/incomplete CRC
- valid prefix survives missing footer
- footer commits CLOSED state
- replay oldest page first
- start a new page after recovery

## Next

Build/test v3.20.2 locally. Then R245: first actual page write + simulated fault/recovery on the empty test board only.
