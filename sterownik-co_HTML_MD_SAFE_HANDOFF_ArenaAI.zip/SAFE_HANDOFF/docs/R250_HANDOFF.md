# R250 HANDOFF

Build lokalny: v3.21.0

Plik źródłowy:
`main_centrala_v3.21.0_LOCAL_R250_CRC_NEGATIVE.cpp`

Test:
`/spool250 TAK`
`/spool250recover`

Produkcja:
v3.19.2 — bez zmian, bez OTA.

PASS wymaga wykrycia uszkodzonego rekordu #2 po CRC i zatrzymania poprawnego prefiksu na 1 rekordzie.
