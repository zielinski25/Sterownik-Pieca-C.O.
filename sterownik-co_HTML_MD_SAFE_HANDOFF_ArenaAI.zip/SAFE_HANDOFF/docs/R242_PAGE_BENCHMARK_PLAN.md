# R242 — PERSISTENT SPOOL V2 — PAGE BENCHMARK

Data: 2026-09-27
Status: READY FOR LOCAL TEST / DIAGNOSTICS ONLY
F2.8: PASS as of 2026-09-27.

## Input
TelemetrySample = 80 B; TelemetryRing = 1440 records / 115200 B.

## Benchmark
Record = TelemetrySample 80 B + CRC32 4 B = 84 B.
Benchmark metadata budget = header 64 B + footer 64 B = 128 B.

Candidate capacities:
- 32 KiB → 388 records max
- 48 KiB → 583 records max
- 64 KiB → 779 records max

Conservative 64 KiB candidate:
- 768 records
- 64,512 B record area
- 128 B header/footer budget
- 64,640 B benchmark used
- 896 B slack
- 12 h 48 min coverage at 1 sample/min

The 768-record value is deliberately below the calculated 779-record maximum.

## Firmware v3.20.0
Read-only diagnostics only. No spool pages are created and no LittleFS write is performed by the new benchmark.

Unchanged:
- Firebase transport
- TelemetryRing behavior
- automation
- logs/history/coredumps
- hard quota behavior
- partitions

## Gate
Local empty test board only:
1. Build `esp32-s3-n16r8`.
2. Build `esp32-s3-ota`.
3. USB upload.
4. Send `/telemetry` 2–3 times.
5. No `/testcrash`.
6. Confirm the benchmark lines and no WDT/PANIC/RESET.

Production remains v3.19.2.

## After PASS
Freeze exact header/footer structs and CRC coverage. Then prepare a separate local-only create/close/recovery test before any production deployment.
