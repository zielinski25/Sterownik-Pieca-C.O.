# ESP32 CENTRALA — HANDOFF R216
Data: 2026-09-25

## STAN
Firmware przygotowany do dalszego testu: **v3.15.1**.
v3.15.0 był wersją wejściową Commit B; v3.15.1 zawiera korekty znalezione podczas audytu statycznego.
**Nie wykonano uploadu v3.15.1.**
Ostatni runtime centrali: v3.14.0, boot 26.
Gate A-0: YELLOW.
R188: 5 h 47 min, nie jest czystym 24 h single-version baseline.

## COMMIT B
Zakres aktualnego artefaktu:
- TelemetrySample 80 B;
- freshness sidecar ×11;
- qualityBits / ageS / simulatedBits;
- sessionNonce / sampleSeq;
- snapshot builder;
- brak Firebase telemetry, JSON, LittleFS spool, TelemetryRing i TelemetryTask.

## KOREKTY R216
- freshness metadata: uint64_t monotonic ms z esp_timer_get_time();
- sample.monoMs nadal uint32_t;
- wygasła symulacja => STALE, simulatedBits pozostaje do fizycznego ACCEPT;
- stateBits tylko PUMP_ON / SMOKE_ALARM / SMOKE_SENSOR_ENABLED;
- sessionNonce z esp_random(), niezależnie od WiFi;
- wersja v3.15.0 -> v3.15.1.

## WALIDACJA
Hostowy exact-struct compile: PASS (`sizeof(TelemetrySample)==80`).
Mini-harness: PASS dla TV04, TV02, TV10, TV13, TV15, TV16, TV17.
Static audit pozostałych TV01/03/05/06/07/08/09/11/12/14/18: PASS.
PlatformIO/ESP-IDF build: NIE WYKONANY w tym środowisku — brak pio i arduino-cli.

## NASTĘPNY KROK
Na Windows:
1. podmienić źródło na `main_centrala_v3.15.1_COMMIT_B.cpp`;
2. wykonać wyłącznie build env `esp32-s3-n16r8`;
3. przy PASS przeprowadzić kontrolowany runtime test v3.15.1 bez kolejnego OTA w trakcie sesji;
4. dopiero po runtime przejść do kolejnej części Commit B: PSRAM TelemetryRing.

Nie dokładać jeszcze Firebase telemetry ani TelemetryTask.
