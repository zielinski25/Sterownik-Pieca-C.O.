# R218 — ELF/Coredump Analysis Update
Date: 2026-09-26

## Exact findings from firmware.elf + coredumps

`firmware.elf` matches the v3.17.0 build used in the supplied coredumps and contains debug symbols for the relevant application functions.

### Coredump 11 / boot 2
- ESP panic detail: `tgTask (CPU 0)` failed TASK_WDT.
- Saved PC: `0x4205b2d8` -> `delay()`.
- Saved return address: `0x4201f39c` -> `HTTPClient::handleHeaderResponse()`.
- Application checkpoint immediately before the operation: `TG op=DESZCZ etap=BEFORE`.
- Source: `pobierzPrognozeDeszczu()` calls `http.GET()` at the DESZCZ checkpoint.

Conclusion: tgTask was blocked in the Open-Meteo HTTPS response-header path long enough to miss its task-WDT deadline.

### Coredump 12 / boot 3
- ESP panic detail: `tgPollTask (CPU 0)` failed TASK_WDT.
- Saved PC: `0x4201c8e2` -> `ssl_starttls_handshake()`.
- Saved return address: `0x4201ba48` -> `NetworkClientSecure::connect(..., ... , ..., ..., ..., ...)`.
- Application checkpoint immediately before the operation: `TG_CONNECT etap=BEFORE`.

Conclusion: tgPollTask was blocked during Telegram TLS connect/handshake long enough to miss its task-WDT deadline.

## Why current timeouts do not fully solve this

`HTTPClient::setTimeout(4000)` is an idle/read timeout used by the response-reading path; each received header line resets `lastDataTime`. It is therefore not a hard total wall-clock deadline for the whole `GET()`.

`NetworkClientSecure::setHandshakeTimeout(4000)` is checked by the outer TLS handshake loop after the underlying mbedTLS handshake call returns. A lower-level blocking socket read can delay that check.

Therefore the current design cannot guarantee that either network worker returns before the 15 s task-WDT solely by setting 4 s network timeouts.

## R219 hardening status

The v3.15.2 ownership fix remains valid: DNS/Firebase worker cleanup no longer waits forever on worker mutexes and does not use the old blocking cleanup path.

It did not address the separate issue demonstrated by coredumps 11/12: network worker tasks themselves are subscribed to the 15 s TASK_WDT while executing blocking TLS/HTTP operations.

## Next code change — v3.18.0 proposal

1. `tgPollTask` must not be subscribed to TASK_WDT because its intended long-poll/connect path is externally blocking and can exceed 15 s.
2. `tgTask`, also a network worker, should likewise not be protected by a per-task 15 s watchdog while inside blocking HTTP/TLS calls.
3. Add lightweight monotonic heartbeat timestamps for both network workers so HEALTH/diagnostics can report a stuck worker without allowing a network stall to reset the control system.
4. Keep the existing WDT protection of the actual control/scheduler tasks unchanged.
5. Do not change TelemetrySample, TelemetryRing, Firebase batch contract, or controller outputs.

No upload is authorized from this analysis alone. First build and review v3.18.0.
