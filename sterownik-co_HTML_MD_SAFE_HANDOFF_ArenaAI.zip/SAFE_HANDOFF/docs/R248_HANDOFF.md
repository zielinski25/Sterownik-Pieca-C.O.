R248 HANDOFF

Stan po R247: PASS. Oczekiwany plik wejscia ma 272 B.

Build lokalny:
v3.20.7 / R248 recovery continue.

Komenda:
/spool248repair TAK

Nie uruchamiac na prawdziwym piecu.

Oczekiwany wynik PASS:
R248 recovery continue: PASS
recovery+continue OK: input=272B validPrefix=232B discardedTail=40B output=316B records=3 headerCRC=OK recordCRC=OK footer=ABSENT continuedSeq=0xF2470003

Po PASS mozna zamknac R248 i przejsc do kolejnego etapu integracji/testow spoola.
