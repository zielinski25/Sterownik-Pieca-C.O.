﻿# R188 / TELEMETRIA — MASTER STATE

> **Jeden plik kontrolny projektu.** Przy wznowieniu pracy najpierw przeczytać ten plik, następnie `TELEMETRIA_RESEARCH_PLAN.md`. Nie zmieniać zakresu prac bez jawnego wpisu w planie.

## 1. Cel główny

Zaprojektować i wdrożyć telemetrykę/logowanie cloud dla istniejącego sterownika centralnego ogrzewania na ESP32-S3, bez pogorszenia bezpieczeństwa i sterowania. Praca jest prowadzona etapami z bramkami jakościowymi; obecnie NIE wdrażamy jeszcze telemetrycznego endpointu.

## 2. Stan na teraz

- **Aktualny etap:** R203 / smoke test strumienia UART zakończony PASS; następny jest krótki test 40–60 s z auto-detekcją profilu CH340, potem 24 h R188.
- **Gate A-0:** YELLOW — nie może przejść na GREEN przed rzeczywistym wykonaniem i oceną R188 runtime baseline.
- **Następny krok:** uruchomić `R188_CAPTURE_1.5_FIXED.ps1` bez `-Port`, sprawdzić automatyczny wybór zweryfikowanego profilu CH340 i uzyskać co najmniej jeden `HEALTH` w 40–60 s; dopiero potem pełne ~24 h R188.
- **Nie wolno teraz:** zmieniać firmware, dodawać Firebase telemetry endpoint, dodawać TelemetryTask, zmieniać auth/TLS, aktualizować FirebaseClient, zmieniać toolchain/platformy, zmieniać partycji.

## 3. Źródło prawdy

1. `R188_MASTER_STATE.md` — krótki stan bieżący i reguły ciągłości.
2. `TELEMETRIA_RESEARCH_PLAN.md` — pełny żywy dziennik badań R130+ i decyzji architektonicznych.
3. `main_centrala.cpp` — aktualny firmware źródłowy.
4. `platformio.ini`, `boards/esp32-s3-n16r8.json`, `partitions.csv`, `sdkconfig.defaults` — konfiguracja/build.
5. `R188_CAPTURE.ps1` — narzędzie runtime baseline; nie jest firmware.

## 4. Aktualny firmware / build — fakty

- Aktualny kod bazowy przed Commit A: `main_centrala.cpp`, wersja **v3.13.0**. Przygotowany artefakt Commit A: `main_centrala_v3.14.0_COMMIT_A.cpp`.
- `Serial.begin(115200)`.
- Board: ESP32-S3-N16R8, 16 MB Flash, 8 MB OPI PSRAM.
- Board VID/PID: **0x303A / 0x1001**.
- PlatformIO: pioarduino platform 55.03.38 → Arduino-ESP32 3.3.8 / ESP-IDF 5.5.4.
- Firmware baseline z dostarczonego Windows build listing: `firmware.bin` 1,852,848 B, około 58.9% slotu 3 MiB.
- Sloty OTA: app0 3 MiB, app1 3 MiB; coredump 64 KiB; pozostała część 16 MB dla NVS/LittleFS wg `partitions.csv`.
- Firmware ma już trzy główne taski projektu na Core 0 (`tgTask`, `tgPollTask`, `historiaTask`) i Arduino loop na Core 1.
- WDT runtime jest częścią obecnego firmware; R188 nie wprowadza zmian w WDT.

## 5. R188 runtime baseline — reguły

### Cel
Udowodnić stabilność aktualnego firmware przed dodaniem telemetryki.

### Czas
Docelowo około **24 h**, bez fault injection.

### T0
T0 = wall-clock hosta zarejestrowany przez capture po jednoznacznym wyborze portu i rozpoczęciu przechwytywania. Nie udajemy, że T0 jest hardware resetem.

### T1
T1 = wall-clock hosta przy kontrolowanym zakończeniu capture po pełnym oknie obserwacji.

### Podczas R188
- nie używać terminala WS,
- nie wykonywać `restart`, OTA, upload, erase, erase_upload,
- nie zmieniać ręcznie parametrów automatyki,
- nie odłączać sztucznie WiFi/zasilania,
- nie wstrzykiwać awarii,
- nie robić restartu tylko po to, żeby „ładniej” rozpocząć sesję.

### Dowody minimalne
- `Serial_raw.txt` — surowy zapis UART,
- `T0.txt`, `T1.txt`,
- `HEALTH_extract.txt`, `HEALTH.csv`,
- `R188_RESULT.md`,
- `operator_events.log`,
- przy FAIL: fragment przed/po awarii, RTC crash report, coredump jeśli istnieje.

### HARD FAIL
- nieoczekiwany restart,
- WDT/PANIC,
- coredump,
- heap/stack failure,
- utrata lub uszkodzenie dowodu,
- ręczna ingerencja zmieniająca automatykę w okresie baseline,
- niewyjaśniona degradacja pamięci / zachowania sterowania.

## 6. Aktualne HEALTH

Firmware emituje około co 30 s:
`tag=HEALTH lvl=INFO zdarzenie=heartbeat heap=<B> largest=<B> tg=<0/1> wifi=<0/1> fb=<0/1>`

`uptime_s` NIE jest emitowane przez obecny HEALTH. Nie wolno tworzyć sztucznego uptime na podstawie czasu hosta.

## 7. R188_CAPTURE.ps1

Aktualna wersja: `R188-CAPTURE-1.1`.

Funkcje:
- auto-detekcja COM,
- dokładny VID/PID `VID_303A&PID_1001` ma najwyższy priorytet,
- nazwa ESP32/Espressif/JTAG może rozstrzygać tylko jednoznaczny przypadek,
- przy niejednoznaczności skrypt kończy się błędem zamiast wybrać losowy port,
- `-Port COMx` jest ręcznym wymuszeniem,
- tworzy izolowany katalog sesji R188,
- zapisuje T0/T1,
- zapisuje surowe bajty do `Serial_raw.txt`,
- wydziela HEALTH do plików pochodnych,
- nie resetuje urządzenia i nie wykonuje upload/erase/OTA.

SHA-256 bieżącego skryptu:
`77267d6226d4ea2660ee67cd3dd244818021ea0fb54b1bd53c93f6a5dd0be747`

**Ważne:** rzeczywista składnia/uruchomienie PowerShell nie była możliwa w środowisku modelu — na Windows trzeba wykonać test runtime.

## 8. Architektura telemetryki — zamrożona do Commit A

Docelowo:
`historiaZapiszProbke()` → `TelemetryRing` SPSC w PSRAM → istniejący wspólny Firebase writer → `/piec/telemetry/1m/v1/YYYY/MM/DD/<record_id>`.

Nie tworzyć drugiego Firebase client/app i nie tworzyć osobnego `TelemetryTask`.

Proponowany rekord binarny ma **80 B**:
- `uint64_t sessionNonce`,
- `uint32_t sampleSeq`,
- `uint32_t unixTs`, `uint32_t monoMs`,
- temperatury fixed-point x10,
- RH/pressure x10,
- dym,
- kąty serw,
- `stateBits`, `qualityBits`, `simulatedBits`,
- `ageS[11]`.

1440 rekordów ≈ 115.2 kB; 2880 ≈ 230.4 kB.

Wire schema ma być oddzielony od binary ring schema. Payload: konserwatywnie ok. 343 B/rekord, `MAX_PAYLOAD_BYTES=6144`, fizyczny bufor roboczy 8192 B w PSRAM; początkowy batch 10.

## 9. Kluczowe ustalenia techniczne

- `record_id`: sessionNonce + sampleSeq; timestamp jest polem sortowania, nie tożsamością.
- `sessionNonce`: `esp_random()` przy starcie sesji; bez NVS.
- `ts=0`: osobny shard `unknown`, nie backdate'ować po późniejszym NTP.
- `qualityBits`: 11 kanałów × 2 bity = uint32; freshness niezależne od quality.
- `ageS`: saturacja do 65535 jako unknown; nie wykrywać freshness przez `lastGoodMs==0`.
- DHT: raw RH w historii/series; corrected RH w status/logach — telemetryka ma jawnie zachować semantykę.
- BMP280: corrected pressure +18 zgodnie z istniejącą logiką.
- Dym: explicit freshness; stary odczyt może pozostać w pamięci, ale nie znaczy to fresh.
- DS18B20: last-good retention po błędzie = STALE, nie INVALID.
- Serwa: telemetryka powinna raportować rzeczywiste kąty (klapa 0–180°, syberek 0–90°), mimo historycznych nazw `%`.
- `stateBits`: tylko bezpieczny subset, bez niestabilnych pól z wieloma writerami.
- scheduler istniejącego firmware nie catch-up'uje opóźnionych okresów.
- sieciowego drainu nie wkładać do ogólnego scheduler loop; użyć istniejącego Firebase/tg path.
- jeden globalny in-flight guard; timeout caller-a nie może uruchomić drugiego requestu, gdy worker nadal pracuje.
- tail ring przesuwać dopiero po potwierdzonym sukcesie całego batcha.

## 10. Rzeczy odłożone / osobne strumienie

- TLS/auth migration (`setInsecure`, LegacyToken/Database Secret) — osobny temat.
- Firebase Rules — brak dostarczonego artefaktu rules; nie zgadywać produkcyjnych reguł.
- Persistent spool V2 — późniejszy etap; najpierw quota/FS/coredump hardening.
- FirebaseClient upgrade z 2.2.9 do nowszej wersji — nie łączyć z telemetryką.
- Platform/toolchain upgrade — osobny etap.
- bezpieczeństwo sekretów/komend — osobny etap.

## 11. Kolejność etapów

1. **R188** — runtime baseline na obecnym firmware.
2. Gate A-0 → GREEN dopiero po PASS + pełnych dowodach.
3. Commit A — tylko diagnostyka/model danych/ring/identity, bez nowych RTDB writes.
4. Commit B — snapshot/freshness/instrumentacja i testy.
5. Commit C — writer/batch Firebase bez naruszania kontroli.
6. Commit D — reguły/monitoring/ewentualna trwała kolejka, po osobnym przeglądzie.

## 12. Zasada ciągłości dla kolejnych rozmów

Gdy rozmowa zaczyna się od zera lub po bardzo długim kontekście:

**Najpierw:** przeczytać `R188_MASTER_STATE.md`.
**Następnie:** przeczytać koniec `TELEMETRIA_RESEARCH_PLAN.md`.
**Dopiero potem:** wykonywać narzędzia i zmiany.

Po KAŻDYM istotnym kroku aktualizować plan. Po zmianie artefaktu podawać SHA-256. Nigdy nie uznawać czegoś za zweryfikowane runtime, jeśli testu runtime nie wykonano.

### Format komunikacji z użytkownikiem

Użytkownik może po prostu pisać:
- `kontynuuj`
- `wykonaj R193`
- `mam wynik R188`
- `przeczytaj MASTER STATE i kontynuuj`

Nie wymaga to ponownego opowiadania całego projektu.

## 13. Następna czynność teraz

**Nie implementować telemetryki.**

Uruchomić na Windows:
1. test auto-detekcji portu `R188_CAPTURE.ps1`,
2. jeśli wybór jest jednoznaczny — rozpocząć pełne R188,
3. po ~24 h zakończyć ENTER,
4. dostarczyć katalog sesji albo przynajmniej `R188_RESULT.md`, `Serial_raw.txt`, `HEALTH_extract.txt`, `HEALTH.csv`.

Po dostarczeniu wyników przechodzimy przez HARD_PASS / OBSERVATION_PASS i dopiero wtedy Gate A-0.

## R194 — bieżący podział pracy

### Teraz po stronie AI
- sprawdzić `R188_CAPTURE.ps1` przed realnym 24 h capture;
- analizować każdy wynik runtime dostarczony przez użytkownika;
- nie oznaczać żadnego runtime jako zweryfikowanego bez danych z fizycznego ESP32.

### Teraz po stronie użytkownika
Wykonać tylko **krótki smoke test** `R188_CAPTURE.ps1` (nie 24 h): autodetekcja COM → ENTER → 30–60 s capture → ENTER → sprawdzenie plików.

### Następny stan
`SMOKE_TEST_PENDING`

Pełne R188 ~24 h dopiero po pozytywnym smoke teście.

## R195 — stan po nieudanej próbie uruchomienia skryptu

**Stan:** `SCRIPT_NOT_PLACED_ON_WINDOWS`

Użytkownik jest w prawidłowym katalogu projektu: `C:\Users\bakoma\Documents\PlatformIO\sterownik-co-esp32`. PowerShell zgłosił brak `.\R188_CAPTURE.ps1`. To jest problem rozmieszczenia artefaktu, nie błąd firmware i nie błąd autodetekcji ESP32.

### Następna czynność użytkownika
Pobrać `R188_CAPTURE.ps1` z rozmowy do katalogu projektu albo skopiować go z Downloads:
```powershell
Copy-Item "$env:USERPROFILE\Downloads\R188_CAPTURE.ps1" ".\R188_CAPTURE.ps1" -Force
Test-Path ".\R188_CAPTURE.ps1"
```
Wynik `True` oznacza gotowość do smoke testu.

### Następna czynność AI
Po otrzymaniu wyniku `True` / uruchomieniu skryptu przeanalizować wynik autodetekcji. Nie oznaczać R188 runtime jako rozpoczętego, dopóki nie ma pozytywnego smoke testu.


## R196 — blokada parsera PowerShell naprawiona

Aktualny `R188_CAPTURE.ps1` został zapisany jako UTF-8 z BOM. Poprzedni błąd `Unexpected token 'ma'` wynikał z uszkodzenia polskich znaków przez odczyt UTF-8 bez BOM w Windows PowerShell 5.1.

Stan: **SMOKE_TEST_PENDING**.

Najbliższy krok użytkownika: ponownie uruchomić `powershell -ExecutionPolicy Bypass -File .\R188_CAPTURE.ps1` i wkleić cały wynik. Nie rozpoczynać jeszcze 24-godzinnego capture.


## R197 — poprawka błędu autodetekcji portu w R188_CAPTURE.ps1

Stan: **SMOKE_TEST_PENDING**

### Problem z Windows PowerShell 5.1
Skrypt został poprawnie sparsowany, ale podczas `Get-PortIdentityScore` zgłosił: `Cannot overwrite variable PID because it is read-only or constant.`

### Diagnoza
Lokalna zmienna `$pid` kolidowała z automatyczną zmienną `$PID` PowerShell.

### Stan po poprawce
`R188_CAPTURE.ps1` = `R188-CAPTURE-1.2`. Lokalna zmienna została zmieniona na `$pidValue`. Zachowano UTF-8 z BOM.

### Następne działanie użytkownika
Ponownie uruchomić:
```powershell
powershell -ExecutionPolicy Bypass -File ".\R188_CAPTURE.ps1"
```
Wynik całego uruchomienia wkleić do rozmowy. Nadal nie uruchamiać 24 h R188 przed PASS smoke testu.

## R198 — ważny stan runtime

Użytkownik uruchomił lokalną kopię `R188_CAPTURE.ps1` w wersji **1.1**, co potwierdził nagłówek programu. Błąd `$PID` jest charakterystyczny dla starej wersji. Aktualny artefakt poprawiony ma wersję **1.2** i używa `$pidValue`. Nie rozpoczynać smoke testu ani 24 h R188, dopóki lokalny plik nie pokaże `R188-CAPTURE-1.2`.

## R199 — stan po pierwszym poprawnym uruchomieniu autodetekcji
- `R188_CAPTURE_1.2_FIXED.ps1` działa składniowo i został zweryfikowany przez użytkownika.
- Jedyny widoczny port: `COM8`.
- PNP: `USB\\VID_1A86&PID_55D3\\5C4D040363`.
- Automatyczne dopasowanie do oczekiwanego ESP32 `303A:1001` nie zachodzi; skrypt prawidłowo odmawia startu capture.
- **Następny krok:** ręczny smoke test `-Port COM8` przez 30–60 s.
- **Nie rozpoczynać 24 h R188 przed PASS smoke testu.**

## R200 — poprawka `Count` w ścieżce `-Port COM8`

**Stan:** `SMOKE_TEST_PENDING / skrypt 1.3 do testu`

### Runtime
Użytkownik uruchomił `R188_CAPTURE_1.2_FIXED.ps1 -Port COM8`. Skrypt przeszedł start i zgłosił błąd PowerShell:
`The property 'Count' cannot be found on this object. Verify that the property exists.`

### Diagnoza
Błąd pochodzi z `Test-SerialPortExists`, gdzie pojedynczy wynik `Where-Object` był traktowany jak obiekt z `.Count` pod `Set-StrictMode -Version Latest`.

### Poprawiony artefakt
`R188_CAPTURE_1.3_FIXED.ps1`
- wersja: `R188-CAPTURE-1.3`
- poprawka: `@(...).Count` w `Test-SerialPortExists`
- SHA-256: `97984F47349316A8C63CB62D00DCBBCEE2D97F54F3DAE77632C660E52DCFF469`

### Następne działanie operatora
Uruchomić:
```powershell
powershell -ExecutionPolicy Bypass -File ".\R188_CAPTURE_1.3_FIXED.ps1" -Port COM8
```

Najpierw oczekujemy przejścia walidacji portu i utworzenia sesji. Następnie 30–60 s smoke testu, bez 24 h.


## R201 — `TickCount64` naprawa skryptu capture

Stan: **SMOKE_TEST_PENDING / skrypt 1.4 do testu**

Użytkownik potwierdził działanie wersji 1.3 do momentu startu sesji, po czym Windows PowerShell 5.1 zgłosił `The property 'TickCount64' cannot be found on this object.`.

Poprawiony artefakt: `R188_CAPTURE_1.4_FIXED.ps1`
- wersja: `R188-CAPTURE-1.4`
- zegar: `System.Diagnostics.Stopwatch` + `Get-MonotonicMs`
- usunięte wszystkie odwołania do `[Environment]::TickCount64`
- zachowany UTF-8 BOM
- SHA-256: `7F87B8C43BA5549057AB271807CA11662C168B42A2178A303D42E681A4659A3C`

### Następny krok użytkownika
Uruchomić:
```powershell
powershell -ExecutionPolicy Bypass -File ".\R188_CAPTURE_1.4_FIXED.ps1" -Port COM8
```
Oczekujemy przejścia do `R188 AKTYWNE`. Dopiero potem 30–60 s smoke testu i ENTER. 24 h R188 nadal zablokowane.

## R202 — status po smoke teście 1.4

**SMOKE_TEST_CAPTURE_LAYER = PASS_PARTIAL**

Potwierdzone na Windows:
- R188_CAPTURE 1.4 uruchamia się;
- ręczny `-Port COM8` działa;
- T0/T1 są zapisywane;
- odebrano 2392 bajty;
- sesja została zakończona przez operatora.

Jeszcze NIE potwierdzono:
- poprawności treści `Serial_raw.txt`;
- braku utraty/korupcji linii;
- obecności wpisu HEALTH (sesja trwała ~8.9 s, więc HEALTH=0 jest oczekiwane).

**Następne działanie operatora:** inspekcja `Serial_raw.txt`, następnie krótki capture ~40 s. 24 h R188 nadal BLOKOWANE.


## R203 — aktualizacja stanu po weryfikacji Serial_raw

- `R188_CAPTURE_1.4_FIXED.ps1 -Port COM8` otworzył COM8, zapisał T0/T1 i odebrał 2392 B.
- `Serial_raw.txt` zawiera autentyczny boot ROM ESP32-S3 oraz logi aplikacji centrali, w tym `SYSTEM START ESP32-S3`, WDT, BOOT i WiFi.
- `SMOKE_TEST_CAPTURE_STREAM = PASS`.
- COM8 używa PNP `USB\VID_1A86&PID_55D3\5C4D040363`; board JSON nadal ma hwid `303A:1001`. Nie zmieniamy boarda — dodajemy do narzędzia zweryfikowany profil mostka UART.
- `R188_CAPTURE_1.5_FIXED.ps1` = aktualny artefakt do następnego testu; SHA-256 `43597EEF1DD4BC978F7AC79C28C9FAD689CD18FA7170220706F32EF19864FFB5`.
- **24 h R188 nadal BLOKOWANE**, ponieważ chcemy jeszcze uzyskać co najmniej jeden `HEALTH` podczas automatycznego capture 40–60 s.
- Nie wklejać pełnego raw logu do rozmowy bez redakcji sekretów WiFi.

## R204 — AKTUALNY STAN: smoke test capture PASS

`R188_CAPTURE_1.5_FIXED.ps1` bez `-Port` poprawnie automatycznie wybrał COM8 po zweryfikowanym VID/PID `1A86:55D3`.
Capture działał ciągle i wykrył co najmniej 6 wpisów `HEALTH` przy `tg=1 wifi=1 fb=1`.

**Wniosek:** `R188_CAPTURE_TOOL_SMOKE_TEST = PASS`.
Nie ma potrzeby dalej czekać w tej sesji.

### TERAZ — działanie użytkownika
Naciśnij **ENTER** w aktualnie działającym oknie PowerShell, aby zakończyć tę krótką sesję i zapisać T1.

Następnie wklej sam końcowy raport skryptu (bez pełnego raw logu).

### Następny etap po T1
1. Zweryfikujemy artefakty sesji `R188_20260924_190202`.
2. Zamkniemy smoke test narzędzia.
3. Przygotujemy start właściwego **24 h R188**.

**24 h R188 jeszcze nie rozpoczęte.**

## R205 — smoke test capture PASS; gotowe do właściwego 24 h R188

Stan: **READY_FOR_24H_R188**

### Potwierdzone runtime
- `R188_CAPTURE_1.5_FIXED.ps1` działa w Windows PowerShell 5.1.
- Automatycznie wybiera COM8 po zweryfikowanym UART VID/PID `1A86:55D3`.
- T0/T1 działają.
- Capture 13 min 37.6 s odebrał 102729 B i rozpoznał 24 wpisy HEALTH.
- W badanym oknie HEALTH raportował `tg=1 wifi=1 fb=1`.
- Narzędzie nie wykonuje resetu/uploadu/erase/OTA.

### Zamknięte problemy narzędzia
- UTF-8/BOM — naprawione.
- konflikt zmiennej `$PID` — naprawiony.
- `.Count` na pojedynczym obiekcie — naprawione.
- `TickCount64` — zastąpiony `Stopwatch`.
- automatyczna identyfikacja CH340 `1A86:55D3` — zweryfikowana runtime.

### Następny krok użytkownika
Rozpocząć właściwy 24 h R188 przez:
```powershell
powershell -ExecutionPolicy Bypass -File ".\\R188_CAPTURE_1.5_FIXED.ps1"
```
Po `R188 AKTYWNE` pozostawić urządzenie bez ingerencji przez 24 h.

### Gate
`R188_CAPTURE_TOOL_SMOKE_TEST = PASS`.
`GATE_A0 = YELLOW / RUNTIME_24H_PENDING`.
Nie rozpoczynać Commit A przed analizą pełnego 24 h baseline.


## R206 — drugi PC
Status: `SECOND_PC_NOT_READY_FOR_R188`
Na PC `Rafcio` skrypt 1.5 widzi tylko COM3/COM4 z VID_8087:0ACA. Brak ESP32 VID/PID. Nie uruchamiać capture na COM3/COM4. Najpierw podłączyć centralę i potwierdzić właściwy UART przez `pio device list` / PnP.

## R207 — DRUGI PC: ESP32 PRAWIDŁOWO WYKRYTY / GOTOWY DO 24 H
**Data:** 2026-09-25

Na komputerze `C:\Users\Rafcio\Documents\PlatformIO\sterownik-co-esp32` po podłączeniu centrali:
- `pio device list` wykazało `COM5`;
- Hardware ID: `USB VID:PID=1A86:55D3 SER=5C4D040363 LOCATION=1-2:x.2`;
- opis: `USB-Enhanced-SERIAL CH343 (COM5)`;
- PnP/WMI potwierdziło `USB\VID_1A86&PID_55D3\5C4D040363`;
- brak urządzenia `VID_303A&PID_1001` jest zgodny z używanym mostkiem UART.

Profil `1A86:55D3` oraz numer seryjny `5C4D040363` są zgodne z wcześniej zweryfikowanym UART-em centrali na pierwszym PC, gdzie COM8 dawał autentyczny boot ROM ESP32-S3 i log aplikacji.

`R188_CAPTURE_1.5_FIXED.ps1` powinien więc na tym PC automatycznie wybrać `COM5` bez `-Port`.

### Decyzja
- `SECOND_PC_NOT_READY_FOR_R188` -> zamknięte.
- `R188_CAPTURE_TOOL_SMOKE_TEST` -> PASS (już wcześniej potwierdzony runtime).
- Nie potrzeba kolejnego testu 13-minutowego.
- Następna sesja uruchomiona na tym PC może być właściwym 24 h R188.

### Instrukcja operatora
Uruchomić:
```powershell
powershell -ExecutionPolicy Bypass -File ".\R188_CAPTURE_1.5_FIXED.ps1"
```
Bez `-Port`. Automat powinien wskazać `COM5`.
Po `R188 AKTYWNE` rozpocząć oficjalne 24 h baseline. Przez sesję nie wykonywać restartu, OTA/upload, erase, zmian ustawień ani ręcznych ingerencji w automatykę; komputer pozostawić aktywny i nie usypiać.

Po około 24 h nacisnąć ENTER, aby zapisać T1 i zakończyć sesję. Następnie przeanalizować pełny pakiet dowodowy i dopiero wtedy rozstrzygać Gate A-0.

## R208 — SECOND PC: AUTODETEKCJA 1.5 NIE WIDZI CH343 / 1.6 PRZYGOTOWANE
**Data:** 2026-09-25

`R188_CAPTURE_1.5_FIXED.ps1` na PC `Rafcio` widzi przez swój pierwszy mechanizm COM3/COM4, ale pomija CH343 COM5. Niezależnie wykonane `pio device list` oraz PnP potwierdziły `COM5 / 1A86:55D3 / SER=5C4D040363`. Przyczyna jest w enumeracji `Win32_SerialPort` + warunkowym fallbacku, nie w ESP32.

Przygotowano `R188_CAPTURE_1.6_FIXED.ps1`, który scala `Win32_SerialPort`, `Win32_PnPEntity` i `Get-PnpDevice`. Status 1.6: `STATIC_CHECKED / NOT_RUNTIME_VERIFIED_HERE`.

### Decyzja operacyjna
Nie opóźniać właściwego baseline kolejnym testem autodetekcji. Do 24 h R188 użyć bezpiecznie jawnego, już potwierdzonego portu:
```powershell
powershell -ExecutionPolicy Bypass -File ".\R188_CAPTURE_1.5_FIXED.ps1" -Port COM5
```
To nie zmienia firmware ani właściwego mechanizmu capture; omija wyłącznie automat wyboru portu.

**CURRENT = READY_FOR_24H_R188_USING_EXPLICIT_COM5**

## R209 — FIX WALIDACJI JAWNEGO COM / 1.7
Status: **R188_TOOL_FIX_READY**

Na drugim PC `pio device list` i PnP potwierdziły `COM5 / 1A86:55D3 / SER=5C4D040363`, ale `R188_CAPTURE_1.5_FIXED.ps1 -Port COM5` fałszywie odrzucił port, ponieważ `Test-SerialPortExists` polegał na `Get-SerialPorts`/Win32_SerialPort.

Przygotowano `R188_CAPTURE_1.7_FIXED.ps1`:
- jawny `-Port` sprawdzany przez `.NET [System.IO.Ports.SerialPort]::GetPortNames()`;
- autodetekcja scala Win32_SerialPort + Win32_PnPEntity + Get-PnpDevice + .NET;
- brak zmian firmware/capture protocol;
- wersja skryptu `R188-CAPTURE-1.7`;
- SHA-256 `a409a9b918fad9a9c1ecb058fccdcedcbbb04ef82a3dd8aa72e1ac46a6dc11c0`;
- status: STATIC_CHECKED / NOT_RUNTIME_VERIFIED_HERE.

**CURRENT = WAITING_OPERATOR_TO_RUN_R188_CAPTURE_1.7**
Nie używać wersji 1.5 z `-Port COM5`, ponieważ wykazano jej fałszywie negatywną walidację.

## R210 — SKRÓCONA SESJA R188 ZAKOŃCZONA / RESETY BYŁY POWIĄZANE Z OTA
**Data:** 2026-09-25

### Pakiet dowodowy
Użytkownik przesłał `R188_20260925_083156.zip`.
SHA-256: `3745fd8309a8cf1d2cc943e4ba9f5fd610e3f13a8f50d9c1ac71088df2891d6d`.

Sesja:
- T0 `2026-09-25 08:31:56.867`
- T1 `2026-09-25 14:19:16.672`
- czas `5 h 47 min 19.805 s`
- port `COM5`
- script `R188-CAPTURE-1.7`
- bytes `1,642,370`
- HEALTH `654`
- stop `OPERATOR_ENTER`

### Reset analysis
W raw logu wystąpiło 6 markerów resetu: 1x `POWERON` + 5x `RTC_SW_CPU_RST`. Wszystkie 5 resetów programowych mają po ponownym starcie `tag=BOOT ... powod=SW`.

W tej samej sesji wystąpiło 5 razy `Aktualizacja pobrana OK. Restart za chwile...`; jawnie potwierdzone zostały uruchomione wersje `v3.12.0` i `v3.13.0`.

Wniosek: resety #2–#6 są zgodne z zaplanowanymi restartami po OTA/aktualizacji, a nie z dowiedzionym WDT/PANIC. Nie oznacza to jednak, że sesja jest czystym baseline jednej wersji firmware.

### HEALTH summary
`heap_free_B`: min `99,220`, max `118,212`, first `113,416`, last `112,872`.
`largest_free_block_B`: min `6,684,660`, max `6,815,732`, first/last `6,815,732`.
`tg=1` w próbkach. `wifi` chwilowo `0` w części sesji. `fb` na początku `0`, później `1`.

### Brak jawnych markerów
W prostym przeszukaniu `Serial_raw.txt`: `PANIC=0`, `coredump=0`.

### Status Gate
- `R188_CAPTURE_1.7_RUNTIME = PASS`
- `R188_SHORT_SESSION = VALID EVIDENCE / NOT A CLEAN 24H SINGLE-VERSION BASELINE`
- `GATE_A0 = YELLOW`
- `COMMIT_A = BLOCKED UNTIL SHORT-BASELINE DECISION`

### Decyzja metodologiczna
Użytkownik nie może prowadzić pełnego 24 h testu. Nie wymuszać 24 h za wszelką cenę. Należy jawnie przejść na `SHORT_BASELINE` na jednej zamrożonej wersji firmware i zachować niższą siłę dowodu. Nie mieszać baseline z kolejnymi OTA.


## R212 — SHORT_BASELINE v3.13.0: decyzja metodologiczna
**Data:** 2026-09-25

### Powód
Pełny 24 h single-version baseline nie został osiągnięty. Sesja R210 trwała 5 h 47 min, ale zawierała 5 kontrolowanych restartów po OTA i przejścia między wersjami, więc nie może być traktowana jako czysty baseline jednej wersji.

### Zamrożona wersja
Dla kolejnej sesji baseline przyjmujemy **v3.13.0**. Nie wykonywać OTA ani innych zmian firmware w trakcie sesji.

### Definicja SHORT_BASELINE
- czas obserwacji: **6 h** lub dłużej;
- jedna wersja firmware przez cały capture: `v3.13.0`;
- 0 nieoczekiwanych restartów;
- 0 WDT/PANIC/coredump znalezionych w przechwyconym materiale;
- brak ręcznej ingerencji w automatykę;
- zachowany pełny `Serial_raw.txt`, T0/T1, HEALTH i wynik sesji;
- HEALTH ma zachować ciągłość zgodną z nominalnym heartbeatem około 30 s, bez niewyjaśnionej długiej przerwy;
- analiza pamięci ma obejmować min/max/first/last `heap_free_B` oraz `largest_free_block_B`, z oceną trendu zamiast arbitralnego progu.

### Interpretacja
`SHORT_BASELINE = PASS` nie jest równoważny pełnemu 24 h PASS. Jest to świadectwo stabilności o niższej sile dowodu, wystarczające do podjęcia kontrolowanej decyzji o rozpoczęciu **Commit A**, jeżeli pozostałe bramki jakościowe są spełnione.

`GATE_A0` pozostaje `YELLOW` po samym SHORT_BASELINE; nie zmieniamy znaczenia GREEN zdefiniowanego dla pełnego baseline.

### Aktualizacja prawdy o firmware
Wcześniejszy §4 tego pliku zawiera historyczną wartość `v3.11.4`. Aktualny `main_centrala.cpp` deklaruje `FIRMWARE_VERSION = v3.13.0`; przed kolejnym wydaniem artefaktu dokumentacja musi zostać ujednolicona, bez usuwania historii.

### Następne działanie operatora
```powershell
powershell -ExecutionPolicy Bypass -File ".\\R188_CAPTURE_1.7_FIXED.ps1" -Port COM5
```
Po `R188 AKTYWNE` pozostawić centralę bez ingerencji przez minimum 6 h i zakończyć ENTER. Nie wykonywać OTA/update/restart ani testów ingerujących w automatykę.

### Następny krok AI
Po dostarczeniu artefaktu sesji wykonać analizę restartów, ciągłości HEALTH, pamięci i dowodów; dopiero wtedy rozstrzygnąć `SHORT_BASELINE PASS/FAIL` i status `COMMIT_A`.

## R213 — COMMIT A PREFLIGHT / BEZ ZMIANY FIRMWARE
**Data:** 2026-09-25

### Przegląd aktualnego źródła
Przed Commit A wykonano analizę `main_centrala.cpp` pod kątem istniejącej diagnostyki.

Potwierdzone już w firmware:
- `diagCheckpoint()` zapisuje `freeHeap`, `largestBlock` i `stackHwmWords` dla LOOP/tgTask/tgPollTask/historiaTask;
- `HEALTH` emituje obecnie `heap` i `largest` około co 30 s;
- istnieje wspólny `fbLoopWorkerZajety()` / `g_fbLoopWorkerZajety` dla ochrony przed równoległym wejściem do `fbApp.loop()`;
- trzy główne taski projektu są tworzone dynamicznie na Core 0: `tgTask`, `tgPollTask`, `historiaTask`;
- `fbLoopWork` i `dnsLookup` są taskami pomocniczymi tworzonymi tylko w określonych ścieżkach.

### Wniosek dla Commit A
Nie należy duplikować istniejących checkpointów ani zmieniać `HEALTH` w sposób, który utrudni porównanie z baseline. Commit A powinien dodać tylko brakujące, jawnie nazwane kanały:
- internal free / largest / minimum-ever;
- PSRAM free / largest / minimum-ever;
- obserwację HWM dla konkretnych tasków bez przenoszenia ich stosów do PSRAM;
- `Firebase taskCount`, jeżeli API aktualnej biblioteki rzeczywiście udostępnia ten pomiar;
- placeholdery liczników telemetryki pozostawione na zero, bez producenta i bez transportu.

### Twarda granica
Do czasu uzyskania `SHORT_BASELINE PASS` nie zmieniamy `main_centrala.cpp`, nie tworzymy `TelemetrySample`, `TelemetryRing`, nowego endpointu RTDB ani nowych tasków telemetrycznych.

### Status
`R213 = COMMIT_A_PREFLIGHT_COMPLETE`
`FIRMWARE_CHANGE = NONE`
`NEXT = SHORT_BASELINE v3.13.0`


## R214 — COMMIT A IMPLEMENTATION / STATIC CHECKED
**Data:** 2026-09-25

### Zakres wykonany
Przygotowano pierwszy funkcjonalny commit telemetryczny zgodnie z zamrożonym zakresem A. Nie dodano producenta próbek, ringu ani zapisu do Firebase.

### Zmiany w firmware
- `FIRMWARE_VERSION`: `v3.13.0` -> `v3.14.0`.
- Nowy `RuntimeDiagState` przechowuje snapshot INTERNAL/PSRAM, HWM tasków i `fbAsyncClient.taskCount()`.
- Nowa funkcja `diagRuntimeSnapshot()` wykonuje pomiar z istniejącej `loop()` co 30 s.
- Pamięć jest rozdzielona na `MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT` oraz `MALLOC_CAP_SPIRAM`; dla każdej klasy logowane są free/largest/minimum.
- HWM jest odczytywany dla `loopTask`, `tgTask`, `tgPollTask`, `historiaTask`. Na ESP32-S3 `uxTaskGetStackHighWaterMark()` jest traktowane jako bajty.
- `fbAsyncClient.taskCount()` jest tylko obserwacją kolejki klienta; nie wykonuje nowego requestu telemetrycznego.
- Dodano zerowe placeholdery `g_telemetrySamplesProduced` i `g_telemetrySamplesDropped`.
- Dotychczasowy `tag=HEALTH` pozostaje bez zmian; diagnostyka A jest osobnym `tag=HEALTH-A`.

### Granica Commit A — potwierdzona
NIE dodano:
`TelemetrySample`, `TelemetryRing`, `Database.update`, nowego RTDB path, persistent spool, freshness metadata, `sessionNonce`, `sampleSeq`, `TelemetryTask`, migracji auth/TLS/Rules.

### Walidacja statyczna
- baseline `main_centrala.cpp` SHA-256 pozostaje: `c094eaa798547e209ef1f5fdb4156e7b8426b13dff94e24ecbf3ad63eba67926`;
- dodany kod ma zbilansowane `{}`, `[]`, `()` w diffie;
- wersja i pojedyncze punkty wejścia są spójne;
- `fbAsyncClient.taskCount()` potwierdzono w dokumentacji FirebaseClient.
- nie wykonano jeszcze builda PlatformIO ani testu runtime v3.14.0 w tym środowisku.

### Artefakty
`main_centrala_v3.14.0_COMMIT_A.cpp`
SHA-256 zostanie podany w komunikacie operatora po finalnym zapisie.

`COMMIT_A_v3.14.0.patch` — unified diff względem baseline v3.13.0.

### Następny krok
Na Windows: zbudować v3.14.0 w faktycznym środowisku projektu. Następnie wykonać test A: cold boot -> 30 min normal network -> 30 min WiFi OFF -> 30 min WiFi ON. Bez telemetrycznych zapisów Firebase. Dopiero po PASS otwieramy Commit B.

**Status:** `COMMIT_A_STATIC_CHECKED / RUNTIME_PENDING`

---

## R215 — aktualizacja po runtime Commit A i freeze Commit B

### Aktualny runtime
- Firmware na centrali: `v3.14.0`
- Boot podczas ostatniego testu: `26`
- Commit A: `RUNTIME_OBSERVED_STABLE_SHORT_TEST`
- brak potrzeby kolejnego uploadu przed przygotowaniem B

### R188
- `R188_20260925_083156.zip` SHA-256: `3745fd8309a8cf1d2cc943e4ba9f5fd610e3f13a8f50d9c1ac71088df2891d6d`
- 5 h 47 min 19.805 s
- `654 HEALTH`
- `R188_24H_SINGLE_VERSION_BASELINE = NOT ACHIEVED`
- `GATE_A0 = YELLOW`

### Commit B — nowy freeze
`TelemetrySample = 80 B` pozostaje ABI binary sample.
`hasGoodValue`, `lastAttemptMonoMs`, `lastGoodMonoMs`, `sourceState` są metadata lokalnego sidecaru `TelemetryFreshnessState[11]`, a nie polami 80-B sample.

Kanały 11:
`t_zewn, t_bojler, t_ogrz, t_ogrz_sr, t_powrot, t_panel, t_pokoj, t_trociny, rh, pressure, dym`.

`qualityBits`: 2 bity/kanał.
`ageS[11]`: uint16, 65535 = brak last-good.
`simulatedBits`: osobna maska.
`stateBits`: tylko PUMP_ON / SMOKE_ALARM / SMOKE_SENSOR_ENABLED.
`sessionNonce`: uint64.
`sampleSeq`: uint32, owner = producent Core 1.
`monoMs`: uint32 w sample; długotrwały age liczony z lokalnego zegara monotonicznego 64-bit.

### Szczególna uwaga
Freshness `t_ogrz_sr` musi śledzić faktyczny materiał wejściowy średniej. Dlatego istniejące bufory średniej dostaną równoległą metadata czasu/źródła; nie wolno oznaczać tej wartości FRESH tylko dlatego, że `obliczanie_srednia()` się wykonało.

### Następny etap
Przygotowanie `v3.15.0` — Commit B, bez ringa, Firebase, JSON i LittleFS.


## R216 — COMMIT B STATIC AUDIT / KOREKTY
**Data:** 2026-09-25

- `v3.15.0` pozostaje artefaktem historycznym wejściowym dla Commit B.
- Aktualny przygotowany firmware: **v3.15.1**, bez uploadu na centralę.
- `TelemetrySample` ABI pozostaje **80 B**.
- Freshness sidecar używa 64-bit monotonic ms (`esp_timer_get_time()`), natomiast `monoMs` w sample pozostaje `uint32_t`.
- Wygasła symulacja nie może pozostawić wartości jako FRESH; `simulatedBits` może pozostać ustawiony do czasu fizycznego ACCEPT.
- `stateBits` ograniczono do: `PUMP_ON`, `SMOKE_ALARM`, `SMOKE_SENSOR_ENABLED`.
- `sessionNonce` jest ephemeral, generowany z `esp_random()`, niezależnie od stanu WiFi.
- Hostowe testy C++ potwierdziły kluczowe zachowania TV02/04/10/13/15/16/17.
- Pełny PlatformIO/ESP-IDF build nie był dostępny w tym środowisku (`pio`/`arduino-cli` nieobecne).
- Ring, Firebase writer, JSON i LittleFS spool nadal NIE są częścią tego etapu.
- `GATE_A0 = YELLOW`.
- Następny krok operacyjny: review artefaktu → build na Windows → dopiero wtedy runtime test v3.15.1; po jego potwierdzeniu kolejna część Commit B to PSRAM TelemetryRing.

## R217 — PLATFORMIO BUILD PASS
Data: 2026-09-25

Operator wykonano rzeczywisty build `v3.15.1` dla środowiska `esp32-s3-n16r8`.
Wynik: **SUCCESS**; powstał combined binary image.
Czas: 218.87 s.

To zamyka wcześniejszą lukę dowodową R216 dotyczącą braku pełnego buildu PlatformIO/ESP-IDF.
Nie jest to jeszcze runtime PASS i nie potwierdza poprawności zachowania na centrali.

### Następny krok
Kontrolowany upload USB v3.15.1 → runtime capture → ocena bez restartu/OTA/ingerencji.
Po pozytywnym runtime dopiero otwieramy PSRAM SPSC TelemetryRing.
