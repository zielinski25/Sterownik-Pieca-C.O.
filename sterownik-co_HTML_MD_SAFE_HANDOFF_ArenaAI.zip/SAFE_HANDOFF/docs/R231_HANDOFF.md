# R231 HANDOFF — Piec_CO

Data: 2026-09-26

## CURRENT
- Produkcyjna centrala: v3.19.2.
- Telemetryka V1: zamknieta na v3.19.2.
- Ostatni runtime telemetryki: stabilny, Drop=0; pojedynczy blad transportu zostal obsluzony przez backlog/ring bez utraty probki.
- Nastapny etap: Commit F1, LittleFS + coredump hardening.

## NEXT
Local build/test only, no OTA until local PASS.

Candidate:
`main_centrala_v3.19.3_COMMIT_F_FS_COREDUMP.cpp`

Patch:
`COMMIT_v3.19.3_COMMIT_F_FS_COREDUMP.patch`

Plan:
`R231_COMMIT_F_PLAN.md`

## SAFETY
- Prawdziwy piec: tylko OTA, nigdy USB.
- Pusty/testowy ESP32-S3: USB/build/upload dozwolone.
- `/testcrash TAK` tylko na plytce testowej z odrebnym botem Telegram; przy wspolnym bocie z piecem nie wykonywac.
- Nie odcinac routera/polaczenia na prawdziwym piecu.
- Nie mieszac F1 z telemetryka, Firebase, auth/TLS ani toolchain upgrade.
