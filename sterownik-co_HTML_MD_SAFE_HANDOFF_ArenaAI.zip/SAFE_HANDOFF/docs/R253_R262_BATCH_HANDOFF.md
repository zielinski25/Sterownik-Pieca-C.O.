# R253-R262 HANDOFF

Build: v3.22.0 LOCAL ONLY

1. Wgraj v3.22.0 przez USB na pusta plytke testowa.
2. W Telegramie wpisz: /spoolbatch TAK
3. Jedna odpowiedz zawiera PASS/FAIL dla R253-R262.
4. Oczekiwany stan to wszystkie R253..R262 = PASS.
5. Po batchu uruchom osobno R252:
   /spool252 TAK
   poczekaj na 3 kolejne normalne probki
   /spool252verify

Produkcji nie aktualizowac. v3.19.2 pozostaje na prawdziwym sterowniku.
