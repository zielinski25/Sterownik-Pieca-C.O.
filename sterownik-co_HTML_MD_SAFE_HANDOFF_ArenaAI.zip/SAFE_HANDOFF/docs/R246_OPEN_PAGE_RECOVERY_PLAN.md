# R246 — recovery strony otwartej Persistent Spool V2

Status: READY do testu lokalnego.

Cel: sprawdzić, że strona zapisana bez footer commit pozostaje odzyskiwalna do ostatniego poprawnego rekordu.

Format testu:
- header 64 B
- 4 rekordy × 84 B
- brak footer
- plik 400 B

Komendy:
- `/spoolopen TAK` — zapisuje open page bez footeru
- `/spoolrecover` — waliduje header CRC i 4 rekordy CRC; brak footeru jest oczekiwanym stanem OPEN

PASS:
`recovery OK ... headerCRC=OK recordCRC=OK footer=ABSENT open=RECOVERABLE`

Zakres: LOCAL ONLY. Brak zmiany normalnej telemetryki V1. Prawdziwy piec pozostaje poza tym buildem.
