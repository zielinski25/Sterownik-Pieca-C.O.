# R249 — pełna strona Spool V2

Cel: potwierdzić pełną zamrożoną pojemność bezpiecznej strony 64 KiB:

- header: 64 B
- rekord: 84 B
- safe records: 768
- footer: 64 B
- całkowity zapis: 64_640 B

Test lokalny, bez integracji z produkcyjnym spoolem.

Kroki:
1. Wgrać v3.20.9 na pustą płytkę.
2. Telegram: `/spool249 TAK`
3. Firmware zapisuje najpierw `.part`.
4. Po zapisie wykonuje `flush`, `close`, `reopen` i kontrolę rozmiaru 64640 B.
5. Weryfikuje header CRC, CRC 768 rekordów, page CRC, footer CRC i commit marker.
6. Dopiero po pełnej weryfikacji wykonuje rename `.part` -> plik finalny.
7. Ponownie weryfikuje plik finalny.

PASS: `R249 full page: PASS` oraz `size=64640 records=768 headerCRC=OK recordCRC=OK pageCRC=OK footerCommit=OK`.

Produkcja: v3.19.2 bez zmian.
