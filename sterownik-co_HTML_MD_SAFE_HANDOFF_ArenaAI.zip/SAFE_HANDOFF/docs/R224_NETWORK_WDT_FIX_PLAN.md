# R224 — v3.18.1 Network/WDT fix

## Wynik R223
- czas capture: 9 min 53.187 s
- reboot/PANIC: 0
- coredump: 0
- HEALTH: 5 w raporcie capture
- telemetry_dropped: 0
- `task_wdt: esp_task_wdt_reset(...): task not found`: 19 576 wystąpień

## Przyczyna
v3.18.0 celowo odsubskrybował `tgTask` i `tgPollTask` z TWDT, ale wspólne funkcje nadal wywoływały bezpośrednio `esp_task_wdt_reset()`. ESP-IDF dokumentuje, że niezsubskrybowany task zwraca `ESP_ERR_NOT_FOUND`; po usunięciu subskrypcji należy przestać wołać reset bezpośrednio.

## Naprawa v3.18.1
Dodano `serwisujTWDTJesliZarejestrowany()` używający `esp_task_wdt_status(NULL)`. Helper wywołuje `esp_task_wdt_reset()` wyłącznie wtedy, gdy bieżący task jest subskrybowany. Pozostała logika telemetryki, Firebase, sterowania i heartbeatów bez zmian.

## Test
Najpierw build obu środowisk. Bez uploadu do czasu potwierdzenia obu `SUCCESS`.
