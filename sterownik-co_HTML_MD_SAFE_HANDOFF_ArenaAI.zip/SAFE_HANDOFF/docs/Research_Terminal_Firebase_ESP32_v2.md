# Research: zdalny terminal diagnostyczny ESP32 → Firebase → zakładka Terminal

**Projekt:** Piec C.O. / ESP32-S3\
**Baza:** firmware v3.31.19\
**Cel:** opcjonalne zdalne oglądanie diagnostyki urządzenia z poziomu
zakładki „Terminal", bez stałego wysyłania logów do Firebase.

------------------------------------------------------------------------

## 1. Cel funkcji

Chcemy mieć w panelu webowym:

-   zakładkę **Terminal**,
-   przycisk **Włącz wysyłanie**,
-   przycisk **Wyłącz wysyłanie**,
-   bieżący terminal przewijany jak konsola,
-   informację o stanie transmisji,
-   licznik odebranych bajtów/linii,
-   licznik utraconych wpisów,
-   opcjonalnie przycisk **Wyczyść ekran**,
-   opcjonalnie przycisk **Pobierz log**.

Po wyłączeniu transmisji urządzenie ma wrócić do normalnego działania i
nie wykonywać okresowych wysyłek terminala.

Najważniejsza zasada:

> Diagnostyka ma być dodatkiem do działającego firmware, a nie nowym
> kanałem, który może destabilizować telemetrię, Firebase, WiFi, OTA
> albo watchdog.

------------------------------------------------------------------------

# 2. Wynik researchu --- najważniejszy wniosek

Najlepszym kierunkiem dla tego projektu nie jest wysyłanie pojedynczej
linii Serial do Firebase.

Najbardziej sensowna architektura to:

``` text
                 ┌──────────────► fizyczny Serial
                 │
log/Serial ──► lokalny bufor diagnostyczny
                 │
                 ▼
           RAM ring buffer
                 │
          co ~5 sekund
                 │
                 ▼
        Firebase RTDB / chunks
                 │
                 ▼
          zakładka Terminal
```

Czyli:

**log powstaje raz → trafia do RAM → fizyczny Serial nadal działa →
tylko gdy terminal jest ON, Firebase dostaje porcje logów.**

ESP-IDF posiada oficjalny mechanizm ring bufferów przeznaczony właśnie
do bezpiecznego przekazywania danych o zmiennej długości pomiędzy
zadaniami. Dokumentacja wskazuje ring buffer jako bardziej odpowiedni od
klasycznej kolejki, gdy elementy mają zmienny rozmiar.\
Źródło: ESP-IDF FreeRTOS ring buffers.

------------------------------------------------------------------------

# 3. Ring buffer --- bardzo dobry kandydat

ESP-IDF udostępnia `xRingbufferCreate()` oraz warianty ring bufferów dla
danych o zmiennej długości.

Ważne cechy:

-   FIFO,
-   dane mogą mieć różną długość,
-   można przekazywać dane pomiędzy taskami,
-   nadaje się do strumienia tekstowego,
-   można kontrolować rozmiar pamięci,
-   istnieje również wariant byte buffer.

Źródło:
https://docs.espressif.com/projects/esp-idf/en/latest/esp32s2/api-reference/system/freertos_additions.html

### Dla naszego projektu

Rozważyć:

``` text
RAM diagnostyczny:
64 KB  — minimum
128 KB — rozsądny wariant
256 KB — bardzo bezpieczny wariant, jeśli PSRAM jest dostępny
```

ESP32-S3 z PSRAM daje tutaj duży komfort.

ESP-IDF pozwala jawnie alokować pamięć z PSRAM przez
`heap_caps_malloc(..., MALLOC_CAP_SPIRAM)`.

Źródło:
https://docs.espressif.com/projects/esp-idf/en/stable/esp32/api-guides/external-ram.html

------------------------------------------------------------------------

# 4. Bardzo ważne: co oznacza „cały Serial"

To jest najtrudniejsza część projektu.

## A. ESP-IDF `ESP_LOGx`

ESP-IDF ma oficjalny mechanizm:

``` cpp
esp_log_set_vprintf(...)
```

Pozwala przekierować wyjście logów do własnej funkcji.

Dokumentacja wprost podaje możliwość przekierowania logów np. do pliku
lub sieci.

Źródło:
https://docs.espressif.com/projects/esp-idf/en/v5.1.2/esp32/api-reference/system/log.html

To jest bardzo dobry mechanizm dla:

``` cpp
ESP_LOGI(...)
ESP_LOGW(...)
ESP_LOGE(...)
ESP_LOGD(...)
```

Możemy zrobić:

``` text
ESP_LOG
   ├──► oryginalny UART
   └──► terminalRingBuffer
```

## B. Arduino `Serial.print()`

To osobna sprawa.

`esp_log_set_vprintf()` nie przechwytuje automatycznie każdego:

``` cpp
Serial.print(...)
Serial.println(...)
Serial.printf(...)
```

Dlatego jeżeli przez „cały Serial" rozumiemy absolutnie wszystko, trzeba
zastosować dodatkową warstwę.

Najbezpieczniejsze rozwiązanie:

``` cpp
Serial.println(...)
        ↓
TeeSerial / DiagnosticSerial
        ├──► prawdziwy Serial
        └──► ring buffer
```

Nie należy robić prostego:

``` cpp
Firebase.setString(...)
```

wewnątrz `Serial.println()`.

To mogłoby blokować logowanie i mieszać odpowiedzialności.

------------------------------------------------------------------------

# 5. Jeszcze lepszy wariant: wspólny system logowania

Zamiast przechwytywać przypadkowo wszystkie `Serial.print`, warto
docelowo uporządkować diagnostykę:

``` text
LOG_ERROR()
LOG_WARN()
LOG_INFO()
LOG_DEBUG()
LOG_TELEMETRY()
LOG_FIREBASE()
LOG_WIFI()
LOG_OTA()
LOG_SPOOL()
```

Każdy wpis może mieć:

``` text
timestamp
level
tag
tekst
```

Np.:

``` text
14:32:05.124 [INFO] WIFI       RSSI=-79
14:32:05.220 [DEBUG] FIREBASE  worker=IDLE
14:32:06.003 [INFO] TELEMETRY producer=REAL_SNAPSHOT
14:32:06.711 [WARN] FIREBASE  timeout
```

Dzięki temu w przyszłości Terminal może mieć filtr:

``` text
[ALL] [ERROR] [WARN] [INFO] [DEBUG]
```

To byłoby dużo bardziej użyteczne niż bezładny strumień tekstu.

------------------------------------------------------------------------

# 6. Firebase RTDB --- jak wysyłać log

Firebase Realtime Database obsługuje:

-   `set`,
-   `update`,
-   `push`,
-   transakcje.

Do logów najbardziej naturalny jest model **push/chunks**.

Źródło: https://firebase.google.com/docs/database/admin/save-data

Proponowana struktura:

``` text
/piec/terminal/
    enabled
    sessionId
    lastSeq
    dropped
    lastUploadMs

/piec/terminal/chunks/
    <chunkId>
        seq
        ts
        text
        bytes
```

Przykład:

``` json
{
  "seq": 1842,
  "ts": 1790685125000,
  "text": "14:32:05.124 [INFO] WIFI RSSI=-79\n...",
  "bytes": 1260
}
```

------------------------------------------------------------------------

# 7. Dlaczego CHUNKS, a nie jedno pole `terminalText`

Nie:

``` text
/piec/terminal/text = "cały terminal..."
```

Bo pole będzie cały czas rosnąć.

Lepiej:

``` text
chunks/
    1001
    1002
    1003
    1004
```

Każdy chunk jest niezależny.

Frontend może obserwować tylko nowe elementy.

Firebase dokumentuje mechanizmy nasłuchiwania zmian przez `onValue()`
oraz zdarzenia dzieci. Przy dużych danych należy słuchać możliwie nisko
w drzewie, a nie na korzeniu.

Źródło: https://firebase.google.com/docs/database/web/read-and-write

------------------------------------------------------------------------

# 8. Jeszcze lepiej: `onChildAdded`

Dla terminala naturalny jest model:

``` text
Firebase
    ↓
nowy chunk
    ↓
onChildAdded
    ↓
appendTerminalText()
```

Wtedy przeglądarka nie musi pobierać całego terminala za każdym razem.

To jest ważne przy długiej sesji diagnostycznej.

------------------------------------------------------------------------

# 9. Częstotliwość wysyłania --- 5 sekund

Pomysł użytkownika:

``` text
co 5 sekund
```

jest rozsądny.

Nie wysyłałbym jednak pustych paczek.

Algorytm:

``` text
co 5 s:

jeżeli terminal OFF:
    nic

jeżeli terminal ON:
    jeżeli ring buffer pusty:
        nic

    jeżeli są dane:
        pobierz maksymalnie np. 4–8 KB
        utwórz chunk
        wyślij Firebase
```

Dzięki temu:

-   przy spokojnym piecu prawie nic nie idzie,
-   przy dużym logowaniu dane są grupowane,
-   liczba operacji Firebase jest mała,
-   terminal wygląda na żywy.

------------------------------------------------------------------------

# 10. Limit wielkości pojedynczego chunka

Nie ma sensu robić:

``` text
1 chunk = 100 KB
```

Lepiej np.:

``` text
1–8 KB / chunk
```

W praktyce proponuję:

``` text
target: 4 KB
hard max: 8 KB
```

Jeżeli przez 5 sekund powstanie 1 KB:

``` text
wysyłamy 1 KB
```

Jeżeli powstanie 20 KB:

``` text
chunk 1 = 8 KB
chunk 2 = 8 KB
chunk 3 = 4 KB
```

------------------------------------------------------------------------

# 11. Firebase ma odpowiednie limity

Aktualna dokumentacja Firebase RTDB podaje m.in.:

-   do 1000 write operations/s na bazę,
-   maksymalnie 256 MB pojedynczego zapisu przez REST,
-   16 MB przez SDK,
-   64 MB/min całkowitego zapisu danych.

Źródło: https://firebase.google.com/docs/database/usage/limits

Nasza diagnostyka będzie wielokrotnie poniżej tych limitów.

Problemem nie jest więc sam limit Firebase, tylko przede wszystkim:

-   stabilność ESP,
-   zużycie transferu,
-   liczba niepotrzebnych operacji,
-   rozrost danych diagnostycznych.

------------------------------------------------------------------------

# 12. Automatyczne czyszczenie

Terminal diagnostyczny nie powinien być archiwum na zawsze.

Proponuję:

``` text
terminal session
        ↓
start
        ↓
chunks
        ↓
stop
        ↓
opcjonalne czyszczenie
```

Najprościej:

### Tryb A --- sesja

Przy ON:

``` text
sessionId = nowy identyfikator
```

Wszystkie chunki trafiają do tej sesji.

Przy OFF:

``` text
session kończy się
```

Frontend pokazuje tylko bieżącą sesję.

Stare dane można później usunąć.

### Tryb B --- limit

Np.:

``` text
max 500 chunków
```

Po przekroczeniu usuwamy najstarsze.

------------------------------------------------------------------------

# 13. Nie zapisujmy terminala do LittleFS

To ważne.

Nie proponuję:

``` text
Serial
  ↓
LittleFS
  ↓
Firebase
```

dla bieżącego terminala.

LittleFS można zostawić jako awaryjne archiwum, ale nie jako główny
bufor live.

Dla live diagnostyki lepszy jest:

``` text
RAM / PSRAM ring buffer
```

a Firebase jest warstwą transportową.

------------------------------------------------------------------------

# 14. Co w przypadku utraty Firebase?

To musi być obsłużone.

Przykład:

``` text
Terminal ON

14:00:00 ───── Firebase OK
14:00:05 ───── Firebase OK
14:00:10 ───── Firebase timeout
14:00:15 ───── Firebase timeout
14:00:20 ───── Firebase timeout
14:00:25 ───── Firebase OK
```

Nie możemy dopuścić, aby diagnostyka blokowała główne zadania.

Dlatego:

``` text
log → ring buffer
             ↓
       Firebase worker
             ↓
        timeout/error
             ↓
       wróć do taska
```

Jeżeli bufor się zapełni:

``` text
dropped++
```

i najstarsze dane są nadpisywane.

------------------------------------------------------------------------

# 15. Firebase może streamować dane do przeglądarki

Firebase RTDB REST API obsługuje Server-Sent Events (SSE).

Dokumentacja opisuje `text/event-stream` oraz zdarzenia `put` i `patch`.

Źródło: https://firebase.google.com/docs/reference/rest/database

Jednak dla naszego HTML prawdopodobnie lepiej pozostać przy oficjalnym
Firebase JS SDK i listenerze RTDB.

Nie ma potrzeby ręcznie implementować SSE, jeżeli aktualny panel już
korzysta z Firebase.

------------------------------------------------------------------------

# 16. Alternatywa: WebSocket bez Firebase

Można zrobić:

``` text
ESP32
  ↓
WebSocket
  ↓
przeglądarka
```

ESPAsyncWebServer/AsyncWebSocket dobrze pasuje do takiego terminala.

Ale jest jeden zasadniczy problem:

**użytkownik nie jest w tej samej sieci LAN co piec.**

Dlatego:

``` text
telefon ───── Internet ───── ESP32 w domu
```

nie dostanie się bezpośrednio do:

``` text
192.168.100.19
```

Firebase rozwiązuje ten problem.

Wniosek:

> WebSocket lokalny warto zostawić jako opcjonalny tryb serwisowy, ale
> nie jako główny kanał zdalnego terminala.

------------------------------------------------------------------------

# 17. Alternatywa: Firebase jako „most"

Najbardziej pasuje:

``` text
ESP32
  │
  │ Firebase upload
  ▼
RTDB
  │
  │ listener
  ▼
HTML Terminal
```

To daje dostęp z dowolnego miejsca.

------------------------------------------------------------------------

# 18. Alternatywa: logi binarne

ESP-IDF Log V2 posiada także tryb logowania binarnego.

Dokumentacja podaje, że binary logging może ograniczyć zużycie flash,
stacka i narzut transmisji.

Źródło:
https://docs.espressif.com/projects/esp-idf/en/stable/esp32c6/api-reference/system/log.html

Dla naszego projektu **na razie nie polecam**.

Powód:

Potrzebujemy czytelnego terminala.

Tekst:

``` text
Firebase timeout
```

jest dla nas znacznie wygodniejszy niż dekodowanie binarnych rekordów.

Binary logging można rozważyć później, jeśli okaże się, że logów jest
bardzo dużo.

------------------------------------------------------------------------

# 19. Bardzo ciekawy wariant: poziomy logowania

Można zrobić drugi parametr:

``` text
terminalEnabled
terminalLevel
```

Np.:

``` text
OFF
ERROR
WARN
INFO
DEBUG
TRACE
```

Normalnie:

``` text
terminalEnabled = false
```

Gdy włączymy:

``` text
INFO
```

Jeżeli potrzebujemy pełnego debugowania:

``` text
DEBUG
```

Dzięki temu nie zawsze trzeba wysyłać absolutnie wszystko.

ESP-IDF ma oficjalne poziomy logowania i możliwość zmiany poziomu dla
tagów w runtime.

Źródło:
https://docs.espressif.com/projects/esp-idf/en/v5.1.2/esp32/api-reference/system/log.html

------------------------------------------------------------------------

# 20. Bardzo ciekawy wariant: filtr po module

Terminal może mieć:

``` text
[✓] WIFI
[✓] FIREBASE
[✓] TELEMETRY
[✓] SPOOL
[✓] OTA
[✓] SENSOR
[✓] SYSTEM
```

Ale tutaj trzeba rozdzielić:

### filtr po stronie ESP

mniej danych wychodzi z ESP.

### filtr tylko w HTML

ESP nadal wysyła wszystko.

Na początek lepszy jest filtr HTML.

Dopiero później można dodać dynamiczne poziomy po stronie ESP.

------------------------------------------------------------------------

# 21. Włączanie terminala

Nie powinno być:

``` text
HTML → terminalEnabled=true
```

bez dodatkowej kontroli.

Lepiej użyć istniejącego mechanizmu komend Firebase:

``` text
HTML
 ↓
Firebase command
 ↓
ESP command worker
 ↓
ACK
 ↓
terminal ON
```

Czyli dokładnie ten sam model, który już wykorzystujemy do sterowania
diagnostyką/komendami.

------------------------------------------------------------------------

# 22. ACK

Po włączeniu:

``` json
{
  "cmd": "terminal_on",
  "cmdId": 1842
}
```

ESP:

``` json
{
  "cmdId": 1842,
  "status": "OK",
  "terminal": true
}
```

Frontend pokazuje:

``` text
🟢 Terminal aktywny
```

Jeżeli ESP nie odpowie:

``` text
🔴 Brak ACK
```

To jest znacznie lepsze niż samo przełączenie przycisku w HTML.

------------------------------------------------------------------------

# 23. Sesja diagnostyczna

Bardzo dobry pomysł:

``` text
Terminal ON
     ↓
sessionId = 20260929_143201
```

Każdy chunk:

``` json
{
  "session": "20260929_143201",
  "seq": 17,
  "ts": 1790685125000,
  "text": "..."
}
```

Wtedy później wiadomo:

``` text
ten log pochodzi z jednej konkretnej sesji diagnostycznej
```

------------------------------------------------------------------------

# 24. Start sesji może zawierać snapshot

To byłaby bardzo przydatna rzecz.

Po:

``` text
TERMINAL ON
```

ESP może wysłać pierwszy specjalny chunk:

``` text
========== TERMINAL SESSION START ==========
FW: v3.31.19
Uptime: ...
WiFi: CONNECTED
RSSI: -79 dBm
Firebase: READY
Free heap: ...
PSRAM: ...
Telemetry: ...
Spool: ...
RTC: ...
============================================
```

Dzięki temu od razu wiemy, w jakim stanie urządzenie rozpoczęło
diagnostykę.

------------------------------------------------------------------------

# 25. Koniec sesji

Po OFF:

``` text
========== TERMINAL SESSION END ==========
duration: 00:17:42
bytes: 184203
chunks: 91
dropped: 0
firebaseErrors: 2
===========================================
```

To jest bardzo wygodne podczas analizy.

------------------------------------------------------------------------

# 26. Co z PANIC / WDT / resetem?

To osobny temat.

Live terminal nie gwarantuje zachowania logów, jeżeli ESP:

``` text
PANIC
WDT
brownout
reset
```

Dlatego warto rozdzielić:

## Live terminal

RAM → Firebase

oraz:

## Crash diagnostics

RTC/NVS/LittleFS → po następnym starcie Firebase.

To daje dwa kanały:

``` text
TERMINAL LIVE
      +
CRASH REPORT
```

To byłaby bardzo wartościowa rozbudowa diagnostyki.

------------------------------------------------------------------------

# 27. Szczególnie interesujący wariant: ostatnie N sekund

Możemy mieć ring buffer aktywny nawet wtedy, gdy terminal jest OFF, ale
**bez wysyłania do Firebase**.

Przykład:

``` text
RAM zawsze przechowuje ostatnie 30–60 sekund logów
```

Normalnie:

``` text
Firebase = OFF
```

Jeżeli wystąpi problem:

``` text
terminal ON
```

ESP może wysłać:

``` text
[HISTORIA PRZED WŁĄCZENIEM]
+ 
[NOWE LOGI]
```

To jest znacznie ciekawsze niż zwykły terminal.

Przykład:

``` text
14:31:30 Firebase OK
14:31:40 Firebase OK
14:31:50 timeout
14:31:55 timeout
14:32:00 terminal ON
```

Po włączeniu dostajemy również logi:

``` text
14:31:05 ...
14:31:10 ...
14:31:15 ...
...
14:32:00 ...
```

czyli możemy zobaczyć **co działo się przed problemem**.

------------------------------------------------------------------------

# 28. Ten wariant wymaga ograniczenia pamięci

Nie można trzymać wszystkiego.

Proponuję:

``` text
PREBUFFER:
32 KB
```

albo:

``` text
60 sekund
```

w zależności od rzeczywistego natężenia logów.

Dopiero po ON:

``` text
LIVE BUFFER:
64–128 KB
```

------------------------------------------------------------------------

# 29. Jeszcze ciekawszy wariant: automatyczny trigger

Można kiedyś zrobić:

``` text
jeżeli:
Firebase timeout > X
WDT event
telemetry error
spool error
WiFi reconnect
heap < threshold
```

to:

``` text
automatycznie zachowaj ostatnie N sekund
```

i wyślij diagnostykę po odzyskaniu Firebase.

To już byłby **system diagnostyczny**, a nie tylko terminal.

------------------------------------------------------------------------

# 30. Bezpieczeństwo

Terminal zawiera potencjalnie dużo informacji diagnostycznych.

Nie powinien być publiczny.

Firebase Rules powinny ograniczyć:

``` text
/piec/terminal/*
```

do autoryzowanego użytkownika.

Szczególnie ważne:

-   terminal READ --- tylko użytkownik,
-   terminal command WRITE --- tylko użytkownik,
-   urządzenie nie powinno przyjmować dowolnego tekstu jako polecenia,
-   komendy powinny mieć whitelistę.

------------------------------------------------------------------------

# 31. Proponowana architektura końcowa

``` text
                     ┌──────────────────────┐
                     │      ESP32-S3        │
                     │                      │
 Serial / ESP_LOG ──►│ Diagnostic Tee       │
                     │        │             │
                     │        ▼             │
                     │   RAM Ring Buffer    │
                     │        │             │
                     │        ├──► USB/UART │
                     │        │             │
                     │        ▼             │
                     │ Firebase Worker      │
                     └────────┬─────────────┘
                              │
                              │ chunks / 5 s
                              ▼
                     ┌──────────────────────┐
                     │    Firebase RTDB     │
                     │                      │
                     │ terminal/session     │
                     │ terminal/chunks      │
                     │ terminal/state       │
                     └────────┬─────────────┘
                              │
                              │ listener
                              ▼
                     ┌──────────────────────┐
                     │   Web App / HTML     │
                     │                      │
                     │      TERMINAL        │
                     │                      │
                     │ ON / OFF             │
                     │ clear                │
                     │ filters              │
                     │ download             │
                     └──────────────────────┘
```

------------------------------------------------------------------------

# 32. Moja propozycja dla tego projektu

Nie robiłbym od razu wszystkiego.

## Etap 1 --- bezpieczny rdzeń

``` text
1. RAM ring buffer
2. terminalEnabled
3. Firebase chunks
4. wysyłanie co 5 s
5. seq
6. dropped
7. ACK
8. zakładka Terminal
```

## Etap 2 --- jakość diagnostyki

``` text
9. sessionId
10. snapshot start
11. snapshot end
12. filtry INFO/WARN/ERROR/DEBUG
13. statystyki transmisji
```

## Etap 3 --- diagnostyka awarii

``` text
14. prebuffer 30–60 s
15. crash report
16. WDT/PANIC context
17. automatyczne capture przy błędach
```

------------------------------------------------------------------------

# 33. Parametry startowe, które warto przyjąć

  Parametr                                      Propozycja
  ----------------- --------------------------------------
  Firebase upload                                   co 5 s
  chunk target                                        4 KB
  chunk max                                           8 KB
  live RAM buffer                                   128 KB
  prebuffer                                          32 KB
  seq                                               uint32
  sessionId                                timestamp/nonce
  terminal OFF                                brak uploadu
  retry                   przez istniejący Firebase worker
  ACK                                             wymagany
  filtr domyślny                                      INFO
  historia RTDB               tylko aktywna/ostatnia sesja
  firmware            bez zmian poza warstwą diagnostyczną

------------------------------------------------------------------------

# 34. Co research potwierdził

### Potwierdzone przez dokumentację Espressif

1.  Możemy użyć `esp_log_set_vprintf()` jako punktu przechwytywania
    logów ESP-IDF.
2.  ESP-IDF ma natywny ring buffer.
3.  Ring buffer jest przeznaczony do danych o zmiennej długości i
    komunikacji między taskami.
4.  PSRAM może być używany przez capability allocator.
5.  ESP-IDF posiada poziomy logowania i możliwość zmiany poziomów
    runtime.

### Potwierdzone przez dokumentację Firebase

1.  RTDB obsługuje `set`, `update`, `push` i transakcje.
2.  Można nasłuchiwać zmian po stronie webowej.
3.  Firebase RTDB obsługuje streaming REST przez SSE.
4.  Firebase ma wystarczające limity dla tak małego kanału
    diagnostycznego.
5.  Firebase ma mechanizmy pracy z utratą połączenia po stronie
    klientów.

------------------------------------------------------------------------

# 35. Wniosek końcowy

**Pomysł jest wykonalny i dobrze pasuje do obecnej architektury.**

Najbardziej podoba mi się jednak nie wersja:

``` text
Serial → Firebase co 5 s
```

lecz:

``` text
                 NORMALNA PRACA
                       │
                       ▼
              RAM prebuffer
                       │
                       │
       ┌───────────────┴───────────────┐
       │                               │
   Terminal OFF                    Terminal ON
       │                               │
   brak Firebase                chunks co ~5 s
                                       │
                                       ▼
                                   Firebase
                                       │
                                       ▼
                                  Web Terminal
```

Dzięki temu możemy później zrobić coś jeszcze lepszego:

> **„Pokaż mi ostatnie 60 sekund przed awarią + wszystko od momentu
> włączenia diagnostyki."**

To byłoby szczególnie wartościowe przy zdalnym sterowniku oddalonym od
użytkownika.

------------------------------------------------------------------------

## Źródła

-   ESP-IDF Logging API --- `esp_log_set_vprintf()` i poziomy
    logowania:\
    https://docs.espressif.com/projects/esp-idf/en/v5.1.2/esp32/api-reference/system/log.html
-   ESP-IDF FreeRTOS ring buffers:\
    https://docs.espressif.com/projects/esp-idf/en/latest/esp32s2/api-reference/system/freertos_additions.html
-   ESP-IDF External RAM / PSRAM:\
    https://docs.espressif.com/projects/esp-idf/en/stable/esp32/api-guides/external-ram.html
-   Firebase RTDB --- odczyt i listenery web:\
    https://firebase.google.com/docs/database/web/read-and-write
-   Firebase RTDB --- zapis danych:\
    https://firebase.google.com/docs/database/admin/save-data
-   Firebase RTDB --- limity:\
    https://firebase.google.com/docs/database/usage/limits
-   Firebase RTDB REST --- streaming/SSE:\
    https://firebase.google.com/docs/reference/rest/database

------------------------------------------------------------------------

## Status research

**Koncepcja: wykonalna.**

**Rekomendowany kierunek:**\
`Diagnostic Tee → RAM/PSRAM Ring Buffer → istniejący Firebase Worker → RTDB chunks → Firebase listener → zakładka Terminal`

**Firmware v3.31.19:** baza pozostaje bez zmian funkcjonalnych do czasu
zaprojektowania i przetestowania osobnego modułu diagnostycznego.

------------------------------------------------------------------------

# 36. Drugi etap researchu --- ważne odkrycia

Po sprawdzeniu aktualnej dokumentacji Espressif i Firebase pojawiło się
kilka istotnych rzeczy, które zmieniają sposób, w jaki warto
zaprojektować Terminal.

## 36.1 Nie musimy przechwytywać każdego `Serial.print()` w taki sam sposób

ESP-IDF ma oficjalny punkt:

``` cpp
esp_log_set_vprintf(...)
```

który pozwala przejąć cały strumień generowany przez `ESP_LOGx`.
Dokumentacja wymaga, aby callback był reentrant, ponieważ może być
wywoływany równolegle z różnych kontekstów. To oznacza, że callback nie
powinien wykonywać ciężkich operacji ani komunikacji z Firebase.

Źródło:
https://docs.espressif.com/projects/esp-idf/en/v5.4/esp32s3/api-reference/system/log.html

### Wniosek

Callback:

``` text
ESP_LOG
  ↓
bardzo krótki callback
  ↓
ring buffer
```

a dopiero osobny task:

``` text
ring buffer
  ↓
Firebase
```

To jest właściwy podział odpowiedzialności.

------------------------------------------------------------------------

# 37. Arduino `Serial` jest innym problemem

Arduino-ESP32 implementuje `Serial` jako `HardwareSerial`, a `Print`
udostępnia wirtualne `write()`.

Źródła:
https://github.com/espressif/arduino-esp32/blob/master/cores/esp32/Print.h
https://github.com/espressif/arduino-esp32/blob/master/cores/esp32/HardwareSerial.cpp

`Print::write()` jest bazą dla `print()/println()`, ale globalny obiekt
`Serial` jest już konkretnym `HardwareSerial`.

### Wniosek

Nie należy na siłę próbować „podmienić Serial" w całym firmware.

Lepsze są trzy warstwy:

``` text
1. ESP_LOGx → esp_log_set_vprintf()
2. istniejące własne logi → wspólny helper diagnostyczny
3. pozostałe Serial.* → etapowo uporządkować
```

Dzięki temu pierwsza wersja Terminala może być bardzo bezpieczna.

------------------------------------------------------------------------

# 38. Bardzo ważna rzecz: `HardwareSerial::write()` jest niskopoziomowe

Arduino-ESP32 ma:

``` cpp
size_t write(uint8_t);
size_t write(const uint8_t *buffer, size_t size);
```

i `HardwareSerial` przekazuje dane do warstwy UART.

Źródło:
https://github.com/espressif/arduino-esp32/blob/master/cores/esp32/HardwareSerial.cpp

Nie warto więc dodawać do ścieżki `write()` żadnego Firebase ani dużego
formatowania.

Jeżeli kiedyś zrobimy własny `DiagnosticPrint`, jego obowiązkiem powinno
być tylko:

``` text
write()
  ├── normalny Serial
  └── krótki zapis do ring buffer
```

------------------------------------------------------------------------

# 39. PSRAM jest idealnym miejscem na większy bufor

Aktualna dokumentacja ESP32-S3 potwierdza:

``` cpp
heap_caps_malloc(size, MALLOC_CAP_SPIRAM)
```

do jawnej alokacji pamięci w PSRAM.

Źródło:
https://docs.espressif.com/projects/esp-idf/en/latest/esp32s3/api-guides/external-ram.html

To pozwala zrobić np.:

``` text
128 KB live terminal buffer
+
32 KB prebuffer
```

bez zabierania dużej części wewnętrznego heapu.

Jednocześnie małe, krytyczne struktury synchronizacyjne powinny pozostać
w zwykłej RAM.

------------------------------------------------------------------------

# 40. Jeszcze lepszy model bufora

Po researchu proponuję nie jeden, lecz dwa bufory:

``` text
                 LOG
                  │
          ┌───────┴────────┐
          │                │
          ▼                ▼
    PREBUFFER           LIVE BUFFER
     32 KB               128 KB
          │                │
          │                └── tylko gdy terminal ON
          │
          └── zawsze ostatnie logi
```

### PREBUFFER

Zawsze aktywny.

Nie wysyła nic do Firebase.

Przechowuje tylko ostatnie N bajtów.

### LIVE BUFFER

Aktywny dopiero po:

``` text
terminalEnabled = true
```

Możemy dzięki temu uzyskać bardzo dobrą funkcję diagnostyczną bez
stałego transferu.

------------------------------------------------------------------------

# 41. Możemy wysłać historię przed włączeniem

Przy:

``` text
TERMINAL ON
```

pierwszy pakiet:

``` text
type = "prebuffer"
```

zawiera ostatnią historię.

Następne:

``` text
type = "live"
```

zawierają nowe logi.

Frontend może wizualnie oddzielić:

``` text
────── HISTORIA PRZED WŁĄCZENIEM ──────

14:28:31 ...
14:28:32 ...
14:28:35 ...

────── LIVE ──────

14:29:01 ...
14:29:02 ...
```

To jest bardzo mocne narzędzie diagnostyczne.

------------------------------------------------------------------------

# 42. Firebase --- `push()` + `onChildAdded()` pasuje prawie idealnie

Firebase dokumentuje `onChildAdded()` jako mechanizm przeznaczony do
list danych: callback jest wywoływany dla istniejących dzieci oraz
ponownie dla każdego nowego dziecka.

Źródła: https://firebase.google.com/docs/reference/js/database
https://firebase.google.com/docs/database/web/lists-of-data

To oznacza, że możemy zrobić:

``` text
/piec/terminal/sessions/<sessionId>/chunks/
```

i frontend:

``` text
onChildAdded(...)
```

dostaje kolejne paczki.

Nie trzeba co 5 sekund robić:

``` text
pobierz cały terminal
```

------------------------------------------------------------------------

# 43. `limitToLast()` daje nam dodatkową ochronę

Firebase pozwala ograniczyć zapytanie:

``` js
limitToLast(N)
```

Dokumentacja potwierdza, że query może ograniczyć liczbę
synchronizowanych elementów.

Źródło: https://firebase.google.com/docs/database/web/lists-of-data

Możemy więc przy otwarciu Terminala pobrać np.:

``` text
ostatnie 100 chunków
```

a potem słuchać tylko nowych.

To jest lepsze niż ładowanie całej historii.

------------------------------------------------------------------------

# 44. Możemy też wymusić ograniczenie w Security Rules

To jest szczególnie ciekawe.

Firebase Security Rules mogą sprawdzać parametry query, w tym:

``` text
query.orderByKey
query.limitToLast
```

Źródło:
https://firebase.google.com/docs/database/security/rules-conditions

Dzięki temu można nie tylko poprosić frontend o:

``` text
limitToLast(100)
```

ale również wymusić w regułach, że klient nie może żądać nieograniczonej
historii.

To jest dodatkowa ochrona przed przypadkowym pobraniem ogromnego
terminala.

------------------------------------------------------------------------

# 45. Firebase limity są dla naszego rozwiązania bardzo duże

Aktualna dokumentacja RTDB podaje:

-   1000 writes/s na bazę,
-   64 MB/min zapisywanych danych,
-   16 MB maksymalnego zapisu przez SDK,
-   256 MB przez REST,
-   10 MB maksymalnej długości pojedynczego stringa.

Źródło: https://firebase.google.com/docs/database/usage/limits

Nasz terminal będzie wielokrotnie poniżej tych wartości.

Przykład:

``` text
4 KB co 5 s
```

to:

``` text
0.8 KB/s
48 KB/min
```

Nawet:

``` text
8 KB co 5 s
```

to tylko:

``` text
1.6 KB/s
96 KB/min
```

Czyli ograniczeniem nie jest Firebase.

Ograniczeniem jest raczej:

``` text
ESP32
TLS
Firebase worker
zużycie RAM
wpływ logowania na timing
```

------------------------------------------------------------------------

# 46. Dlatego nie potrzebujemy wysyłać co 5 sekund, jeżeli nie ma danych

To można jeszcze poprawić.

Timer 5 s powinien być:

``` text
maksymalnym okresem flush
```

a nie obowiązkowym zapisem.

Algorytm:

``` text
co 5 s:

if buffer == empty:
    return

flush(buffer)
```

Jeżeli pojawi się dużo danych:

``` text
flush wcześniej
```

np.:

``` text
buffer >= 4 KB
```

wtedy wysyłamy natychmiast.

To daje:

``` text
mały ruch → mało Firebase
duży log → szybkie opróżnianie
```

------------------------------------------------------------------------

# 47. Firebase po stronie ESP może pracować asynchronicznie

Aktualny ekosystem Firebase dla Arduino ma przykłady asynchronicznych
operacji RTDB.

Nowa biblioteka `FirebaseClient` pokazuje:

``` cpp
Database.set<T>(async_client, path, value, callback, uid);
```

oraz obsługę `AsyncResult`.

Źródła: https://github.com/mobizt/FirebaseClient
https://github.com/mobizt/FirebaseClient/blob/main/examples/RealtimeDatabase/Set/Set.ino

Starsza biblioteka Firebase-ESP32/Firebase-ESP-Client również udostępnia
warianty `pushStringAsync()` i `pushJSONAsync()`.

Źródło:
https://github.com/mobizt/Firebase-ESP32/blob/master/src/README.md

### Ważny wniosek

Nie trzeba zmieniać całego systemu na nową bibliotekę tylko po to, żeby
zrobić Terminal.

Najpierw należy wykorzystać **istniejący worker Firebase** w v3.31.19.

------------------------------------------------------------------------

# 48. Nie dodawałbym drugiego stałego połączenia Firebase tylko dla Terminala

Research bibliotek pokazuje, że dodatkowe `AsyncClient`/SSL client może
zwiększać zużycie pamięci, a społeczność biblioteki zgłaszała problemy z
pamięcią przy wielu klientach/streamach.

Przykład dyskusji:
https://github.com/mobizt/FirebaseClient/discussions/34
https://github.com/mobizt/FirebaseClient/discussions/77

Nie jest to dowód, że dodatkowy klient zawsze będzie problemem, ale dla
naszego stabilnego sterownika jest to niepotrzebne ryzyko.

### Decyzja projektowa

``` text
NIE:
Terminal → osobny Firebase client

TAK:
Terminal → istniejący Firebase worker
```

------------------------------------------------------------------------

# 49. Możemy mieć dwa kanały Firebase

To jest bardzo ciekawa możliwość.

``` text
Firebase worker
    │
    ├── normalna telemetria
    │
    ├── komendy / ACK
    │
    └── terminal chunks
```

Ale terminal musi być:

``` text
najniższy priorytet
```

Jeżeli wystąpi konflikt:

``` text
telemetria > komenda/ACK > terminal
```

Terminal nigdy nie powinien blokować ważniejszych operacji.

------------------------------------------------------------------------

# 50. Terminal może mieć budżet czasowy

Jeszcze lepsze zabezpieczenie:

``` text
max terminal work per cycle = np. 5–10 ms
```

Jeżeli jest 100 KB zaległych logów:

``` text
nie wysyłamy wszystkiego naraz
```

tylko porcjami.

To chroni:

-   watchdog,
-   telemetrię,
-   WiFi,
-   Firebase,
-   timing sterowania.

------------------------------------------------------------------------

# 51. Terminal może mieć automatyczny limit sesji

Przycisk:

``` text
Włącz terminal
```

może mieć opcję:

``` text
[30 min]
[1 h]
[4 h]
[bez limitu]
```

Po czasie:

``` text
terminal OFF
```

To zabezpiecza przed przypadkowym pozostawieniem diagnostyki włączonej
przez kilka dni.

------------------------------------------------------------------------

# 52. Bardzo dobry pomysł: „AUTO OFF po braku użytkownika"

Frontend może wysłać:

``` text
terminal_touch
```

ale nie polegałbym tylko na przeglądarce.

Bezpieczniej:

``` text
ESP terminal timeout = np. 60 min
```

Po 60 minutach:

``` text
terminalEnabled=false
```

i ESP przestaje wysyłać logi nawet jeżeli telefon został zamknięty.

------------------------------------------------------------------------

# 53. Terminal powinien raportować własną kondycję

W `terminal/state`:

``` json
{
  "enabled": true,
  "session": "20260929_1432",
  "bufferBytes": 3821,
  "bufferFree": 127651,
  "dropped": 0,
  "uploadedBytes": 18231,
  "uploadedChunks": 7,
  "firebaseErrors": 0,
  "lastUploadMs": 1790685125000
}
```

To daje nam możliwość sprawdzenia:

``` text
czy problem jest w logowaniu
czy w Firebase
czy w buforze
```

------------------------------------------------------------------------

# 54. Terminal może mieć diagnostykę „meta"

Możemy w terminalu pokazać osobny pasek:

``` text
TERMINAL: ON
BUF: 3.8 KB / 128 KB
DROP: 0
UPLOAD: 18.2 KB
CHUNKS: 7
FB ERR: 0
LAST: 2.1 s
```

To jest bardzo przydatne podczas zdalnej diagnostyki.

------------------------------------------------------------------------

# 55. Co z `ESP_LOG` podczas krytycznych sekcji?

Dokumentacja Espressif zaznacza, że logowanie w sekcjach krytycznych i
przy wyłączonych przerwaniach jest ograniczone; istnieją warianty
`ESP_DRAM_LOGx`, ale Espressif zaleca oszczędność.

Źródło:
https://docs.espressif.com/projects/esp-idf/en/v5.0.4/esp32s3/api-reference/system/log.html

### Wniosek

Nasz callback logowania musi być bardzo lekki.

Nie:

``` text
ESP_LOG
 ↓
String
 ↓
JSON
 ↓
Firebase
```

Tylko:

``` text
ESP_LOG
 ↓
timestamp/tag/text
 ↓
ring buffer
```

------------------------------------------------------------------------

# 56. Czego NIE robić

## Nie:

``` cpp
Serial.println(text);
Firebase.RTDB.setString(...);
```

w każdym miejscu logowania.

## Nie:

``` cpp
Firebase.RTDB.setString(..., całyTerminal);
```

co 5 sekund.

## Nie:

``` text
terminal → LittleFS → Firebase
```

jako główny live path.

## Nie:

``` text
Terminal → osobny ciężki SSL client
```

jeżeli istniejący worker może obsłużyć kolejkę.

## Nie:

``` text
frontend pobiera cały /terminal
```

przy każdym odświeżeniu.

------------------------------------------------------------------------

# 57. Nowa architektura po drugim researchu

``` text
                         ESP32-S3
                            │
              ┌─────────────┴─────────────┐
              │                           │
          ESP_LOGx                    własne logi
              │                           │
              └─────────────┬─────────────┘
                            ▼
                    Diagnostic Sink
                            │
             ┌──────────────┴──────────────┐
             ▼                             ▼
       PREBUFFER 32 KB               LIVE BUFFER 128 KB
       zawsze aktywny                tylko TERMINAL ON
             │                             │
             └──────────────┬──────────────┘
                            ▼
                    Diagnostic Worker
                            │
                max ~5–10 ms / cykl
                            │
                            ▼
                     Firebase Worker
                            │
              ┌─────────────┴─────────────┐
              ▼                           ▼
          terminal/state             terminal/chunks
                                            │
                                            ▼
                                      onChildAdded
                                            │
                                            ▼
                                      Web Terminal
```

------------------------------------------------------------------------

# 58. Nowy priorytet projektu

Po drugim researchu kolejność powinna być:

### P0 --- nie naruszyć stabilności v3.31.19

### P1 --- przechwycić `ESP_LOGx`

### P2 --- ring buffer w PSRAM

### P3 --- prebuffer

### P4 --- terminal ON/OFF przez istniejący command/ACK

### P5 --- upload chunks przez istniejący Firebase worker

### P6 --- HTML `onChildAdded`

### P7 --- statystyki

### P8 --- filtry

### P9 --- crash capture

------------------------------------------------------------------------

# 59. Jedna ważna decyzja techniczna do sprawdzenia w kodzie

Przed napisaniem v3.31.20 trzeba dokładnie ustalić:

``` text
jaki mechanizm Firebase jest faktycznie używany przez v3.31.19
```

oraz:

``` text
które taski obecnie mogą wykonywać Firebase writes.
```

Nie wolno zakładać, że przykład z nowej biblioteki `FirebaseClient`
można wkleić bezpośrednio do obecnego firmware.

Najpierw trzeba przeanalizować istniejący:

``` text
Firebase worker
telemetry producer
command mailbox
ACK
```

i dopiero do niego dopiąć terminal.

------------------------------------------------------------------------

# 60. Research --- decyzja na dziś

Po dwóch etapach researchu najbardziej sensowny projekt to:

**Terminal diagnostyczny v1**

``` text
✓ ESP_LOG capture
✓ RAM/PSRAM ring buffer
✓ prebuffer
✓ terminal ON/OFF
✓ ACK
✓ sessionId
✓ chunks
✓ upload co maks. 5 s
✓ upload wcześniej przy pełnym buforze
✓ istniejący Firebase worker
✓ onChildAdded w HTML
✓ limit historii
✓ dropped counter
✓ upload/error counters
✓ auto-off
```

Bez:

``` text
✗ nowego Firebase client
✗ stałego uploadu
✗ zapisu każdego logu osobno
✗ blokującego Firebase w callbacku logowania
✗ zmian w telemetrii
✗ zmian w OTA
```

To daje nam znacznie większą pewność, że Terminal będzie **narzędziem
diagnostycznym**, a nie kolejnym źródłem problemów.


---

# 61. Trzeci etap researchu — alternatywy bardziej „produkcyjne”

Ten etap objął także gotowe projekty ESP32, oficjalny ESP Insights oraz alternatywy typu WebSocket, syslog i MQTT.

Najciekawsza obserwacja:

> Pomysł z własnym Terminalem w Firebase jest wykonalny, ale nie jest jedynym sensownym rozwiązaniem. Możemy połączyć kilka sprawdzonych wzorców z ekosystemu ESP32.

---

# 62. ESP Insights — bardzo ważny punkt odniesienia

Espressif ma własny projekt **ESP Insights**, którego celem jest zdalna diagnostyka urządzeń pracujących w terenie.

Projekt zbiera m.in.:

- error logs,
- warning logs,
- custom events,
- reset reason,
- informacje o coredumpie.

Źródło:
https://github.com/espressif/esp-insights

To bardzo mocno potwierdza, że architektura:

```text
lokalny log
    ↓
bufor
    ↓
okresowa wysyłka
    ↓
zdalny dashboard
```

jest właściwym wzorcem dla urządzenia IoT.

---

# 63. ESP Insights ma coś jeszcze ciekawszego — dwa rodzaje danych

ESP Insights dzieli dane na:

```text
Critical
    Errors
    Warnings
    Events

Non-Critical
    Metrics
    Variables
```

Dane są buforowane, kodowane i wysyłane okresowo. Okres raportowania jest dynamiczny.

Źródło:
https://github.com/espressif/esp-insights

To sugeruje bardzo ciekawy model dla naszego projektu:

```text
TERMINAL LIVE
      +
DIAGNOSTYKA SYSTEMOWA
```

Nie wszystko musi być traktowane jako „tekst terminala”.

---

# 64. ESP Insights ma mechanizm zachowania danych przed crashem

To jest szczególnie interesujące.

Dokumentacja ESP Insights opisuje wykorzystanie pamięci RTC do zachowania krytycznych błędów poprzedzających crash i zgłoszenia ich po następnym starcie.

Źródło:
https://github.com/espressif/esp-insights/blob/main/FEATURES.md

Czyli nasz wcześniejszy pomysł:

```text
prebuffer → crash → reboot → wyślij historię
```

ma odpowiednik w rozwiązaniu Espressif.

To dodatkowo wzmacnia sens tej funkcji.

---

# 65. ESP Insights potwierdza też model „wysyłaj gdy bufor osiągnie próg”

Przykładowa dokumentacja ESP Insights podaje, że diagnostyka jest raportowana dynamicznie albo po zapełnieniu buforów do skonfigurowanego progu.

Źródło:
https://github.com/espressif/esp-insights/blob/main/examples/minimal_diagnostics/README.md

To jest praktycznie dokładnie model, który warto zastosować dla Terminala:

```text
5 s = max flush interval
+
buffer threshold = wcześniejszy flush
```

---

# 66. Jednak ESP Insights nie powinien być bezpośrednio dodany do naszego projektu

To ważne.

ESP Insights ma własny:

- cloud backend,
- transport,
- format danych,
- konfigurację,
- autoryzację,
- dashboard.

Nasz projekt już ma:

```text
Firebase
+
własny HTML
+
własny system komend
+
własną telemetrię
```

Dodanie ESP Insights oznaczałoby drugi ekosystem diagnostyczny.

Nie ma więc dużego sensu wprowadzać go tylko po to, żeby dostać Terminal.

---

# 67. Ale możemy skopiować wzorce z ESP Insights

Najciekawsze wzorce:

```text
1. bufory
2. dynamiczny flush
3. osobny kanał diagnostyczny
4. critical vs non-critical
5. crash persistence
6. poziomy logowania
7. metryki diagnostyczne
```

To jest bardzo dobry materiał projektowy.

---

# 68. Gotowy projekt MycilaDataLogger

Znalazłem również projekt:

**MycilaDataLogger**

Jest to ESP32 firmware służący do zdalnego oglądania logów Serial drugiego ESP32 przez web.

Projekt wspiera m.in.:

- zdalny podgląd logów,
- crash/stack trace,
- web interface,
- WebSocket,
- możliwość strumieniowania logów do terminala.

Źródło:
https://github.com/mathieucarbou/MycilaDataLogger

Projekt pokazuje, że architektura:

```text
Serial
  ↓
web stream
  ↓
terminal
```

jest praktycznie używana na ESP32.

---

# 69. Jeszcze jeden gotowy przykład — ESP32 Web Terminal

Projekt:

**ausil/esp32-web-terminal**

zawiera:

- pełny terminal browserowy,
- xterm.js,
- WebSocket,
- HTTPS,
- uwierzytelnianie,
- zapis logów,
- ESP32-S3,
- UART,
- USB CDC.

Źródło:
https://github.com/ausil/esp32-web-terminal

To jest bardzo interesujące pod kątem **samego UI Terminala**.

Nie rozwiązuje naszego problemu z Internetem/Firebase, ale pokazuje gotowy wzorzec:

```text
xterm.js
+
WebSocket
+
scrollback
+
Save Log
+
authentication
```

---

# 70. Co z tego możemy wykorzystać

Do naszego HTML można później przenieść:

```text
terminal font
scrollback
auto-scroll
pause
copy
download
clear
search
```

bez konieczności używania WebSocket jako transportu.

Czyli:

```text
Firebase = transport zdalny
xterm.js = prezentacja
```

To może dać dużo lepsze doświadczenie niż zwykły `<pre>`.

---

# 71. Syslog — kolejna ciekawa alternatywa

Znalazłem projekt ESP32, który przekierowuje logi do zdalnego serwera syslog przez UDP.

Projekt zachowuje przy tym normalny Serial.

Źródło:
https://github.com/martin-ger/esp32_nat_router/wiki/Syslog

To jest znany i prosty wzorzec:

```text
ESP_LOG
   ├──► Serial
   └──► Syslog UDP
```

---

# 72. Projekt esp-idf-net-logging jest jeszcze ciekawszy

Projekt `esp-idf-net-logging` pokazuje przekierowywanie logów ESP-IDF przez:

- TCP,
- MQTT,
- HTTP,
- SSE.

W opisie znajduje się również użycie `xRingBuffer` jako IPC.

Źródło:
https://github.com/nopnop2002/esp-idf-net-logging

To bardzo mocno potwierdza naszą koncepcję:

```text
ESP_LOG
   ↓
ring buffer
   ↓
worker
   ↓
network
```

---

# 73. SSE może być ciekawą metodą lokalną

Projekt `esp-idf-net-logging` pokazuje także SSE.

A ESP-IDF ma oficjalne wsparcie dla HTTP server i WebSocket.

Źródło:
https://docs.espressif.com/projects/esp-idf/en/latest/esp32/api-reference/protocols/esp_http_server.html

Można więc zrobić:

```text
ESP32
  ↓
SSE / WebSocket
  ↓
browser
```

ale tylko wtedy, kiedy browser może dotrzeć bezpośrednio do ESP32.

Dla naszego zdalnego scenariusza:

```text
telefon ≠ LAN pieca
```

Firebase nadal rozwiązuje problem dostępu przez Internet.

---

# 74. MQTT — bardzo ciekawa alternatywa transportowa

ESP-IDF ma natywne wsparcie dla MQTT.

W połączeniu z brokerem można zrobić:

```text
ESP32
  ↓
MQTT
  ↓
broker
  ↓
web app
```

MQTT ma przewagę w przypadku typowej telemetrii IoT, ale wymagałoby dodania:

```text
brokera
+
autoryzacji
+
web MQTT client
```

Do obecnego projektu nie daje to przewagi wystarczającej, aby zastąpić działający Firebase.

---

# 75. Firebase kontra MQTT

## Firebase

```text
+ już mamy
+ brak nowego serwera
+ autoryzacja już istnieje
+ HTML już korzysta z Firebase
+ komendy i ACK już istnieją
+ dane historyczne zostają w RTDB
```

## MQTT

```text
+ naturalny dla strumieni
+ lekkie wiadomości
+ QoS
+ bardzo dobre dla live telemetry
- potrzebny broker
- dodatkowa autoryzacja
- dodatkowa infrastruktura
- kolejny kanał utrzymania
```

### Wniosek

Dla **tego konkretnego projektu** Firebase pozostaje naturalniejszą bazą.

MQTT warto zapamiętać jako opcję przyszłości.

---

# 76. WebSocket kontra Firebase

## WebSocket

Najlepszy do:

```text
prawdziwy live terminal
```

Praktycznie:

```text
~natychmiast
```

## Firebase

Naturalny do:

```text
zdalne urządzenie
+
Internet
+
historia
+
sterowanie
```

### Najciekawsza architektura hybrydowa

Można kiedyś zrobić:

```text
LAN:
ESP32 → WebSocket → browser

Internet:
ESP32 → Firebase → browser
```

Wtedy lokalny panel ma prawdziwy live stream, a zdalny panel korzysta z RTDB.

Ale to jest przyszły etap.

---

# 77. Możemy mieć „Terminal LIVE” i „Terminal Archive”

To jeszcze jeden dobry pomysł wynikający z researchu.

```text
                  Terminal
                     │
          ┌──────────┴──────────┐
          ▼                     ▼
       LIVE VIEW             ARCHIVE
      ostatnie N              session
      chunks                  chunks
```

LIVE:

```text
limitToLast(100)
```

ARCHIVE:

```text
wybrana sesja
```

Dzięki temu użytkownik widzi terminal tak jak konsolę, ale może później pobrać całą sesję.

---

# 78. `push()` jest bardzo dobrym kluczem dla chunków

Firebase dokumentuje, że klucze `push()` są unikalne, oparte na czasie i naturalnie porządkują elementy chronologicznie.

Źródło:
https://firebase.google.com/docs/database/web/lists-of-data

Nie potrzebujemy więc koniecznie:

```text
000001
000002
000003
```

Możemy użyć:

```text
push()
```

a wewnątrz rekordu nadal trzymać:

```text
seq
```

dla diagnostyki i kontroli ciągłości.

---

# 79. Jeszcze lepszy rekord chunku

Proponowany model:

```json
{
  "seq": 27,
  "session": "20260929_143201",
  "ts": 1790685125000,
  "type": "live",
  "bytes": 3812,
  "text": "..."
}
```

Dodatkowo:

```text
firstTs
lastTs
```

może pomóc w odtwarzaniu i kontroli luk.

---

# 80. Możemy wykrywać utracone chunki

Jeżeli mamy:

```text
seq=27
seq=28
seq=30
```

frontend od razu widzi:

```text
BRAK CHUNKA 29
```

i może wyświetlić:

```text
⚠ utracony fragment terminala
```

To jest dużo lepsze od cichego zniknięcia danych.

---

# 81. Możemy rozróżniać „Firebase error” od „ESP drop”

To bardzo ważne diagnostycznie.

Licznik:

```text
bufferDropped
```

oznacza:

```text
ESP wygenerował więcej danych niż mogliśmy przechować
```

Natomiast:

```text
firebaseUploadErrors
```

oznacza:

```text
transport Firebase miał problem
```

A:

```text
chunkGap
```

oznacza:

```text
frontend nie dostał jednego lub więcej rekordów
```

Trzy różne problemy.

---

# 82. Firebase `onDisconnect()` można wykorzystać do sesji

Firebase posiada serwerową operację `onDisconnect()`, która może zapisać lub usunąć dane po rozłączeniu klienta.

Źródło:
https://firebase.google.com/docs/database/web/offline-capabilities

Dla Terminala można to wykorzystać po stronie webowej:

```text
user enters Terminal
    ↓
presence/session active
    ↓
onDisconnect → mark UI session offline
```

Nie powinno to jednak sterować bezpośrednio `terminalEnabled` w ESP.

To nadal powinno być po stronie ESP z timeoutem.

---

# 83. Dlaczego timeout musi być po stronie ESP

Wyobraźmy sobie:

```text
telefon:
Terminal ON
```

następnie:

```text
telefon umiera
```

albo:

```text
Chrome zostaje ubity
```

ESP nie może zakładać, że frontend go wyłączy.

Dlatego:

```text
terminalEnabled = true
terminalDeadline = now + 60 min
```

na ESP.

---

# 84. Możemy mieć „kill switch”

Bardzo dobra ochrona:

```text
terminal ON
```

ale jeśli:

```text
heap < X
queue backlog > Y
Firebase errors > Z
```

to firmware automatycznie:

```text
terminalEnabled = false
```

i zapisuje:

```text
TERMINAL AUTO-OFF: resource protection
```

To zabezpiecza urządzenie przed skutkami ekstremalnego logowania.

---

# 85. Task Watchdog potwierdza potrzebę takiej ochrony

Dokumentacja ESP-IDF mówi, że TWDT wykrywa taski, które zbyt długo nie oddają CPU.

Źródło:
https://docs.espressif.com/projects/esp-idf/en/v5.5/esp32s3/api-reference/system/wdts.html

Terminal nie może:

```text
blokować
```

ani:

```text
spinloopować
```

Dlatego każdy etap uploadu musi mieć możliwość przerwania/yield.

---

# 86. Jeszcze jedna ciekawa rzecz: ESP-IDF ma osobny secondary console

ESP-IDF obsługuje także dodatkowe wyjście konsoli, więc stdout/stderr może być kierowany jednocześnie na dwa interfejsy.

Źródło:
https://docs.espressif.com/projects/esp-idf/en/latest/esp32s3/api-guides/stdio.html

To jest ciekawy wzorzec architektoniczny:

```text
primary console
secondary console
```

ale nie oznacza bezpośrednio:

```text
Firebase console
```

Dla nas bardziej użyteczny jest analog:

```text
Serial
+
diagnostic sink
```

---

# 87. Web terminal może używać xterm.js

Projekt `esp32-web-terminal` używa xterm.js.

To daje:

- terminalowy wygląd,
- auto-scroll,
- selection,
- copy,
- keyboard,
- ANSI escape sequences,
- scrollback.

Źródło przykładowego projektu:
https://github.com/ausil/esp32-web-terminal

To może być dobrym kandydatem na przyszłą warstwę UI.

---

# 88. Ale xterm.js nie jest konieczny w pierwszej wersji

Obecny dashboard jest czystym HTML/JS.

Na początek można zrobić:

```html
<pre id="terminal"></pre>
```

i dopiero gdy mechanizm transportu będzie stabilny:

```text
<pre>
    ↓
xterm.js
```

To rozdziela problem transportu od prezentacji.

---

# 89. Bardzo ważne: terminal nie powinien logować samego terminala

Jeżeli dodamy:

```text
Terminal upload OK
```

i log przejdzie znowu przez:

```text
Diagnostic Sink
```

możemy stworzyć pętlę:

```text
log
 ↓
buffer
 ↓
Firebase
 ↓
log Firebase OK
 ↓
buffer
```

Dlatego trzeba mieć:

```text
DIAG_INTERNAL
```

który nie trafia do terminalowego sinka.

To jest ważne zabezpieczenie architektury.

---

# 90. To samo dotyczy Firebase

Nie wolno generować diagnostyki dla każdej wewnętrznej operacji terminala na poziomie `INFO`, bo terminal zacznie sam siebie zalewać.

Lepsze:

```text
terminal upload errors → WARN/ERROR
terminal upload success → DEBUG
```

a domyślny terminal:

```text
INFO+
```

---

# 91. Finalna architektura po trzecim researchu

```text
                          ┌─────────────────────┐
                          │      ESP32-S3       │
                          │                     │
 ESP_LOGx ───────────────►│                     │
 własne LOG ─────────────►│ Diagnostic Sink     │
                          │                     │
                          └────────┬────────────┘
                                   │
                    ┌──────────────┴──────────────┐
                    ▼                             ▼
             PREBUFFER 32 KB                LIVE BUFFER 128 KB
             zawsze aktywny                 tylko Terminal ON
                    │                             │
                    │                             ▼
                    │                    threshold / 5 s
                    │                             │
                    └──────────────┬──────────────┘
                                   ▼
                              Firebase worker
                                   │
                     ┌─────────────┴──────────────┐
                     ▼                            ▼
               terminal/state                terminal/chunks
                                                   │
                                                   ▼
                                              onChildAdded
                                                   │
                                                   ▼
                                               Web UI
                                                   │
                                      ┌────────────┴────────────┐
                                      ▼                         ▼
                                   LIVE VIEW                 ARCHIVE
```

---

# 92. Wariant „premium” na przyszłość

Po zrobieniu podstawowego Terminala można dorzucić:

```text
✓ xterm.js
✓ INFO/WARN/ERROR/DEBUG
✓ filtr modułu
✓ search
✓ pause
✓ auto-scroll ON/OFF
✓ copy
✓ download session
✓ prebuffer
✓ crash capture
✓ WDT capture
✓ heap snapshot
✓ task state snapshot
✓ WiFi/Firebase state
✓ dropped counters
✓ automatic resource protection
```

Wtedy zakładka przestaje być zwykłym logiem i staje się pełnym panelem zdalnej diagnostyki.

---

# 93. Decyzja po trzech etapach researchu

Na podstawie dokumentacji i istniejących projektów nie widzę potrzeby zmiany głównej koncepcji.

Najlepszy kierunek pozostaje:

```text
ESP32
  ↓
Diagnostic Sink
  ↓
Ring Buffer / PSRAM
  ↓
istniejący Firebase Worker
  ↓
RTDB chunks
  ↓
onChildAdded
  ↓
Terminal
```

Najważniejsze ulepszenia po researchu:

```text
1. prebuffer
2. threshold + 5 s flush
3. sessionId
4. seq / gap detection
5. auto-off
6. resource protection
7. crash/pre-reset diagnostics
8. możliwość xterm.js
```

---

# 94. Źródła trzeciego etapu

- ESP Insights — remote diagnostics:
  https://github.com/espressif/esp-insights
- ESP Insights features:
  https://github.com/espressif/esp-insights/blob/main/FEATURES.md
- ESP Insights minimal diagnostics:
  https://github.com/espressif/esp-insights/blob/main/examples/minimal_diagnostics/README.md
- MycilaDataLogger:
  https://github.com/mathieucarbou/MycilaDataLogger
- ESP32 Web Terminal:
  https://github.com/ausil/esp32-web-terminal
- ESP-IDF network logging:
  https://github.com/nopnop2002/esp-idf-net-logging
- ESP32 syslog example:
  https://github.com/martin-ger/esp32_nat_router/wiki/Syslog
- ESP-IDF HTTP server / WebSocket:
  https://docs.espressif.com/projects/esp-idf/en/latest/esp32/api-reference/protocols/esp_http_server.html
- ESP-IDF console:
  https://docs.espressif.com/projects/esp-idf/en/v5.2/esp32s3/api-reference/system/console.html
- ESP-IDF standard IO / secondary console:
  https://docs.espressif.com/projects/esp-idf/en/latest/esp32s3/api-guides/stdio.html
- Firebase list data / push:
  https://firebase.google.com/docs/database/web/lists-of-data
- Firebase offline capabilities / onDisconnect:
  https://firebase.google.com/docs/database/web/offline-capabilities
- Firebase security rules:
  https://firebase.google.com/docs/database/security/rules-conditions
- Firebase RTDB limits:
  https://firebase.google.com/docs/database/usage/limits
- ESP-IDF watchdog:
  https://docs.espressif.com/projects/esp-idf/en/v5.5/esp32s3/api-reference/system/wdts.html


---

# 95. Czwarty etap researchu — nowe ustalenia, których wcześniej nie mieliśmy

Po kolejnym przeglądzie dokumentacji i projektów znalazłem kilka nowych, konkretnych rzeczy. Nie zmieniają one głównej architektury, ale poprawiają jej odporność i pokazują dwie dodatkowe drogi dla bardziej zaawansowanego trybu diagnostycznego.

---

# 96. Najważniejsze nowe odkrycie: `esp_trace` w 2026 roku

Espressif wprowadził nowy komponent **`esp_trace`**, opisany oficjalnie w czerwcu 2026.

Źródło:
https://developer.espressif.com/blog/2026/06/introducing-esp-trace-component/

To ważne, bo Espressif rozdzielił:

```text
TRACE FORMAT
      +
TRANSPORT
```

Dzięki temu można podpiąć własny encoder albo własny transport bez modyfikowania frameworka.

Oficjalna dokumentacja:
https://docs.espressif.com/projects/esp-idf/en/latest/esp32/api-guides/tracing/custom-trace-library.html

---

# 97. `esp_trace` daje dokładnie model, którego szukamy

Dokumentacja Espressif zaleca dla niestandardowego transportu:

```text
runtime callback
       ↓
preallocated buffer
       ↓
ring buffer
       ↓
worker task
       ↓
sieć
```

i wyraźnie mówi, że callback czasu rzeczywistego powinien być tylko producentem danych:

- bez blokowania,
- bez ciężkich operacji,
- bez alokacji,
- z szybkim powrotem.

Cięższą pracę ma wykonywać worker.

Źródło:
https://docs.espressif.com/projects/esp-idf/en/latest/esp32/api-guides/tracing/custom-trace-library.html

### To jest mocne potwierdzenie naszej architektury.

Nasze:

```text
Diagnostic Sink → Ring Buffer → Firebase Worker
```

jest zgodne z wzorcem opisanym przez Espressif dla trace transportu.

---

# 98. `esp_trace` może kiedyś dać nam coś więcej niż Terminal

Oficjalna architektura pozwala zbierać nie tylko tekstowe logi.

Można później śledzić:

```text
task switch
ISR
queue
custom events
własne zdarzenia aplikacji
```

Źródło:
https://docs.espressif.com/projects/esp-idf/en/latest/esp32/api-guides/tracing/index.html

Czyli długoterminowo można mieć:

```text
TERMINAL
+
TRACE
+
METRICS
+
CRASH
```

Ale to jest już osobny poziom diagnostyki.

---

# 99. Ważne ograniczenie: `esp_trace` nie jest potrzebne do pierwszej wersji

Nowy komponent jest bardzo interesujący, ale nie należy go teraz wciskać do działającego v3.31.19.

W szczególności trzeba uwzględnić:

```text
wersję ESP-IDF
PlatformIO/pioarduino
obecne komponenty
obecne menuconfig
```

Jeżeli obecny firmware nie korzysta z wersji IDF, w której ten komponent jest dostępny, jego dodanie tylko po to, żeby mieć Terminal, byłoby niepotrzebnym ryzykiem.

### Decyzja

```text
Terminal v1:
własny Diagnostic Sink

Przyszłość:
opcjonalna integracja z esp_trace
```

---

# 100. Nowe odkrycie: retry może powodować duplikaty przy `push()`

To jest bardzo istotne.

Wcześniej zakładaliśmy:

```text
push() → chunk
```

ale teraz trzeba uwzględnić sytuację:

```text
ESP wysyła chunk
        ↓
Firebase zapisuje
        ↓
odpowiedź ginie po drodze
        ↓
ESP widzi timeout
        ↓
ESP robi retry
```

Jeżeli retry wykona kolejne `push()`, dostaniemy:

```text
chunk 27
chunk 27
```

jako dwa różne rekordy.

Firebase `push()` generuje nowy klucz dla każdego zapisu. citeturn511876search5

---

# 101. Lepsze rozwiązanie: deterministyczny klucz chunku

Zamiast:

```text
chunks/<push-id>
```

możemy zrobić:

```text
chunks/<seq>
```

np.:

```text
chunks/000001
chunks/000002
chunks/000003
```

i wysyłać:

```text
set("/chunks/000027", chunk)
```

Jeżeli odpowiedź zginie i wykonamy retry:

```text
set("/chunks/000027", chunk)
```

to zapisujemy ten sam rekord zamiast tworzyć drugi.

Firebase `set()` zapisuje dane pod wskazaną ścieżką, a REST `PUT` zapisuje lub zastępuje dane pod zdefiniowaną ścieżką. citeturn506916search0turn574508search0

### Wniosek

Dla naszego terminala:

```text
SEQ = część protokołu
```

nie tylko licznik diagnostyczny.

To daje **idempotentny retry**.

---

# 102. Sekwencja może być per sesja

Proponuję:

```text
session = 20260929_150000
seq = 1
2
3
...
```

Ścieżka:

```text
/piec/terminal/sessions/<sessionId>/chunks/<seq>
```

Przykład:

```text
/piec/terminal/sessions/20260929_150000/chunks/000001
```

To rozwiązuje jednocześnie:

```text
sesja
kolejność
retry
wykrywanie luk
```

---

# 103. Frontend może wznowić odbiór od konkretnego `seq`

Firebase obsługuje:

```text
orderByKey()
startAt()
endAt()
```

Źródło:
https://firebase.google.com/docs/database/admin/retrieve-data

Dzięki temu Terminal może znać:

```text
lastReceivedSeq = 183
```

i ponownie pobrać:

```text
seq >= 184
```

To przydaje się po:

- zamknięciu przeglądarki,
- utracie Internetu,
- przeładowaniu strony,
- chwilowym problemie Firebase.

---

# 104. Możemy mieć prawie dokładnie-once dla terminala

Nie należy nazywać tego formalnie „exactly once” dla całej sieci.

Ale możemy uzyskać:

```text
at-least-once transport
+
idempotent storage by session+seq
+
deduplication
```

czyli praktycznie:

```text
bez podwójnych logów
```

nawet po retry.

To jest dużo lepsze od zwykłego:

```text
push + retry
```

---

# 105. Nowe odkrycie: Firebase zachęca do utrzymywania połączeń

Aktualna dokumentacja wydajności Firebase mówi, że częste krótkie połączenia REST zwiększają:

- koszty SSL,
- obciążenie bazy,
- transfer.

Firebase zaleca natywne SDK z utrzymywanymi połączeniami, a gdy REST jest konieczny — HTTP keep-alive albo SSE.

Źródło:
https://firebase.google.com/docs/database/usage/optimize

### Wniosek dla ESP

Jeżeli obecny Firebase worker już utrzymuje połączenie/klienta, Terminal powinien korzystać z niego zamiast tworzyć:

```text
nowe HTTPS
co 5 s
```

---

# 106. Nowe odkrycie: możemy archiwizować sesję poza RTDB

Firebase sam sugeruje używanie Cloud Storage dla danych, które nie muszą pozostawać bezpośrednio w strukturze RTDB.

Źródło:
https://firebase.google.com/docs/database/usage/optimize

Możliwy model:

```text
RTDB
 ↓
live chunks
 ↓
Terminal

po zakończeniu sesji:
 ↓
plik .log / .txt / .json
 ↓
Cloud Storage
```

Daje to:

```text
RTDB = live transport
Storage = archive
```

---

# 107. Jednak nie potrzebujemy Cloud Storage w v1

Dla pojedynczego sterownika:

```text
kilkadziesiąt KB
```

jest niewielkie.

Możemy po prostu zrobić:

```text
Pobierz sesję
```

w HTML i zbudować lokalnie:

```text
terminal_20260929_150000.log
```

Bez dodawania żadnej nowej usługi.

---

# 108. Ważna wiadomość o Firebase Extensions

Znalazłem aktualną informację:

**Firebase Extensions zostaną wyłączone 31 marca 2027.**

Dotyczy to również oficjalnego rozszerzenia:

```text
Limit Child Nodes
```

Źródło:
https://www.extensions.dev/extensions/firebase/rtdb-limit-child-nodes

To ma znaczenie dla wcześniejszej koncepcji automatycznego limitowania chunków.

### Decyzja

Nie budować krytycznej części Terminala na tej Extension.

Zamiast tego:

```text
własna Cloud Function
```

albo:

```text
cleanup z poziomu własnego backendu
```

jeżeli kiedyś będziemy potrzebować trwałego archiwum.

---

# 109. `Limit Child Nodes` nadal jest ciekawym wzorcem

Samo rozszerzenie robi dokładnie to, czego potrzebujemy:

```text
jeżeli liczba child nodes > limit
       ↓
usuń najstarsze
```

Źródło:
https://www.extensions.dev/extensions/firebase/rtdb-limit-child-nodes

Natomiast ze względu na zapowiedziane wyłączenie Extensions nie należy go traktować jako docelowej infrastruktury.

---

# 110. Bardzo ciekawa alternatywa: Cloud Run + WebSocket

Google Cloud Run oficjalnie obsługuje WebSocket bez dodatkowej konfiguracji.

Źródło:
https://docs.cloud.google.com/run/docs/triggering/websockets

Można więc kiedyś zrobić:

```text
ESP32
  ↓
WSS
  ↓
Cloud Run
  ↓
WebSocket
  ↓
Browser
```

To daje prawdziwy:

```text
live terminal
```

bez 5-sekundowych porcji.

---

# 111. Cloud Run ma jednak kilka kosztów architektonicznych

Oficjalna dokumentacja mówi o:

- timeoutcie WebSocket do 60 min,
- konieczności reconnect,
- możliwej zmianie instancji,
- potrzebie synchronizacji stanu między instancjami,
- rozliczaniu aktywnego połączenia.

Źródła:
https://docs.cloud.google.com/run/docs/triggering/websockets
https://docs.cloud.google.com/run/docs/tutorials/websockets

Dla jednego pieca to byłoby przerostem infrastruktury nad potrzebą.

---

# 112. Ale Cloud Run daje ciekawą wersję „PRO”

Można kiedyś mieć:

```text
ESP32
   │
   ├── Firebase → history / control
   │
   └── WSS → Cloud Run → live terminal
```

Czyli:

```text
Firebase = reliable data plane
WebSocket = live debug plane
```

To jest technicznie bardzo eleganckie, ale wymaga dodatkowego backendu.

---

# 113. Kolejna możliwość: lokalny WebSocket

Gotowy projekt MycilaDataLogger pokazuje użycie:

```text
/webserialws
```

i `websocat`.

Źródło:
https://github.com/mathieucarbou/MycilaDataLogger

Czyli:

```text
ESP32
 ↓
WebSocket
 ↓
LAN browser
```

To może być świetne do serwisowania na miejscu, a Firebase pozostaje kanałem zdalnym.

---

# 114. Bardzo ciekawa architektura dwutorowa

Możemy docelowo zrobić:

```text
                    ESP32
                      │
            ┌─────────┴──────────┐
            │                    │
            ▼                    ▼
      LAN WebSocket         Firebase chunks
            │                    │
            ▼                    ▼
       lokalny serwis       Internet
                                 │
                                 ▼
                           zdalny Terminal
```

Zaleta:

```text
LAN → praktycznie natychmiast
WAN → odporny, zapisany w RTDB
```

---

# 115. Nowe odkrycie: Telegram dobrze nadaje się jako awaryjny kanał

Telegram Bot API pozwala:

```text
sendMessage
```

dla wiadomości do:

```text
1–4096 znaków
```

Źródło:
https://core.telegram.org/bots/api

Telegram FAQ podaje również ograniczenia częstotliwości wiadomości, np. unikanie więcej niż jednej wiadomości na sekundę w pojedynczym czacie.

Źródło:
https://core.telegram.org/bots/faq

### Wniosek

Telegram nie nadaje się jako główny live Terminal.

Ale bardzo dobrze nadaje się jako:

```text
ALARM:
"Firebase terminal failed"

+
ostatnie 10–20 linii
```

albo:

```text
PANIC DETECTED
ostatni fragment logu
```

---

# 116. Nie wysyłałbym pełnego Terminala przez Telegram

Powód:

```text
limit długości
rate limits
słaba nawigacja po tysiącach linii
brak wygodnego streamingu
```

Telegram:

```text
alert / emergency snapshot
```

Firebase:

```text
pełny terminal
```

---

# 117. Bardzo ciekawa kompozycja kanałów

Po czwartym etapie researchu mamy:

```text
                 ┌──────────────► USB/UART Serial
                 │
LOG SOURCE ─────► Diagnostic Sink
                 │
                 ▼
             PREBUFFER
                 │
                 ▼
             LIVE BUFFER
                 │
        ┌────────┴─────────┐
        ▼                  ▼
 Firebase            Telegram
 chunks              emergency
        │
        ▼
 Web Terminal
```

oraz opcjonalnie:

```text
LAN:
WebSocket
```

---

# 118. Jeszcze bardziej zaawansowany wariant: Terminal + Trace

Można kiedyś rozdzielić:

```text
TERMINAL
────────────
tekst człowieka
ESP_LOG
WARN
ERROR
INFO

TRACE
────────────
task switch
ISR
queue
timing
custom events

METRICS
────────────
heap
PSRAM
CPU
task runtime
WiFi RSSI
Firebase latency
```

To odpowiada w zasadzie temu, jak Espressif rozdziela logging, tracing i diagnostykę. citeturn844503search4turn844503search1

---

# 119. Runtime task statistics — ważna pułapka

FreeRTOS:

```cpp
uxTaskGetSystemState()
```

może dać:

```text
task name
priority
state
runtime
```

Źródło:
https://docs.espressif.com/projects/esp-idf/en/v5.5/esp32/api-reference/system/freertos_idf.html

Ale dokumentacja ostrzega, że ta funkcja może długo utrzymywać scheduler zawieszony i jest przeznaczona do debugowania.

### Wniosek

Nie uruchamiać jej:

```text
co 5 sekund
```

na stałe.

Lepiej:

```text
przycisk "Snapshot systemu"
```

lub:

```text
Terminal DEBUG
```

raz na żądanie.

---

# 120. Heap tracing też powinien być „on demand”

ESP-IDF ma:

```text
standalone heap tracing
host-based heap tracing
```

Źródło:
https://docs.espressif.com/projects/esp-idf/en/stable/esp32s3/api-reference/system/heap_debug.html

Host-based może wysyłać dane przez JTAG/apptrace.

To jest świetne podczas pracy warsztatowej, ale nie nadaje się jako ciągły element firmware produkcyjnego.

---

# 121. Nowa funkcja diagnostyczna, którą warto dodać później: „Snapshot”

Przycisk:

```text
SNAPSHOT SYSTEMU
```

mógłby wygenerować jednorazowo:

```text
===== SYSTEM SNAPSHOT =====
FW
uptime
reset reason
heap
largest block
PSRAM
WiFi RSSI
Firebase state
task state
telemetry state
spool state
OTA state
===========================
```

To jest o wiele tańsze niż ciągłe przesyłanie szczegółowych statystyk.

---

# 122. Jeszcze jeden ważny wzorzec: „event before verbosity”

Zamiast bardzo dużo logować:

```text
co sekundę
```

można logować głównie zdarzenia:

```text
WIFI_DISCONNECT
WIFI_RECONNECT
FB_TIMEOUT
FB_REAUTH
SPOOL_OPEN
SPOOL_COMMIT
TELEMETRY_DROP
WDT_WARNING
OTA_BEGIN
OTA_VALID
```

a Terminal uruchamiać wtedy, kiedy trzeba.

To daje mniejszy koszt i lepszą diagnostykę.

---

# 123. Crash report może zawierać konkretny stan systemu

Po crashie:

```text
reset reason
panic reason
current task
previous task
heap
PSRAM
WiFi
Firebase
last telemetry seq
last spool seq
last terminal seq
```

ESP-IDF core dump może przechowywać dane z RAM i stosy zadań; można także oznaczać wybrane zmienne jako przeznaczone do zrzutu. citeturn571247search3turn571247search9

---

# 124. `__NOINIT_ATTR` daje jeszcze jedną możliwość

Aktualna dokumentacja ESP-IDF wskazuje, że dane w `.noinit` nie są inicjalizowane podczas startu i mogą zachować wartość po software restart.

Źródło:
https://docs.espressif.com/projects/esp-idf/en/stable/esp32/api-guides/memory-types.html

Możemy więc przechować np.:

```text
lastEvent
lastState
lastError
lastTerminalSeq
lastImportantReason
```

po zwykłym restarcie programowym.

Dla krytycznych danych trzeba jednak uwzględnić rodzaj resetu i poprawną walidację zawartości.

---

# 125. `RTC_NOINIT_ATTR` może zachowywać dane przez odpowiednie cykle restartu/wake

ESP-IDF opisuje `RTC_NOINIT_ATTR` jako sekcję, której wartości zachowują się przez reset/wake w odpowiednich scenariuszach.

Źródło:
https://github.com/espressif/esp-idf/blob/master/components/esp_common/include/esp_attr.h

To może się przydać jako mały:

```text
panic breadcrumb
```

np.:

```text
last subsystem
last operation
last command
last sequence
```

---

# 126. Ostateczne ustalenie po kolejnym researchu

Pojawiło się kilka nowych możliwości, ale **żadna nie obala podstawowego projektu**.

Najbardziej dojrzały rdzeń to:

```text
ESP_LOG / Diagnostic Sink
        ↓
PSRAM Ring Buffer
        ↓
session + seq
        ↓
idempotent Firebase chunk
        ↓
onChildAdded / range resume
        ↓
Web Terminal
```

Z dodatkami:

```text
prebuffer
auto-off
resource protection
snapshot
crash breadcrumb
```

A jako przyszłe opcje:

```text
ESP Trace
LAN WebSocket
Cloud Run WSS
Telegram emergency
Cloud Storage archive
```

---

# 127. Priorytet technologii

| Technologia | Rola |
|---|---|
| Ring Buffer | rdzeń |
| PSRAM | bufor |
| ESP_LOG hook | przechwytywanie |
| Firebase RTDB | transport WAN + stan |
| session+seq | niezawodność |
| onChildAdded | live web |
| `startAt()` | wznowienie |
| prebuffer | diagnostyka przed zdarzeniem |
| xterm.js | UI premium |
| Telegram | awaryjny alert |
| WebSocket LAN | lokalny live |
| esp_trace | zaawansowany tracing |
| Cloud Run | przyszły live WAN |
| Cloud Storage | archiwum |
| MQTT | alternatywny transport |
| ESP Insights | osobny ekosystem diagnostyczny |

---

# 128. Koniec researchu architektury Terminala — na obecnym etapie

Po kolejnych wyszukiwaniach nie znalazłem rozwiązania, które dawałoby wyraźnie lepszy stos dla tego konkretnego projektu niż:

```text
Firebase + istniejący worker + ring buffer
```

Znalazłem natomiast ważne ulepszenia:

```text
1. `esp_trace` jako przyszła warstwa trace
2. deterministyczny `session + seq` zamiast ślepego `push()+retry`
3. wznowienie przez `startAt()`
4. dynamiczny flush zamiast sztywnego uploadu
5. Cloud Storage jako ewentualne archiwum
6. Telegram tylko jako kanał awaryjny
7. WebSocket jako lokalny lub przyszły WAN live
8. własny cleanup zamiast zależności od Firebase Extension
9. snapshot systemu on-demand
10. breadcrumbs w NOINIT/RTC i crash context
```

To jest obecnie najbardziej kompletna mapa możliwości dla zdalnego Terminala tego sterownika.
