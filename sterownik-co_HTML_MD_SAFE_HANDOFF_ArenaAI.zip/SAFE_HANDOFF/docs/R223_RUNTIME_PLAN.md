# R223 — RUNTIME PLAN v3.18.0
Data: 2026-09-26

## Cel
Sprawdzić, czy odłączenie `tgTask` i `tgPollTask` od per-task TASK_WDT eliminuje wcześniej obserwowane resety podczas blokujących operacji sieciowych.

## Środowisko
- ESP32-S3-N16R8
- v3.18.0
- test na pustej płytce
- R188 capture / COM5 / 115200

## Czas
Około 30 min.

## Zakaz podczas testu
- OTA
- upload
- ręczny restart
- erase
- zmiany parametrów automatyki
- fault injection

## Oczekiwane dowody
- `R188_RESULT.md`
- `HEALTH.csv`
- `HEALTH_extract.txt`
- `Serial_raw.txt`
- ewentualne coredumpy przy FAIL

## Kryterium PASS
- 0 TASK_WDT
- 0 PANIC
- 0 nieoczekiwanych restartów
- 0 coredump
- normalny HEALTH-A
- normalny `telemetry_produced` / `telemetry_dropped`
- brak regresji sterowania

## Ważne
Brak czujników na płytce oznacza, że `age[11]=65535` i zastępcze wartości `a[]` są oczekiwane. Nie traktować ich jako błędu runtime.

## Decyzja
Po sesji:
- PASS -> przejść do kolejnego testu niezawodności telemetryki;
- FAIL -> nie dodawać funkcji, tylko analizować nowe coredumpy względem v3.18.0 ELF.
