# HANDOFF — R243

## Immediate task

Use `main_centrala_v3.20.1_LOCAL_SPOOL_BENCH_FIX.cpp` as `src/main_centrala.cpp` on the local empty ESP32-S3 test board.

Build:
1. esp32-s3-n16r8
2. esp32-s3-ota

Upload: USB to empty/local board only.

Runtime:
- 2-3 `/telemetry` reports
- no `/testcrash`

Expected benchmark:
```text
32K max = 388
48K max = 583
64K max = 778
64K safe = 768
64K safe used = 64640 B
64K safe slack = 896 B
```

Production controller must remain v3.19.2.
