# R367-R379 — RTDB Integration Mega Batch v3.31.2

Status: local/test firmware only.

## Basis
v3.31.1 compiled, but live R368/R369/R370/R372/R373/R377 requests all returned TIMEOUT.
Diagnosis: test namespace `/piec/_rtdb_test/...` is not covered by the deployed H2 Rules and therefore inherits root deny. This is consistent with the deployed rules and explains the common failure mode.

## Fix
All live RTDB test data is now placed under the authenticated device's permitted H2 shadow telemetry path:
`/piec/devices/<uid>/telemetry/_rtdb_test/<runNonce>/...`
The V1 path `/piec/telemetry/1m/v1` remains untouched.

## Batch
- R367 Firebase UserAuth + UID + transport ready
- R368 single sample write/read-back
- R369 5-record same-day patch + read-back
- R370 records across midnight + RTDB range query
- R371 range exclusion + timestamp ordering
- R372 exact same-batch retry
- R373 duplicate logical key
- R374 ts=0 serializer policy
- R375 clock rollback semantics
- R376 deterministic record IDs
- R377 isolated cleanup + null verification
- R378 own-device shadow isolation / V1 untouched
- R379 Firebase health after batch

## Safety
- test-only local build
- no production firmware change
- no Rules change required
- unique run subtree under the device's own shadow telemetry
- cleanup removes only the test subtree

## Run
1. `/version` -> v3.31.2
2. `/rtdbmega`
3. Return the complete result.
