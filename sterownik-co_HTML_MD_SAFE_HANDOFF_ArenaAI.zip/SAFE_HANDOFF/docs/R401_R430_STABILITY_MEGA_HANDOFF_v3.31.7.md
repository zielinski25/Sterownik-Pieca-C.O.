# R401-R430 STABILITY-MEGA — v3.31.7

## Cel
Jeden duzy lokalny batch powtórzeniowy po PASS R380-R400. Test-only; produkcja pozostaje v3.19.2.

## Zakres
- R401-R406: health preflight (LittleFS, TelemetryRing, WiFi, FirebaseAuth, worker, telemetry request)
- R407: prawdziwy snapshot telemetryczny przygotowany przez normalny scheduler
- R408-R409: dwa kolejne przebiegi R273-R282 producer/telemetry -> spool
- R410-R411: dwa kolejne przebiegi R301-R312 replay/ACK/delete
- R412-R413: dwa kolejne przebiegi R313-R324 fault/recovery/quota
- R414-R415: dwa kolejne przebiegi R325-R334 Commit G
- R416-R417: dwa kolejne przebiegi H1 R335-R344
- R418-R419: dwa kolejne przebiegi H2 R345-R356
- R420-R422: trzy kolejne świeże przebiegi R367-R379 RTDB
- R423: health po całej serii
- R424: odczyt najnowszego zarchiwizowanego coredumpu (bez generowania crasha)
- R425-R426: konserwatywne progi wolnego heap/largest block jako tripwire regresji
- R427-R429: Firebase circuit, Telegram poll oraz worker/request idle
- R430: wynik całościowy

## Komenda
`/stabilitymega TAK`

## Ważne
- Tylko lokalna/testowa płytka.
- Nie używać na produkcji v3.19.2.
- Batch nie wywołuje `/testcrash` i nie celowo restartuje ESP32.
- RTDB korzysta z istniejącej świeżej przestrzeni testowej R367-R379 i obowiązujących Rules z `.indexOn: ["ts"]`.

## Oczekiwany wynik
`R401-R430 stability mega batch: PASS` oraz `R430:PASS STABILITY-MEGA overall=PASS`.

## Weryfikacja lokalna
Przed wgraniem sprawdź `/version` = `v3.31.7`.
