# TELEMETRIA RESEARCH PLAN — UPDATED THROUGH R244

## Status

R242/R243 page benchmark: PASS.
R244 page-format freeze: READY for local build; no spool writes yet.

## Frozen values

```text
TelemetrySample = 80 B
record = 84 B (80 B + CRC32)
page = 64 KiB
header = 64 B
footer = 64 B
safe records = 768
safe payload area = 64 512 B
safe page used = 64 640 B
slack = 896 B
coverage = 12 h 48 min
```

Theoretical maximum remains 778 records with only 56 B slack; therefore 768 is the safe operating count.

## Frozen recovery contract

A page is CLOSED only after a valid footer is written and verified.
An OPEN page can be recovered by scanning fixed-size records and accepting the valid prefix until the first bad/incomplete record.
A partial last record is ignored; earlier valid records are retained.
A recovered OPEN page is not appended to after reboot; new data goes to a new page.

## Design invariants retained

- physical LittleFS usedBytes() is quota source
- spool has hard cap and cannot consume protected reserve
- coredump source is not erased before verified archive
- no auto-format after production LittleFS mount failure
- one Firebase request in flight
- ring tail moves only after ACK
- deterministic IDs for retry
- no new Firebase client/task for spool

## Next stage: R245

Local-only implementation of page create/write/close/recovery with fault injection. Production controller unchanged.
