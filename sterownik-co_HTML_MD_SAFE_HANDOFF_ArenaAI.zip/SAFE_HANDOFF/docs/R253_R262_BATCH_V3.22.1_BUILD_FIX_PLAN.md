# R253-R262 v3.22.1 — build-fix plan

The v3.22.0 batch harness logic is retained unchanged. This patch only fixes C++ declaration order and updates the test firmware version.

Expected build result: no errors about unknown `TelemetrySample` and no `spoolR245* was not declared in this scope` errors.
