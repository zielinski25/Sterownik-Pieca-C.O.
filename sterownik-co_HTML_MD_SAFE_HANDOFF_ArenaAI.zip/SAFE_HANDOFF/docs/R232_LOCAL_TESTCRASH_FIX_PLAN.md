# R232 — v3.19.4 lokalny test coredumpu: zabezpieczenie przed ponownym wykonaniem komendy

Data: 2026-09-26

## Stan
- v3.19.3 F1 został uruchomiony na pustej płytce testowej.
- Test coredumpu wykazał poprawny PANIC, archiwizację `.part -> final`, zachowanie coredumpu po restarcie i wysyłkę pliku przez Telegram.
- Problem ujawniony w teście: po restarcie `tgLastUpdateId` wracał do 0, więc ta sama stara wiadomość `/testcrash TAK` była ponownie wykonywana.

## v3.19.4 — zakres tylko lokalny
1. `/testcrash` uzbraja test na 60 s; sama komenda nie powoduje crasha.
2. `/testcrash TAK` działa tylko w stanie uzbrojonym.
3. `update_id` wykonanej komendy jest zapisywany w NVS namespace `tc_test` przed crashem.
4. Po restarcie ten sam `update_id` nie może ponownie wykonać crasha.
5. Przy błędzie NVS test jest blokowany (fail-closed).
6. Przed wykonaniem crasha stan uzbrojenia jest zerowany.

## Gate
- build `esp32-s3-n16r8` PASS
- build `esp32-s3-ota` PASS
- USB upload tylko pusta płytka testowa
- po starcie wysłać `/testcrash TAK` ze starej kolejki: ma NIE crashować, bo brak uzbrojenia
- wysłać `/testcrash`, następnie w ciągu 60 s `/testcrash TAK`: jeden PANIC
- po restarcie ta sama `/testcrash TAK` ma zostać odrzucona bez kolejnego PANIC
- nowa para `/testcrash` + `/testcrash TAK` może wykonać kolejny pojedynczy test

## Produkcja
v3.19.4 NIE może być wysyłane OTA na prawdziwy sterownik. Produkcyjna centrala pozostaje na v3.19.2.
