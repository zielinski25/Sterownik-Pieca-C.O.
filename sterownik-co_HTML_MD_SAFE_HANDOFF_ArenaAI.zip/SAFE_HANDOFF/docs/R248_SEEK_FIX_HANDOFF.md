# R248 HANDOFF — v3.20.8

R248 runtime FAIL byl false negative.

Log:
`R248 recovery continue: FAIL`
`seek R247 po headerze nieudany`

Root cause: `File::seek()` jest API bool, ale kod sprawdzal je przez porownanie z pozycja 64.
Fix: `if (!src2.seek(SPOOL_HEADER_BYTES))`.

Uruchom na pustej plytce:
`/spool248repair TAK`

Oczekiwany PASS: input 272 B -> valid prefix 232 B -> tail 40 B odrzucony -> output 316 B / 3 rekordy.
