# R345-R356 — Commit H2 / handoff

Data: 2026-09-27
Status: IMPLEMENTATION PREPARED — runtime gate pending

## Cel

Migracja runtime auth z LegacyToken / Database Secret do Firebase UserAuth z credentialami per-device w NVS, przy pozostawieniu obecnych namespace'ow V1 nietknietych.

## Firmware

`main_centrala_v3.29.0_LOCAL_SECURITY_H2_USERAUTH_SHADOW.cpp`

Zmiany:
- `ENABLE_USER_AUTH`
- `ENABLE_LEGACY_TOKEN` usuniete z build options
- brak `LegacyToken`, `fbLegacyToken`, `fbSecret`, `DEFAULT_FIREBASE_SECRET`
- `UserAuth` tworzony z `firebase/api_key`, `firebase/auth_email`, `firebase/auth_pass`
- fail-closed przy brakujacym komplecie credentiali
- TLS pozostaje CA-verified na dotychczasowym `fbSSLClient` / `R1X+R4`
- H2 shadow namespace: `/piec/devices/<uid>/...`
- istniejace `/piec/status`, `/piec/cmd`, `/piec/ack` pozostaja bez migracji w tym commicie

## Rules

Artefakt: `firebase_rtdb_h2_rules_fragment.json`

Kluczowa zasada:
- device (`auth.uid == $uid`): write tylko `telemetry`, `status`, `ack`
- device: brak prawa write do `cmd`
- operator (`auth.token.operator == true`): read telemetry/status/ack oraz write cmd
- brak nadrzednego `.read/.write` pod `devices/$uid`, aby child rules mogly rzeczywiscie ograniczac dostep

## Provisioning

Artefakt: `firebase_h2_provision_local.ino`

Wpisuje credentiale do NVS namespace `firebase` i usuwa stary klucz `secret`.

## Runtime gate

Po provisioningu i wdrozeniu fragmentu Rules do projektu testowego uruchomic:

`/securityh2 TAK`

Oczekiwane:

```text
R345:userAuthBuild=ENABLED
R346:legacyTokenCompile=DISABLED
R347:userAuthNVS=YES api/email/password=present
R348:userAuthObject=READY
R349:firebaseAuth=READY
R350:firebaseAuth=READY authMode=USER_AUTH uidPresent=YES ...
R351:tokenDiagnostics=REDACTED idToken=NOT_EMITTED
R352:legacyStatusGET=OK method=GET readOnly=YES
R353:ownDeviceShadowRead=OK path=/piec/devices/<uid>/status
R354:foreignDeviceRead=DENIED
R355:ownDeviceCmdWrite=DENIED
R356:v1Paths=UNCHANGED h2ShadowOnly=YES legacySecret=NOT_USED
```

## Ważne

`firebase_rtdb_h2_rules_fragment.json` jest fragmentem do włączenia do aktualnego dokumentu Rules, a nie plikiem do bezrefleksyjnego zastąpienia całych obecnych Rules.

Runtime PASS wymaga rzeczywiście ustawionych Rules i poprawnego konta Firebase Authentication dla urządzenia.
