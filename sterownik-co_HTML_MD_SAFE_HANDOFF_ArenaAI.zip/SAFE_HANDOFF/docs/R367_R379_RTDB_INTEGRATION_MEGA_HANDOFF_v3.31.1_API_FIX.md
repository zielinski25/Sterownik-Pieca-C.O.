# R367-R379 — RTDB Integration Mega Batch

Data: 2026-09-28
Firmware: v3.31.1
Zakres: lokalna/testowa plytka בלבד; produkcja pozostaje v3.19.2.

## Komenda

`/rtdbmega`

Pakiet wykonuje calosc jako jeden przebieg i po sobie sprzata wlasny namespace:
`/piec/_rtdb_test/<run>/`

## Testy

- R367: Firebase UserAuth + WiFi/transport READY
- R368: pojedynczy rekord SET + GET read-back
- R369: 5 rekordow w jednym UPDATE + GET
- R370: rekordy przez granice polnocy + prawdziwy RTDB range query `orderBy("ts")`, `startAt`, `endAt`
- R371: wykluczenie danych spoza zakresu + kolejnosc po `ts`
- R372: identyczny batch wyslany dwukrotnie + kontrola liczby logicznych rekordow
- R373: ten sam klucz zapisany dwukrotnie -> jeden logiczny wezel
- R374: rzeczywista polityka serializera `ts=0` -> `unknown/<recordId>`
- R375: semantyka rollback zegara — sciezka daty wynika z `sample.unixTs`, nie z aktualnego zegara
- R376: deterministyczne i unikalne ID rekordu
- R377: usuniecie tylko namespace testowego + GET == `null`
- R378: namespace testowy nie jest sciezka V1 telemetryki
- R379: final health Firebase Auth + circuit CLOSED

## Srodowisko

Do realnego range query uzywany jest `DatabaseOptions` z filtrem `orderBy/startAt/endAt`, zgodnie z API FirebaseClient. Pakiet korzysta z tego samego `fbAsyncClient`, `fbApp`, `fbDatabase`, TLS i UserAuth co normalna telemetria.

## Kryterium PASS

Wszystkie R367-R379 musza miec PASS. W razie pojedynczej porazki caly batch raportuje FAIL i pokazuje konkretna linie testu; cleanup jest wykonywany w ramach przebiegu przed R379.

## Granica produkcyjna

Nie wgrywac do sterownika produkcyjnego. Firmware jest lokalnym kandydatem testowym.


## v3.31.1 API FIX

Naprawiono kompatybilność testu zakresu RTDB z wersją FirebaseClient zainstalowaną w projekcie: używany jest synchroniczny `get<String>(client, path, DatabaseOptions&)`, ponieważ kompilator projektu nie udostępnia wariantu 4-argumentowego z `AsyncResult`. Logika mega-testu pozostaje bez zmian.
