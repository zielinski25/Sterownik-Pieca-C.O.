# R357-R366 — Commit G2 / Persistent Spool V2 runtime exercise

Data: 2026-09-27
Status: candidate prepared, local build/runtime pending

## Basis

R325-R334 Commit G runtime verification: PASS.
R335-R344 H1 security: PASS.
R345-R356 H2 UserAuth + Rules: PASS.

## Scope

This candidate activates the real Persistent Spool V2 runtime path ONLY after explicit:

`/spoolrt TAK`

on the local/test board.

Production firmware remains v3.19.2.

## G2 runtime policy in this test build

- normal online path remains `TelemetryRing -> Firebase V1`;
- if transport is unavailable for >= 120 s, oldest ring records may be moved into closed Spool V2 page(s);
- a high ring backlog (>= 120 records) also permits a spill;
- one spill page contains up to 128 records;
- page uses frozen V2 header/records/footer and is fully reopened/verified before ring tail moves;
- replay is FIFO, one Firebase request at a time, maximum 10 records/request;
- page is deleted only after all records in the page receive a successful request ACK;
- if the device restarts before page deletion, replay cursor resets to 0, intentionally preserving at-least-once semantics;
- runtime test pages use reserved page-sequence range starting at `0xE0000000` so old R325 test files are not mixed into the G2 scan;
- `/spoolrt STOP` disables the runtime path without deleting retained pages.

## Commands

1. `/version` -> expect `v3.30.0`
2. `/spoolrt TAK` -> arm runtime path
3. `/spoolrt` -> report counters/state
4. Create WAN loss (keep the ESP32 powered) for >= 120 s; 15 min is preferred for a useful sample set.
5. Restore WAN.
6. `/spoolrt` -> confirm spill/replay/delete counters.

## Important restart test

After a runtime page exists but BEFORE it is fully replayed, power-cycle the local test board.
After boot and WAN restoration, send `/spoolrt TAK` again.
The retained page must replay from cursor 0 and only then be deleted after successful ACKs.

## Serial evidence

Capture lines beginning with:

`tag=SPOOL-G2`

Expected examples:

- `armed`
- `spill_ok pageSeq=... records=... firstSeq=... lastSeq=...`
- `replay_ack pageSeq=... cursor=.../... batch=...`
- `replay_page_deleted pageSeq=... records=...`

Any `quota_block`, `spill_*_fail`, `replay_*fail`, WDT, panic or reset is a gate failure until explained.

## Acceptance

R357-R366 is PASS only when the actual runtime evidence proves:

- ring samples spill to durable closed pages under transport loss/backpressure;
- tail advances only after durable verification;
- replay is oldest-page/oldest-record first;
- no replay request exceeds 10 records;
- partial ACK retains page;
- full ACK deletes page;
- restart before delete preserves the page and replays deterministically;
- no silent data loss, duplicate logical IDs, WDT/PANIC or uncontrolled FS growth is observed;
- normal online V1 telemetry remains unchanged outside the explicitly armed local G2 mode.

## Production boundary

No OTA to the real controller is allowed from this candidate.
