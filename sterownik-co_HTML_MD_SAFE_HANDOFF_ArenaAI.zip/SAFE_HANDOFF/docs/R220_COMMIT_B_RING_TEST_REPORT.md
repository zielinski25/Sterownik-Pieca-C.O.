# R220 — Commit B / TelemetryRing
Data: 2026-09-26

## R219 runtime
- Firmware under test: v3.15.2
- Capture: 2026-09-26 00:18:57.601 -> 00:49:09.614
- Duration: 30 min 12.013 s
- HEALTH records: 60
- TASK_WDT/PANIC/crash/reset/coredump in captured UART: 0
- heap_free observed: 100032..114232 B
- largest_free_block observed: 6815732 B
- telemetry_produced=0, telemetry_dropped=0 (ring not yet integrated in v3.15.2)
- FB-CMD and FB-SEND continued normally; longest observed request in raw UART was in the low seconds, not a watchdog-scale stall.
- Known non-crash warnings/errors occurred at startup (DHT/SD/RTC) and one FLASH-STALL 181 ms; none caused reset during the capture window.

Classification: R219_RUNTIME_OBSERVATION_PASS. This is not a 24 h baseline PASS.

## R220 implementation
- Version target: v3.16.0
- Commit: PSRAM SPSC TelemetryRing
- Capacity: 1440 TelemetrySample records
- Record size: 80 B
- PSRAM allocation: 115200 B
- Producer: historiaZapiszProbke() / existing scheduler path
- Consumer API: peek() + commitPop(); no consumer integrated yet
- Full behavior: push() returns false; sampleSeq is not rolled back
- Synchronization: atomic acquire/release head/tail; no mutex in producer/consumer path
- Forbidden in ring: Firebase, DNS, TLS, LittleFS, malloc/free per push, new task

## Host ring harness
PASS: capacity, FIFO order, full/drop behavior, and non-reused sequence behavior.

## Not yet verified
- PlatformIO build of v3.16.0 in this environment
- ESP32 runtime of v3.16.0
- cross-core live producer/consumer runtime on hardware
- Firebase drain

## Next step
1. Replace source with `main_centrala_v3.16.0_COMMIT_B_RING.cpp`.
2. Run `pio run -e esp32-s3-n16r8`.
3. Do NOT upload until build result is reviewed.
