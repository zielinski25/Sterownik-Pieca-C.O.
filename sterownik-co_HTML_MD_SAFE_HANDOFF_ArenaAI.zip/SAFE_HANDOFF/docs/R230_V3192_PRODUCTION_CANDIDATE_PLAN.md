# R230 — v3.19.2 production candidate after R229

Data: 2026-09-26

## Status wejściowy

R229 lokalny fault-injection: PASS.
Sekwencja potwierdzona na pustej płytce:
`FAIL -> rekord pozostaje w ringu -> retry -> Wysłane rośnie -> ring=0 -> Drop=0`.

v3.18.1 pozostaje aktualnym punktem rollback/master dla prawdziwej centrali do czasu zakończenia gate v3.19.2.

## Cel

Przygotować czysty kandydat produkcyjny bez kodu testowego R229.

## Zakres v3.19.2

- pozostaje diagnostyka telemetryki z v3.19.0;
- usunięto `LOCAL_TELEMETRY_FAULT_TEST`;
- usunięto `/telemetryfail` i sztuczny FAIL;
- usunięto tekst `Test lokalny FAIL: wlaczony`;
- `FIRMWARE_VERSION` ustawione na `v3.19.2`;
- nie zmieniono ringu, batch size, payload limitu, timeoutu requestu, interwału, TWDT, TLS, automatyki ani endpointu Firebase.

## Ważna korekta

W artefakcie v3.19.0 changelog zawierał wpis v3.19.0, ale stała `FIRMWARE_VERSION` pozostawała `v3.18.1`. v3.19.2 usuwa ten rozjazd.

## Gate lokalny

1. Backup `src/main_centrala.cpp`.
2. Podmiana tylko na `main_centrala_v3.19.2_TELEMETRY_PROD_CANDIDATE.cpp`.
3. Build `esp32-s3-n16r8`.
4. Build `esp32-s3-ota`.
5. Jeżeli oba buildy PASS, upload USB wyłącznie na pustą płytkę.
6. Sprawdzić Telegram `Diagnostyka -> Telemetria`.
7. Pozostawić lokalną płytkę poza testem R229; nie uruchamiać `/telemetryfail`, bo komendy już nie ma.
8. Krótki runtime lokalny bez WDT/PANIC/RESET/COREDUMP/task-not-found i ze spójnymi produced/sent/drop.

## Gate produkcyjny

Dopiero po lokalnym PASS:
- przygotować ewentualny OTA na prawdziwą centralę;
- OTA wyłącznie przez istniejącą ścieżkę zdalną;
- po OTA sprawdzić `/version`, `Diagnostyka -> Telemetria` i logi przez Telegram.

## Nie robimy teraz

- persistent spool;
- zmian Firebase;
- zmian auth/TLS;
- zmian automatyki;
- kolejnego fault-injection na prawdziwym sterowniku;
- odłączania routera w domu.

## Artefakty

Source: `main_centrala_v3.19.2_TELEMETRY_PROD_CANDIDATE.cpp`
Patch: `COMMIT_v3.19.2_TELEMETRY_PROD_CANDIDATE.patch`
