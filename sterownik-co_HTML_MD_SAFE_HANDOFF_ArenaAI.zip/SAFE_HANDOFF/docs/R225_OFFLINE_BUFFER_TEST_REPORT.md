# R225 — Offline Buffer / Backlog Drain Test

Data: 2026-09-26
Firmware: v3.18.1
Environment: esp32-s3-n16r8

## Result
PASS for offline buffering and backlog drain.

Session: 2026-09-26 04:47:35.329 — 05:04:28.418 local (~16 min 53 s)
HEALTH: 34
Unexpected reset: 0
TASK_WDT: 0
PANIC: 0
Coredump: 0
telemetry_dropped: 0

## Observed network interruption
Wi-Fi disconnected around mono 1,380,107 ms and reconnected around mono 1,802,? ms; observed outage was about 7 minutes.

Before outage, telemetry had been sent through seq 22.
After reconnect:
- telemetry batch_ok count=8 last_seq=30 sent=30
- later batch_ok last_seq=31, 32, 33

This demonstrates that records accumulated while Wi-Fi was unavailable and were later drained from the ring after connectivity returned.

## Important limitation
This session did NOT produce an explicit telemetry `batch_fail` event followed by retry of the same batch. There were Firebase command/send timeouts during recovery, followed by successful Firebase activity, but the telemetry log itself showed successful batches rather than an explicit telemetry failure.

Therefore:
- OFFLINE BUFFERING = PASS
- BACKLOG DRAIN = PASS
- FAIL -> RETRY -> ACK -> COMMIT TAIL = NOT DIRECTLY PROVEN

No firmware change is required from this test.
