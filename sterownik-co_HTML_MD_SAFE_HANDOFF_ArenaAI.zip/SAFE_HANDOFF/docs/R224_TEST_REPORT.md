# R224 TEST REPORT — przygotowanie

## R223 evidence
T0_local=2026-09-26 04:13:27.945
T1_local=2026-09-26 04:23:21.132
czas=9m53.187s
port=COM8
script=R188-CAPTURE-1.7
bytes=1,233,539

Brak `CRASH / restart centrali` w Serial_raw.
Brak `PANIC` / `COREDUMP` w Serial_raw.
Wystąpiło 19 576 `task_wdt: esp_task_wdt_reset(...): task not found`.
TelemetryRing/Firebase nadal działały; `telemetry_dropped=0` w obserwowanych HEALTH-A.

## Ocena
R223 = NOT PASS (log/kontrakt WDT niespójny), mimo braku faktycznego resetu.
