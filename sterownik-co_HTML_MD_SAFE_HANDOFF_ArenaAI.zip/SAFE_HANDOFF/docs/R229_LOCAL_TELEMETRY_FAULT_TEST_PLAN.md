# R229 — lokalny test telemetryki FAIL -> retry -> ACK -> commit tail

Data: 2026-09-26

## Cel

Jednoznacznie zweryfikować na pustej płytce lokalnej sekwencję:

FAIL pierwszego batcha -> rekordy pozostają w ringu -> retry -> SUCCESS/ACK -> commit tail -> pending=0.

## Zasada bezpieczeństwa

Ten firmware jest testowy i przeznaczony wyłącznie dla pustej płytki.
Nie używać go do OTA prawdziwej centrali.

## Artefakt

`main_centrala_v3.19.1_LOCAL_TELEMETRY_FAULT_TEST.cpp`

SHA-256:
`37dd63efb211d0584dca72e73d75fe1a87c69737e69f2324150279a5ac6f29f3`

Patch:
`COMMIT_v3.19.1_LOCAL_TELEMETRY_FAULT_TEST.patch`

SHA-256:
`d960482a7dd94683a5e409ec5b23b786076083276aa1e2773cf6571cb84ecf32`

## Zmiany

- FIRMWARE_VERSION = `v3.19.1`
- compile-time guard `LOCAL_TELEMETRY_FAULT_TEST=1`
- komenda `/telemetryfail TAK` uzbraja jeden sztuczny FAIL
- sztuczny FAIL nie wykonuje requestu Firebase
- batch pozostaje w ringu, ponieważ nie wykonywany jest `commitPopN()`
- następna próba korzysta z istniejącej ścieżki Firebase bez zmian
- raport Telegrama pokazuje dodatkowo `Test lokalny FAIL: wlaczony`
- nie zmieniono `TELEMETRY_RING_CAPACITY=1440`
- nie zmieniono `TELEMETRY_BATCH_MAX_RECORDS=10`
- nie zmieniono `TELEMETRY_MAX_PAYLOAD_BYTES=6144`
- nie zmieniono `TELEMETRY_REQUEST_LIMIT_MS=6000`
- nie zmieniono `TELEMETRY_SEND_INTERVAL_MS=60000`
- nie zmieniono TWDT / TLS / automatyki

## Procedura

1. W lokalnym projekcie zrób kopię aktualnego `src/main_centrala.cpp`.
2. Zastąp go plikiem `main_centrala_v3.19.1_LOCAL_TELEMETRY_FAULT_TEST.cpp`.
3. Zbuduj `esp32-s3-n16r8`.
4. Zbuduj `esp32-s3-ota`.
5. Jeżeli oba Buildy przejdą, wgraj firmware przez USB tylko na pustą płytkę.
6. Po starcie odczekaj do pierwszej normalnej próbki telemetrycznej.
7. Wyślij `/telemetryfail TAK`.
8. Poczekaj na kolejny batch telemetryczny. W odpowiedzi z Telegrama ma być potwierdzenie uzbrojenia.
9. Wywołaj `Diagnostyka -> Telemetria` po sztucznym FAIL.
10. Oczekiwany stan po FAIL:
    - `Błędy transportu` większe o 1
    - `Wysłane` bez zwiększenia o liczbę odrzuconego batcha
    - `Ring` większy od 0
    - `Drop` bez zwiększenia
11. Poczekaj na kolejną próbę Firebase.
12. Wywołaj ponownie `Diagnostyka -> Telemetria` po sukcesie.
13. Oczekiwany stan po retry:
    - `Wysłane` zwiększone o wielkość zaległego batcha
    - `Ring` wrócił do 0/1440
    - `Drop` nadal 0
    - `Błędy transportu` pozostaje na wartości z FAIL
14. Zbierz log po teście i sprawdź wpisy:
    - `tag=TELEMETRY-TEST ... fail_once_armed`
    - `tag=TELEMETRY-TEST ... batch_fail_injected`
    - `tag=TELEMETRY ... batch_ok`

## PASS

PASS, jeśli po sztucznym FAIL rekordy nadal są dostępne w ringu, a następny normalny request wysyła je i `pending` wraca do zera.

## FAIL

FAIL, jeśli po sztucznym FAIL:
- `Drop` rośnie,
- ring traci rekordy,
- `Wysłane` rośnie mimo braku SUCCESS,
- `pending` nie wraca do zera po normalnym retry,
- pojawi się `TASK_WDT`, `PANIC`, `RESET`, `COREDUMP` lub `task not found`.

## Produkcja

Brak OTA na prawdziwą centralę z tego artefaktu.
v3.18.1 pozostaje punktem rollback/master.
