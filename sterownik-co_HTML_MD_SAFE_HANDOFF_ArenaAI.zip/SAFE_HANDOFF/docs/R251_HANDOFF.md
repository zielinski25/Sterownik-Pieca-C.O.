# R251 HANDOFF

1. Wgraj v3.21.1 na pusta plytke przez USB.
2. W Telegram wpisz `/spool251 TAK`.
3. Oczekuj `R251 quota boundary: PASS` z `exact=ADMIT over1=REJECT`.
4. Jezeli jest FAIL, nie przechodz dalej — podeslij caly komunikat.

Produkcja: v3.19.2, bez OTA.
