# R224 HANDOFF

Aktualny firmware na płytce: v3.18.0.

R223: brak resetów podczas 9m53s, ale FAIL z powodu 19 576 komunikatów `task_wdt ... task not found`.

v3.18.1 poprawia tylko ten kontrakt TWDT: `esp_task_wdt_status(NULL)` -> reset tylko dla zarejestrowanego taska.

Nie wgrywać v3.18.1 przed BUILD PASS.

Następny krok: build `esp32-s3-n16r8` i `esp32-s3-ota`.
