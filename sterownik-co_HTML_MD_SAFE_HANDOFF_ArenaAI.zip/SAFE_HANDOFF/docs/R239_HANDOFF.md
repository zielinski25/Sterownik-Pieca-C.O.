# R239 HANDOFF — Piec_CO

Data: 2026-09-26

## PRODUKCJA

- Prawdziwa centrala: v3.19.2
- OTA only
- v3.19.8 i kolejne lokalne wersje nie wdrażać OTA bez osobnego PASS.

## ZAMKNIĘTE

- Telemetry V1 — PASS
- F1 — PASS
- F2.1 — PASS
- F2.2 — PASS
- F2.3 — PASS
- F2.5 — PASS

## F2.6

v3.19.8 przygotowana jako diagnostyka dynamicznej pozostałej rezerwy.
W tej rozmowie nie ma jeszcze zgłoszonego wyniku runtime v3.19.8, więc status pozostaje `RUNTIME PENDING`.

## R239 / F2.7

Temat: dokładny kontrakt `panel_firmware.bin`.

Wniosek audytu:
- kod zna `Content-Length` pobieranego assetu;
- istnieje `g_panelFirmwareSize`;
- panel jest już uwzględniony w accounting FS;
- brak aktualnego artefaktu `firmware_panel.bin` uniemożliwia uczciwe ustalenie dokładnego limitu.

Nie wprowadzamy arbitralnego limitu 1 MiB ani 2 MiB.

## NEXT

Zdobyć rzeczywisty `firmware_panel.bin`, policzyć `size + SHA-256`, zamknąć F2.7, a następnie zaktualizować finalną hard quota LittleFS.
