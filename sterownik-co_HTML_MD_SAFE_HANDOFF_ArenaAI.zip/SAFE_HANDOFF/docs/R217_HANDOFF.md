# ESP32 CENTRALA — HANDOFF R217
Data: 2026-09-25

## CURRENT STATE
Firmware: **v3.15.1**
Commit A: runtime-observed stable on previous v3.14.0
Commit B: static audit PASS WITH FIXES
PlatformIO build v3.15.1: **PASS** for `esp32-s3-n16r8`
Upload v3.15.1 to central: **NOT YET CONFIRMED**
Gate A-0: YELLOW

## BUILD EVIDENCE
Reported by operator:
- Successfully created combined binary image.
- Environment `esp32-s3-n16r8` = SUCCESS.
- Duration 218.87 s.

Source SHA-256:
`739cf427b8cd944dedc1d1f7f3c37207730beb6c5cdba210a350011815575a81`

## COMMIT B
Included:
- TelemetrySample 80 B;
- freshness sidecar x11;
- qualityBits / ageS / simulatedBits;
- sessionNonce / sampleSeq;
- snapshot builder;
- no Firebase telemetry;
- no TelemetryRing;
- no TelemetryTask;
- no LittleFS telemetry spool.

## RUNTIME NEXT
Upload v3.15.1 once over USB, then perform a controlled runtime session. During that session do not use OTA/restart/erase and do not modify automation parameters. Record UART/HEALTH and any reset evidence.

Runtime PASS is required before opening PSRAM SPSC TelemetryRing.
