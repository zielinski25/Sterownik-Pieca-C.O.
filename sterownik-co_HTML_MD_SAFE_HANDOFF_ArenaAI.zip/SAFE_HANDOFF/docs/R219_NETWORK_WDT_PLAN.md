# R219 — NETWORK/WDT STABILIZATION PLAN
Data: 2026-09-26

## 1. Status
- R218 runtime v3.15.1: **FAIL** — 3× TASK_WDT on `tgTask`.
- Commit B: **BLOCKED**.
- TelemetryRing: **NOT IMPLEMENTED**.
- Firebase telemetry endpoint: **NOT IMPLEMENTED**.
- Gate A-0: **YELLOW**.

## 2. Root-cause finding
Coredumps seq8/9/10 point to `tgTask` as the task that failed the Task WDT.
The pre-reset checkpoints were:
- boot2: `FB_CMD BEFORE`;
- boot3: `TG_CONNECT BEFORE`;
- boot4: `FB_CMD BEFORE`.

Source audit found a concrete deadlock/ownership defect in the timeout-worker hardening that was already present in v3.15.1:

### DNS worker
`wifiHostByNameZLimitem()` created a worker and, after the caller-side time limit expired, executed:
`xSemaphoreTake(ctx->mutex, portMAX_DELAY)`.
If the worker remained blocked in `WiFi.hostByName()`, the caller could block indefinitely waiting for the worker to release the mutex. That directly defeats the external timeout and can expose the caller to TWDT.

### Firebase worker
`fbCzekajImpl()` had the same pattern after timeout: it waited on the worker context mutex with `portMAX_DELAY` before marking the worker abandoned.
The success path also allowed the caller to delete the context/mutex immediately after observing `gotowe`, while the worker still had a final access to the same context. This is an ownership race / potential use-after-free.

## 3. v3.15.2 fix scope
Only worker timeout/ownership is changed.

Changes:
- DNS context: explicit two-owner refcount (caller + worker).
- Firebase context: explicit two-owner refcount (caller + worker).
- `gotowe` is published atomically with acquire/release semantics.
- Caller never waits on the worker context mutex.
- On timeout caller only marks context abandoned and releases its own reference.
- Worker releases its reference only after returning from the potentially blocking network operation.
- If worker creation fails, operation is cancelled; there is no fallback to the blocking inline Firebase loop.
- No change to `TelemetrySample`, freshness, stateBits, session identity or telemetry architecture.
- No increase of TWDT timeout.

## 4. Validation already completed
- Source structural audit: PASS.
- No remaining `ctx->mutex` use in DNS/Firebase worker helpers.
- No remaining `portMAX_DELAY` wait in those worker cleanup paths.
- No remaining blocking inline Firebase fallback after worker creation failure.
- Host-side ownership/race harness: PASS, 10,000 iterations of the success/timeout/race model.

## 5. Required operator validation
1. Build `v3.15.2` in the real PlatformIO project for `esp32-s3-n16r8`.
2. **Do not upload until build PASS is confirmed.**
3. After build PASS, upload once over USB.
4. Run a short controlled runtime capture (30–60 min is sufficient for this stabilization check).
5. Do not OTA/restart/erase/change automation during the capture.
6. Collect UART/HEALTH and reset/coredump evidence.

## 6. Success condition
No TASK_WDT/restart/coredump during the controlled runtime, with normal scheduler/control behavior.

If successful, the project can reopen the next incremental step. If not, analyze the new coredump before changing telemetry architecture.
