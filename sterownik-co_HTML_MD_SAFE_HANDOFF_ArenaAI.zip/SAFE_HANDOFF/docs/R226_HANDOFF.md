# R226 HANDOFF

Punkt startowy: v3.18.1.

Najważniejsze potwierdzone:
- v3.18.1 build PASS.
- R224 runtime na pustej płytce: brak WDT/reset/PANIC/coredump oraz brak "task not found".
- R225: ring zachował próbki podczas braku Wi-Fi i po powrocie połączenia opróżnił backlog; telemetry_dropped=0.
- Rekordy RTDB mają poprawną wire schema. Na pustej płytce age=65535 było oczekiwane.
- Wcześniejsze v3.17.0 miało realne TASK_WDT w tgTask/tgPollTask; v3.18.x rozdziela workerów sieciowych od per-task TWDT.

Następny krok: krótki runtime v3.18.1 na prawdziwej centrali z czujnikami.
Nie zmieniać kodu przed wynikiem tego testu.
