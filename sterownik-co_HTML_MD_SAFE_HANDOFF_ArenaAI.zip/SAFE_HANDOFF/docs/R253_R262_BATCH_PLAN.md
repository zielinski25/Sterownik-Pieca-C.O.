# R253-R262 — SPOOL V2 BATCH PLAN

Cel: jeden lokalny build v3.22.0, jedna komenda /spoolbatch TAK, dziesiec niezaleznych testow rdzenia V2.

UWAGA: tylko pusta/testowa plytka. Produkcja zostaje v3.19.2. Test nie integruje spoola z Firebase ani z produkcyjnym backlogiem.

R253 — committed page roundtrip: 1 rekord + poprawny header/record/page CRC/footer commit.
R254 — open page tail: 2 pelne rekordy + 30 B niepelnego ogona; recovery ma widziec 2 rekordy i tail=30.
R255 — FIFO/pageSeq: trzy zamkniete strony z rosnacym pageSeq; kolejnosc musi byc scisla.
R256 — bad record CRC: 3 rekordy, celowo uszkodzony payload rekordu #2; recovery ma zatrzymac sie po rekordzie #1.
R257 — bad header CRC: uszkodzony CRC headera ma odrzucic strone przed akceptacja danych.
R258 — bad footer commit: footer istnieje, ale marker COMMIT jest zly; strona nie moze zostac uznana za committed.
R259 — bad page CRC: wszystkie rekordy maja poprawne CRC, ale payload CRC w footerze jest zly; commit ma byc odrzucony.
R260 — rollover 768+1: pierwsza strona ma 768 rekordow, druga 1 rekord; sekwencja musi byc ciagla.
R261 — .part publish: poprawny .part jest zweryfikowany przed rename, potem final jest ponownie weryfikowany.
R262 — physical accounting: po zapisie 32 rekordow fizyczny usedBytes musi wzrosnac co najmniej o realny rozmiar logicznej strony, a protected reserve pozostaje bez zmian.

R252 real telemetry mirror pozostaje osobno: /spool252 TAK -> trzy kolejne probki -> /spool252verify.
R247 power-loss nie jest powtarzany, bo zostal zaliczony.
