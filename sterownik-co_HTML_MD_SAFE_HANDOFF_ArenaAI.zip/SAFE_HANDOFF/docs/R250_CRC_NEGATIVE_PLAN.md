# R250 — negative test CRC rekordu

## Cel
Potwierdzić, że recovery nie akceptuje pełnego rekordu z uszkodzonym payloadem, gdy zapisany CRC32 pozostaje stary.

## Zakres
Tylko lokalna pusta płytka ESP32-S3. Nie dotyka produkcji v3.19.2. Nie zmienia normalnej ścieżki telemetrii ani transportu Firebase.

## Test
1. `/spool250 TAK` tworzy `/telemetry_spool/r250_crc_corrupt.bin` o długości 400 B: header 64 B + 4 rekordy po 84 B, bez footeru.
2. Test zmienia dokładnie jeden bajt payloadu rekordu #2 bez zmiany jego CRC32.
3. `/spool250recover` skanuje rekordy od początku i ma zatrzymać recovery na rekordzie #2.

## PASS
- size=400 B
- headerCRC=OK
- validPrefix=1
- record1CRC=OK
- record2CRC=FAIL
- badRecord=2
- footer=ABSENT
- recovery=REJECT_BAD_RECORD
