R248 — Recovery -> odrzucenie niepelnego ogona -> kontynuacja zapisu

Zakres: TYLKO pusta plytka testowa. Produkcyjny piec pozostaje v3.19.2.

Wejscie testu:
- /telemetry_spool/r247_powerloss_page.bin = 272 B
- header 64 B
- 2 pelne rekordy po 84 B
- niepelny ogon 40 B
- footer absent

Test:
1. Wgraj lokalnie v3.20.7.
2. Potwierdz, ze R247 zostal wykonany z power-loss i recovery PASS.
3. Wpisz /spool248repair TAK.
4. Harness waliduje header + 2 CRC rekordow.
5. Odrzuca 40 B ogona.
6. Tworzy .part, kopiuje 2 poprawne rekordy i dopisuje nowy pelny rekord #3.
7. flush -> close -> reopen -> CRC wszystkich 3 rekordow.
8. Dopiero po PASS verify podmienia plik testowy.

PASS:
recovery+continue OK: input=272B validPrefix=232B discardedTail=40B output=316B records=3 headerCRC=OK recordCRC=OK footer=ABSENT continuedSeq=0xF2470003

FAIL: brak poprawnego prefiksu, zly CRC, inny rozmiar wejscia, niepelny zapis .part, nieudany rename albo final verify.
