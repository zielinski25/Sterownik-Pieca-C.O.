# R263-R272 — Persistent Spool V2 Batch 2

Cel: szybka bateria 10 lokalnych testow semantyki formatu i danych.

R263 — footer bounds: first/last/count zgodne z rekordami.
R264 — duplicate sampleSeq: recovery odrzuca drugi taki sam seq.
R265 — footer recordCount mismatch: poprawny CRC footera, ale zla liczba rekordow => reject.
R266 — footer pageSeq mismatch: poprawny CRC footera, ale pageSeq niezgodny z headerem => reject.
R267 — footer first/last mismatch: pola zakresu niezgodne z payloadem => reject.
R268 — trailing byte: dodatkowy bajt po commit footerze => page nie jest akceptowana jako poprawnie zamknieta.
R269 — bad .part publish gate: uszkodzony .part nie moze nadpisac poprawnego final.
R270 — TelemetrySample byte-exact roundtrip: 80 B ABI + CRC rekordu.
R271 — quality/age/simulated preservation: pola telemetryczne przechodza bez zmian.
R272 — full-page semantics: 768 rekordow, first/last seq i 64640 B zgodne z zamrozona geometria.

Uruchomienie:
/spoolbatch2 TAK

Wylacznie na pustej plytce testowej. Zero OTA na sterownik produkcyjny.
