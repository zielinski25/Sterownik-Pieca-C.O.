# R238 — MASTER STATE / PIEС_CO

Data: 2026-09-26
Status: AKTUALNY STAN PROJEKTU

## PRODUKCJA

Prawdziwa centrala:
- firmware: **v3.19.2**
- wdrożenie: OTA
- stan: pozostaje bez zmian
- v3.19.7/v3.19.8 nie wdrażać OTA.

Telemetryka V1:
- **ZAMKNIĘTA / PASS**
- ring: 1440
- batch: 10
- payload limit: 6144 B
- jeden request in-flight
- retry przez zachowanie tail do ACK
- Drop = 0 w ostatnich testach
- at-least-once + deterministyczne record IDs / idempotent overwrite.

## COMMIT F — LITTLEFS / COREDUMP

F1: **PASS / ZAMKNIĘTY**

Potwierdzone:
- brak automatycznego formatowania po błędzie mount;
- coredump: `image_check -> image_get -> .part -> write-check -> size -> close/reopen -> rename -> erase`;
- źródło coredumpu nie jest usuwane przed zweryfikowaną kopią.

Test lokalny `/testcrash TAK`:
- po poprawce v3.19.4 pojedynczy crash/restart;
- coredump archiwalny ~32 KB;
- wielokrotne wykonanie poprzednio wynikało z ponownego przetwarzania starego Telegram `update_id`; gate NVS w v3.19.4 zamknął ten problem.

## F2 — LITTLEFS ACCOUNTING / QUOTA

### F2.1 — fizyczny accounting
**PASS**

Źródło decyzji:
```text
LittleFS.usedBytes()
LittleFS.totalBytes()
```

Suma `File.size()` pozostaje diagnostyką.

### F2.2 — rezerwy liczbowe
**PASS**

```text
COREDUMP_RESERVE     1 310 720 B
HIST_SHORT_RESERVE     131 072 B
HIST_LONG_RESERVE    2 097 152 B
CRITICAL_FREE_MIN      310 641 B
--------------------------------
RAZEM                3 849 585 B
```

Panel firmware: **OPEN**.
Telemetry spool quota: **OPEN**.

### F2.3 — FsUsageSnapshot
**PASS**

Snapshot obejmuje:
- total/used/free;
- logical bytes;
- logs;
- settings;
- histS;
- histL;
- panel;
- coredump bytes;
- coredump file count.

### F2.5 — shadow quota
**PASS**

Runtime lokalny 23:37:
```text
used=1 314 816 B
free=9 039 872 B
logical=1 222 821 B
diff=91 995 B
coredump=666 480 B / 20
rezerwa=3 849 585 B
po_rezerwach=5 190 287 B
status=OK
```

Runtime lokalny 23:40:
```text
used=1 323 008 B
free=9 031 680 B
logical=1 225 723 B
diff=97 285 B
coredump=666 480 B / 20
rezerwa=3 849 585 B
po_rezerwach=5 182 095 B
status=OK
```

Telemetryka:
```text
produkcja = wysłane
Drop = 0
Błędy transportu = 0
```

### F2.6 — dynamiczna pozostała rezerwa
**PRZYGOTOWANE / RUNTIME PENDING**

Na podstawie realnie zajętych danych liczymy pozostałą, jeszcze niewykorzystaną część rezerw coredump/historii oraz stałą rezerwę krytyczną.

Dla danych R237:
```text
pozostała rezerwa chroniona = 3 052 520 B
planning headroom 23:37 = 5 987 352 B
planning headroom 23:40 = 5 979 160 B
```

To nadal nie jest hard quota i nie steruje kasowaniem.

## NAJWAŻNIEJSZE INVARIANTS

```text
I1  telemetry producer nie blokuje sterowania siecią/FS.
I2  jeden AsyncClient Firebase.
I3  jeden fbApp.loop path.
I4  maks. jeden telemetry request in-flight.
I5  tail przesuwa się dopiero po commit/ACK.
I6  retry używa tych samych record_id.
I7  timestamp nie jest jedyną tożsamością.
I8  last-good != fresh; quality mówi o jakości.
I9  physical FS usedBytes() jest źródłem quota.
I10 coredump source nie jest kasowany przed verify.
I11 mount error nie formatuje automatycznie produkcyjnych danych.
I12 persistent spool ma mieć twardą quota i nie może zjadać rezerwy crash/log.
I13 status i telemetry mają niezależne kontrakty.
I14 upgrade biblioteki/toolchain jest osobnym etapem.
```

## REGUŁA SPRZĘTOWA

```text
PRAWDZIWY PIEC:
  OTA ONLY
  brak USB
  brak /testcrash
  nie odcinać sieci/routera

PUSTA PŁYTKA TESTOWA:
  USB/build/upload dozwolone
  fault injection dozwolone
```

## NEXT

**F2.6 / v3.19.8 — lokalny runtime dynamicznej rezerwy.**

Po PASS:
**F2.7 — kontrakt maksymalnego panel firmware + finalizacja hard quota.**

Persistent spool V2 nadal nie jest implementowany.
