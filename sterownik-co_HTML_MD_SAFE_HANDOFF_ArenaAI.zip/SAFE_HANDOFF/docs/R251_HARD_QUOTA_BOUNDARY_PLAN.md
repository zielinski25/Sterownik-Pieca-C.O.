# R251 — Hard quota boundary test

## Cel
Potwierdzic, ze wspolny admission check dla przyszlego Persistent Spool V2 nie pozwala przekroczyc dostepnego hard quota.

## Test
- odczyt `FsQuotaHard` z fizycznego `LittleFS.freeBytes`;
- request dokładnie równy `availableQuotaBytes` musi byc ADMIT;
- request `availableQuotaBytes + 1 B` musi byc REJECT;
- dodatkowo raportowana jest decyzja dla bezpiecznej strony Spool V2 64640 B;
- test nie wypelnia filesystemu i nie tworzy danych spool.

## Kryterium PASS
`exact=ADMIT` oraz `over1=REJECT`, przy prawidlowym snapshot/quota.

## Bezpieczenstwo
Tylko lokalna plytka testowa. Produkcja pozostaje v3.19.2.
