# PIECO — MASTER STATE CURRENT — 2026-09-28 — v3.31.18

## 0. SOURCE OF TRUTH / SCOPE
This document supersedes the older v3.31.16 master-state documents for current-project position only.
Historical files remain unchanged and are evidence of earlier gates/builds.

The project Library was reviewed recursively on 2026-09-28: 394 Library items were enumerated across the saved project history, with 352 filename-matched as project-relevant. In addition, the current conversation uploads were searched/read directly.

## 1. CURRENT REAL CONTROLLER
- Remote real boiler/controller currently reports: **v3.31.18**.
- Telegram `/version` result: **Obecna wersja: v3.31.18**.
- Remote OTA update at 2026-09-28 ~19:42–19:43 reported:
  - new version 3.31.18 found from GitHub;
  - update downloaded OK;
  - restart performed;
  - update completed successfully; running version v3.31.18.
- Current boot after update: **boot=33**.
- No manual USB intervention was required on the remote controller.

### Important historical boundary
- Previous documented production baseline: **v3.19.2**, OTA-only.
- That historical state is now superseded by the actual remote OTA deployment of v3.31.18 documented above.
- The OTA-only principle remains: production/remote controller must be serviced remotely; do not plan USB flashing of the real boiler.

## 2. v3.31.18 CHANGE / DELTA FROM v3.31.16
Canonical current source:
`main_centrala_v3.31.18_FINAL_OTA_CONFIRM_FIREBASE.cpp`

v3.31.18 is based on the v3.31.16 architecture and adds the deployment fixes needed for the remote controller:

1. **Remote Firebase H2/UserAuth provisioning**
   - Telegram command:
     `/fbprov|API_KEY|EMAIL|PASSWORD`
   - credentials are written to `Preferences("firebase")` under:
     `api_key`, `auth_email`, `auth_pass`;
   - existing architecture remains Firebase UserAuth; no rollback to LegacyToken/Database Secret;
   - Firebase is reloaded/reinitialized after provisioning;
   - credential values are not logged.

2. **OTA first-boot confirmation**
   - `potwierdzPartycjeJesliCzeka()` handles `ESP_OTA_IMG_PENDING_VERIFY`;
   - calls `esp_ota_mark_app_valid_cancel_rollback()`;
   - current remote boot proved the call returned `ESP_OK`.

3. **Firmware version**
   - `FIRMWARE_VERSION` is now `v3.31.18`.
   - CHANGELOG contains the v3.31.18 entry.

## 3. LIVE OTA EVIDENCE — REMOTE BOOT 33
From `piec_log (12).txt`:

```text
boot=33
OTA-ROLLBACK stan_partycji partycja=app1 stan=1
OTA-ROLLBACK potwierdzono_valid wynik=ESP_OK
```

Immediately after boot, Firebase needed a short initialization window, then became healthy:

```text
19:43:54  fb=0
19:44:24  fb=1
19:44:54  fb=1
19:45:24  fb=1
19:45:54  fb=1
```

The same log shows `firebaseWorker=0` on the later HEALTH-A samples and normal telemetry production continuing.

## 4. FIREBASE / WEB DASHBOARD CURRENT STATE
Current dashboard artifact:
`Piec_UserAuth_piectest_AUTO_FIXED.html`

Verified design:
- Firebase Authentication UserAuth;
- ID token is used for existing V1 database paths;
- RTDB paths:
  - `/piec/status`
  - `/piec/cmd`
  - `/piec/ack/<cmdId>`
- Dashboard OTA is intentionally not performed through Firebase; remote OTA is through Telegram/GitHub release flow.
- User confirmed the dashboard is currently **working** against the remote boiler.

Security note:
- The current auto-login HTML contains Firebase UserAuth credentials. Treat that HTML as a secret-bearing artifact and do not publish/share it outside the intended operator environment.

## 5. HISTORICAL TEST CHAIN — INHERITED, NOT RE-RUN IN v3.31.18
The following gates are documented as PASS on **v3.31.16** and are inherited by v3.31.18 from the same base architecture, but were not re-executed merely because the version was bumped:

- R247-R252 — Persistent Spool V2 fundamentals
- R253-R262 — spool batch
- R263-R272 — spool semantics
- R273-R282 — real telemetry producer / byte-exact
- R283-R300 — extended spool integrity/quota
- R301-R312 — replay / ACK / delete
- R313-R324 — fault recovery / quota
- R325-R334 — Commit G
- R335-R344 — Security H1
- R345-R356 — Security H2 / UserAuth / Rules
- R357-R366 — G2 runtime
- R367-R379 — RTDB integration
- R380-R400 — final regression mega
- R401-R430 — stability mega
- R431-R470 — recovery / OTA / FS / boot mega
- controlled `/testcrash` one-shot + coredump seq98 + stale replay rejection

Key v3.31.16 architectural closure:
- v3.31.14 detached Firebase worker caused lwIP TCP/IP core-lock assertion;
- v3.31.15 attempted `LOCK_TCPIP_CORE()` but live runtime showed worker-stuck behavior;
- v3.31.16 removed the detached Firebase worker and kept `fbApp.loop()` in `tgTask`.

## 6. CURRENT RUNTIME OBSERVATION
Current remote `/status` confirmed:
- Zewn: 17.0 C
- Bojler: 17.0 C
- Ogrz: 15.8 C
- Pompa: wylaczona
- Alarm dymu: brak
- Alarm CO: brak
- Alarm panelu: brak
- WiFi RSSI: -76 dBm

The user also confirmed the web dashboard works after v3.31.18 deployment.

## 7. BUILD / RELEASE ARTIFACT STATUS
### Verified historical build evidence
v3.31.16 had a recorded successful PlatformIO build in both configured environments:
- `esp32-s3-n16r8`
- `esp32-s3-ota`

Recorded v3.31.16 flash usage was about 2.029 MB of the 3 MiB application slot.

### v3.31.18 artifact identity gap
- The current canonical **source** is present in Library.
- The successful **v3.31.18 binary was built by the operator and deployed through the GitHub OTA path**, but an exact v3.31.18 `firmware.bin` SHA-256 is not currently recorded in the persistent documentation set.
- Do not invent a binary hash from older firmware artifacts.

## 8. DOCUMENTATION DRIFT FOUND
The v3.31.18 source header still contains historical comments such as `Test-only; production remains v3.19.2` in inherited sections. Those comments describe the historical development state, not the current deployed remote controller.
For future source releases, keep the version header/current deployment note synchronized with the real field state.

## 9. RELEASE / NEXT-DIRECTION GATE
No reliable R471+ test matrix is defined in the reviewed project sources. Do not invent R471+ numbers.

The next work remains named release-gate work:

### A — single-version soak
- freeze one firmware version;
- no OTA, manual restart or erase during the capture;
- inspect HEALTH continuity, Firebase state, worker/request idle state, memory trend and unexpected resets;
- a 6 h SHORT_BASELINE is distinct from a full 24 h baseline.

### B — release identity
Record:
- exact release tag;
- exact binary asset name;
- SHA-256 of the binary;
- source SHA-256 where available.

### C — OTA / rollback validation
Use the existing OTA/GitHub procedure on the local test board for formal repeatability evidence. The remote v3.31.18 deployment itself already proved on the actual controller:
- correct release discovery;
- successful download;
- successful reboot;
- `PENDING_VERIFY -> VALID` with `ESP_OK`;
- final reported version v3.31.18.

### D — production/field follow-up
The remote controller is already running v3.31.18. The immediate operational priority is therefore stability evidence and artifact traceability, not another firmware change.

## 10. OPERATING RULES FOR CONTINUATION
- Keep **v3.31.18 frozen** until a concrete defect or documented change request exists.
- Do not revert to LegacyToken/Database Secret.
- Do not USB-flash the real remote controller.
- Do not run deliberate `/testcrash` or destructive test batches on the remote real boiler.
- Prefer passive diagnostics on the real unit.
- Keep historical R247-R470 evidence as historical PASS; do not relabel it as newly executed on v3.31.18.
- Every new runtime result must be recorded exactly as observed.

## 11. CURRENT POSITION IN ONE LINE
**We are at v3.31.18 deployed on the real remote boiler, OTA-confirmed with `ESP_OK`, Firebase UserAuth active, dashboard working; the next objective is frozen-version soak + release artifact traceability, without inventing R471+ tests.**
