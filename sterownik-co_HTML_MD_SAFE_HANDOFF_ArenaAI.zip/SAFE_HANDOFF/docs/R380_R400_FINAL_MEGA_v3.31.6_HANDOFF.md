# R380-R400 FINAL REGRESSION MEGA v3.31.6

Status: local/test firmware only. Production remains v3.19.2.

## Why v3.31.6
The v3.31.5 mega batch reached R380-R386, but R387-R390 failed because the board had just rebooted and the first normal history/telemetry sample had not yet been produced. `historiaZapiszProbke()` is scheduled every 60 s. The dependent gates intentionally require the real `g_telemetryLastSnapshot` and therefore correctly refused to invent a sample.

v3.31.6 adds a test-only telemetry prime immediately before R387:
- if a real snapshot already exists, it is reused;
- otherwise the existing scheduler slot for `historiaZapiszProbke()` is marked due now;
- the normal scheduler executes the real producer in its normal context;
- the test waits up to 10 s for a non-zero `sampleSeq` + `sessionNonce`;
- it never calls `telemetryBuildSnapshot()` directly from the Final-Mega worker and does not synthesize telemetry data.

## Test sequence
1. Flash only the local/test board.
2. `/version` must report `v3.31.6`.
3. `/finalmega TAK`.
4. Return the entire `R380-R400 final regression mega batch` message.

Expected new diagnostic line before R387:
`FINAL-MEGA:telemetryPrime:PASS ...`

Production: v3.19.2, OTA-only, untouched.

## Build note
This environment does not have the local PlatformIO toolchain available, so the source was not compiled here. The change is source-reviewed and the version string was verified to be v3.31.6. Build/flash must use the same local PlatformIO environment as before.
