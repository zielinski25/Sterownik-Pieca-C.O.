# R227 — NEXT PHASE

## Punkt startowy

MASTER/STABLE = v3.18.1

## Czego nie ruszamy

- watchdog / TWDT
- Telegram networking
- Firebase auth/TLS
- istniejący status
- sterowanie pompą i serwami
- partycje
- toolchain / biblioteki
- produkcyjny firmware bez konkretnej przyczyny

## Co jest już zrobione w telemetryce

1. model danych
2. freshness / quality
3. PSRAM ring
4. Firebase batch
5. retry / backlog drain
6. telemetry wire schema

## Pozostałe duże bloki

### F — LittleFS / coredump hardening
Oddzielny etap. Najpierw bezpieczne księgowanie FS i gwarancja, że coredump nie zostanie usunięty przed zweryfikowaną kopią.

### G — persistent spool V2
Dopiero po F i po potwierdzeniu potrzeb. Immutable pages, CRC, recovery po power loss, FIFO replay, twarda quota.

### H — security
Auth/TLS/rules/sekrety jako osobny commit.

### I — library/toolchain
Osobny etap, nigdy razem z telemetryką.

## Rekomendowany następny ruch

Nie dodawać kolejnego mechanizmu buforowania do działającego v3.18.1 bez konkretnego wymagania użytkowego.

Najpierw wybrać jedną nową funkcję sterownika/aplikacji i zrobić ją jako v3.19.0 na lokalnej płytce.
