# R217 — COMMIT B RUNTIME VALIDATION
Data: 2026-09-25

## Status
- Firmware target: **v3.15.1**
- Commit B scope: TelemetrySample 80 B + freshness sidecar + snapshot builder
- Firebase telemetry: NOT IMPLEMENTED
- TelemetryRing: NOT IMPLEMENTED
- TelemetryTask: NOT IMPLEMENTED
- Gate A-0: YELLOW

## Build evidence
User-reported PlatformIO result:

`Successfully created combined binary image.`
`[SUCCESS] Took 218.87 seconds`
Environment: `esp32-s3-n16r8`
Result: **BUILD PASS**

Source SHA-256:
`739cf427b8cd944dedc1d1f7f3c37207730beb6c5cdba210a350011815575a81`

## Meaning
This closes the R216 gap "PlatformIO/ESP-IDF build not executed". It does **not** constitute runtime PASS.

## Next controlled test
1. Flash/upload **v3.15.1 once by USB** to the ESP32-S3.
2. Verify boot/version from UART.
3. Start one isolated capture session.
4. Do not perform OTA, restart, erase, parameter changes, or artificial fault injection during the observation window.
5. Observe normal operation and HEALTH/diagnostic output.
6. Collect the complete capture directory and runtime report.

## Runtime assertions
- no reboot/PANIC/coredump;
- no visible change in control behavior;
- no new Firebase telemetry traffic;
- no new task created for telemetry;
- no filesystem telemetry writes;
- snapshot generation remains local/non-blocking;
- existing scheduler/history behavior remains unchanged;
- `TelemetrySample` ABI remains 80 B.

## Boundary
If runtime is clean, Commit B runtime is accepted and only then may the project open the next incremental step: **PSRAM SPSC TelemetryRing**. Firebase writer/batching remains a later step.
