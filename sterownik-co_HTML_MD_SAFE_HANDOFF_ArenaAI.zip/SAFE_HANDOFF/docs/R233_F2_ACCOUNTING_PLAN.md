# R233 — F2.1 LittleFS accounting diagnostyka

Data: 2026-09-26

## Zakres
- lokalny eksperyment na pustej plytce;
- brak zmiany automatyki;
- brak zmiany Firebase/telemetry transport;
- brak zmiany guard/rotacja/trim;
- brak zmiany partycji.

## Co dodano w v3.19.5
- raport realnego LittleFS `totalBytes()/usedBytes()/free`;
- suma logiczna rozmiarow: log_a, log_b, log_krytyczny, log_ustawien,
  hist_short, hist_long, panel_firmware oraz pliki `/coredumps/`;
- raport `used - logical` jako metryka roznicy;
- helper jest diagnostyczny i nie jest wywolywany przez guard.

## Gate
1. build `esp32-s3-n16r8` PASS;
2. build `esp32-s3-ota` PASS;
3. USB upload tylko pusta plytka;
4. zwykly runtime bez crash testu;
5. Telegram `/telemetry` i odczyt `FS fizyczny` + `FS logiczny`;
6. obserwacja kilku kolejnych raportow i porownanie stabilnosci wartosci.

## Decyzja po danych
Dopiero po pomiarach wybieramy F2.2: snapshot accounting + nowe progi rezerwy.
Nie zmieniac jeszcze produkcyjnego guardu i nie wysylac OTA na prawdziwy sterownik.

## SHA-256
source: 02fbf1be3a05120c564af31838f907378d128975ac2b1f2a2ea8b92bd9843aa7
