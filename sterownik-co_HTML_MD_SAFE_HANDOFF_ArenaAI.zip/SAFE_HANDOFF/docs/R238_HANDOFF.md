# R238 HANDOFF — Piec_CO

Data: 2026-09-26

## CURRENT

- Produkcyjna centrala: **v3.19.2**
- Telemetry V1: **PASS / zamknięta**
- Commit F1: **PASS / zamknięty**
- F2.1: **PASS**
- F2.2: **PASS**
- F2.3: **PASS**
- F2.5: **PASS**
- Ostatnie lokalne telemetry:
  - Drop=0
  - produkcja=wysłane
  - błędy transportu=0
  - FS shadow status=OK

## POTWIERDZONY STAN FS

```text
total=10 354 688 B
used≈1.31 MiB
free≈9.03 MiB
static reserve=3 849 585 B
coredump=666 480 B / 20
panel=0 B
```

## NEXT — F2.6

Przygotowany lokalny artefakt **v3.19.8** dodaje tylko dynamiczną diagnostykę pozostałej części rezerw.

Plik:
`main_centrala_v3.19.8_LOCAL_FS_DYNAMIC_RESERVE.cpp`

Patch:
`COMMIT_v3.19.8_LOCAL_FS_DYNAMIC_RESERVE.patch`

Plan:
`R238_F2.6_DYNAMIC_RESERVE_PLAN.md`

Nie zmienia guard/trim/delete/Firebase/automatyki/partycji.

## GATE

Na Windows, tylko pusty ESP32-S3:
1. backup `src/main.cpp`
2. wstawić v3.19.8
3. Build `esp32-s3-n16r8`
4. Build `esp32-s3-ota`
5. USB upload
6. `/telemetry` × 2–3
7. bez `/testcrash`

## EXPECTED

```text
pozostala_rezerwa=3052520 B
headroom≈5.98 MiB
panel=OPEN
status=OK
Drop=0
produkcja=wysłane
```

**Prawdziwy piec pozostaje na v3.19.2.**
