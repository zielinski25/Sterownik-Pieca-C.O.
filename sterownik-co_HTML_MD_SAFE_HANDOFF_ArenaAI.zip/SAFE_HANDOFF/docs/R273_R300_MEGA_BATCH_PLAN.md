R273-R300 MEGA BATCH — plan

Cel: jedna lokalna wersja firmware i jedna komenda Telegram zamiast wielu buildow.
Baza: znany-dobry v3.22.1, z zachowaniem istniejącego Telegram/V1.
Produkcja: NIE DOTYKAĆ. Sterownik produkcyjny zostaje v3.19.2.

R273 byteExact TelemetrySample + record CRC
R274 deterministyczny sample/CRC
R275 exact header fields
R276 exact committed footer + scan
R277 one record
R278 768 records
R279 open page -> append footer -> commit dopiero po footerze
R280 page payload CRC
R281 footer recordCount mismatch reject
R282 footer firstSampleSeq mismatch reject
R283 footer lastSampleSeq mismatch reject
R284 footer pageSeq mismatch reject
R285 header recordBytes mismatch reject
R286 header capacity mismatch reject
R287 header magic mismatch reject
R288 header formatVersion mismatch reject
R289 footer magic mismatch reject
R290 footer formatVersion mismatch reject
R291 footer CRC mismatch reject
R292 trailing byte reject
R293 open page + 83 B tail recoverable
R294 empty open page recoverable
R295 3-page ordering
R296 contiguous sample sequence across pages
R297 rollover 768 + 1
R298 invalid .part does not destroy final
R299 hard quota exact admit / +1 reject
R300 physical usedBytes delta >= page minimum

Wszystkie pliki testowe sa pod /telemetry_spool/r_mega_*.bin i sa sprzatane po batchu.
Batch nie modyfikuje normalnej kolejki V1/Firebase.
