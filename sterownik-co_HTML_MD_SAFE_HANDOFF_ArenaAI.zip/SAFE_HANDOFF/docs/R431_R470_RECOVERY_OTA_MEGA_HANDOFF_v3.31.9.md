# R431-R470 RECOVERY / OTA / FS / BOOT MEGA — v3.31.9

## Co poprawiono po wyniku v3.31.8
- R451/R455 byly wrażliwe na ponowne wejście `tgPollTaskFn` w long-poll podczas batcha.
- R461-R464 nie startowały bez aktualnego prawdziwego `TelemetrySample` po świeżym boocie.
- Dodano guard `g_recoveryOtaMegaActive` do `tgPollTaskFn`.
- Dodano `recoveryOtaMegaEnsureRealTelemetrySnapshot()`: ustawia istniejący slot `historiaZapiszProbke()` jako due i czeka maks. 10 s na snapshot wykonany przez normalny scheduler.
- Po prime jest maks. 15 s na zejście Firebase/telemetry request do idle.
- Brak sztucznego `sampleSeq`/`sessionNonce`, brak OTA flash, brak rebootu.

## Komenda
Tylko lokalna płytka testowa:

```text
/version
/recoverymega TAK
```

## Oczekiwane
`R431-R470 recovery OTA mega batch: PASS` oraz `R470:PASS RECOVERY-OTA-MEGA overall=PASS`.

## SHA256
`056395fc06b1634b2abe85e80bf40096139952ed0112c2765dce10696a580596`

Produkcja v3.19.2 pozostaje nietknięta.
