# Research: zdalny terminal diagnostyczny ESP32 → Firebase → zakładka Terminal

**Projekt:** Piec C.O. / ESP32-S3\
**Baza:** firmware v3.31.19\
**Cel:** opcjonalne zdalne oglądanie diagnostyki urządzenia z poziomu
zakładki „Terminal", bez stałego wysyłania logów do Firebase.

------------------------------------------------------------------------

## 1. Cel funkcji

Chcemy mieć w panelu webowym:

-   zakładkę **Terminal**,
-   przycisk **Włącz wysyłanie**,
-   przycisk **Wyłącz wysyłanie**,
-   bieżący terminal przewijany jak konsola,
-   informację o stanie transmisji,
-   licznik odebranych bajtów/linii,
-   licznik utraconych wpisów,
-   opcjonalnie przycisk **Wyczyść ekran**,
-   opcjonalnie przycisk **Pobierz log**.

Po wyłączeniu transmisji urządzenie ma wrócić do normalnego działania i
nie wykonywać okresowych wysyłek terminala.

Najważniejsza zasada:

> Diagnostyka ma być dodatkiem do działającego firmware, a nie nowym
> kanałem, który może destabilizować telemetrię, Firebase, WiFi, OTA
> albo watchdog.

------------------------------------------------------------------------

# 2. Wynik researchu --- najważniejszy wniosek

Najlepszym kierunkiem dla tego projektu nie jest wysyłanie pojedynczej
linii Serial do Firebase.

Najbardziej sensowna architektura to:

``` text
                 ┌──────────────► fizyczny Serial
                 │
log/Serial ──► lokalny bufor diagnostyczny
                 │
                 ▼
           RAM ring buffer
                 │
          co ~5 sekund
                 │
                 ▼
        Firebase RTDB / chunks
                 │
                 ▼
          zakładka Terminal
```

Czyli:

**log powstaje raz → trafia do RAM → fizyczny Serial nadal działa →
tylko gdy terminal jest ON, Firebase dostaje porcje logów.**

ESP-IDF posiada oficjalny mechanizm ring bufferów przeznaczony właśnie
do bezpiecznego przekazywania danych o zmiennej długości pomiędzy
zadaniami. Dokumentacja wskazuje ring buffer jako bardziej odpowiedni od
klasycznej kolejki, gdy elementy mają zmienny rozmiar.\
Źródło: ESP-IDF FreeRTOS ring buffers.

------------------------------------------------------------------------

# 3. Ring buffer --- bardzo dobry kandydat

ESP-IDF udostępnia `xRingbufferCreate()` oraz warianty ring bufferów dla
danych o zmiennej długości.

Ważne cechy:

-   FIFO,
-   dane mogą mieć różną długość,
-   można przekazywać dane pomiędzy taskami,
-   nadaje się do strumienia tekstowego,
-   można kontrolować rozmiar pamięci,
-   istnieje również wariant byte buffer.

Źródło:
https://docs.espressif.com/projects/esp-idf/en/latest/esp32s2/api-reference/system/freertos_additions.html

### Dla naszego projektu

Rozważyć:

``` text
RAM diagnostyczny:
64 KB  — minimum
128 KB — rozsądny wariant
256 KB — bardzo bezpieczny wariant, jeśli PSRAM jest dostępny
```

ESP32-S3 z PSRAM daje tutaj duży komfort.

ESP-IDF pozwala jawnie alokować pamięć z PSRAM przez
`heap_caps_malloc(..., MALLOC_CAP_SPIRAM)`.

Źródło:
https://docs.espressif.com/projects/esp-idf/en/stable/esp32/api-guides/external-ram.html

------------------------------------------------------------------------

# 4. Bardzo ważne: co oznacza „cały Serial"

To jest najtrudniejsza część projektu.

## A. ESP-IDF `ESP_LOGx`

ESP-IDF ma oficjalny mechanizm:

``` cpp
esp_log_set_vprintf(...)
```

Pozwala przekierować wyjście logów do własnej funkcji.

Dokumentacja wprost podaje możliwość przekierowania logów np. do pliku
lub sieci.

Źródło:
https://docs.espressif.com/projects/esp-idf/en/v5.1.2/esp32/api-reference/system/log.html

To jest bardzo dobry mechanizm dla:

``` cpp
ESP_LOGI(...)
ESP_LOGW(...)
ESP_LOGE(...)
ESP_LOGD(...)
```

Możemy zrobić:

``` text
ESP_LOG
   ├──► oryginalny UART
   └──► terminalRingBuffer
```

## B. Arduino `Serial.print()`

To osobna sprawa.

`esp_log_set_vprintf()` nie przechwytuje automatycznie każdego:

``` cpp
Serial.print(...)
Serial.println(...)
Serial.printf(...)
```

Dlatego jeżeli przez „cały Serial" rozumiemy absolutnie wszystko, trzeba
zastosować dodatkową warstwę.

Najbezpieczniejsze rozwiązanie:

``` cpp
Serial.println(...)
        ↓
TeeSerial / DiagnosticSerial
        ├──► prawdziwy Serial
        └──► ring buffer
```

Nie należy robić prostego:

``` cpp
Firebase.setString(...)
```

wewnątrz `Serial.println()`.

To mogłoby blokować logowanie i mieszać odpowiedzialności.

------------------------------------------------------------------------

# 5. Jeszcze lepszy wariant: wspólny system logowania

Zamiast przechwytywać przypadkowo wszystkie `Serial.print`, warto
docelowo uporządkować diagnostykę:

``` text
LOG_ERROR()
LOG_WARN()
LOG_INFO()
LOG_DEBUG()
LOG_TELEMETRY()
LOG_FIREBASE()
LOG_WIFI()
LOG_OTA()
LOG_SPOOL()
```

Każdy wpis może mieć:

``` text
timestamp
level
tag
tekst
```

Np.:

``` text
14:32:05.124 [INFO] WIFI       RSSI=-79
14:32:05.220 [DEBUG] FIREBASE  worker=IDLE
14:32:06.003 [INFO] TELEMETRY producer=REAL_SNAPSHOT
14:32:06.711 [WARN] FIREBASE  timeout
```

Dzięki temu w przyszłości Terminal może mieć filtr:

``` text
[ALL] [ERROR] [WARN] [INFO] [DEBUG]
```

To byłoby dużo bardziej użyteczne niż bezładny strumień tekstu.

------------------------------------------------------------------------

# 6. Firebase RTDB --- jak wysyłać log

Firebase Realtime Database obsługuje:

-   `set`,
-   `update`,
-   `push`,
-   transakcje.

Do logów najbardziej naturalny jest model **push/chunks**.

Źródło: https://firebase.google.com/docs/database/admin/save-data

Proponowana struktura:

``` text
/piec/terminal/
    enabled
    sessionId
    lastSeq
    dropped
    lastUploadMs

/piec/terminal/chunks/
    <chunkId>
        seq
        ts
        text
        bytes
```

Przykład:

``` json
{
  "seq": 1842,
  "ts": 1790685125000,
  "text": "14:32:05.124 [INFO] WIFI RSSI=-79\n...",
  "bytes": 1260
}
```

------------------------------------------------------------------------

# 7. Dlaczego CHUNKS, a nie jedno pole `terminalText`

Nie:

``` text
/piec/terminal/text = "cały terminal..."
```

Bo pole będzie cały czas rosnąć.

Lepiej:

``` text
chunks/
    1001
    1002
    1003
    1004
```

Każdy chunk jest niezależny.

Frontend może obserwować tylko nowe elementy.

Firebase dokumentuje mechanizmy nasłuchiwania zmian przez `onValue()`
oraz zdarzenia dzieci. Przy dużych danych należy słuchać możliwie nisko
w drzewie, a nie na korzeniu.

Źródło: https://firebase.google.com/docs/database/web/read-and-write

------------------------------------------------------------------------

# 8. Jeszcze lepiej: `onChildAdded`

Dla terminala naturalny jest model:

``` text
Firebase
    ↓
nowy chunk
    ↓
onChildAdded
    ↓
appendTerminalText()
```

Wtedy przeglądarka nie musi pobierać całego terminala za każdym razem.

To jest ważne przy długiej sesji diagnostycznej.

------------------------------------------------------------------------

# 9. Częstotliwość wysyłania --- 5 sekund

Pomysł użytkownika:

``` text
co 5 sekund
```

jest rozsądny.

Nie wysyłałbym jednak pustych paczek.

Algorytm:

``` text
co 5 s:

jeżeli terminal OFF:
    nic

jeżeli terminal ON:
    jeżeli ring buffer pusty:
        nic

    jeżeli są dane:
        pobierz maksymalnie np. 4–8 KB
        utwórz chunk
        wyślij Firebase
```

Dzięki temu:

-   przy spokojnym piecu prawie nic nie idzie,
-   przy dużym logowaniu dane są grupowane,
-   liczba operacji Firebase jest mała,
-   terminal wygląda na żywy.

------------------------------------------------------------------------

# 10. Limit wielkości pojedynczego chunka

Nie ma sensu robić:

``` text
1 chunk = 100 KB
```

Lepiej np.:

``` text
1–8 KB / chunk
```

W praktyce proponuję:

``` text
target: 4 KB
hard max: 8 KB
```

Jeżeli przez 5 sekund powstanie 1 KB:

``` text
wysyłamy 1 KB
```

Jeżeli powstanie 20 KB:

``` text
chunk 1 = 8 KB
chunk 2 = 8 KB
chunk 3 = 4 KB
```

------------------------------------------------------------------------

# 11. Firebase ma odpowiednie limity

Aktualna dokumentacja Firebase RTDB podaje m.in.:

-   do 1000 write operations/s na bazę,
-   maksymalnie 256 MB pojedynczego zapisu przez REST,
-   16 MB przez SDK,
-   64 MB/min całkowitego zapisu danych.

Źródło: https://firebase.google.com/docs/database/usage/limits

Nasza diagnostyka będzie wielokrotnie poniżej tych limitów.

Problemem nie jest więc sam limit Firebase, tylko przede wszystkim:

-   stabilność ESP,
-   zużycie transferu,
-   liczba niepotrzebnych operacji,
-   rozrost danych diagnostycznych.

------------------------------------------------------------------------

# 12. Automatyczne czyszczenie

Terminal diagnostyczny nie powinien być archiwum na zawsze.

Proponuję:

``` text
terminal session
        ↓
start
        ↓
chunks
        ↓
stop
        ↓
opcjonalne czyszczenie
```

Najprościej:

### Tryb A --- sesja

Przy ON:

``` text
sessionId = nowy identyfikator
```

Wszystkie chunki trafiają do tej sesji.

Przy OFF:

``` text
session kończy się
```

Frontend pokazuje tylko bieżącą sesję.

Stare dane można później usunąć.

### Tryb B --- limit

Np.:

``` text
max 500 chunków
```

Po przekroczeniu usuwamy najstarsze.

------------------------------------------------------------------------

# 13. Nie zapisujmy terminala do LittleFS

To ważne.

Nie proponuję:

``` text
Serial
  ↓
LittleFS
  ↓
Firebase
```

dla bieżącego terminala.

LittleFS można zostawić jako awaryjne archiwum, ale nie jako główny
bufor live.

Dla live diagnostyki lepszy jest:

``` text
RAM / PSRAM ring buffer
```

a Firebase jest warstwą transportową.

------------------------------------------------------------------------

# 14. Co w przypadku utraty Firebase?

To musi być obsłużone.

Przykład:

``` text
Terminal ON

14:00:00 ───── Firebase OK
14:00:05 ───── Firebase OK
14:00:10 ───── Firebase timeout
14:00:15 ───── Firebase timeout
14:00:20 ───── Firebase timeout
14:00:25 ───── Firebase OK
```

Nie możemy dopuścić, aby diagnostyka blokowała główne zadania.

Dlatego:

``` text
log → ring buffer
             ↓
       Firebase worker
             ↓
        timeout/error
             ↓
       wróć do taska
```

Jeżeli bufor się zapełni:

``` text
dropped++
```

i najstarsze dane są nadpisywane.

------------------------------------------------------------------------

# 15. Firebase może streamować dane do przeglądarki

Firebase RTDB REST API obsługuje Server-Sent Events (SSE).

Dokumentacja opisuje `text/event-stream` oraz zdarzenia `put` i `patch`.

Źródło: https://firebase.google.com/docs/reference/rest/database

Jednak dla naszego HTML prawdopodobnie lepiej pozostać przy oficjalnym
Firebase JS SDK i listenerze RTDB.

Nie ma potrzeby ręcznie implementować SSE, jeżeli aktualny panel już
korzysta z Firebase.

------------------------------------------------------------------------

# 16. Alternatywa: WebSocket bez Firebase

Można zrobić:

``` text
ESP32
  ↓
WebSocket
  ↓
przeglądarka
```

ESPAsyncWebServer/AsyncWebSocket dobrze pasuje do takiego terminala.

Ale jest jeden zasadniczy problem:

**użytkownik nie jest w tej samej sieci LAN co piec.**

Dlatego:

``` text
telefon ───── Internet ───── ESP32 w domu
```

nie dostanie się bezpośrednio do:

``` text
192.168.100.19
```

Firebase rozwiązuje ten problem.

Wniosek:

> WebSocket lokalny warto zostawić jako opcjonalny tryb serwisowy, ale
> nie jako główny kanał zdalnego terminala.

------------------------------------------------------------------------

# 17. Alternatywa: Firebase jako „most"

Najbardziej pasuje:

``` text
ESP32
  │
  │ Firebase upload
  ▼
RTDB
  │
  │ listener
  ▼
HTML Terminal
```

To daje dostęp z dowolnego miejsca.

------------------------------------------------------------------------

# 18. Alternatywa: logi binarne

ESP-IDF Log V2 posiada także tryb logowania binarnego.

Dokumentacja podaje, że binary logging może ograniczyć zużycie flash,
stacka i narzut transmisji.

Źródło:
https://docs.espressif.com/projects/esp-idf/en/stable/esp32c6/api-reference/system/log.html

Dla naszego projektu **na razie nie polecam**.

Powód:

Potrzebujemy czytelnego terminala.

Tekst:

``` text
Firebase timeout
```

jest dla nas znacznie wygodniejszy niż dekodowanie binarnych rekordów.

Binary logging można rozważyć później, jeśli okaże się, że logów jest
bardzo dużo.

------------------------------------------------------------------------

# 19. Bardzo ciekawy wariant: poziomy logowania

Można zrobić drugi parametr:

``` text
terminalEnabled
terminalLevel
```

Np.:

``` text
OFF
ERROR
WARN
INFO
DEBUG
TRACE
```

Normalnie:

``` text
terminalEnabled = false
```

Gdy włączymy:

``` text
INFO
```

Jeżeli potrzebujemy pełnego debugowania:

``` text
DEBUG
```

Dzięki temu nie zawsze trzeba wysyłać absolutnie wszystko.

ESP-IDF ma oficjalne poziomy logowania i możliwość zmiany poziomu dla
tagów w runtime.

Źródło:
https://docs.espressif.com/projects/esp-idf/en/v5.1.2/esp32/api-reference/system/log.html

------------------------------------------------------------------------

# 20. Bardzo ciekawy wariant: filtr po module

Terminal może mieć:

``` text
[✓] WIFI
[✓] FIREBASE
[✓] TELEMETRY
[✓] SPOOL
[✓] OTA
[✓] SENSOR
[✓] SYSTEM
```

Ale tutaj trzeba rozdzielić:

### filtr po stronie ESP

mniej danych wychodzi z ESP.

### filtr tylko w HTML

ESP nadal wysyła wszystko.

Na początek lepszy jest filtr HTML.

Dopiero później można dodać dynamiczne poziomy po stronie ESP.

------------------------------------------------------------------------

# 21. Włączanie terminala

Nie powinno być:

``` text
HTML → terminalEnabled=true
```

bez dodatkowej kontroli.

Lepiej użyć istniejącego mechanizmu komend Firebase:

``` text
HTML
 ↓
Firebase command
 ↓
ESP command worker
 ↓
ACK
 ↓
terminal ON
```

Czyli dokładnie ten sam model, który już wykorzystujemy do sterowania
diagnostyką/komendami.

------------------------------------------------------------------------

# 22. ACK

Po włączeniu:

``` json
{
  "cmd": "terminal_on",
  "cmdId": 1842
}
```

ESP:

``` json
{
  "cmdId": 1842,
  "status": "OK",
  "terminal": true
}
```

Frontend pokazuje:

``` text
🟢 Terminal aktywny
```

Jeżeli ESP nie odpowie:

``` text
🔴 Brak ACK
```

To jest znacznie lepsze niż samo przełączenie przycisku w HTML.

------------------------------------------------------------------------

# 23. Sesja diagnostyczna

Bardzo dobry pomysł:

``` text
Terminal ON
     ↓
sessionId = 20260929_143201
```

Każdy chunk:

``` json
{
  "session": "20260929_143201",
  "seq": 17,
  "ts": 1790685125000,
  "text": "..."
}
```

Wtedy później wiadomo:

``` text
ten log pochodzi z jednej konkretnej sesji diagnostycznej
```

------------------------------------------------------------------------

# 24. Start sesji może zawierać snapshot

To byłaby bardzo przydatna rzecz.

Po:

``` text
TERMINAL ON
```

ESP może wysłać pierwszy specjalny chunk:

``` text
========== TERMINAL SESSION START ==========
FW: v3.31.19
Uptime: ...
WiFi: CONNECTED
RSSI: -79 dBm
Firebase: READY
Free heap: ...
PSRAM: ...
Telemetry: ...
Spool: ...
RTC: ...
============================================
```

Dzięki temu od razu wiemy, w jakim stanie urządzenie rozpoczęło
diagnostykę.

------------------------------------------------------------------------

# 25. Koniec sesji

Po OFF:

``` text
========== TERMINAL SESSION END ==========
duration: 00:17:42
bytes: 184203
chunks: 91
dropped: 0
firebaseErrors: 2
===========================================
```

To jest bardzo wygodne podczas analizy.

------------------------------------------------------------------------

# 26. Co z PANIC / WDT / resetem?

To osobny temat.

Live terminal nie gwarantuje zachowania logów, jeżeli ESP:

``` text
PANIC
WDT
brownout
reset
```

Dlatego warto rozdzielić:

## Live terminal

RAM → Firebase

oraz:

## Crash diagnostics

RTC/NVS/LittleFS → po następnym starcie Firebase.

To daje dwa kanały:

``` text
TERMINAL LIVE
      +
CRASH REPORT
```

To byłaby bardzo wartościowa rozbudowa diagnostyki.

------------------------------------------------------------------------

# 27. Szczególnie interesujący wariant: ostatnie N sekund

Możemy mieć ring buffer aktywny nawet wtedy, gdy terminal jest OFF, ale
**bez wysyłania do Firebase**.

Przykład:

``` text
RAM zawsze przechowuje ostatnie 30–60 sekund logów
```

Normalnie:

``` text
Firebase = OFF
```

Jeżeli wystąpi problem:

``` text
terminal ON
```

ESP może wysłać:

``` text
[HISTORIA PRZED WŁĄCZENIEM]
+ 
[NOWE LOGI]
```

To jest znacznie ciekawsze niż zwykły terminal.

Przykład:

``` text
14:31:30 Firebase OK
14:31:40 Firebase OK
14:31:50 timeout
14:31:55 timeout
14:32:00 terminal ON
```

Po włączeniu dostajemy również logi:

``` text
14:31:05 ...
14:31:10 ...
14:31:15 ...
...
14:32:00 ...
```

czyli możemy zobaczyć **co działo się przed problemem**.

------------------------------------------------------------------------

# 28. Ten wariant wymaga ograniczenia pamięci

Nie można trzymać wszystkiego.

Proponuję:

``` text
PREBUFFER:
32 KB
```

albo:

``` text
60 sekund
```

w zależności od rzeczywistego natężenia logów.

Dopiero po ON:

``` text
LIVE BUFFER:
64–128 KB
```

------------------------------------------------------------------------

# 29. Jeszcze ciekawszy wariant: automatyczny trigger

Można kiedyś zrobić:

``` text
jeżeli:
Firebase timeout > X
WDT event
telemetry error
spool error
WiFi reconnect
heap < threshold
```

to:

``` text
automatycznie zachowaj ostatnie N sekund
```

i wyślij diagnostykę po odzyskaniu Firebase.

To już byłby **system diagnostyczny**, a nie tylko terminal.

------------------------------------------------------------------------

# 30. Bezpieczeństwo

Terminal zawiera potencjalnie dużo informacji diagnostycznych.

Nie powinien być publiczny.

Firebase Rules powinny ograniczyć:

``` text
/piec/terminal/*
```

do autoryzowanego użytkownika.

Szczególnie ważne:

-   terminal READ --- tylko użytkownik,
-   terminal command WRITE --- tylko użytkownik,
-   urządzenie nie powinno przyjmować dowolnego tekstu jako polecenia,
-   komendy powinny mieć whitelistę.

------------------------------------------------------------------------

# 31. Proponowana architektura końcowa

``` text
                     ┌──────────────────────┐
                     │      ESP32-S3        │
                     │                      │
 Serial / ESP_LOG ──►│ Diagnostic Tee       │
                     │        │             │
                     │        ▼             │
                     │   RAM Ring Buffer    │
                     │        │             │
                     │        ├──► USB/UART │
                     │        │             │
                     │        ▼             │
                     │ Firebase Worker      │
                     └────────┬─────────────┘
                              │
                              │ chunks / 5 s
                              ▼
                     ┌──────────────────────┐
                     │    Firebase RTDB     │
                     │                      │
                     │ terminal/session     │
                     │ terminal/chunks      │
                     │ terminal/state       │
                     └────────┬─────────────┘
                              │
                              │ listener
                              ▼
                     ┌──────────────────────┐
                     │   Web App / HTML     │
                     │                      │
                     │      TERMINAL        │
                     │                      │
                     │ ON / OFF             │
                     │ clear                │
                     │ filters              │
                     │ download             │
                     └──────────────────────┘
```

------------------------------------------------------------------------

# 32. Moja propozycja dla tego projektu

Nie robiłbym od razu wszystkiego.

## Etap 1 --- bezpieczny rdzeń

``` text
1. RAM ring buffer
2. terminalEnabled
3. Firebase chunks
4. wysyłanie co 5 s
5. seq
6. dropped
7. ACK
8. zakładka Terminal
```

## Etap 2 --- jakość diagnostyki

``` text
9. sessionId
10. snapshot start
11. snapshot end
12. filtry INFO/WARN/ERROR/DEBUG
13. statystyki transmisji
```

## Etap 3 --- diagnostyka awarii

``` text
14. prebuffer 30–60 s
15. crash report
16. WDT/PANIC context
17. automatyczne capture przy błędach
```

------------------------------------------------------------------------

# 33. Parametry startowe, które warto przyjąć

  Parametr                                      Propozycja
  ----------------- --------------------------------------
  Firebase upload                                   co 5 s
  chunk target                                        4 KB
  chunk max                                           8 KB
  live RAM buffer                                   128 KB
  prebuffer                                          32 KB
  seq                                               uint32
  sessionId                                timestamp/nonce
  terminal OFF                                brak uploadu
  retry                   przez istniejący Firebase worker
  ACK                                             wymagany
  filtr domyślny                                      INFO
  historia RTDB               tylko aktywna/ostatnia sesja
  firmware            bez zmian poza warstwą diagnostyczną

------------------------------------------------------------------------

# 34. Co research potwierdził

### Potwierdzone przez dokumentację Espressif

1.  Możemy użyć `esp_log_set_vprintf()` jako punktu przechwytywania
    logów ESP-IDF.
2.  ESP-IDF ma natywny ring buffer.
3.  Ring buffer jest przeznaczony do danych o zmiennej długości i
    komunikacji między taskami.
4.  PSRAM może być używany przez capability allocator.
5.  ESP-IDF posiada poziomy logowania i możliwość zmiany poziomów
    runtime.

### Potwierdzone przez dokumentację Firebase

1.  RTDB obsługuje `set`, `update`, `push` i transakcje.
2.  Można nasłuchiwać zmian po stronie webowej.
3.  Firebase RTDB obsługuje streaming REST przez SSE.
4.  Firebase ma wystarczające limity dla tak małego kanału
    diagnostycznego.
5.  Firebase ma mechanizmy pracy z utratą połączenia po stronie
    klientów.

------------------------------------------------------------------------

# 35. Wniosek końcowy

**Pomysł jest wykonalny i dobrze pasuje do obecnej architektury.**

Najbardziej podoba mi się jednak nie wersja:

``` text
Serial → Firebase co 5 s
```

lecz:

``` text
                 NORMALNA PRACA
                       │
                       ▼
              RAM prebuffer
                       │
                       │
       ┌───────────────┴───────────────┐
       │                               │
   Terminal OFF                    Terminal ON
       │                               │
   brak Firebase                chunks co ~5 s
                                       │
                                       ▼
                                   Firebase
                                       │
                                       ▼
                                  Web Terminal
```

Dzięki temu możemy później zrobić coś jeszcze lepszego:

> **„Pokaż mi ostatnie 60 sekund przed awarią + wszystko od momentu
> włączenia diagnostyki."**

To byłoby szczególnie wartościowe przy zdalnym sterowniku oddalonym od
użytkownika.

------------------------------------------------------------------------

## Źródła

-   ESP-IDF Logging API --- `esp_log_set_vprintf()` i poziomy
    logowania:\
    https://docs.espressif.com/projects/esp-idf/en/v5.1.2/esp32/api-reference/system/log.html
-   ESP-IDF FreeRTOS ring buffers:\
    https://docs.espressif.com/projects/esp-idf/en/latest/esp32s2/api-reference/system/freertos_additions.html
-   ESP-IDF External RAM / PSRAM:\
    https://docs.espressif.com/projects/esp-idf/en/stable/esp32/api-guides/external-ram.html
-   Firebase RTDB --- odczyt i listenery web:\
    https://firebase.google.com/docs/database/web/read-and-write
-   Firebase RTDB --- zapis danych:\
    https://firebase.google.com/docs/database/admin/save-data
-   Firebase RTDB --- limity:\
    https://firebase.google.com/docs/database/usage/limits
-   Firebase RTDB REST --- streaming/SSE:\
    https://firebase.google.com/docs/reference/rest/database

------------------------------------------------------------------------

## Status research

**Koncepcja: wykonalna.**

**Rekomendowany kierunek:**\
`Diagnostic Tee → RAM/PSRAM Ring Buffer → istniejący Firebase Worker → RTDB chunks → Firebase listener → zakładka Terminal`

**Firmware v3.31.19:** baza pozostaje bez zmian funkcjonalnych do czasu
zaprojektowania i przetestowania osobnego modułu diagnostycznego.
