# PIECO / Piec_CO — MASTER STATE — 2026-09-27

## 1. Stan produkcji
- Produkcyjny sterownik / piec pozostaje na **v3.19.2**.
- Na produkcji obowiązuje wyłącznie **OTA**.
- Nie wykonywać USB na prawdziwym sterowniku.
- Nie wdrażać żadnego z buildów laboratoryjnych v3.20.x/v3.21.x/v3.22.x na produkcję bez osobnej decyzji i pełnej walidacji.

## 2. Ostatni stan testów Spool V2
- R242/R243 — PASS
- R244 — PASS — format freeze
- R245 — PASS — pierwszy zapis + verify
- R246 — PASS — open page recovery
- R247 — PASS — rzeczywisty power-loss recovery na płytce testowej
- R248 — PASS — recovery + odrzucenie 40 B ogona + continuation
- R249 — PASS — pełna strona 768 rekordów, 64640 B, CRC/page/footer
- R250 — PASS — uszkodzony rekord CRC odrzucony
- R251 — PASS — hard quota boundary
- R252 — przygotowany jako mirror realnej telemetrii; osobny etap wymagający 3 rzeczywistych próbek
- R253–R262 — PASS — batch
- R263–R272 — PASS — batch2

## 3. Wyniki R253–R262
R253 PASS OK
R254 PASS size=262 records=2 tail=30
R255 PASS pageSeq=2551,2552,2553
R256 PASS badRecord=2 validPrefix=1
R257 PASS headerCRC=FAIL rejected
R258 PASS footerCommit=FAIL rejected
R259 PASS recordCRC=OK pageCRC=FAIL
R260 PASS page1=768 page2=1 seq-contiguous
R261 PASS .part verified -> rename -> final verified
R262 PASS usedDelta=4096 min=2816 protected=5141736

## 4. Wyniki R263–R272
R263 PASS first=0xF2630001 last=0xF2630004 count=4
R264 PASS duplicateSeq=0xF2640001 badRecord=2 validPrefix=1
R265 PASS footerRecordCount=5 expected=4 rejected
R266 PASS footerPageSeq=9999 headerPageSeq=266 rejected
R267 PASS footer first/last mismatch rejected
R268 PASS size=297 trailing=1 rejected
R269 PASS bad .part rejected; final pageSeq=2690 preserved
R270 PASS sampleABI=80B byteExact=YES recordCRC=OK
R271 PASS qualityBits=0xA5A55A5A simulatedBits=0x0555 ageS=100..110 preserved
R272 PASS records=768 first=0xF2720001 last=0xF2720300 size=64640 footer=OK

## 5. Frozen spool geometry / ABI
TelemetrySample ABI: 80 B.
Record: 84 B = sample 80 B + CRC32 4 B.
Page metadata: header 64 B + footer 64 B.
Page: 64 KiB.
Safe records: 768.
Safe page used: 64640 B.
Slack at safe capacity: 896 B.
Coverage at 1 sample/min: 12 h 48 min.
Max mathematical record count in 64 KiB page: 778; safe frozen count is 768.

Frozen fields/contracts:
- header CRC
- per-record CRC
- page CRC
- footer commit marker
- open page is recoverable without footer
- incomplete tail is rejected/discarded during recovery
- duplicate sequence is rejected
- invalid header/footer/page CRC causes rejection
- .part must be verified before rename; bad .part must not replace final
- physical LittleFS usedBytes() is quota source; logical accounting is diagnostic

## 6. Filesystem / quota hardening
F2 / Commit F work completed through hard quota:
- physical accounting proved
- FsUsageSnapshot implemented
- quota shadow tested
- dynamic reserve diagnostic prepared/tested
- panel firmware contract: max 2 MiB
- hard quota boundary R251 PASS

Current known model from previous stages:
- physical total around 10,354,688 B on test board
- coredump reserve 20 x 64 KiB = 1,310,720 B
- physical used/free/total are authoritative for quota
- logical bytes are diagnostic only

## 7. Firmware / production history
v3.18.0 decoupled tgTask/tgPollTask from per-task TWDT.
v3.18.1 fixed post-unsubscribe esp_task_wdt_reset() calls; local R224 showed TASK_WDT=0 and task-not-found=0.
v3.18.1 local offline-buffer test R225 had no reset/WDT/PANIC and telemetry_drop=0.
v3.19.2 is current production candidate and production version.
v3.19.4 local testcrash-once + NVS update_id persistence was validated; production stayed v3.19.2.

## 8. R279 — current interruption point
The user reported:
- the R279 build **did upload successfully** locally;
- then there was **no Telegram response**.

Immediately before that, the compiler had shown a syntax error in:
`spoolR279CommitOnlyAtTarget(String&)`
with:
`const sizeAfter3 = mid ? mid.size() : 0U;`
which was invalid because the type was missing.
A fix was prepared for that local compile issue. The user then said **"wgralo sie"**.

Important: there is currently no confirmed Telegram diagnostic after upload, and no trustworthy evidence here yet whether the no-response is due to boot failure, Telegram task failure, command handler issue, Wi-Fi, or another runtime condition. Do not infer the cause.

Also important: a separately saved R279 source/patch artifact was not found in /mnt/data inventory at handoff time. The package therefore contains all artifacts that are actually present, but not a fictional R279 source.

## 9. R252 status
R252 is a separate local mirror test for real telemetry. It was prepared to arm from Telegram and mirror 3 subsequent TelemetrySample values from historiaZapiszProbke(). Final PASS has not been reported in the current handoff context.

## 10. Rules for continuation
- Real production remains v3.19.2.
- All new spool/integration builds stay local until separately validated.
- Do not use USB on production.
- Prefer batch tests over one-test-per-build when possible.
- Do not create another test merely for vanity coverage; focus next on real telemetry -> durable spool -> retry/ACK/commit behavior.
- Before any production OTA, require a clearly documented release candidate, local build/pass, and production-safe rollback path.

## 11. Files in transfer package
See:
- `TRANSFER_INDEX.txt`
- `TRANSFER_SHA256.txt`
- complete ZIP archive of all current /mnt/data artifacts.

