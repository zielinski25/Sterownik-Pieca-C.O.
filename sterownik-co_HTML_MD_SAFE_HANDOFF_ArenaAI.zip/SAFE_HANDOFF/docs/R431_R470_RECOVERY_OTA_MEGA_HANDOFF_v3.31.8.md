# R431-R470 RECOVERY / OTA / FS / BOOT MEGA — v3.31.8

## Cel
Jedna duza komenda testowa dla lokalnej plytki testowej. Pakiet nie flashuje OTA, nie wykonuje rebootu i nie generuje celowego crasha.

## Zakres
- wersja firmware i gotowosc LittleFS
- tymczasowy write/read/delete na LittleFS
- hard/dynamic quota snapshot
- coredump discovery/existence/size
- running/boot OTA partition oraz zgodnosc
- bezpieczny odczyt stanu OTA
- aktywny verifyRollbackLater()
- boot counter, RTC crash diagnostics i crash queue
- potwierdzenie braku operacji flash/reboot
- runtime health Firebase/telemetry/Telegram
- heap/largest block
- regresja producer/replay/fault/Commit G/H1/H2/RTDB

## Komenda
Tylko na lokalnej plytce testowej:

```text
/version
/recoverymega TAK
```

## Oczekiwany koniec
`R431-R470 recovery OTA mega batch: PASS` oraz `R470:PASS RECOVERY-OTA-MEGA overall=PASS`.

## Bezpieczenstwo
Produkcja v3.19.2 pozostaje nietykana. Ten batch nie wykonuje flashowania OTA ani resetu.

## SHA256
Firmware SHA256 jest w `R431_R470_SHA256_MANIFEST_v3.31.8.txt`.
