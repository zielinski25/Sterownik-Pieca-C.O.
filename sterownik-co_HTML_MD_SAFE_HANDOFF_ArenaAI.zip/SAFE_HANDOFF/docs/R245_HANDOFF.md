# R245 HANDOFF

## Stan
R244 format freeze = PASS.
R245 = READY, local-only.

## Firmware
v3.20.3
`main_centrala_v3.20.3_LOCAL_SPOOL_WRITE_RECOVERY.cpp`

## Bezpieczeństwo
Prawdziwy piec: v3.19.2.
Żadnego OTA v3.20.x.

## Procedura
Build `esp32-s3-n16r8` + `esp32-s3-ota`; USB upload tylko na pustą płytkę.
Następnie:
`/spooltest TAK`
`/spoolverify`

Oczekiwane: testowy plik 800 B, 8 rekordów, commit footer, wszystkie CRC OK.
