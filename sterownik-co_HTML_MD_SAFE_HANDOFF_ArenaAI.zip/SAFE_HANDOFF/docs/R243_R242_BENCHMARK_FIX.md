# R243 — R242 benchmark fix

## Wynik

Build v3.20.0 zatrzymał się na static_assert:

```text
expected: 779
actual:   778
```

To nie jest błąd implementacji kalkulatora. Błąd był w wartości oczekiwanej testu.

## Matematyka

```text
page = 64 KiB = 65536 B
header + footer = 128 B
record = TelemetrySample 80 B + CRC32 4 B = 84 B

payload area = 65536 - 128 = 65408 B
65408 / 84 = 778 remainder 56
```

Zatem:

```text
MAX_64K = 778 rekordów
```

Przy 779 rekordach byłoby:

```text
128 + 779 * 84 = 65564 B
```

czyli o 28 B za dużo.

## Pozostałe benchmarki

```text
32 KiB -> 388 rekordów
48 KiB -> 583 rekordy
64 KiB -> 778 rekordów
```

Bezpieczny wariant pozostaje:

```text
64 KiB
768 rekordów
64640 B użyte
896 B slack
12 h 48 min nominalnego pokrycia
```

## Zmiana

Tylko:

```text
FIRMWARE_VERSION: v3.20.0 -> v3.20.1
static_assert 64K: 779 -> 778
changelog: opis korekty
```

Brak zmian w:

```text
Firebase
TelemetryRing
LittleFS
automatyce
coredump
OTA
```

## Gate

R242 pozostaje OPEN do czasu kompilacji v3.20.1 i odczytu 2–3 raportów `/telemetry`.
