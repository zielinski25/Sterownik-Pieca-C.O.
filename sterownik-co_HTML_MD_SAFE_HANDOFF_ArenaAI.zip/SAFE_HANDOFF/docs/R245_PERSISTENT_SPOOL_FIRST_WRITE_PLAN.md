# R245 — Persistent Spool V2: pierwszy rzeczywisty zapis + verify

Data: 2026-09-27
Status: READY — LOCAL ONLY

## Cel
Wykonać pierwszy kontrolowany zapis strony Spool V2 do LittleFS oraz niezależny odczyt/weryfikację.

## Zakres
- tylko pustą płytka testowa;
- brak zmiany normalnej ścieżki telemetryki V1;
- brak integracji spool z Firebase;
- brak power-loss w tym kroku;
- brak `/testcrash`;
- prawdziwy piec pozostaje na v3.19.2.

## Plik testowy
`/telemetry_spool/r245_test_page.bin`

Nie jest to jeszcze produkcyjna kolejka `page_*.bin`.

## Format
- HEADER 64 B
- RECORD 84 B = TelemetrySample 80 B + CRC32 4 B
- FOOTER 64 B
- commit = footer z poprawnym CRC i `commitMarker`
- test zapisuje 8 kontrolowanych rekordów

Oczekiwany rozmiar pliku:
`64 + 8*84 + 64 = 800 B`

## Testy
1. `/spooltest TAK`
   - sprawdzenie hard quota;
   - utworzenie `/telemetry_spool`;
   - zapis headera;
   - zapis 8 rekordów z CRC;
   - zapis footera/commit;
   - close;
   - reopen;
   - kontrola finalnego rozmiaru.
2. `/spoolverify`
   - reopen;
   - kontrola header CRC;
   - kontrola każdego record CRC;
   - kontrola page CRC;
   - kontrola footer CRC + commit marker;
   - kontrola liczby rekordów.

## PASS
- oba polecenia zwracają PASS;
- plik ma 800 B;
- 8/8 rekordów przechodzi CRC;
- footer commit OK;
- brak restartu/WDT/PANIC;
- normalna telemetria V1 pozostaje bez zmian.

## Następny etap po PASS
R246 — kontrolowany test strony otwartej/niezamkniętej i recovery, a następnie osobno power-loss.
