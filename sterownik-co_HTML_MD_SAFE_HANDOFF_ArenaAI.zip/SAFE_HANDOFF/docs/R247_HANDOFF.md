# HANDOFF R247

Stan przed testem:
- R242/R243 benchmark PASS
- R244 format freeze PASS
- R245 complete page write+verify PASS
- R246 open-page recovery PASS
- Produkcja: v3.19.2 bez zmian

Artefakt lokalny:
- `main_centrala_v3.20.6_LOCAL_R247_POWERLOSS_RECOVERY.cpp`

Test:
- `/spool247 TAK`
- fizyczne odciecie zasilania w oknie 15 s
- po restarcie `/spool247recover`

Cel recovery:
- header CRC OK
- >=2 pelne rekordy CRC OK
- footer ABSENT
- tail <84 B
- open=RECOVERABLE

Nie OTA produkcji.
