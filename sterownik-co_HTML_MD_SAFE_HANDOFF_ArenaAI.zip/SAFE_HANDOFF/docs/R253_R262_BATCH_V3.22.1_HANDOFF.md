# R253-R262 — v3.22.1 BUILD FIX HANDOFF

## Problem
v3.22.0 failed to compile because R252/R253-R262 referenced `TelemetrySample` and R245 helper functions before their declarations.

## Fix
- forward declaration `struct TelemetrySample;` before the early R252 prototype;
- forward declarations for `spoolR245Crc32`, `spoolR245HeaderCrc`, `spoolR245FooterCrc`, `spoolR245BuildSample` after the SpoolPage types are complete;
- `FIRMWARE_VERSION` bumped to v3.22.1.

## Scope
LOCAL ONLY. Production remains v3.19.2. Do not OTA this build to the real controller.

## Test
1. Replace local `src/main_centrala.cpp` with v3.22.1 source.
2. Build `esp32-s3-n16r8`.
3. Upload only to the empty/test ESP32-S3 board.
4. Run `/spoolbatch TAK`.

R252 remains separate and should be run only with `/spool252 TAK` + `/spool252verify` because it waits for 3 real telemetry samples.
