# R245 — R242 compile fix

## Problem
Build zatrzymał się w `pollTelegramCommands()` na komunikacie dla `/spooltest`.

Błędny literal:

```cpp
F("R245: wpisz "/spooltest TAK" aby zapisac kontrolowana strone Spool V2 na LittleFS.")
```

Podwójne cudzysłowy zakończyły string wcześniej, dlatego kompilator potraktował `spooltest` jako identyfikator C++.

## Fix

Komunikat uproszczono do:

```cpp
F("R245: wpisz /spooltest TAK aby zapisac kontrolowana strone Spool V2 na LittleFS.")
```

Brak zmian w logice zapisu, CRC, header/footer, commit ani recovery.

## Status

**FIX READY — brak runtime PASS tej poprawki w tym środowisku.**

Po poprawionym buildzie wykonać lokalnie:

```text
Build esp32-s3-n16r8
Build esp32-s3-ota
USB upload na pustą płytkę
/spooltest TAK
/spoolverify
```
