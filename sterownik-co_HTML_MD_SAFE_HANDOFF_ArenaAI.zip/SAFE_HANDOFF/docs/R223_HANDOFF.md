# ESP32 CENTRALA — HANDOFF R223
Data: 2026-09-26

## Aktualny punkt startowy
- Firmware testowany: **v3.18.0**.
- Build obu env: PASS.
- R223 runtime na pustej płytce: **W TOKU**.
- Cel: potwierdzić usunięcie resetów TASK_WDT z `tgTask` / `tgPollTask`.

## Co już działa i było testowane
1. TelemetrySample 80 B + freshness sidecar.
2. PSRAM SPSC TelemetryRing 1440 x 80 B.
3. Firebase batch writer z ACK -> commit tail.
4. Na pustej płytce RTDB przyjmuje rekordy pod `/piec/telemetry/1m/v1`.
5. `age=65535` jest oczekiwane bez podłączonych czujników.

## Problem wykryty w v3.17.0
Coredumpy 11–16 pokazały TASK_WDT podczas blokujących operacji:
- Open-Meteo HTTP GET;
- Telegram TLS connect;
- Firebase send.

## v3.18.0
Zmiana wyłącznie network/WDT:
- brak per-task TWDT dla `tgTask` i `tgPollTask`;
- heartbeat/state workerów w HEALTH-A;
- bez zmian w telemetryce i sterowaniu.

## Operator teraz
1. Dokończyć bieżący capture R223 (~30 min).
2. ENTER w R188.
3. Przekazać ZIP.
4. Nie wgrywać niczego przed analizą wyniku.

## Reguła
Nie uznawać R223 za PASS bez sprawdzenia całego capture, nawet jeżeli w trakcie nie było widocznego resetu.
