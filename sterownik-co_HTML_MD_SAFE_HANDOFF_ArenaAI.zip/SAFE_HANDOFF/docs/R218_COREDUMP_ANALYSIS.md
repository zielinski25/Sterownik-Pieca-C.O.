# R218 — analiza runtime v3.15.1 / coredump

Data: 2026-09-26
Firmware analizowany: v3.15.1 (Commit B)

## 1. Klasyfikacja

- BUILD: PASS
- RUNTIME: FAIL
- Commit B: BLOCKED — nie przechodzimy jeszcze do TelemetryRing
- Gate A-0: YELLOW

## 2. Materiał

Sesja: R188_20260925_233448
T0: 2026-09-25 23:34:48.975
T1: 2026-09-26 00:00:10.372
Czas sesji: ok. 25 min 21 s
HEALTH: 50

Dostępne coredumpy:
- boot2 / seq8: 39460 B
- boot3 / seq9: 34276 B
- boot4 / seq10: 34020 B

Firmware ELF SHA-256:
631354d607374a0206988b4a67bf334c6afd9bf46bb6a9b0541bdb0c86972652

W każdym coredumpie ESP_CORE_DUMP_INFO wskazuje ten sam prefiks SHA aplikacji: 631354d60, zgodny z dostarczonym firmware.elf.

## 3. WDT — wynik z coredumpów

Wszystkie trzy coredumpy mają ESP_PANIC_DETAILS:

Task watchdog got triggered. The following tasks/users did not reset the watchdog in time:
 - tgTask (CPU 0)

Czyli we wszystkich trzech awariach watchdog wskazał tgTask na CPU0.

## 4. Lokalizacja ostatniego checkpointu

BOOT 2 / seq8:
- tgTask: FB_CMD BEFORE, up_ms=589094
- WDT log: 622771 ms
- różnica: 33677 ms

Interpretacja: tgTask wszedł w ścieżkę checkFirebaseCommands() i nie wrócił do checkpointu AFTER przed WDT.

BOOT 3 / seq9:
- tgTask: TG_CONNECT BEFORE, up_ms=17981
- WDT log: 49598 ms
- różnica: 31617 ms

BOOT 4 / seq10:
- tgTask: FB_CMD BEFORE, up_ms=14115
- WDT log: 44338 ms
- różnica: 30223 ms

## 5. Najważniejszy wniosek

TelemetrySample / snapshot / TelemetryRing nie są bezpośrednim źródłem tych resetów:

- telemetry_produced=0 przez całą sesję,
- TelemetryRing nie jest jeszcze zaimplementowany,
- watchdog wskazuje tgTask, nie historiaTask,
- checkpointy awarii leżą w istniejących ścieżkach Firebase/Telegram.

Nie wolno więc przypisać tej awarii Commit B telemetrycznemu modelowi danych.

## 6. Podejrzana wspólna klasa problemu

Istniejące firmware wykonuje blokujące operacje sieciowe w tgTask. Kod ma limity dla części oczekiwania, ale same wejścia do niektórych operacji sieciowych mogą nadal wykonać blokujące connect()/TLS/I/O zanim sterowanie wróci do kodu, który regularnie karmi WDT.

Pierwsza i trzecia awaria są w FB_CMD. Druga jest w TG_CONNECT; log pokazuje, że nastąpiła podczas serii prób Telegrama po restarcie i obsługi odroczonego crash-reportu.

To wskazuje na problem warstwy network/Firebase/Telegram + WDT budgeting, który istniał poza telemetryką i został ujawniony w tej sesji.

## 7. Dodatkowe obserwacje

- heap pozostaje rzędu ~100–115 kB po restartach; brak dowodu klasycznego wycieku heap.
- PSRAM pozostaje około 6.8–6.96 MB; brak dowodu wyczerpania PSRAM.
- po serii trzech resetów urządzenie później pracuje dalej; problem nie jest ciągłym crash loop przez cały capture.
- w logu występują błędy TLS oraz timeouty Firebase: FB-SEND ~6025 ms, FB-CMD ~5020 ms.
- w jednym momencie HEALTH-A pokazuje fb_tasks=2, co potwierdza obecność porzuconego/jeszcze pracującego workera Firebase w trakcie problemu.

## 8. Decyzja R218

STOP. Nie wgrywać kolejnego firmware.
Nie implementować TelemetryRing.
Nie zwiększać timeoutu WDT jako „naprawy”.

Najpierw poprawić istniejącą ścieżkę blokującego network I/O tak, aby tgTask nie mógł przekroczyć okna TWDT niezależnie od awarii sieci.

Następny patch powinien być osobnym etapem stabilizacji network/WDT, bez zmian TelemetrySample i bez Firebase telemetry endpoint.
