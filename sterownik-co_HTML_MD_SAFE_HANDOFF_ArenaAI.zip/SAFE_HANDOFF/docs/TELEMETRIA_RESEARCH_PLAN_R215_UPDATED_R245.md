# TELEMETRIA RESEARCH PLAN — UPDATED TO R245

## Current implementation state
R1–R244 previous history remains valid.

### Storage gates
- F1: PASS
- F2.1: PASS
- F2.2: PASS
- F2.3: PASS
- F2.5: PASS
- F2.6: pending runtime evidence for v3.19.8
- F2.7: PASS
- F2.8: PASS
- R242/R243 benchmark: PASS
- R244 format freeze: PASS
- R245 first real write/verify: READY

## V2 page contract
- 64 KiB page
- 64 B header
- 84 B record
- 64 B footer
- 768 safe records
- 8-record local test in R245
- no normal V1 integration yet

## R245 boundary
This step verifies the application-level format on LittleFS. It does not prove power-loss durability. Power-loss remains a separate gate.

## Important invariant
Persistent spool must have a hard quota and must not consume protected coredump/log space.
